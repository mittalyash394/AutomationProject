                                REST ASSURED - API automation framework 

 This is a Java-based framework for testing RESTful APIs using the Rest Assured library
 and Cucumber. Cucumber is a BBD(Behavior Driven Development) based framework.
 REST Assured : REST Assured is a Java library that provides a domain-specific language (DSL) for writing powerful,
 maintainable tests for RESTful APIs
 BBD framework:Behavior Driven Development is a software development approach that allows to create test cases in simple text language (English).
 
 Quick Start
 - Java
 - IntelliJ IDE
 - Maven
 - BBD
 
 How to set up Project
 * take a pull from main branch
 * Update the maven project
 * add maven dependency if required
 * add user credentials in configration.properties file
 * go to the test runner file and run the file
 
 Project Structure
 * src
     - main
     - java
         - api // API-related classes and utilities
         - common // Common utilities and helpers
     - test
         - java
             - baseBuilder // Environment setup init & Hooks
             - features // Feature files written in Gherkin syntax
             - stepdefinitions // Step definitions corresponding to feature files
             - testRunner // For executing feature and stpe-definition
             - utility // Utility classes and helpers for tests
                 - CommonStep // Contain all common steps
                 - GlobalConstant // contain HTTPS code and in-app URLs
                 - JSONPayload // Request HashMap
                 - PropertyReader // Configuration reader
                 - Utils // Common utilities and helpers
             - configuration.properties // Contain HOST and Test data
             - NYE-APIAutomation.yml // CI-CD AWS pipeline
             - env.json // Runtime execution
 
 Getting Started
 * To create a REST Assured + BDD-based test automation framework, follow these steps:
     - Set up a new Java project or add the framework to an existing project
     - Add the necessary dependencies in your build configuration file (e.g., Maven):
         - REST Assured: io.rest-assured:rest-assured:<version>
         - BDD Framework (e.g., Cucumber): io.cucumber:cucumber-java:<version>
         - Other dependencies (e.g., logging, assertions, reporting).
     - Create the project structure as outlined in the "Project Structure" section.
 
 Writing Tests
 * Follow these guidelines when writing tests in the framework:
     - Create feature files in the features directory using the Gherkin syntax. Feature files should have a .feature extension.
     - Write scenarios in the feature files, describing the behavior to be tested using Given-When-Then steps.
     - Implement step definitions for the scenarios in the stepdefinitions directory. These step definitions should map to the Given-When-Then steps in the feature files.
     - Use REST Assured's fluent API within step definitions to send requests, validate responses, and perform assertions. 