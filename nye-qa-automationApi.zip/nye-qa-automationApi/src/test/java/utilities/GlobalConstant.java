package utilities;

import java.net.URI;

public class GlobalConstant {
    public static final int HTTP_OK = 200;
    public static final int HTTP_CREATED = 201;
    public static final int HTTP_BAD_REQUEST = 400;
    public static final int HTTP_UNAUTHORIZED = 401;
    public static final int HTTP_INTERNAL_SERVER_ERROR = 500;
    public static final int HTTP_NOT_FOUND = 404;
    public static final int HTTP_FORBIDDEN = 403;
    public static final int HTTP_SERVICE_UNAVAILABLE = 503;
    public static final int NO_CONTENT = 204;

    public static final int REQUESTED_RESOURCE_LCOKED = 423;

    public final static String encryptDataURL = "/auth/api/v1/test/encrypt";
    public final static String mobileLoginURL = "/auth/api/v1/access/mobile/login";
    public final static String pandingMandateURL = "/mandate/api/v1/pending-mandate-list";
    public final static String createMandateURL = "/mandate/api/v1/create-mandate";
    public final static String createSIMandateURL = "mandate/api/v1/create-payer-mandate";
    public final static String approveMandateURL = "/mandate/api/v1/authorize-mandate";
    public final static String getMandateByEnumURL = "/mandate/api/v1/get-mandate";
    public final static String getModifyMandateURL = "/mandate/api/v1/modify-mandate";
    public final static String getMandateByIdURL = "mandate/api/v1/get-mandate-by-id";
    public final static String verifyUPIURL = "wallet/api/v1/verify-upi";
    public final static String verifyUPIByRequestIdURL = "wallet/api/v1/verify-upi-by-request-id";
    public final static String payApiURL = "wallet/api/v1/pay";
    public final static String getBalanceURL = "wallet/api/v1/balance";
    public final static String vpaCheckURL = "wallet/api/v1/vpa-check";
    public final static String checkRuleApiURL = "wallet/api/v1/check-rule";

    public final static String verifyIFSCCodeURL = "wallet/api/v1/search-by-ifsc";
    public final static String addBeneficiaryURL = "wallet/api/v1/beneficiary";

    public final static String getAllBeneficiaryURL = "wallet/api/v1/all-beneficiary";
    public final static String transactionChargeURL = "wallet/api/v1/transaction-charge";
    public final static String payByRequestIdURL = "wallet/api/v1/pay-by-request-id";
    public final static String deleteBeneficiaryURL = "wallet/api/v1/beneficiary";
    public final static String sendCollectRequestURL = "wallet/api/v1/collect-pay";
    public final static String pendingTransactionURL = "wallet/api/v1/pending-transaction";
    public final static String cashLoadingAdminLoginURL = "access-management/api/v1/provideCred";
    public final static String cashLoadingPaymentURL = "tm2/api/v1/cico/confirm-payment";

    public final static String adminLoginURL = "admin-auth/api/v1/login";
    public final static String reconReversalURL = "/tm2/api/v1/recon/recon-reversal";
    public final static String sendCardTransactionOtpURL = "cms/api/v1/send-transaction-otp";
    public final static String payCardURL = "cms/api/v1/pay-card";
    public final static String generateSmsStringEndpoint = "/auth/api/v1/mobile/sign_up/generate_sms_string";

    public final static String verifyPasswordEndpoint = "/auth/api/v1/recovery/password_verification";


    public final static String sendEmailEndpoint = "/auth/api/v1/mobile/sign_up/send_email_verification";

    public final static String jsonStringAPI = "/casa/casamanager/api/v1/non-prod/jsonString";
    public final static String encryptionAPI = "/casa/casamanager/api/v1/non-prod/encrypt";

    public final static String panValidation = "/casa/casamanager/api/v1/pan-validation";
    public final static String setPasswordEndpoint = "/auth/api/v1/mobile/sign_up/set_password";
    public final static String setPasscodeEndpoint = "/auth/api/v1/mobile/sign_up/set_passcode";
    public final static String authDeleteEndpoint = "/auth/api/v1/test/delete";
    public final static String authDeleteUserCacheEndpoint = "auth/api/v1/test/deleteCache";

    public final static String activeSubscription = "/casa/casamanager/api/v1/active-subscription";

    public final static String sendSmsEndpoint = "/messaging/api/v1/send_sms";

    public final static String SendEmailMessagingEndpoint = "/messaging/api/v1/send_email";

    public final static String getKeyIdentityEndpoint = "/auth/api/v1/access/get_key";

    public final static String getNonceEndpoint = "/auth/api/v1/mobile/get_nonce";
    public final static String getDeviceDetailsEndpoint = "/auth/api/v1/mobile/get/device_details";
    public final static String getUserInfoEndpoint = "/auth/api/v1/access/user_info";
    public final static String pinCodeAPI = "/casa/casamanager/api/v1/pincode-meta";

    public final static String createWallet = "/wallet/api/v1/create";
    public final static String recoverPasswordEndpoint = "/auth/api/v1/recovery/recover_passcode";
    public final static String updateDeviceDetailsEndpoint = "/auth/api/v1/update/device_details";
    public final static String verifySmsStringEndpoint = "/auth/api/v1/mobile_webhooks/sign_up/verify_sms_string";
    public final static String mobileNumberVerificationStatusEndpoint = "/auth/api/v1/access/mobile_number_verification_status";

    public final static String generateSmsStringRecoveryEndpoint = "/auth/api/v1/reset/mobile/generate_sms_string";
    public final static String resetPasswordEndpoint = "/auth/api/v1/reset/password";
    public final static String resetPasscodeEndpoint = "/auth/api/v1/reset/passcode";
    public final static String verifyPasswordAfterLoginEndpoint = "/auth/api/v1/access/verify_password";
    public final static String changePasswordEndpoint = "/auth/api/v1/update/password";
    public final static String verifyPasscodeAfterLoginEndpoint = "/auth/api/v1/access/verify_passcode";
    public final static String changePasscodeEndpoint = "/auth/api/v1/update/passcode";

    public final static String saveCommunicationAddressAPI = "/casa/casamanager/api/v1/save-communication-address";

    public final static String checkAvailableProducts = "/casa/casamanager/api/v1/check-available-products";

    public final static String deleteVCWalletEndpoint = "/wallet/api/v1/all-data";

    public final static String ckycsecuredsearchloginEndpoint = "/ckyc/api/v1/secured-search";

    public final static String ckycsecureddownloadEndpoint = "/ckyc/api/v1/secured-download";

    public final static String performckycEndpoint = "/ckyc/api/v1/perform-ckyc";
    public final static String initPaymentEndpoint = "/payments/api/v1/manager/internals/init";

    public final static String getMenuMeta = "grievance/api/v2/getMenuMeta";

    public final static String getIssueMetaForNyeAccounts = "grievance/api/v2/getIssueMeta";

    public final static String getScreenOptionsMeta = "grievance/api/v2/getScreenOptionsMeta";

    public final static String raiseIssue = "grievance/api/v2/raiseIssue";
    public final static String getUserTickets = "grievance/api/v2/getUserTickets";

    public final static String updateTicket = "grievance/api/v2/updateTicket";

}
