package utilities;

import base.BaseBuilder;
import io.restassured.RestAssured;
import io.restassured.authentication.PreemptiveBasicAuthScheme;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import org.json.JSONArray;
import org.json.simple.JSONObject;
import org.junit.Assert;
import resources.*;

import java.io.FileNotFoundException;
import java.sql.*;
import java.util.ArrayList;
import java.util.HashMap;

import static io.restassured.RestAssured.given;
import static io.restassured.RestAssured.requestSpecification;
import static utilities.GlobalConstant.*;
import static utilities.JSONPayload.*;
import static utilities.Utils.*;

public class CommonStepDef {
    private static RequestSpecification reqspec;
    private static Response res;
    private static org.json.JSONObject responseObject;

    private static final BaseBuilder baseBuilder = new BaseBuilder();
    private static final PropertyReader reader = new PropertyReader();

    public static Response login(String mobileNumber, String passcode, String deviceId,String newDeviceId) throws FileNotFoundException {
        JSONObject jsonObject = new JSONObject();
        String deviceAndUnixTime = deviceId + "," + getUnixTime();
        String loginDetails = getEncryptedAuthData("{   \"mobileNumber\": \"" + mobileNumber
                + "\",   \"passcode\": \"" + passcode + "\",   \"deviceId\": \"" + deviceAndUnixTime + "\" , \"newDeviceId\": \"" +newDeviceId +"\" }");
        jsonObject.put("loginDetails", loginDetails);
        reqspec = new BaseBuilder().placeSpecBuilder();
        reqspec = RestAssured.given().spec(reqspec).body(jsonObject.toJSONString());
        res = reqspec.post(GlobalConstant.mobileLoginURL).then().extract().response();
        if (res.getStatusCode() != HTTP_OK) {
            System.out.println(res.asPrettyString());
        }
        return res;
    }

    public static String stringToJsonString(String payloadForPanValidation) throws FileNotFoundException {
        reqspec = baseBuilder.placeSpecBuilder();
        Response response = given()
                .spec(reqspec)
                .body(payloadForPanValidation)
                .post(GlobalConstant.jsonStringAPI);

        System.out.println("The response is " + response.body().asString());

        return Utils.stringToJsonString(response, "results");
    }

    public static String encryption(HashMap<String, String> data) {
        Response responseForEncryption = given()
                .spec(reqspec)
                .body(data)
                .post(GlobalConstant.encryptionAPI);

        String resultsForEncryption = Utils.encryption(responseForEncryption, "results");
        System.out.println("The results for encryption is " + resultsForEncryption);
        return resultsForEncryption;
    }

    public static Response verifyUPI(String vpa, String accessToken) throws FileNotFoundException {
        HashMap<String, Object> verifyUPIPayload = createTwoParameterWithLocation("vpa", vpa, "location");
        reqspec = baseBuilder.placeSpecBuilder();
        reqspec = reqspec.header("Authorization", "Bearer " + accessToken);
        reqspec = RestAssured.given().spec(reqspec).body(verifyUPIPayload);
        res = reqspec.post(GlobalConstant.verifyUPIURL);
        return res;

    }

    public static Response verifyByRequestId(String requestId, String accessToken,boolean isExternalVpa) throws FileNotFoundException, InterruptedException {
        HashMap<String, Object> verifyByRequestIdPayload = JSONPayload.createOneParameterPayload("requestId", requestId);
        reqspec = baseBuilder.placeSpecBuilder();
        reqspec = reqspec.header("Authorization", "Bearer " + accessToken);
        reqspec = RestAssured.given().spec(reqspec).body(verifyByRequestIdPayload);
        if(isExternalVpa){
            Thread.sleep(5000);
        }
        res = reqspec.post(GlobalConstant.verifyUPIByRequestIdURL);
        //Thread.sleep(10000);
        return res;

    }

    public static Response pay(Payee payee, Payer payer, String transTypeEnum, String accessToken) throws FileNotFoundException {
        HashMap<String, Object> payload = JSONPayload.getPayApiPayload(payee, payer, transTypeEnum);
        System.out.println(payload);
        reqspec = baseBuilder.placeSpecBuilder();
        reqspec = reqspec.header("Authorization", "Bearer " + accessToken);
        reqspec = RestAssured.given().spec(reqspec).body(payload);

        if (transTypeEnum!= null && (transTypeEnum.equalsIgnoreCase("COLLECT_WALLET_TO_OTHER_WALLET"))) {
            res = reqspec.post(sendCollectRequestURL);
        } else {
            res = reqspec.post(GlobalConstant.payApiURL);
        }
        return res;
    }

    public static Response upiPayByRequestId(String requestId, String accessToken,boolean isExternalVpa) throws InterruptedException {
        HashMap<String, Object> payload = createOneParameterPayload("requestId", requestId);
        reqspec = reqspec.header("Authorization", "Bearer " + accessToken);
        reqspec = given().spec(reqspec).body(payload);
        if(isExternalVpa){
            Thread.sleep(1000);
        }
        res = reqspec.post(payByRequestIdURL);
        return res;

    }

    public static String getWalletBalance(String accessToken) throws FileNotFoundException {
        reqspec = new BaseBuilder().placeSpecBuilder();
        reqspec = RestAssured.given().spec(reqspec).header("Authorization", "Bearer " + accessToken);
        res = reqspec.get(GlobalConstant.getBalanceURL).then().extract().response();
        String balance = (String) getResponseData(res, "results.balance");
        if(balance!=null){
            return balance;
        }
        else {
            Assert.assertEquals("Wallet balance fetched successfully","Unable to fetch wallet balance");
            return "";
        }
    }

    public static Response checkVpa(String accessToken, String vpa) throws FileNotFoundException {
        HashMap<String, Object> checkVpaPayload = createTwoParameterWithLocation("contactNumber", vpa, "location");
        reqspec = new BaseBuilder().placeSpecBuilder();
        reqspec = given().spec(reqspec).header("Authorization", "Bearer " + accessToken).body(checkVpaPayload);
        res = reqspec.post(vpaCheckURL);
        return res;
    }

    public static Response checkRuleApi(Payee payee, Payer payer, String transTypeEnum, String accessToken) throws FileNotFoundException {
        HashMap<String, Object> payload = getCheckRuleApiPayload(payee, payer, transTypeEnum);
        reqspec = new BaseBuilder().placeSpecBuilder();
        reqspec = reqspec.header("Authorization", "Bearer " + accessToken);
        reqspec = given().spec(reqspec).body(payload);
        res = reqspec.post(checkRuleApiURL);
        return res;
    }

    public static Response verifyIFSCCode(String ifsc, String accessToken) throws FileNotFoundException {
        HashMap<String, String> payload = searchByIFSCCodePayload(ifsc);
        reqspec = baseBuilder.placeSpecBuilder();
        reqspec = reqspec.header("Authorization", "Bearer " + accessToken);
        reqspec = given().spec(reqspec).body(payload);
        res = reqspec.post(verifyIFSCCodeURL);
        return res;
    }

    public static Response addBeneficiary(Payee payee, String passcode,String accessToken) throws FileNotFoundException {
        HashMap<String, Object> payload = addBeneficiaryPayload(payee, passcode);
        reqspec = baseBuilder.placeSpecBuilder();
        reqspec = reqspec.header("Authorization", "Bearer " + accessToken);
        reqspec = given().spec(reqspec).body(payload);
        res = reqspec.post(addBeneficiaryURL);
        return res;
    }

    public static Response getBeneficiaryDetails(String accessToken, String limit, String offset) throws FileNotFoundException {
        HashMap<String, Object> payload = createTwoParameterPayload("limit", limit, "offset", offset);
        reqspec = baseBuilder.placeSpecBuilder();
        reqspec = reqspec.header("Authorization", "Bearer " + accessToken);
        reqspec = given().spec(reqspec).body(payload);
        res = reqspec.post(getAllBeneficiaryURL);
        return res;
    }

    public static Response getTransactionCharges(String accessToken, Payee payee, String transTypeEnum) {
        HashMap<String, String> payload = transactionChargesPayload(payee, transTypeEnum);
        reqspec = reqspec.header("Authorization", "Bearer " + accessToken);
        reqspec = given().spec(reqspec).body(payload);
        res = reqspec.post(transactionChargeURL);
        return res;

    }

    public static Response payByRequestId(String requestId, String accessToken) {
        HashMap<String, Object> payload = createOneParameterPayload("requestId", requestId);
        reqspec = reqspec.header("Authorization", "Bearer " + accessToken);
        reqspec = given().spec(reqspec).body(payload);
        res = reqspec.post(payByRequestIdURL);
        return res;


    }

    public static Response deleteBeneficiary(String id, String passcode, String accessToken) throws FileNotFoundException {
        HashMap<String, Object> payload = createTwoParameterPayload("id", id, "passcode", passcode);
        reqspec = baseBuilder.placeSpecBuilder();
        reqspec = reqspec.header("Authorization", "Bearer " + accessToken);
        reqspec = given().spec(reqspec).body(payload);
        res = reqspec.delete(deleteBeneficiaryURL);
        return res;
    }

    public static Response getPendingTransaction(String accessToken) throws FileNotFoundException {
        reqspec = baseBuilder.placeSpecBuilder();
        reqspec = reqspec.header("Authorization", "Bearer " + accessToken);
        res = given().spec(reqspec).get(pendingTransactionURL);
        return res;
    }

    public static Response cashLoadingLogin() throws FileNotFoundException {
        reqspec = baseBuilder.placeSpecBuilder();
        reqspec = reqspec.header("Content-Type", reader.getValueFromConfig("wallet.cash.loading.content.type"));
        reqspec = reqspec.header("username", reader.getValueFromConfig("wallet.cash.loading.user.name"));
        reqspec = reqspec.header("clientId", reader.getValueFromConfig("wallet.cash.loading.client.id"));
        reqspec = reqspec.header("clientSecret", reader.getValueFromConfig("wallet.cash.loading.client.secret"));
        reqspec = reqspec.header("password", reader.getValueFromConfig("wallet.cash.loading.password"));
        res = given().spec(reqspec).post(cashLoadingAdminLoginURL);
        return res;
    }

    public static Response cashLoadingPayment(String userMobileNumber, String amount, String idToken) throws FileNotFoundException {
        HashMap<String, Object> payload = getCashLoadingPaymentPayload(userMobileNumber, amount);
        reqspec = baseBuilder.placeSpecBuilder();
        reqspec = reqspec.header("Authorization", "Bearer " + idToken);
        reqspec = given().spec(reqspec).body(payload);
        res = reqspec.post(cashLoadingPaymentURL);
        return res;
    }

    public static Response createMandate(Payee payee, Payer payer, String accessToken) throws FileNotFoundException {
        HashMap<String, Object> payload = getCreateMandatePayload(payee, payer);
        reqspec = baseBuilder.placeSpecBuilder();
        reqspec = reqspec.header("Authorization", "Bearer " + accessToken);
        reqspec = given().spec(reqspec).body(payload);
        if (payer.getRecurrencePattern().equalsIgnoreCase(String.valueOf(RecurrencePatternEnum.ASPRESENTED))) {
            res = reqspec.post(GlobalConstant.createMandateURL);
        } else {
            res = reqspec.post(GlobalConstant.createSIMandateURL);
        }

        return res;
    }

    public static Response getPendingMandateList(String accessToken) throws FileNotFoundException {
        reqspec = baseBuilder.placeSpecBuilder();
        reqspec = reqspec.header("Authorization", "Bearer " + accessToken);
        res = given().spec(reqspec).get(pandingMandateURL);
        return res;
    }

    public static Response approveDeclineModifyMandate(Payer payer, String transTypeEnum, String accessToken) throws FileNotFoundException {
        HashMap<String, Object> payload = approveDeclineModifyMandatePayload(payer, transTypeEnum);
        reqspec = baseBuilder.placeSpecBuilder();
        reqspec = reqspec.header("Authorization", "Bearer " + accessToken);
        reqspec = given().spec(reqspec).body(payload);
        if (transTypeEnum.equals(String.valueOf(TransTypeEnum.UPDATE)) || (transTypeEnum.equals(String.valueOf(TransTypeEnum.REVOKE)))) {
            // modify mandate url
            res = reqspec.post(getModifyMandateURL);
        } else {
            // Authorize mandate url
            res = reqspec.post(approveMandateURL);
        }

        return res;
    }

    public static Response getMandateByEnum(String accessToken, String enumType) throws FileNotFoundException {
        reqspec = baseBuilder.placeSpecBuilder();
        reqspec = reqspec.header("Authorization", "Bearer " + accessToken);
        res = given().spec(reqspec).get(getMandateByEnumURL + "?mandateEnum=" + enumType);
        return res;
    }

    public static Response getMandateById(String accessToken, String id) throws FileNotFoundException {
        reqspec = baseBuilder.placeSpecBuilder();
        reqspec = reqspec.header("Authorization", "Bearer " + accessToken);
        res = given().spec(reqspec).get(getMandateByIdURL + "?txnId=" + id);
        return res;
    }

    public static String  successTransactionValidation(Response response, Payee payee, Payer payer, String transTypeEnum) {
        String id = null;
        System.out.println(response.asPrettyString());
        responseObject = extractJsonObjectFromResponse(response);
        assertJsonValueEquals("message", "Success", extractJsonObjectFromResponse(response)); // assertion
        org.json.JSONObject results = extractNestedJsonObject(responseObject, "results"); // extracting result from response
//        if(payer.getIsExternalVpa()){
//            id = getValueFromJSONObject(results,"transactionHeaderId");
//        }
//        else {
//           id = getValueFromJSONObject(results,"transactionId");
//        }
        //id = getValueFromJSONObject(results,"transactionHeaderId");
        assertJsonValueEquals("ledgerType", "Dr", results);
        if(transTypeEnum.equalsIgnoreCase(String.valueOf(TransTypeEnum.WALLET_TO_OTHER_WALLET))){
            String vpaExtension = payee.getReceiverVpa().substring(payee.getReceiverVpa().indexOf("@"));
            if (vpaExtension.equalsIgnoreCase("@nye") && transTypeEnum.equalsIgnoreCase(String.valueOf(TransTypeEnum.WALLET_TO_OTHER_WALLET))) {
                assertJsonValueEquals("transactionType", String.valueOf(TransTypeEnum.WALLET_TO_WALLET), results);
                assertJsonValueEquals("receiverVpa", payee.getReceiverVpa().substring(0,payee.getReceiverVpa().indexOf("@")), results);
                assertJsonValueEquals("senderVpa", payer.getSenderVpa().substring(0,payer.getSenderVpa().indexOf("@")), results);
                assertJsonValueEquals("senderAccountId", payer.getSenderVpa().substring(0,payer.getSenderVpa().indexOf("@")), results);
                id = getValueFromJSONObject(results,"transactionId");
        }
            else {
                assertJsonValueEquals("transactionType", transTypeEnum, results);
                assertJsonValueEquals("receiverVpa", payee.getReceiverVpa(), results);
                assertJsonValueEquals("senderVpa", payer.getSenderVpa(), results);
                assertJsonValueEquals("senderAccountId", payer.getSenderAccountId(), results);
                id = getValueFromJSONObject(results,"transactionHeaderId");
            }
        }
        else if(transTypeEnum.equalsIgnoreCase(String.valueOf(TransTypeEnum.WALLET_TO_WALLET))){
            assertJsonValueEquals("transactionType", transTypeEnum, results);
            assertJsonValueEquals("receiverVpa", payee.getReceiverMobileNumber(), results);
            Double transactionAmount = Double.valueOf(payee.getAmount());
            assertJsonValueEquals("drAmount", String.format("%.2f",transactionAmount), results);
            assertJsonValueEquals("requestedAmount", String.format("%.2f",transactionAmount), results);
            Double closingBalance = Double.parseDouble(payer.getWalletBalance())-Double.parseDouble(payee.getAmount());
            assertJsonValueEquals("closingBalance",String.format("%.2f",closingBalance),results);
            id = getValueFromJSONObject(results,"transactionId");
        }
        else if (transTypeEnum.equalsIgnoreCase(String.valueOf(TransTypeEnum.WALLET_TO_BANK))){
            assertJsonValueEquals("transactionType", transTypeEnum, results);
            Double transactionAmount = Double.valueOf(payer.getTotalTransactionAmount());
            assertJsonValueEquals("drAmount", String.format("%.2f",transactionAmount), results);
            assertJsonValueEquals("requestedAmount",String.format("%.2f",transactionAmount) , results);
            Double closingBalance = Double.parseDouble(payer.getWalletBalance())-Double.parseDouble(payer.getTotalTransactionAmount());
            assertJsonValueEquals("closingBalance",String.format("%.2f",closingBalance),results);
            id = getValueFromJSONObject(results,"transactionId");
        }
//        assertJsonValueEquals("transactionType", transTypeEnum, results);
//        assertJsonValueEquals("senderVpa", payer.getSenderVpa(), results);
//        assertJsonValueEquals("senderAccountId", payer.getSenderAccountId(), results);
        //assertJsonValueEquals("transactionStatus", "SUCCESS", results);
        assertJsonValueEquals("crAmount", "0.00", results);
        Double openingBalance = Double.valueOf(payer.getWalletBalance());
        assertJsonValueEquals("openingBalance",String.format("%.2f",openingBalance),results);
        return id;
    }

    public static void successTransactionValidationFromDB(Response response, Transaction transaction, String transTypeEnum) throws SQLException {
        responseObject = extractJsonObjectFromResponse(response);
        assertJsonValueEquals("message", "Success", extractJsonObjectFromResponse(response)); // assertion
        org.json.JSONObject results = extractNestedJsonObject(responseObject, "results"); // extracting result from response
        assertJsonValueEquals("transactionHeaderId",transaction.getTransactionHeaderId(),results);
        assertJsonValueEquals("transactionId",transaction.getTransactionId(),results);
        assertJsonValueEquals("txnTime",transaction.getTransactionTime().replace(" ","T"),results);
        assertJsonValueEquals("ledgerType",transaction.getLedgerType(),results);
        assertJsonValueEquals("transactionType",transaction.getTransactionType(),results);
        assertJsonValueEquals("transactionStatus",transaction.getTransactionStatus(),results);
        assertJsonValueEquals("senderAccountId",transaction.getSenderAccount(),results);
        assertJsonValueEquals("senderVpa",transaction.getSenderAccount(),results);
        //String senderName = convertToLowercaseExceptFirst(transaction.getSenderName().toUpperCase());//transaction.getSenderName().toUpperCase();
        //assertJsonValueEquals("senderName",senderName,results);
        if (transTypeEnum.equalsIgnoreCase("WALLET_TO_BANK")){
            String receiverAccount = transaction.getReceiverAccount();
            String accountNumber = receiverAccount.substring(0,receiverAccount.indexOf("||"));
            String ifscCode = receiverAccount.substring(receiverAccount.indexOf("||")+2);
            assertJsonValueEquals("receiverAccountId",accountNumber,results);
            assertJsonValueEquals("receiverIfsc",ifscCode,results);
        }
        else {
            assertJsonValueEquals("receiverVpa",transaction.getReceiverAccount(),results);
        }
        //String receiverName = convertToLowercaseExceptFirst(transaction.getReceiverName());
        //assertJsonValueEquals("receiverName",receiverName,results);
        assertJsonValueEquals("openingBalance",String.format("%.2f",Double.valueOf(transaction.getOpeningBalance())),results);
        assertJsonValueEquals("requestedAmount",String.format("%.2f",Double.parseDouble(transaction.getRequestedAmount())),results);
        if(transaction.getDebitAmount().equals("0")){
            assertJsonValueEquals("drAmount",transaction.getDebitAmount()+".00",results);
        }
        else {
            assertJsonValueEquals("drAmount", String.format("%.2f",Double.valueOf(transaction.getDebitAmount())),results);
        }
        if(transaction.getCreditAmount().equals("0")){
            assertJsonValueEquals("crAmount",transaction.getCreditAmount()+".00",results);
        }
        else {
            assertJsonValueEquals("crAmount",transaction.getCreditAmount(),results);
        }
        assertJsonValueEquals("closingBalance",String.format("%.2f",Double.valueOf(transaction.getClosingBalance())),results);
        System.out.println("Transaction has been verified Successfully from DB!");
        closeConnection(); // calling method to close db connection
    }


    public static void upiNotActivatedValidation(Response response) {
        System.out.println(response.asPrettyString());
        responseObject = extractJsonObjectFromResponse(response);
        org.json.JSONObject errorResponse = extractJsonValueFromJsonArray(responseObject, "errors", 0);
        if (getValueFromJSONObject(errorResponse, "code").equals("NYE-PPI-222")) {
            assertJsonValueEquals("message", "UPI is not activated", errorResponse);
            assertJsonValueEquals("description", "Please activate UPI first", errorResponse);
        }
        else if(getValueFromJSONObject(errorResponse, "code").equals("NYE-PPI-023")){
            assertJsonValueEquals("message", "UPI not found", errorResponse);
            assertJsonValueEquals("description", "UPI not found", errorResponse);
        }
        else {
            Assert.assertEquals("UPI not activated","UPI activated");
        }
    }

    public static Payer calculateTransactionCharge(Response response,Payee payee){
        Payer payer = new Payer();
        jsonSchemaValidator(res,reader.getValueFromConfig("wallet.b2b.transaction.charge.valid.schema"));
        responseObject = extractJsonObjectFromResponse(response);  // extracting data from response
        assertJsonValueEquals("message","Transaction charge calculated successfully",responseObject);  // assertions
        org.json.JSONObject results = extractNestedJsonObject(responseObject,"results");
        Double amount = Double.valueOf(payee.getAmount());
        assertJsonValueEquals("amount",String.format("%.2f",amount),results);  // amount validation with response
        String transactionFees = getValueFromJSONObject(results,"transactionFees");
        String sgstAmount = getValueFromJSONObject(results,"sgstAmount");
        String cgstAmount = getValueFromJSONObject(results,"cgstAmount");
        Double totalGstAmount = (Double.parseDouble(sgstAmount)+Double.parseDouble(cgstAmount));
        assertJsonValueEquals("totalGstAmount",String.format("%.2f",totalGstAmount),results); // total gst amount validation with response
        Double totalTransactionFeesWithGst = Double.parseDouble(transactionFees)+totalGstAmount;
        assertJsonValueEquals("totalTransactionFeesWithGst",String.format("%.2f",totalTransactionFeesWithGst),results);
        Double totalTransactionAmount = Double.parseDouble(payee.getAmount())+totalTransactionFeesWithGst;
        assertJsonValueEquals("totalTransactionAmount",String.format("%.2f",totalTransactionAmount),results); // total amount validation with response
        payer.setTransactionChargeId(getValueFromJSONObject(results,"transactionChargeId")); // set transaction charge id
        payer.setTotalTransactionAmount(String.valueOf(totalTransactionAmount));
        return payer;
    }

    public static Payee setBeneficiaryDetails(Response response){
        Payee payee = new Payee();
        responseObject = extractJsonObjectFromResponse(response);  // extracting data from response
        org.json.JSONObject results = extractNestedJsonObject(responseObject,"results");
        if(!getValueFromJSONObject(results,"totalCount").equalsIgnoreCase("0")){ // counting beneficiary
            org.json.JSONObject dataFromResponse = extractJsonValueFromJsonArray(results,"data",0);
            payee.setBankName(getValueFromJSONObject(dataFromResponse,"bankName"));  // set bank name
            payee.setAccountNumber(getValueFromJSONObject(dataFromResponse,"accountNumber")); //set account number
            payee.setIfsc(getValueFromJSONObject(dataFromResponse,"ifsc")); // set ifsc code
            payee.setReceiverName(reader.getValueFromConfig("wallet.account.holder.name")); // set account holder name
        }
        else {
            System.out.println("There is not beneficiary. Please add beneficiary details!");
        }
        return payee;

    }

    public static void errorValidationOfTM(Response response, Payee payee, Payer payer) throws FileNotFoundException {
        System.out.println(response.asPrettyString());
        //jsonSchemaValidator(res,reader.getValueFromConfig("wallet.transaction.error.valid.schema")); // schema validation for wallet not exits
        responseObject = extractJsonObjectFromResponse(response);
        org.json.JSONObject errorFromResponse = extractJsonValueFromJsonArray(responseObject, "errors", 0);
        if (getValueFromJSONObject(errorFromResponse, "code").equals("NYE-PPI-034")) {
            assertJsonValueEquals("message", "Entered amount is invalid", errorFromResponse);
            assertJsonValueEquals("description", "Please add a value between INR 1.00 to INR 200000.00", errorFromResponse);
        }
        else if(payee.getTransactionSubTypeEnum()==null &&(getValueFromJSONObject(errorFromResponse,"code").equals("NYE-TM-026"))){  // assertion for insufficient balance for other transaction
            Double amount = Double.valueOf(payee.getAmount()) -Double.valueOf( payer.getWalletBalance());
            assertJsonValueEquals("message","Unable to Process the transaction , Add money to your wallet "+String.format("%.2f",amount),errorFromResponse);
            assertJsonValueEquals("description", String.format("%.2f",amount),errorFromResponse);
        }
        else if((getValueFromJSONObject(errorFromResponse,"code").equals("NYE-TM-026"))){  // assertion for insufficient balance for p2b
            Double amount1 = Double.parseDouble(payer.getTotalTransactionAmount())-Double.valueOf(payer.getWalletBalance());
            String actualAmount = String.format("%.2f",amount1);
            assertJsonValueEquals("message","Unable to Process the transaction , Add money to your wallet "+ actualAmount,errorFromResponse);
            assertJsonValueEquals("description",actualAmount,errorFromResponse);
        }
        else if(getValueFromJSONObject(errorFromResponse,"code").equals("NYE-PPI-097")){        // validation for invalid receiver vpa
            assertJsonValueEquals("message","Receiver VPA not Exist/Invalid",errorFromResponse);
            assertJsonValueEquals("description","Please verify your credential",errorFromResponse);
        }
        else if(getValueFromJSONObject(errorFromResponse,"code").equals("NYE-PPI-007")){        // validation for invalid receiver vpa
            assertJsonValueEquals("message","NYE Prepaid does not exist",errorFromResponse);
            assertJsonValueEquals("description","NYE Prepaid not found for this user. Please complete your NYE Prepaid registration.",errorFromResponse);
        }
        else if (getValueFromJSONObject(errorFromResponse, "code").equals("NYE-PPI-158")) {
            assertJsonValueEquals("message", "Comment length should not exceed 250 characters", errorFromResponse);
            assertJsonValueEquals("description", "Comment length should not exceed 250 characters", errorFromResponse);
        }
        else if(getValueFromJSONObject(errorFromResponse, "code").equals("NYE-PPI-153")){
            assertJsonValueEquals("message","Receiver NYE Prepaid not found",errorFromResponse);
            assertJsonValueEquals("description","NYE Prepaid not found for this receiver vpa",errorFromResponse);
        }
        else if(getValueFromJSONObject(errorFromResponse, "code").equals("NYE-TM-002")){
            assertJsonValueEquals("message","Unique frontend id already exists",errorFromResponse);
            assertJsonValueEquals("description","Please verify your credential",errorFromResponse);
        }
        else if(getValueFromJSONObject(errorFromResponse, "code").equals("NYE-PPI-205")){
            assertJsonValueEquals("message","UniqueFrontEndId can not be null or empty",errorFromResponse);
            assertJsonValueEquals("description","Invalid UniqueFrontEndId",errorFromResponse);
        }
        else if(getValueFromJSONObject(errorFromResponse, "code").equals("NYE-COMM-001")){
            assertJsonValueEquals("message","Found Bad Request",errorFromResponse);
            assertJsonValueEquals("description","Check Request Body",errorFromResponse);
        }
        else if(getValueFromJSONObject(errorFromResponse, "code").equals("NYE-PPI-033")){
            assertJsonValueEquals("message","name is not present in User Profile",errorFromResponse);
            assertJsonValueEquals("description","Please update name in userProfile",errorFromResponse);
        }
        else if(getValueFromJSONObject(errorFromResponse, "code").equals("NYE-PPI-132")){
            assertJsonValueEquals("message","Invalid Action Type",errorFromResponse);
            assertJsonValueEquals("description","Please Provide Valid Action Enum",errorFromResponse);
        }
        else if(getValueFromJSONObject(errorFromResponse, "code").equals("NYE-PPI-141")){
            assertJsonValueEquals("message","Sender and Reciever VPA cannot be same",errorFromResponse);
            assertJsonValueEquals("description","Please enter the valid Vpa",errorFromResponse);
        }
        else if(getValueFromJSONObject(errorFromResponse, "code").equals("NYE-PPI-045")){
            assertJsonValueEquals("message","Transaction Type Enum Should Be correct",errorFromResponse);
            assertJsonValueEquals("description","Please provide correct type",errorFromResponse);
        }
        else if(getValueFromJSONObject(errorFromResponse, "code").equals("NYE-PPI-85")){
            assertJsonValueEquals("message","Only nickname can be null",errorFromResponse);
            assertJsonValueEquals("description","please enter all the values",errorFromResponse);
        }
        else if(getValueFromJSONObject(errorFromResponse, "code").equals("NYE-PPI-086")){
            assertJsonValueEquals("message","Maximum limit reached",errorFromResponse);
            assertJsonValueEquals("description","Maximum 3 beneficiaries can be added in a day. Please try again tomorrow.",errorFromResponse);
        }
        else if(getValueFromJSONObject(errorFromResponse, "code").equals("NYE-PPI-049")){
            assertJsonValueEquals("message","Invalid account number",errorFromResponse);
            assertJsonValueEquals("description","Please enter correct account number",errorFromResponse);
        }
        else if(getValueFromJSONObject(errorFromResponse, "code").equals("NYE-PPI-039")){
            assertJsonValueEquals("message","Invalid IFSC Code",errorFromResponse);
            assertJsonValueEquals("description","Please enter a valid IFSC code",errorFromResponse);
        }
        else if(getValueFromJSONObject(errorFromResponse, "code").equals("NYE-PPI-105")){
            assertJsonValueEquals("message","Receiver name and ifsc and accountNumber cannot be null",errorFromResponse);
            assertJsonValueEquals("description","Receiver name and ifsc and accountNumber cannot be null ",errorFromResponse);
        }
        else if(getValueFromJSONObject(errorFromResponse, "code").equals("NYE-PPI-045")){
            assertJsonValueEquals("message","Transaction Type Enum Should Be correct",errorFromResponse);
            assertJsonValueEquals("description","Please provide correct type",errorFromResponse);
        }
        else if(getValueFromJSONObject(errorFromResponse, "code").equals("NYE-PPI-212")){
            assertJsonValueEquals("message","Transaction Sub Type Enum Should Be correct",errorFromResponse);
            assertJsonValueEquals("description","Provide correct transaction sub type",errorFromResponse);
        }
        else if(getValueFromJSONObject(errorFromResponse, "code").equals("NYE-PPI-214")){
            assertJsonValueEquals("message","Maximum Rs 200000 is allowed for transaction and amount should be greater than 0",errorFromResponse);
            assertJsonValueEquals("description","Amount is not valid for transaction",errorFromResponse);
        }
        else if(getValueFromJSONObject(errorFromResponse, "code").equals("NYE-PPI-224")){
            assertJsonValueEquals("message","Transaction cannot be done. Kindly update NYE App.",errorFromResponse);
            assertJsonValueEquals("description","Transaction cannot be done. Kindly update NYE App.",errorFromResponse);
        }
        else if(getValueFromJSONObject(errorFromResponse, "code").equals("NYE-PPI-171")){
            assertJsonValueEquals("message","please try again",errorFromResponse);
            assertJsonValueEquals("description","User NYE Prepaid is not completed and active",errorFromResponse);
        }
        else if(getValueFromJSONObject(errorFromResponse, "code").equals("NYE-AUTH-035")){
            assertJsonValueEquals("message","Try After Some Time...",errorFromResponse);
            assertJsonValueEquals("description","Sorry, Something Went Wrong...",errorFromResponse);
        }
        else if(getValueFromJSONObject(errorFromResponse, "code").equals("NYE-PPI-138")){
            assertJsonValueEquals("message","Enter Valid Beneficiary",errorFromResponse);
            assertJsonValueEquals("description","Beneficiary Doesn't Exist",errorFromResponse);
        }
        else if(getValueFromJSONObject(errorFromResponse, "code").equals("NYE-PPI-040")){
            //assertJsonValueEquals("message","Entered bank name "+payee.getBankName()+" is not valid",errorFromResponse);
            assertJsonValueEquals("description","Please enter correct name",errorFromResponse);
        }
        else if(getValueFromJSONObject(errorFromResponse, "code").equals("NYE-AUTH-008")){
            assertJsonValueEquals("message","Incorrect Pin",errorFromResponse);
            assertJsonValueEquals("description","Unauthorized user",errorFromResponse);
        }

        else if(getValueFromJSONObject(errorFromResponse, "code").equals("NYE-APIG-002")){
            assertJsonValueEquals("message","Invalid value for Authorization header or Unauthorized",errorFromResponse);
            assertJsonValueEquals("description","Provide valid value for required header Authorization or User is not allowed to access this resource",errorFromResponse);
        }
        else if (getValueFromJSONObject(errorFromResponse, "code").equals("NYE-PPI-222")) {
            assertJsonValueEquals("message", "UPI is not activated", errorFromResponse);
            assertJsonValueEquals("description", "Please activate UPI first", errorFromResponse);
        }
        else if(getValueFromJSONObject(errorFromResponse, "code").equals("NYE-PPI-023")){
            assertJsonValueEquals("message", "UPI not found", errorFromResponse);
            assertJsonValueEquals("description", "UPI not found", errorFromResponse);
        }

        else {
            assertJsonValueEquals("code", "NYE-TM-001", errorFromResponse);
        }
    }



    public static Transaction getTransactionDetails(String transactionId) throws SQLException {
        Transaction transaction = new Transaction();
        transaction.setTransactionId(transactionId);
        Connection con = getConnection("wallettm");
        String query1 = "select * from transaction where transaction_id =\'"+transactionId+"\'";
        Statement statement1 = con.createStatement();
        ResultSet resultSet1 = statement1.executeQuery(query1);
        resultSet1.next();
        transaction.setTransactionHeaderId(resultSet1.getString("transaction_header_id"));
        transaction.setWalletId(resultSet1.getString("wallet_id"));
        transaction.setLedgerType(resultSet1.getString("ledger_type"));
        transaction.setOpeningBalance(resultSet1.getString("opening_balance"));
        transaction.setClosingBalance(resultSet1.getString("closing_balance"));
        transaction.setDebitAmount(resultSet1.getString("debit_amount"));
        transaction.setCreditAmount(resultSet1.getString("credit_amount"));

        String query2 = "select * from transaction_header where transaction_header_id =\'"+transaction.getTransactionHeaderId()+"\'";
        Statement statement2 = con.createStatement();
        ResultSet resultSet2 = statement2.executeQuery(query2);
        resultSet2.next();
        transaction.setUserId(resultSet2.getString("user_id"));
        transaction.setRequestedAmount(resultSet2.getString("requested_amount"));
        transaction.setSenderId(resultSet2.getString("sender_id"));
        transaction.setSenderAccount(resultSet2.getString("sender_account"));
        transaction.setSenderName(resultSet2.getString("sender_name"));
        transaction.setReceiverName(resultSet2.getString("receiver_name"));
        transaction.setReceiverId(resultSet2.getString("receiver_id"));
        transaction.setReceiverAccount(resultSet2.getString("receiver_account"));
        transaction.setReceiverName(resultSet2.getString("receiver_name"));
        transaction.setTransactionStatus(resultSet2.getString("transaction_status"));
        transaction.setTransactionType(resultSet2.getString("transaction_type"));
        transaction.setTransactionTime(resultSet2.getString("transaction_time"));
        transaction.setUniqueFrontendId(resultSet2.getString("unique_frontend_id"));
        closeConnection();
        return transaction;
    }

    public static Transaction getUPITransactionDetails(String transactionHeaderId) throws SQLException {
        Transaction transaction = new Transaction();
        String ledgerType = "Dr";
        transaction.setTransactionHeaderId(transactionHeaderId);
        Connection con = getConnection("wallettm");
        String query1 = "select * from transaction where transaction_header_id =\'"+transactionHeaderId+"\' and ledger_type =\'"+ledgerType+"\'";
        Statement statement1 = con.createStatement();
        ResultSet resultSet1 = statement1.executeQuery(query1);
        resultSet1.next();
        transaction.setWalletId(resultSet1.getString("wallet_id"));
        transaction.setLedgerType(resultSet1.getString("ledger_type"));
        transaction.setOpeningBalance(resultSet1.getString("opening_balance"));
        transaction.setClosingBalance(resultSet1.getString("closing_balance"));
        transaction.setDebitAmount(resultSet1.getString("debit_amount"));
        transaction.setCreditAmount(resultSet1.getString("credit_amount"));

        System.out.println(transactionHeaderId);
        String query2 = "select * from transaction_header where transaction_header_id =\'"+transactionHeaderId+"\'";
        Statement statement2 = con.createStatement();
        ResultSet resultSet2 = statement2.executeQuery(query2);
        resultSet2.next();
        transaction.setTransactionId(resultSet2.getString("rrn"));
        transaction.setUserId(resultSet2.getString("user_id"));
        transaction.setRequestedAmount(resultSet2.getString("requested_amount"));
        transaction.setSenderId(resultSet2.getString("sender_id"));
        transaction.setSenderAccount(resultSet2.getString("sender_account"));
        transaction.setSenderName(resultSet2.getString("sender_name"));
        transaction.setReceiverName(resultSet2.getString("receiver_name"));
        transaction.setReceiverId(resultSet2.getString("receiver_id"));
        transaction.setReceiverAccount(resultSet2.getString("receiver_account"));
        transaction.setReceiverName(resultSet2.getString("receiver_name"));
        transaction.setTransactionStatus(resultSet2.getString("transaction_status"));
        transaction.setTransactionType(resultSet2.getString("transaction_type"));
        transaction.setTransactionTime(resultSet2.getString("transaction_time"));
        transaction.setUniqueFrontendId(resultSet2.getString("unique_frontend_id"));
        closeConnection();
        return transaction;
    }



    public static ArrayList<Transaction> getReconReversalData(String transactionType) throws SQLException {
        Transaction transaction = new Transaction();
        Connection con = getConnection("wallettm");
        ArrayList<Transaction> transactionData = new ArrayList<>();
        String query = "select * from transaction_header where transaction_type =\'"+transactionType+"\' LIMIT \'"+reader.getValueFromConfig("wallet.recon.reversal.transaction.limit")+"\'";
        Statement statement = con.createStatement();
        ResultSet resultSet = statement.executeQuery(query);
        while (resultSet.next()){
            transaction.setTransactionHeaderId(resultSet.getString("transaction_header_id"));
            transaction.setSenderId(resultSet.getString("sender_id"));
            transaction.setUniqueFrontendId(resultSet.getString("unique_frontend_id"));
            transaction.setRequestedAmount(resultSet.getString("requested_amount"));
            transaction.setTransactionTime(resultSet.getString("transaction_time"));
            transaction.setTransactionStatus(resultSet.getString("transaction_status"));
            transaction.setRrn(resultSet.getString("rrn"));
            transactionData.add(transaction);
        }
        closeConnection();
        return transactionData;
    }

    public static Response reconReversal(String accessToken,ArrayList<Transaction> transactionData) throws FileNotFoundException {
        HashMap<String,Object> payload = getReconReversalPayload(transactionData);
        reqspec = baseBuilder.placeSpecBuilder();
        reqspec = reqspec.header("Authorization", "Bearer " + accessToken);
        reqspec = given().spec(reqspec).body(payload);
        res = reqspec.post(reconReversalURL);
        return res;
    }

    public static void successReconReversalValidation(Response response,ArrayList<Transaction> transactions,String transactionType){
        org.json.JSONObject jsonObject = extractJsonObjectFromResponse(response);
        JSONArray responseArray = extractJsonArrayFromJsonObject(jsonObject,"results");
        for(int i=0;i<responseArray.length();i++){
            org.json.JSONObject responseObject = (org.json.JSONObject) responseArray.get(i);
            Transaction transactionObject = transactions.get(i);
            //System.out.println(responseObject);
            assertJsonValueEquals("transactionHeaderId",transactionObject.getTransactionHeaderId(),responseObject); // transaction header id validation
            //String transactionDate = transactionObject.getTransactionTime().replace(" ","T");
//            assertJsonValueEquals("transactionDate",transactionDate,responseObject); // transaction timing validation
//            assertJsonValueEquals("transactionType",transactionType,responseObject); // transaction type validation
            if (getValueFromJSONObject(responseObject,"status").equalsIgnoreCase("Failure") && transactionType.equalsIgnoreCase(String.valueOf(TransTypeEnum.WALLET_TO_WALLET_CHASHBACK))){
                assertJsonValueEquals("errorReason","Manual CashBack Reversal not allowed",responseObject);
                System.out.println("Manual CashBack Reversal not allowed");
            }
            else if (getValueFromJSONObject(responseObject,"status").equalsIgnoreCase("Failure") && transactionType.equalsIgnoreCase(String.valueOf(TransTypeEnum.REVERSAL))){
                assertJsonValueEquals("errorReason","Amount auto reverted, manual reversal not allowed",responseObject);
                System.out.println("Amount auto reverted, manual reversal not allowed");
            }
            else if (getValueFromJSONObject(responseObject,"status").equalsIgnoreCase("Failure") && transactionType.equalsIgnoreCase(String.valueOf(TransTypeEnum.RECON_REVERSAL))){
                assertJsonValueEquals("errorReason","Transaction Already reverted",responseObject);
                System.out.println("Transaction Already reverted");
            }
            else if (getValueFromJSONObject(responseObject,"status").equalsIgnoreCase("Failure") && transactionType.equalsIgnoreCase(String.valueOf(TransTypeEnum.CASHBACK_REVERSAL))){
                assertJsonValueEquals("errorReason","CashBack Reversal's Reversal not allowed",responseObject);
                System.out.println("CashBack Reversal's Reversal not allowed");
            }
            else if (getValueFromJSONObject(responseObject,"status").equalsIgnoreCase("Failure") && transactionObject.getTransactionStatus().equalsIgnoreCase("FAILURE")){
                assertJsonValueEquals("errorReason","Transaction status is not Success or Pending",responseObject);
                System.out.println("Transaction status is not Success or Pending");
            }
            else if(getValueFromJSONObject(responseObject,"status").equalsIgnoreCase("Failure")){
                assertJsonValueEquals("errorReason","Total Reversal amount is greater than actual amount",responseObject);
                System.out.println("Total Reversal amount is greater than actual amount");
            }
            else {
                assertJsonValueEquals("status","Success",responseObject);  // assertion for success recon reversal
                assertJsonValueEquals("errorReason","null",responseObject);
                System.out.println("Recon reversal done successfully!!!!");
            }
        }
    }

    public static Response sendCardTransactionOtp(Card card, String accessToken) throws FileNotFoundException {
        HashMap<String,Object> payload = getSendCardTransactionOtpPayload(card);
        System.out.println(payload);
        reqspec = baseBuilder.placeSpecBuilder();
        reqspec = reqspec.header("Authorization", "Bearer " + accessToken);
        reqspec = given().spec(reqspec).body(payload);
        res = reqspec.post(sendCardTransactionOtpURL);
        return res;
    }

    public static Response payCard(Card card, String accessToken) throws FileNotFoundException {
        HashMap<String,Object> payload = getPayCardApiPayload(card);
        System.out.println(payload);
        reqspec = baseBuilder.placeSpecBuilder();
        reqspec = reqspec.header("Authorization", "Bearer " + accessToken);
        reqspec = given().spec(reqspec).body(payload);
        res = reqspec.post(payCardURL);
        return res;
    }

    public static void cardTransactionErrorValidation(Response response , Card card){
        System.out.println(response.asPrettyString());
        jsonSchemaValidator(response,reader.getValueFromConfig("wallet.card.failed.transaction.valid.schema"));
        responseObject = extractJsonObjectFromResponse(response);
        org.json.JSONObject errorFromResponse = extractJsonValueFromJsonArray(responseObject, "errors", 0);
        if(getValueFromJSONObject(errorFromResponse,"code").equalsIgnoreCase("NYE-COMM-014")){
            assertJsonValueEquals("message","Global Exception",errorFromResponse);
            assertJsonValueEquals("description","Our Services Are Down",errorFromResponse);
        }
        else if(getValueFromJSONObject(errorFromResponse,"code").equalsIgnoreCase("NYE-PPI-CARD-112")){
            assertJsonValueEquals("message","Otp not received",errorFromResponse);
            assertJsonValueEquals("description","Please try again",errorFromResponse);
        }
        else if(getValueFromJSONObject(errorFromResponse,"code").equalsIgnoreCase("NYE-PPI-CARD-103")){
            assertJsonValueEquals("message","card details not found",errorFromResponse);
            assertJsonValueEquals("description","please try again",errorFromResponse);
        }
        else if(getValueFromJSONObject(errorFromResponse,"code").equalsIgnoreCase("NYE-PPI-CARD-104")){
            assertJsonValueEquals("message","card details not found",errorFromResponse);
            assertJsonValueEquals("description","please enter correct card token",errorFromResponse);
        }
        else if(getValueFromJSONObject(errorFromResponse,"code").equalsIgnoreCase("NYE-TM-108")){
            assertJsonValueEquals("message","insufficent balance",errorFromResponse);
            assertJsonValueEquals("description","Please verify your credential",errorFromResponse);
        }
        else if(getValueFromJSONObject(errorFromResponse,"code").equalsIgnoreCase("NYE-PPI-CARD-110")){
            assertJsonValueEquals("message","Transaction can only be performed if card state is active",errorFromResponse);
            assertJsonValueEquals("description","Please try again",errorFromResponse);
        }
        else {
            assertJsonValueEquals("code", "NYE-TM-001", errorFromResponse);
        }
    }

    public static String successCardTransactionValidation(Response response,Card card){
        jsonSchemaValidator(response,reader.getValueFromConfig("wallet.card.success.transaction.valid.schema"));
        responseObject = extractJsonObjectFromResponse(response);
        assertJsonValueEquals("transaction","SUCCESS",responseObject);
        Double closingBalance = Double.parseDouble(card.getWalletBalance())-Double.parseDouble(card.getTransactionAmount());
        assertJsonValueEquals("closingBalance",String.format("%.2f",closingBalance),responseObject);
        return getValueFromJSONObject(responseObject,"transactionHeaderId");
    }

    public static void successCardTransactionValidationFromDB(Payer payer,Card card) throws SQLException {
        Transaction transaction = getCardTransactionDetails(card.getTransactionHeaderId());
        Assert.assertEquals(transaction.getRequestedAmount(),card.getTransactionAmount());
        Assert.assertEquals(transaction.getSenderAccount(),payer.getSenderAccountId());
        Assert.assertEquals(transaction.getReceiverId(),card.getTransactionType());
        Assert.assertEquals(transaction.getReceiverAccount(),card.getMerchantId());
        Assert.assertEquals(transaction.getReceiverName(),card.getLocation());
        Assert.assertEquals(transaction.getTransactionStatus(),"SUCCESS");
        Assert.assertEquals(transaction.getTransactionType(),card.getTransactionType());
        System.out.println("Card transaction successfully verified from DB!!!!");
    }

    public static Transaction getCardTransactionDetails(String transactionHeaderId) throws SQLException {
        Transaction transaction = new Transaction();
        Connection con = getConnection("wallettm");
        String query = "select * from transaction_header where transaction_header_id =\'"+transactionHeaderId+"\'";
        Statement statement = con.createStatement();
        ResultSet resultSet = statement.executeQuery(query);
        resultSet.next();
        transaction.setUserId(resultSet.getString("user_id"));
        transaction.setRequestedAmount(resultSet.getString("requested_amount"));
        transaction.setSenderAccount(resultSet.getString("sender_account"));
        transaction.setSenderName(resultSet.getString("sender_name"));
        transaction.setReceiverId(resultSet.getString("receiver_id"));
        transaction.setReceiverAccount(resultSet.getString("receiver_account"));
        transaction.setReceiverName(resultSet.getString("receiver_name"));
        transaction.setTransactionStatus(resultSet.getString("transaction_status"));
        transaction.setTransactionType(resultSet.getString("transaction_type"));
        transaction.setTransactionTime(resultSet.getString("transaction_time"));
        closeConnection();
        return transaction;
    }

    public static PreemptiveBasicAuthScheme ckycLogin(){
        PreemptiveBasicAuthScheme authScheme = new PreemptiveBasicAuthScheme();
        authScheme.setUserName(reader.getValueFromConfig("vc.username.ckycsecuredsearch"));
        authScheme.setPassword(reader.getValueFromConfig("vc.password.ckycsecuredsearch"));
        RestAssured.authentication = authScheme;
        return authScheme;
    }

    public static void checkRuleSuccessValidation(Response response){
        jsonSchemaValidator(res,reader.getValueFromConfig("check.rule.valid.schema")); //schema validation
        assertJsonValueEquals("message","Success",extractJsonObjectFromResponse(res)); // assertion
    }

    public static Response getScreenOptions(String issueId, String accessToken) throws FileNotFoundException {

        requestSpecification = baseBuilder.placeSpecBuilder();

        Response response = given()
                .headers("Authorization", accessToken)
                .spec(requestSpecification)
                .queryParam("issueId",  issueId)
                .when()
                .log().all()
                .get(GlobalConstant.getScreenOptionsMeta);
        return response;
    }

    public static Response getRaiseIssueApiResponse(String accessToken, String apiKey, String issueId, String attachmentPath, String description, String hasAttachment, String referenceId, String referenceType, String selectedOption, String subscriptionMappingId, String serviceProductId) throws FileNotFoundException {
        HashMap<Object, Object> payloadForRaisingIssue = JSONPayload.payloadForRaisingIssue(issueId, attachmentPath, description, hasAttachment, referenceId, referenceType, selectedOption, subscriptionMappingId, serviceProductId);

        requestSpecification = baseBuilder.placeSpecBuilder();

        Response response = given()
                .headers("Authorization", accessToken)
                .header("X-Api-Key", apiKey)
                .spec(requestSpecification)
                .body(payloadForRaisingIssue)
                .when()
                .log().all()
                .post(GlobalConstant.raiseIssue);
        return response;
    }

    public static Response updateGrievanceApiForCancellation(String statusForCancel, String resolution, String nyeTicketId, String accessToken, String api_key) throws FileNotFoundException {
        HashMap<Object, Object> payloadForCancellingIssue = JSONPayload.payloadForCancellingIssue(statusForCancel, resolution, nyeTicketId);
        requestSpecification = baseBuilder.placeSpecBuilder();
        Response response = given()
                .headers("Authorization", accessToken)
                .header("X-Api-Key", api_key)
                .spec(requestSpecification)
                .body(payloadForCancellingIssue)
                .when()
                .log().all()
                .put(updateTicket);
        return response;
    }
}


