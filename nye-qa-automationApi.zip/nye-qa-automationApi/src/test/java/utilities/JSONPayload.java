package utilities;

import com.google.gson.Gson;
import resources.*;

import java.util.ArrayList;
import java.util.HashMap;

import static utilities.Utils.*;

public class JSONPayload {

    private static final PropertyReader reader = new PropertyReader();


    public static HashMap<String, Object> createOneParameterPayload(String param, String value) {
        HashMap<String, Object> payload = new HashMap<>();
        payload.put(param, value);
        return payload;
    }

    public static HashMap<String, Object> createTwoParameterPayload(String var1, String value1, String var2, String value2) {
        HashMap<String, Object> payload = new HashMap<>();
        payload.put(var1, value1);
        payload.put(var2, value2);
        return payload;
    }

    public static HashMap<String, Object> createFourParameterPayload(String var1, String value1, String var2, String value2, String var3,
                                                                     String value3, String var4, String value4) {
        HashMap<String, Object> payload = new HashMap<>();
        payload.put(var1, value1);
        payload.put(var2, value2);
        payload.put(var3, value3);
        payload.put(var4, value4);
        return payload;
    }

    public static HashMap<String, Object> createThreeParameterPayload(String var1, String value1, String var2, String value2, String var3,
                                                                      String value3) {
        HashMap<String, Object> payload = new HashMap<>();
        payload.put(var1, value1);
        payload.put(var2, value2);
        payload.put(var3, value3);
        return payload;
    }

    public static HashMap<String, Object> createSevenParameterPayload(String var1, String value1, String var2, String value2,
                                                                      String var3, String value3, String var4, String value4,
                                                                      String var5, String value5, String var6, String value6,
                                                                      String var7, String value7) {
        HashMap<String, Object> payload = new HashMap<>();
        payload.put(var1, value1);
        payload.put(var2, value2);
        payload.put(var3, value3);
        payload.put(var4, value4);
        payload.put(var5, value5);
        payload.put(var6, value6);
        payload.put(var7, value7);
        return payload;
    }

    public static String payloadForPanValidation(String panNumber) {
        HashMap<String, String> hm = new HashMap<>();
        hm.put("panId", panNumber);
        System.err.println("HEREEE->" + new Gson().toJson(new Gson().toJson(hm)));
        String jsonString = new Gson().toJson(hm);
        System.out.println(jsonString);
        return jsonString;
    }

    public static HashMap<String, String> payloadForEncryption(String data) {
        String aesSymmetricKey = reader.getValueFromConfig("aes.symmetric.key");
        String rsaPublicKey = reader.getValueFromConfig("rsa.public.key");

        HashMap<String, String> encryptedHashmap = new HashMap<>();
        encryptedHashmap.put("aesSymmetricKey", aesSymmetricKey);
        encryptedHashmap.put("rsaPublicKey", rsaPublicKey);
        encryptedHashmap.put("data", data);
        System.err.println("The payload passing with hashmap is " + encryptedHashmap);
        return encryptedHashmap;
    }

    public static HashMap<String, Object> createTwoParameterWithLocation(String param1, String value1, String param2) {
        HashMap<String, Object> payload = new HashMap<>();
        payload.put(param1, value1);
        payload.put(param2, getLocation());
        return payload;
    }

    public static HashMap<String, Object> getPayApiPayload(Payee payee, Payer payer, String transTypeEnum) {
        HashMap<String, Object> payload = new HashMap<>();
        payload.put("amount", payee.getAmount());
        HashMap<String, String> payeePayload = new HashMap<>();
        payeePayload.put("receiverVpa", payee.getReceiverVpa());
        payeePayload.put("receiverName", payee.getReceiverName());
        payeePayload.put("receiverAccountId", payee.getAccountNumber());
        payeePayload.put("receiverIfsc", payee.getIfsc());
        payload.put("payee", payeePayload);
        HashMap<String, String> payerPayload = new HashMap<>();
        payload.put("comment", payee.getComment());
        if (transTypeEnum != null && (transTypeEnum.equalsIgnoreCase("COLLECT_WALLET_TO_OTHER_WALLET"))) {   // setting action for send collect
            payload.put("action", payer.getAction());
            payerPayload.put("senderVpa", payer.getSenderVpa());
            payerPayload.put("senderName", payer.getSenderName());
            payload.put("uniqueFrontendId", payer.getTxnId());
        } else if (transTypeEnum != null && (transTypeEnum.equalsIgnoreCase("COLLECT_WALLET_TO_OTHER_WALLET") && (payer.getAction().equalsIgnoreCase("COLLECTAPPROVE") || payer.getAction().equalsIgnoreCase("COLLECTREJECT")))) {
            payload.put("action", payer.getAction());
            payload.put("uniqueFrontendId", payer.getTxnId());
            payerPayload.put("passcode", payer.getPasscode());
        } else {   // setting action for pay
            payload.put("action", payer.getAction());
            payerPayload.put("passcode", payer.getPasscode()); // setting passcode
            payload.put("uniqueFrontendId", payer.getUniqueFrontendId());
        }
        payload.put("payer", payerPayload);
        payload.put("deviceTypeEnum", payer.getDeviceTypeEnum());
        payload.put("transactionTypeEnum", transTypeEnum);
        if (transTypeEnum != null && (transTypeEnum.equalsIgnoreCase("WALLET_TO_BANK"))) {  // extra payload for bank transfer
            payload.put("transactionSubTypeEnum", payee.getTransactionSubTypeEnum());
            payload.put("transactionChargeId", payee.getTransactionChargeId());
        }
        payload.put("location", getLocation());
        return payload;

    }

    public static HashMap<String, Object> getCheckRuleApiPayload(Payee payee, Payer payer, String transTypeEnum) {
        HashMap<String, Object> payload = new HashMap<>();
        payload.put("amount", payee.getAmount());
        HashMap<String, String> payeePayload = new HashMap<>();
        payeePayload.put("receiverVpa", payee.getReceiverVpa());
        payeePayload.put("receiverName", payee.getReceiverName());
        payeePayload.put("receiverAccountId", payee.getAccountNumber());
        payeePayload.put("receiverIfsc", payee.getIfsc());
        payload.put("payee", payeePayload);
        HashMap<String, String> payerPayload = new HashMap<>();
        payload.put("comment", payee.getComment());
        if (transTypeEnum != null && (transTypeEnum.equalsIgnoreCase("COLLECT_WALLET_TO_OTHER_WALLET"))) {   // setting action for send collect
            payload.put("action", payer.getAction());
            payerPayload.put("senderVpa", payer.getSenderVpa());
            payerPayload.put("senderName", payer.getSenderName());
            payload.put("uniqueFrontendId", payer.getTxnId());
        } else if (transTypeEnum != null && (transTypeEnum.equalsIgnoreCase("COLLECT_WALLET_TO_OTHER_WALLET") && (payer.getAction().equalsIgnoreCase("COLLECTAPPROVE") || payer.getAction().equalsIgnoreCase("COLLECTREJECT")))) {
            payload.put("action", payer.getAction());
            payload.put("uniqueFrontendId", payer.getTxnId());
            //payerPayload.put("passcode",payer.getPasscode());
        } else {   // setting action for pay
            payload.put("action", payer.getAction());
            payload.put("uniqueFrontendId", payer.getUniqueFrontendId());
        }
        payload.put("payer", payerPayload);
        payload.put("deviceTypeEnum", payer.getDeviceTypeEnum());
        payload.put("transactionTypeEnum", transTypeEnum);
        if (transTypeEnum != null && (transTypeEnum.equalsIgnoreCase("WALLET_TO_BANK"))) {  // extra payload for bank transfer
            payload.put("transactionSubTypeEnum", payee.getTransactionSubTypeEnum());
            payload.put("transactionChargeId", payee.getTransactionChargeId());
        }
        payload.put("location", getLocation());
        return payload;

    }

    public static HashMap<String, Object> getSendSmsPayload(SendSmsPayload values) {
        HashMap<String, Object> sendSmsPayload = new HashMap<>();
        sendSmsPayload.put("receiverAddress", values.getReceiverAddress());
        sendSmsPayload.put("templateName", values.getTemplateName());
        HashMap<String, Object> requiredParameters = new HashMap<>();
        requiredParameters.put("FirstName", values.getFirstName());
        requiredParameters.put("vKYC", values.getVkyc());
        sendSmsPayload.put("requiredParameters", requiredParameters);
        sendSmsPayload.put("preferredLanguage", values.getPreferredLanguage());
        sendSmsPayload.put("callingService", values.getCallingService());
        sendSmsPayload.put("domain", values.getDomain());
        return sendSmsPayload;
    }

    public static HashMap<String, Object> getSendEmailPayload(SendEmailPayload values) {
        HashMap<String, Object> sendEmailPayload = new HashMap<>();
        sendEmailPayload.put("receiverAddress", values.getReceiverAddress());
        sendEmailPayload.put("templateName", values.getTemplateName());
        HashMap<String, Object> requiredParameters = new HashMap<>();
        requiredParameters.put("userName", values.getUserName());
        requiredParameters.put("productName", values.getProductName());
        sendEmailPayload.put("requiredParameters", requiredParameters);
        sendEmailPayload.put("preferredLanguage", values.getPreferredLanguage());
        sendEmailPayload.put("callingService", values.getCallingService());
        sendEmailPayload.put("domain", values.getDomain());
        sendEmailPayload.put("files", values.getFiles());
        return sendEmailPayload;
    }

    public static HashMap<String, String> searchByIFSCCodePayload(String ifscCode) {
        HashMap<String, String> payload = new HashMap();
        payload.put("limit", reader.getValueFromConfig("limit"));
        payload.put("offset", reader.getValueFromConfig("offset"));
        payload.put("ifsc", ifscCode);
        return payload;

    }

    public static HashMap<String, Object> addBeneficiaryPayload(Payee payee, String passcode) {
        HashMap<String, Object> payload = new HashMap<>();
        payload.put("bankName", payee.getBankName());
        payload.put("accountNumber", payee.getAccountNumber());
        payload.put("confirmAccountNumber", payee.getAccountNumber());
        payload.put("ifsc", payee.getIfsc());
        payload.put("accountHolderName", payee.getReceiverName());
        payload.put("passcode", passcode);
        payload.put("nickName", "xyz");
        payload.put("location", getLocation());
        return payload;
    }

    public static HashMap<String, String> transactionChargesPayload(Payee payee, String transTypeEnum) {
        HashMap<String, String> payload = new HashMap<>();
        payload.put("amount", payee.getAmount());
        payload.put("transactionTypeEnum", transTypeEnum);
        payload.put("transactionSubTypeEnum", payee.getTransactionSubTypeEnum());
        return payload;
    }

    public static String payloadForSavingCommunicationAddress(String addressLine1, String addressLine2, String city, String pinCode, String state) {
        HashMap<String, String> hm = new HashMap<>();
        hm.put("addressLine1", addressLine1);
        hm.put("addressLine2", addressLine2);
        hm.put("pinCode", pinCode);
        hm.put("city", city);
        hm.put("state", state);
        System.err.println("HEREEE->" + new Gson().toJson(new Gson().toJson(hm)));
        String jsonString = new Gson().toJson(hm);
        System.out.println(jsonString);
        return jsonString;
    }

    public static HashMap<String, Object> getCashLoadingPaymentPayload(String userMobileNumber, String amount) {
        HashMap<String, Object> payload = new HashMap<>();
        payload.put("smid", reader.getValueFromConfig("wallet.cash.loading.smid"));
        payload.put("cicoTransactionId", getRandomAccountNumber());
        payload.put("transactionDateTime", reader.getValueFromConfig("wallet.cash.loading.transaction.date.time"));
        payload.put("userMobileNumber", userMobileNumber);
        HashMap<String, String> paymentDetails = new HashMap<>();
        paymentDetails.put("amount", amount);
        paymentDetails.put("paymentMode", reader.getValueFromConfig("wallet.cash.loading.payment.mode"));
        paymentDetails.put("transactionType", reader.getValueFromConfig("wallet.cash.loading.transaction.type"));
        paymentDetails.put("comment", reader.getValueFromConfig("wallet.cash.loading.comment"));
        payload.put("paymentDetails", paymentDetails);
        return payload;
    }

    public static String payloadForCheckAvailableProducts(String dobForPrs, String accountTypeForCheckAvailableProducts) {
        HashMap<String, String> hm = new HashMap<>();
        hm.put("dob", dobForPrs);
        hm.put("accountType", accountTypeForCheckAvailableProducts);
        System.err.println("HEREEE->" + new Gson().toJson(new Gson().toJson(hm)));
        String jsonString = new Gson().toJson(hm);
        System.out.println(jsonString);
        return jsonString;
    }

    public static HashMap<String, Object> approveDeclineModifyMandatePayload(Payer payer, String transTypeEnum) {
        HashMap<String, Object> payload = new HashMap<>();
        if (transTypeEnum.equals(String.valueOf(TransTypeEnum.UPDATE))) {
            payload.put("txnId", payer.getTxnId());
            payload.put("modifiedAmount", payer.getModifiedAmount());
            payload.put("modifiedValidity", payer.getModifiedValidity());
        } else if (transTypeEnum.equals(String.valueOf(TransTypeEnum.REVOKE))) {
            payload.put("txnId", payer.getTxnId());
        } else {
            payload.put("amount", payer.getAmount());
            payload.put("beneName", payer.getBeneName());
            payload.put("orgTxnId", payer.getTxnId());
            payload.put("validityEnd", payer.getValidityEnd());
            payload.put("amountRule", payer.getAmountRule());
            payload.put("recurrencePattern", payer.getRecurrencePattern());
        }
        payload.put("location", getLocation()); //
        payload.put("tranTypeEnum", transTypeEnum);//
        payload.put("passcode", payer.getPasscode());//
        return payload;
    }

    public static HashMap<String, Object> getCreateMandatePayload(Payee payee, Payer payer) {
        HashMap<String, Object> createPayload = new HashMap<>();
        if (payer.getRecurrencePattern().equalsIgnoreCase(String.valueOf(RecurrencePatternEnum.ASPRESENTED))) {
            createPayload.put("amount", payee.getAmount());
            createPayload.put("triggerAmount", payee.getTriggerAmount());
            HashMap<String, String> payerPayload = new HashMap<>();
            payerPayload.put("senderVpa", payer.getSenderVpa());
            payerPayload.put("senderName", payer.getSenderName());
            createPayload.put("payer", payerPayload);
        } else {
            createPayload.put("amount", payer.getAmount());
            createPayload.put("validityStart", payer.getValidityStart());
            createPayload.put("validityEnd", payer.getValidityEnd());
            createPayload.put("comment", payer.getComment());
            createPayload.put("recurrencePatternEnum", payer.getRecurrencePattern());
            HashMap<String, String> payeePayload = new HashMap<>();
            payeePayload.put("receiverVpa", payee.getReceiverVpa());
            payeePayload.put("receiverName", payee.getReceiverName());
            createPayload.put("payee", payeePayload);
            createPayload.put("passcode", payer.getPasscode());
            if ((payer.getRecurrencePattern().equals(String.valueOf(RecurrencePatternEnum.YEARLY))) || (payer.getRecurrencePattern().equals(String.valueOf(RecurrencePatternEnum.WEEKLY)))) {
                createPayload.put("debitStartAt", payer.getDebitStartAt());
            } else if (payer.getRecurrencePattern().equals(String.valueOf(RecurrencePatternEnum.MONTHLY))) {
                createPayload.put("debitDate", payer.getDebitStartAt());
            }
        }

        createPayload.put("location", getLocation());
        return createPayload;
    }

    public static HashMap<String, Object> getModifyMandatePayload(Payer payer, String transTypeEnum) {
        HashMap<String, Object> modifyPayload = new HashMap<>();
        modifyPayload.put("txnId", payer.getTxnId());
        modifyPayload.put("modifiedAmount", payer.getModifiedAmount());
        modifyPayload.put("passcode", payer.getPasscode());
        modifyPayload.put("tranTypeEnum", transTypeEnum);
        modifyPayload.put("modifiedValidity", payer.getModifiedValidity());
        modifyPayload.put("location", getLocation());
        return modifyPayload;
    }

    public static HashMap<String, Object> getReconReversalPayload(ArrayList<Transaction> transactionData) {
        HashMap<String, Object> payload = new HashMap<>();
        ArrayList<HashMap<String, Object>> reconDataPayload = new ArrayList<>();
        HashMap<String, Object> transactionPayload = new HashMap<>();
        for (Transaction transaction : transactionData) {
            transactionPayload.put("transactionHeaderId", transaction.getTransactionHeaderId());
            transactionPayload.put("senderId", transaction.getSenderId());
            transactionPayload.put("amount", transaction.getRequestedAmount());
            transactionPayload.put("uniqueId", transaction.getUniqueFrontendId());
            transactionPayload.put("rrn", transaction.getRrn());
            reconDataPayload.add(transactionPayload);
        }
        payload.put("reconData", reconDataPayload);
        return payload;
    }

    public static HashMap<String, Object> getSendCardTransactionOtpPayload(Card card) {
        HashMap<String, Object> payload = new HashMap<>();
        payload.put("transactionId", card.getTransactionId());
        payload.put("otp", card.getOtp());
        payload.put("otpTimeout", reader.getValueFromConfig("wallet.card.otp.timeout"));
        payload.put("retries", reader.getValueFromConfig("wallet.card.otp.retries"));
        HashMap<String, Object> data = new HashMap<>();
        data.put("customerid", card.getCustomerId());
        payload.put("data", data);
        return payload;
    }

    public static HashMap<String, Object> getPayCardApiPayload(Card card) {
        HashMap<String, Object> payload = new HashMap<>();
        payload.put("transactionNumber", card.getTransactionNumber());
        payload.put("transactionId", card.getTransactionId());
        payload.put("customerId", card.getCustomerId());
        payload.put("cardToken", card.getCardToken());
        payload.put("transactionAmount", card.getTransactionAmount());
        payload.put("merchantCategoryCode", card.getMerchantCategoryCode());
        payload.put("merchantId", card.getMerchantId());
        payload.put("location", card.getLocation());
        payload.put("channel", card.getChannel());
        return payload;
    }

    public static HashMap<String, Object> nestedPayloadForCkycSecuredSearch(String panNumber) {
        HashMap<String, Object> nestedpayload = new HashMap<>();
        HashMap<String, Object> pid = new HashMap<>();
        pid.put("PAN", panNumber);
        nestedpayload.put("pids", pid);
        return nestedpayload;
    }

    public static HashMap<String, Object> nestedPayloadForCkycSecuredDownload(String ckycNo, String dateofBirth, String pincodewithYearofBirth) {
        HashMap<String, Object> nestedpayload = new HashMap<>();
        nestedpayload.put("ckycNo", ckycNo);
        HashMap<String, Object> authfactors = new HashMap<>();
        authfactors.put("DOB", dateofBirth);
        authfactors.put("PINCODE_WITH_YEAR_OF_BIRTH", pincodewithYearofBirth);
        nestedpayload.put("authFactors", authfactors);
        System.out.println("The nested payload is " + nestedpayload);
        return nestedpayload;
    }

    public static HashMap<String,Object>nestedPayloadToPerformCKYC(String pan, String dateofBirth) {
        HashMap<String, Object> nestedpayload = new HashMap<>();
        HashMap<String, Object> pids = new HashMap<>();
        pids.put("PAN", pan);
        HashMap<String, Object> authfactors = new HashMap<>();
        authfactors.put("DOB", dateofBirth);
        nestedpayload.put("pids",pids);
        nestedpayload.put("authFactors", authfactors);
        return nestedpayload;

    }

    public static HashMap<Object, Object> payloadForRaisingIssue(String issueId, String attachmentPath, String description, String hasAttachment, String referenceId, String referenceType, String selectedOption, String subscriptionMappingId, String serviceProductId) {
        HashMap<Object, Object> dataMap= new HashMap<>();
        HashMap<Object, Object> bodyForRaisingIssue = new HashMap<>();
        bodyForRaisingIssue.put("attachmentPath", attachmentPath);
        bodyForRaisingIssue.put("dataMap", dataMap);
        bodyForRaisingIssue.put("description",description);
        bodyForRaisingIssue.put("hasAttachment", hasAttachment);
        bodyForRaisingIssue.put("issueId", issueId);
        bodyForRaisingIssue.put("referenceId", referenceId);
        bodyForRaisingIssue.put("referenceType", referenceType);
        bodyForRaisingIssue.put("selectedOption", selectedOption);
        bodyForRaisingIssue.put("subscriptionMappingId", subscriptionMappingId);

        return bodyForRaisingIssue;
    }

    public static HashMap<Object, Object> payloadForCancellingIssue(String statusForCancel, String resolution, String nyeTicketId) {
        HashMap<Object, Object> bodyForCancellingIssue = new HashMap<>();
        bodyForCancellingIssue.put("nyeTicketId",nyeTicketId);
        bodyForCancellingIssue.put("resolution", resolution);
        bodyForCancellingIssue.put("status", statusForCancel);
        return bodyForCancellingIssue;
    }
}



