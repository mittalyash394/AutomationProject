package utilities;

import base.BaseBuilder;
import com.google.gson.Gson;
import io.restassured.RestAssured;
import io.restassured.module.jsv.JsonSchemaValidator;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import org.json.JSONArray;
import org.json.JSONObject;
import org.junit.Assert;
import resources.RecurrencePatternEnum;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.Reader;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.math.RoundingMode;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.HashMap;
import java.util.Random;
import java.util.UUID;

import static io.restassured.RestAssured.given;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNull;
import static utilities.GlobalConstant.HTTP_OK;
import static utilities.GlobalConstant.adminLoginURL;
import static utilities.JSONPayload.createTwoParameterPayload;

public class Utils {

    private static final String latitude = "51";
    private static final String longitude = "36";
    private static final String ip = "20.0.123.123";

    private static RequestSpecification reqspec;
    private static Connection connection;

    private static Response res;
    private static PropertyReader reader = new PropertyReader();
    private static final BaseBuilder baseBuilder = new BaseBuilder();

    public static HashMap<String, String> getLocation() {
        HashMap<String, String> locationPayload = new HashMap<>();
        locationPayload.put("latitude", latitude);
        locationPayload.put("longitude", longitude);
        locationPayload.put("ip", ip);
        locationPayload.put("device", reader.getValueFromConfig("device"));
        return locationPayload;
    }

    public static String getUnixTime() {
        long unix = System.currentTimeMillis();
        return String.valueOf(unix);

    }

    public static JsonPath rawToJson(Response response) {
        JsonPath js = new JsonPath(response.body().asString());
        return js;
    }

    public static void verifyStatusCode(Response response, int statusCode) {
        int actualStatusCode = response.getStatusCode();
        assertEquals(statusCode, actualStatusCode);
    }

    public static Object getResponseData(Response response, String parameter) {
        JsonPath jsonPathEvaluator = response.jsonPath();
        Object responseValue = jsonPathEvaluator.get(parameter);
        return responseValue;
    }

    public static String getAccessTokenResponseData(Response response, String parameter) {
        String responseValue = response.path("results." + parameter);
        return responseValue;
    }

    public static RequestSpecification setBearerToken(RequestSpecification reqspec, String token) {
        return null;
    }

    public static String getEncryptedAuthData(String data) throws FileNotFoundException {
        reqspec = new BaseBuilder().placeSpecBuilder();
        reqspec = given().spec(reqspec).queryParam("content", data);
        res = reqspec.get(GlobalConstant.encryptDataURL);
        return res.getBody().asString();
    }

    public static void jsonSchemaValidator(Response response, String schemaFilePath) {
        File schemaFile = new File(schemaFilePath);
        JsonSchemaValidator validator = JsonSchemaValidator.matchesJsonSchema(schemaFile);
        response.then().assertThat().body(validator);
    }

    public static JSONObject extractJsonObjectFromResponse(Response response) {
        String responseBody = response.getBody().asString();
        return new JSONObject(responseBody);
    }

    public static JSONObject extractNestedJsonObject(JSONObject parentObject, String param) {
        return parentObject.getJSONObject(param);
    }

    public static JSONObject extractJsonValueFromJsonArray(JSONObject jsonObject,String param,int index){
        JSONArray errorsArray = jsonObject.getJSONArray(param);
        return errorsArray.getJSONObject(index);
    }

    public static String getValueFromJSONObject(JSONObject jsonObject,String param){
        return jsonObject.get(param).toString();
    }

    public static void assertJsonValueEquals(String param, String expectedValue, JSONObject jsonObject) {
        assertEquals(expectedValue, jsonObject.get(param).toString());
    }

    public static String stringToJsonString(Response response, String parameter) {
        String jsonStringResponse = response.body().asString();
        System.out.println("The jsonStringResponse is " + jsonStringResponse);
        return response.jsonPath().getJsonObject(parameter).toString();
    }

    public static String encryption(Response response, String parameter) {
        String jsonStringResponse = response.body().asString();
        System.out.println("The jsonStringResponse is " + jsonStringResponse);
        String str = new Gson().toJson(new Gson().fromJson(jsonStringResponse, HashMap.class).get(parameter));
        return str;
    }

    public static String getUniqueFrontendId(){
        UUID uuid = UUID.randomUUID();
        String randomUUIDString = uuid.toString();
        return randomUUIDString;

    }

    public static void deleteAuthUser(String mobile){
        reqspec = given().spec(reqspec).body(JSONPayload.createOneParameterPayload("mobileNumber",mobile));
        res = reqspec.delete(GlobalConstant.authDeleteEndpoint);
    }

    public static void deleteAuthUserCache(String mobile){
        reqspec = given().spec(reqspec).body(JSONPayload.createOneParameterPayload("mobileNumber",mobile));
        res = reqspec.post(GlobalConstant.authDeleteUserCacheEndpoint);
    }

    public static double getRandomAmount() {
        Random random = new Random();
        double amount = Double.parseDouble(reader.getValueFromConfig("amount"));
        double randomValue = random.nextDouble();
        amount = amount+randomValue;
        return 1.0*Math.round(amount * 100.0) / 100.0;
    }

    public static String getRandomAccountNumber() {
        int minDigits = 9;
        int maxDigits = 18;
        Random random = new Random();
        // Generate a random number of digits between minDigits and maxDigits
        int numDigits = random.nextInt(maxDigits - minDigits + 1) + minDigits;
        BigInteger min = BigInteger.TEN.pow(numDigits - 1);
        BigInteger max = BigInteger.TEN.pow(numDigits).subtract(BigInteger.ONE);
        BigInteger range = max.subtract(min).add(BigInteger.ONE);
        BigInteger randomOffset = new BigInteger(range.bitLength(), random);
        return String.valueOf(randomOffset);
    }



    public static boolean extractBooleanFromJsonObject(JSONObject jsonObject, String booleanVariable){
        return jsonObject.getBoolean(String.valueOf(booleanVariable));
    }

    public static void assertBooleanEquals(boolean expectedValue, JSONObject jsonObject){
        assertEquals(expectedValue, jsonObject.has(String.valueOf(expectedValue)));
    }

    public static JSONArray extractJsonArrayFromJsonObject(JSONObject jsonObject, String variable){
        return jsonObject.getJSONArray(variable);
    }

    public static String getModifyValidity(String validity){
        LocalDate date = LocalDate.parse(validity);
        // Get the date and month values
        int year = date.getYear();
        int day = (date.getDayOfMonth()+1)%31 == 0 ? (date.getDayOfMonth()+1)%31+1 :  (date.getDayOfMonth()+1)%31;
        int month = (date.getMonthValue()+1)%12 == 0 ? (date.getMonthValue()+1)%12+1 : (date.getMonthValue()+1)%12;
        String modifyDay;
        String modifyMonth;
        if(day <10 ){
            modifyDay = "-0"+day;
        }
        else {
            modifyDay =  "-"+day;
        }
        if(month<10 ){
            modifyMonth = "-0"+month;
        }
        else {
            modifyMonth = "-"+month;
        }
        return year+modifyMonth+modifyDay;
    }

    public static String getDebitDate(String validityStart,String recurrenceType){
        LocalDate date = LocalDate.parse(validityStart);
        int month = date.getMonthValue();
        int year = date.getYear();
        String debitStartAt;
        if(recurrenceType.equals(String.valueOf(RecurrencePatternEnum.YEARLY))){
           debitStartAt = String.valueOf(month+1 == 12 ? (month+1)%12+1: (month+1)%12);
        }
        else if(recurrenceType.equals(String.valueOf(RecurrencePatternEnum.MONTHLY))){
            debitStartAt = String.valueOf(month+1 == 12 ? (month+1)%12+1: (month+1)%12);
            if(month>Integer.parseInt(debitStartAt)){
                year = year+1;
            }
            if(Integer.parseInt(debitStartAt)<10){
                debitStartAt = year+"-0"+debitStartAt+"-01";
            }
            else {
                debitStartAt = year+"-"+debitStartAt+"-01";
            }

        }
        else{
            debitStartAt = "1"; // by default for weekly (Monday)
        }
        return (debitStartAt);

    }


    public static void assertBooleanValues(boolean storedInDb, boolean b) {
        assertEquals(storedInDb, b);
    }

    public static Response deleteVCWallet(String accessToken) throws FileNotFoundException {
        reqspec = baseBuilder.placeSpecBuilder();
        reqspec = reqspec.header("Authorization","Bearer " + accessToken);
        //reqspec = reqspec.header("subscriptionType","PPI");
        reqspec = reqspec.param("subscriptionType","PPI");
        reqspec = given().spec(reqspec);
         res    = reqspec.delete(GlobalConstant.deleteVCWalletEndpoint);
         return res;

    }
    public static Connection getConnection(String db) throws SQLException {
        if (connection == null || connection.isClosed()) {
            String url = reader.getValueFromConfig("uat.db.host.url")+db;
            String username = reader.getValueFromConfig("uat.db.user");
            String password = reader.getValueFromConfig("uat.db.password");
            connection = DriverManager.getConnection(url, username, password);
        }
        return connection;
    }

    public static void closeConnection() throws SQLException {
        if (connection != null && !connection.isClosed()) {
            connection.close();
        }
    }




    public static String adminLogin(String emailId, String password) throws FileNotFoundException {
        HashMap<String,Object> payload = createTwoParameterPayload("email",emailId,"password",password);
        reqspec = baseBuilder.placeSpecBuilder();
        reqspec = given().spec(reqspec).body(payload);
        res = reqspec.post(adminLoginURL);
        if(res.getStatusCode()!=HTTP_OK){
            System.out.println(res.asPrettyString());
            Assert.assertTrue(false);
            return null;
        }
        else {
            String accessToken = getAccessTokenResponseData(res,"access_token");
            return accessToken;
        }
    }

    public static String generateRandomNumber(){
        int min = 100000; // Minimum 6-digit number (100000)
        int max = 999999; // Maximum 6-digit number (999999)
        Random random = new Random();
        // Generate a random number with 6 digit
        int randomNumber = random.nextInt(max - min + 1) + min;
       return String.valueOf(randomNumber);
    }

    public static void assertJsonNullValue(String key) {
        assertEquals(key, "null");
    }

    public static void assertIntegerValueFromJsonObject(int expectedTransactionCount) {
        assertEquals(expectedTransactionCount, 0);
    }
}
