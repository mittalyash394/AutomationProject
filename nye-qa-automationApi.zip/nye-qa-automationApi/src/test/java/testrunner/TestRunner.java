package testrunner;


import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;
import org.junit.runner.RunWith;
//This runner file is used to run the TestCases
//In tag we can run the particular feature in place of complete feature file by passing Tag Name.
@RunWith(Cucumber.class)
@CucumberOptions(
        features = {"src/test/java/features/"},
        glue = {"stepdef"},
        tags = "not @ignore and not @skip", // Skips scenarios and steps with @ignore or @skip tags
//      tags =  "~@SKIP",
        plugin = {"json:target/cucumber-report.json", "pretty", "html:target/test-report.html"},
        publish = true,
        monochrome = true
)
public class TestRunner {
}
