package resources;

import com.google.gson.annotations.SerializedName;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class InitPayments {
    public static class Method {
        private String name;
        private String smid;
        private List<Provider> providers;
    }

    public static class Provider {
        private String name;
        private String smpid;
    }

    private List<Method> methods;
    private String productId;
    @SerializedName("oTxid")
    private String oTxid;
    private String action;
    private int amount;
    private String narration;
    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class PayeeAndPayer {
        private String firstName = "";
        private String lastName = "";
        private String contactNumber = "";
        private String email = "";
        private String account = "";
        private String accountNumber = "";
        private String ifsc = "";
        private String vpa = "";
    }
    private PayeeAndPayer payee;
    private PayeeAndPayer payer;
    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class MetaData {
        private String ip="";
        private String location="";
        private String deviceId="";
        private String mac="";
        private String lat="";
        @SerializedName("long")
        private String longitude="";
        private String deviceType;
        private String platformType;
    }

    private MetaData meta;
    private String callback = "";
}
