package resources;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;

@Data
public class Transaction {
    private String transactionId;
    private String transactionHeaderId;
    private String transactionTime;
    private String ledgerType;
    private String openingBalance;
    private String closingBalance;
    private String debitAmount;
    private String creditAmount;
    private String userId;
    private String walletId;
    private String requestedAmount;
    private String senderId;
    private String senderAccount;
    private String senderName;
    private String receiverId;
    private String receiverAccount;
    private String receiverName;
    private String transactionStatus;
    private String transactionType;
    private String uniqueFrontendId;
    private String rrn;

}
