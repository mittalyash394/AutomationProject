package resources;
import lombok.Getter;
import lombok.Setter;
@Getter
@Setter
public class SendSmsPayload {
    private String receiverAddress;
    private String templateName;
    private String firstName;
    private String vkyc;
    private String preferredLanguage;
    private String callingService;
    private String domain;
}
