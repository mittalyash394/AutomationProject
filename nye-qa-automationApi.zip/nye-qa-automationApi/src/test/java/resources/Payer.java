package resources;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Payer {
    private String senderVpa;
    private String senderAccountId;
    private String senderName;
    private String action;
    private String txnId;
    private String passcode;
    private String amount;
    private String beneName;
    private String validityStart;
    private String validityEnd;
    private String amountRule;
    private String recurrencePattern;
    private String modifiedAmount;
    private String modifiedValidity;
    private String umn;
    private String comment;
    private String debitStartAt;
    private String senderMobileNumber;
    private String deviceTypeEnum;
    private String uniqueFrontendId;
    private String walletBalance;
    private Boolean isNameValid;
    private String totalTransactionAmount;
    private Boolean isTransactionSuccess;
    private String transactionChargeId;
    private String accountType;
    private Boolean isExternalVpa;
}
