package resources;

import java.util.List;
import lombok.Data;

@Data
public class SendEmailPayload {
    private String receiverAddress;
    private String templateName;
    private String preferredLanguage;
    private String callingService;
    private String domain;
    private String userName;
    private String productName;
    private List<SendEmailPayloadObjects> files;
}
