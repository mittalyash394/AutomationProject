package resources;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class Card {
    private String transactionId;
    private String otp;
    private String customerId;
    private String cardToken;
    private String transactionNumber;
    private String transactionAmount;
    private String merchantCategoryCode;
    private String merchantId;
    private String location;
    private String channel;
    private String walletBalance;
    private Boolean isCardTransactionSuccess;
    private String transactionType;
    private String transactionHeaderId;
}
