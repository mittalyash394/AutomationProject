package resources;

public enum RecurrencePatternEnum {
    ASPRESENTED,
    DAILY,
    MONTHLY,
    YEARLY,
    WEEKLY,
    ONETIME
}
