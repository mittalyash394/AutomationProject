package resources;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class Payee {
    private String receiverVpa;
    private String receiverName;
    private String amount;
    private String triggerAmount;
    private String comment;
    private String bankName;
    private String accountNumber;
    private String ifsc;
    private String transactionSubTypeEnum;
    private String transactionChargeId;
    private String receiverMobileNumber;
}
