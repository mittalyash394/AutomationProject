package resources;

import lombok.Data;

@Data
public class SendEmailPayloadObjects {
    private String fileUrl;
    private String fileName;
}
