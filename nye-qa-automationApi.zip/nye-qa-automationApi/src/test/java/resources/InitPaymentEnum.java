package resources;

public enum InitPaymentEnum {

    DEBIT,
    CREDIT,
    REFUND,
    LOAD,
    INITIAL_FUNDING,
    ECOLLECT,
    POLLING_FOR_TRANSACTION_STATUS_PROCESSING,
    PREPAID_CARD_PAYMENT,
    CASA,
    NBP,
    WALLET,
    WEB,
    MOBILE,
    PAYMENTS,
    ANDROID,
    IOS


}
