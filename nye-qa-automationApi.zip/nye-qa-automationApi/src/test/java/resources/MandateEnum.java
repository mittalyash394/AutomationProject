package resources;

public enum MandateEnum {
    BY_ME,
    BY_OTHERS,
    ACTIVE,

}
