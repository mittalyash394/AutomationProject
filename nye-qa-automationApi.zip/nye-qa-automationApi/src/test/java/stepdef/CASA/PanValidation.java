package stepdef.CASA;

import base.BaseBuilder;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import org.json.JSONArray;
import org.json.JSONObject;
import utilities.*;

import java.io.FileNotFoundException;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.HashMap;

import static io.restassured.RestAssured.get;
import static io.restassured.RestAssured.given;

public class PanValidation {

    private final PropertyReader reader = new PropertyReader();

    public RequestSpecification requestSpecification;

    BaseBuilder baseBuilder = new BaseBuilder();

    private Response response;
    public String accessToken;

    private JSONObject jsonObject;

    private JSONArray jsonArray;
    @Given("Pass the token")
    public void pass_the_token() throws FileNotFoundException {
        System.out.println("Login with valid credentials");
        String mobileNumber = reader.getValueFromConfig("casa.user.mobile.number");
        String passcode = reader.getValueFromConfig("casa.user.passcode");
        String deviceId = reader.getValueFromConfig("casa.user.deviceId");
        response = CommonStepDef.login(mobileNumber,passcode,deviceId,deviceId);
        accessToken = Utils.getAccessTokenResponseData(response,"access_token");
        System.out.println(response.asPrettyString());
        Utils.verifyStatusCode(response,GlobalConstant.HTTP_OK);

    }
    @And("Enter the valid PAN number")
    public void enter_the_valid_pan_number() throws FileNotFoundException, MalformedURLException {
        String panNumber = reader.getValueFromConfig("pan.number");
        String payloadForPanValidation = JSONPayload.payloadForPanValidation(panNumber);
        String results = CommonStepDef.stringToJsonString(payloadForPanValidation);
        System.out.println("The results is " + results);
        HashMap<String, String> data = JSONPayload.payloadForEncryption(results);
        String encryptedPayload = CommonStepDef.encryption(data);
        System.out.println("The payloadForEncryption is " + encryptedPayload);
        requestSpecification = baseBuilder.placeSpecBuilder();
        response = given()
                .header("Authorization", accessToken)
                .spec(requestSpecification)
                .body(encryptedPayload)
                .when()
                .log().all()
                .post(GlobalConstant.panValidation);

        System.out.println("The response is " + response.asString());
        String responseData = Utils.stringToJsonString(response, "results");
        System.out.println("The responseData for panValidation API is " + responseData);
    }

    @Then("Verify the status code of PanValidation API")
    public void verify_the_statusCode_Of_panValidation_API() {
        System.out.println("Verifying the statusCode for PanValidation API");
        Utils.verifyStatusCode(response, GlobalConstant.HTTP_OK);
    }

    @Then("The response message should be valid for PanValidation API")
    public void theResponseMessageShouldBeValidForPanValidationAPI() {
        System.out.println("Verifying the response message for PanValidation API");
        jsonObject = Utils.extractJsonObjectFromResponse(response);
        Utils.assertJsonValueEquals("message", "NYE Pan Validation Executed SuccessFully!!", jsonObject);
    }

    @Then("The response schema should be valid")
    public void the_response_schema_should_be_valid() {
        System.out.println("The response schema for panValidation API");
        jsonObject = Utils.extractJsonObjectFromResponse(response);
        Utils.jsonSchemaValidator(response, reader.getValueFromConfig("casa.prs.panValidation.schema"));
        Utils.assertJsonValueEquals("message", "NYE Pan Validation Executed SuccessFully!!", jsonObject);
    }

    @When("Enter the panNumber {string} and hit the pan-validation API with negative scenerios")
    public void enter_the_pan_number_and_hit_the_pan_validation_api_with_negative_scenerios(String panNumber) throws FileNotFoundException {
        String payloadForPanValidation = JSONPayload.payloadForPanValidation(panNumber);
        String results = CommonStepDef.stringToJsonString(payloadForPanValidation);
        System.out.println("The results is " + results);
        HashMap<String, String> data = JSONPayload.payloadForEncryption(results);
        String encryptedPayload = CommonStepDef.encryption(data);
        System.out.println("The payloadForEncryption is " + encryptedPayload);
        requestSpecification = baseBuilder.placeSpecBuilder();
        response = given()
                .header("Authorization", accessToken)
                .spec(requestSpecification)
                .body(encryptedPayload)
                .when()
                .log().all()
                .post(GlobalConstant.panValidation);

        System.out.println("The response is " + response.asString());
    }

    @Then("Verify the statusCodes {string} of pan-validation API with negative scenerios")
    public void verify_the_statusCodes_of_pan_validation_api_with_negative_scenerios(String statusCode) {
        System.out.println("Verifying the statusCode for yes PanValidation API");
        Utils.verifyStatusCode(response, Integer.parseInt(statusCode));
    }

    @Then("Verify the response message of pan-validation API with negative scenerios")
    public void verify_the_response_message_of_pan_validation_api_with_negative_scenerios() {
        System.out.println("Verifying the response message for negative scenerios");
        jsonObject = Utils.extractJsonObjectFromResponse(response);
        jsonArray = Utils.extractJsonArrayFromJsonObject(jsonObject, "errors");
        System.out.println("The errors response is " + jsonArray);
        JSONObject messageForCheck = jsonArray.getJSONObject(0);
        Utils.assertJsonValueEquals("message", "Invalid PAN", messageForCheck);
    }

    @Then("Verify the response schema of pan-validation API with negative scenerios")
    public void verify_the_response_schema_of_pan_validation_api_with_negative_scenerios() {
        System.out.println("Verifying the error response schema for pan-validations API with negative scenerios");
        jsonObject = Utils.extractJsonObjectFromResponse(response);
        System.out.println(jsonObject);
        jsonArray = Utils.extractJsonArrayFromJsonObject(jsonObject, "errors");
        System.out.println("The jsonArray for pan-validations API with negative scenerios is " + jsonArray);
        Utils.jsonSchemaValidator(response, reader.getValueFromConfig("casa.errors.schema"));
    }

    @Then("The response body for pan-validation API should be valid with negative scenerios on passing {string}")
    public void the_response_body_for_pan_validation_api_should_be_valid_with_negative_scenerios_on_passing(String panNumber) {

        if(panNumber.equals("")){
            System.out.println("Verifying the response body for pan-validations API with negative scenerios");
            System.out.println("Verifying the response message for negative scenerios");
            jsonObject = Utils.extractJsonObjectFromResponse(response);
            jsonArray = Utils.extractJsonArrayFromJsonObject(jsonObject, "errors");
            System.out.println("The errors response is " + jsonArray);
            JSONObject messageForCheck = jsonArray.getJSONObject(0);
            Utils.assertJsonValueEquals("message", "Invalid PAN", messageForCheck);

            System.out.println("  ********* code  *********");
            JSONObject codeForCheck = jsonArray.getJSONObject(0);
            Utils.assertJsonValueEquals("code", "NYE-PRS-401", codeForCheck);

            System.out.println("  ********  description  *********");
            JSONObject descriptionForCheck = jsonArray.getJSONObject(0);
            Utils.assertJsonValueEquals("description", "PAN Cannot be Null or Blank", descriptionForCheck);
        }
        else if(response.getStatusCode() == 400){
            System.out.println("Verifying the response body for pan-validations API with negative scenerios");
            System.out.println("Verifying the response message for negative scenerios");
            jsonObject = Utils.extractJsonObjectFromResponse(response);
            jsonArray = Utils.extractJsonArrayFromJsonObject(jsonObject, "errors");
            System.out.println("The errors response is " + jsonArray);
            JSONObject messageForCheck = jsonArray.getJSONObject(0);
            Utils.assertJsonValueEquals("message", "Invalid PAN", messageForCheck);

            System.out.println("  ********* code  *********");
            JSONObject codeForCheck = jsonArray.getJSONObject(0);
            Utils.assertJsonValueEquals("code", "NYE-KYC-011", codeForCheck);

            System.out.println("  ********  description  *********");
            JSONObject descriptionForCheck = jsonArray.getJSONObject(0);
            Utils.assertJsonValueEquals("description", "Please check if you have entered PAN correctly", descriptionForCheck);
        }else {
            System.out.println("Verifying the response body for pan-validations API with negative scenerios");
            System.out.println("Verifying the response message for negative scenerios");
            jsonObject = Utils.extractJsonObjectFromResponse(response);
            jsonArray = Utils.extractJsonArrayFromJsonObject(jsonObject, "errors");
            System.out.println("The errors response is " + jsonArray);
            JSONObject messageForCheck = jsonArray.getJSONObject(0);
            Utils.assertJsonValueEquals("message", "Invalid PAN", messageForCheck);

            System.out.println("  ********* code  *********");
            JSONObject codeForCheck = jsonArray.getJSONObject(0);
            Utils.assertJsonValueEquals("code", "NYE-PRS-405", codeForCheck);

            System.out.println("  ********  description  *********");
            JSONObject descriptionForCheck = jsonArray.getJSONObject(0);
            Utils.assertJsonValueEquals("description", "Invalid PAN format", descriptionForCheck);
        }

    }

}
