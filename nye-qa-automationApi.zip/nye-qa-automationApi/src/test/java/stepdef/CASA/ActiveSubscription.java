package stepdef.CASA;

import base.BaseBuilder;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import org.json.JSONArray;
import org.json.JSONObject;
import utilities.CommonStepDef;
import utilities.GlobalConstant;
import utilities.PropertyReader;
import utilities.Utils;

import java.io.FileNotFoundException;

import static io.restassured.RestAssured.given;

public class ActiveSubscription {

    private final PropertyReader propertyReader = new PropertyReader();

    public RequestSpecification requestSpecification;

    BaseBuilder baseBuilder = new BaseBuilder();
    private String access_token;

    private Response response;

    private JSONObject jsonObject;

    private JSONArray jsonArray;
    @Given("The user pass the token in the API")
    public void the_user_pass_the_token_in_the_api() throws FileNotFoundException {

        System.out.println("Login with valid credentials");
        String mobileNumber = propertyReader.getValueFromConfig("casa.user.mobile.number");
        String passcode = propertyReader.getValueFromConfig("casa.user.passcode");
        String deviceId = propertyReader.getValueFromConfig("casa.user.deviceId");
        response = CommonStepDef.login(mobileNumber,passcode,deviceId,deviceId);
        access_token = Utils.getAccessTokenResponseData(response,"access_token");
        System.out.println(response.asPrettyString());
        Utils.verifyStatusCode(response, GlobalConstant.HTTP_OK);
    }

    @When("The user hits the activeSubscription API")
    public void the_user_hits_the_active_subscription_api() throws FileNotFoundException {
        requestSpecification = baseBuilder.placeSpecBuilder();

        response = given()
                .headers("Authorization", access_token)
                .spec(requestSpecification)
                .when()
                .log().all()
                .get(GlobalConstant.activeSubscription);
        System.out.println("The active subscription response is " +response.asString());
    }

    @Then("Verify the status code of activeSubscription API")
    public void verify_the_status_code_Of_ActiveSubscription_API() {
        System.out.println("Verifying the status code of activeSubscription API");
        Utils.verifyStatusCode(response, GlobalConstant.HTTP_OK);
    }
    @And("The response message should be valid for ActiveSubscription API")
    public void theResponseMessageShouldBeValidForActiveSubscriptionAPI() {
        jsonObject = Utils.extractJsonObjectFromResponse(response);
        System.out.println(jsonObject);
        Utils.assertJsonValueEquals("message", "Active Subscription executed successfully!!", jsonObject);
//        Utils.jsonSchemaValidator(response, propertyReader.getValueFromConfig("casa.prs.activeSubscription.schema"));
    }

    @And("Response schema should be valid")
    public void response_schema_should_be_valid() {
        jsonObject = Utils.extractJsonObjectFromResponse(response);
        System.out.println(jsonObject);
        JSONObject results = Utils.extractNestedJsonObject(jsonObject, "results");
        boolean actualActiveSubscription = Utils.extractBooleanFromJsonObject(results, "hasActiveSubscription");
        System.out.println("The actualActiveSubscription is " + actualActiveSubscription);
        Utils.jsonSchemaValidator(response, propertyReader.getValueFromConfig("casa.prs.activeSubscription.schema"));
//        Utils.assertBooleanEquals(false, jsonObject);
    }

    @And("Response body should be valid")
    public void responseBodyShouldBeValid() {
        jsonObject = Utils.extractJsonObjectFromResponse(response);
        System.out.println(jsonObject);
        JSONObject results = Utils.extractNestedJsonObject(jsonObject, "results");
        boolean actualActiveSubscription = Utils.extractBooleanFromJsonObject(results, "hasActiveSubscription");
        System.out.println("The actualActiveSubscription is " + actualActiveSubscription);
        Utils.jsonSchemaValidator(response, propertyReader.getValueFromConfig("casa.prs.activeSubscription.schema"));
        Utils.assertBooleanEquals(false, jsonObject);
    }


    @Given("The user does not pass the token in the API")
    public void the_user_does_not_pass_the_token_in_the_api() {
        System.out.println("Assigning the value in access_token");
        access_token = "";
    }

    @When("The user hits the activeSubscription API on not passing the token")
    public void theUserHitsTheActiveSubscriptionAPIOnNotPassingTheToken() throws FileNotFoundException {
        requestSpecification = baseBuilder.placeSpecBuilder();

        response = given()
                .headers("Authorization", access_token)
                .spec(requestSpecification)
                .when()
                .log().all()
                .get(GlobalConstant.activeSubscription);
        System.out.println("The active subscription response is " +response.asString());
    }

    @Then("Verify the status code of activeSubscription API on not passing the token")
    public void verifyTheStatusCodeOfActiveSubscriptionAPIOnNotPassingTheToken() {
        System.out.println("Verifying the status code of ActiveSubscription API when not passing the token");
        Utils.verifyStatusCode(response, GlobalConstant.HTTP_UNAUTHORIZED);
    }

    @Then("Verify the error schema for ActiveSubscription API")
    public void verify_the_error_schema_for_active_subscription_api() {
        System.out.println("Verifying the error schema for activeSubscription API on not passing the token");
        jsonObject = Utils.extractJsonObjectFromResponse(response);
        System.out.println(jsonObject);
        jsonArray = Utils.extractJsonArrayFromJsonObject(jsonObject, "errors");
        System.out.println("The jsonArray for activeSubscription API is " + jsonArray);
        System.out.println(" ***********    Verifying the error code    **********");
        JSONObject codeForCheck = jsonArray.getJSONObject(0);
        System.out.println("The codeForCheck is " + codeForCheck);
        Utils.assertJsonValueEquals("code", "NYE-APIG-001", codeForCheck);

        System.out.println(" ***********    Verifying the error message   *********");
        JSONObject messageForCheck = jsonArray.getJSONObject(0);
        System.out.println("The messageForCheck is " + messageForCheck);
        Utils.assertJsonValueEquals("message", "Value is not present in required Header Authorization", messageForCheck);
    }
    @Then("Verify the error response schema for ActiveSubscription API")
    public void verify_the_error_response_schema_for_active_subscription_api() {
        System.out.println("Verifying the error response schema for activeSubscription API");
        jsonObject = Utils.extractJsonObjectFromResponse(response);
        System.out.println(jsonObject);
        jsonArray = Utils.extractJsonArrayFromJsonObject(jsonObject, "errors");
        System.out.println("The jsonArray for activeSubscription API is " + jsonArray);
        Utils.jsonSchemaValidator(response, propertyReader.getValueFromConfig("casa.errors.schema"));
    }
    @Then("Verify the error response body for ActiveSubscription API")
    public void verify_the_error_response_body_for_active_subscription_api() {
        System.out.println("Verifying the error response body for activeSubscription API");
        jsonObject = Utils.extractJsonObjectFromResponse(response);
        System.out.println(jsonObject);
        jsonArray = Utils.extractJsonArrayFromJsonObject(jsonObject, "errors");
        System.out.println("The jsonArray for activeSubscription API is " + jsonArray);
        System.out.println(" ***********    Verifying the error code    **********");
        JSONObject codeForCheck = jsonArray.getJSONObject(0);
        System.out.println("The codeForCheck is " + codeForCheck);
        Utils.assertJsonValueEquals("code", "NYE-APIG-001", codeForCheck);

        System.out.println(" ***********    Verifying the error message   *********");
        JSONObject messageForCheck = jsonArray.getJSONObject(0);
        System.out.println("The messageForCheck is " + messageForCheck);
        Utils.assertJsonValueEquals("message", "Value is not present in required Header Authorization", messageForCheck);
        System.out.println(" ***********     Verifying the description    *********");
        JSONObject descriptionForCheck = jsonArray.getJSONObject(0);
        System.out.println("The descriptionForCheck is " + descriptionForCheck);
        Utils.assertJsonValueEquals("description", "Provide value for required Header Authorization", descriptionForCheck);
    }
}
