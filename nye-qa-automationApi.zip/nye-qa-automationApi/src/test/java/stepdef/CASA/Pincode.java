package stepdef.CASA;

import base.BaseBuilder;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import org.json.JSONArray;
import org.json.JSONObject;
import utilities.CommonStepDef;
import utilities.GlobalConstant;
import utilities.PropertyReader;
import utilities.Utils;

import java.io.FileNotFoundException;

import static io.restassured.RestAssured.given;

public class Pincode {

    private final PropertyReader propertyReader = new PropertyReader();

    public RequestSpecification requestSpecification;

    BaseBuilder baseBuilder = new BaseBuilder();
    private String access_token;

    private Response response;

    private JSONObject jsonObject;

    private JSONArray jsonArray;

    @Given("Pass the token in pinCode API")
    public void pass_the_token_in_pin_code_api() throws FileNotFoundException {
        System.out.println("Login with valid credentials");
        String mobileNumber = propertyReader.getValueFromConfig("casa.user.mobile.number");
        String passcode = propertyReader.getValueFromConfig("casa.user.passcode");
        String deviceId = propertyReader.getValueFromConfig("casa.user.deviceId");
        response = CommonStepDef.login(mobileNumber,passcode,deviceId,deviceId);
        access_token = Utils.getAccessTokenResponseData(response,"access_token");
        System.out.println(response.asPrettyString());
        Utils.verifyStatusCode(response, GlobalConstant.HTTP_OK);
    }


    @Given("Enter the valid pinCode and hit the PinCode API")
    public void enter_the_valid_pin_code_and_hit_the_pin_code_api() throws FileNotFoundException {

        String pinCode = propertyReader.getValueFromConfig("casa.prs.pinCode");
        requestSpecification = baseBuilder.placeSpecBuilder();

        response = given()
                .headers("Authorization", access_token)
                .spec(requestSpecification)
                .queryParam("pincode",  pinCode)
                .when()
                .log().all()
                .get(GlobalConstant.pinCodeAPI);
        System.out.println("The pinCode API response is " +response.asString());

    }


    @Then("Verify the statusCode of pinCode API")
    public void Verify_the_status_code_of_pin_code_api() {
        System.out.println("Verifying the statusCode for pinCode API");
        Utils.verifyStatusCode(response, GlobalConstant.HTTP_OK);

    }

    @And("Verify the response message of PinCode API")
    public void verifyTheResponseMessageOfPinCodeAPI() {
        System.out.println("Verifying the pinCode API response");
        jsonObject = Utils.extractJsonObjectFromResponse(response);
        Utils.assertJsonValueEquals("message", "PIN Code Meta Executed Successfully", jsonObject);
    }

    @And("Verify the response schema of PinCode API")
    public void verifyTheResponseSchemaOfPinCodeAPI() {
        System.out.println("Verifying the pinCode API response");
        jsonObject = Utils.extractJsonObjectFromResponse(response);
        System.out.println("The jsonObject response for pinCode API is " + jsonObject);
        JSONObject results = Utils.extractNestedJsonObject(jsonObject, "results");
        System.out.println("The jsonObject results response for pinCode API is " + results);
        jsonArray = Utils.extractJsonArrayFromJsonObject(results, "location");
        System.out.println("The jsonArray response is " + jsonArray);
        Utils.jsonSchemaValidator(response, propertyReader.getValueFromConfig("casa.prs.pinCode.schema"));
    }
    @Then("The response body for PinCode API should be valid")
    public void the_response_body_for_pin_code_api_should_be_valid() {
        System.out.println("Verifying the pinCode API response");
        jsonObject = Utils.extractJsonObjectFromResponse(response);
        System.out.println("The jsonObject response for pinCode API is " + jsonObject);
        JSONObject results = Utils.extractNestedJsonObject(jsonObject, "results");
        System.out.println("The jsonObject results response for pinCode API is " + results);
        jsonArray = Utils.extractJsonArrayFromJsonObject(results, "location");
        System.out.println("The jsonArray response is " + jsonArray);
        Utils.jsonSchemaValidator(response, propertyReader.getValueFromConfig("casa.prs.pinCode.schema"));
        Utils.extractJsonValueFromJsonArray(results, "location", 1);
        System.out.println("The jsonArray is " + jsonArray.get(0));
        JSONObject firstArray = jsonArray.getJSONObject(0);
        System.out.println("The first array response is " + firstArray);
        System.out.println(firstArray.get("country"));
        Utils.assertJsonValueEquals("country", "India", firstArray);
    }

    @When("Enter the pinCodes {string} and hit the pinCode API with negative scenerios")
    public void enter_the_pin_codes_and_hit_the_pin_code_api_with_negative_scenerios(String pinCode) throws FileNotFoundException {
        requestSpecification = baseBuilder.placeSpecBuilder();

        response = given()
                .headers("Authorization", access_token)
                .spec(requestSpecification)
                .queryParam("pincode",  pinCode)
                .when()
                .log().all()
                .get(GlobalConstant.pinCodeAPI);
        System.out.println("The pinCode API response is " +response.asString());
    }
    @Then("Verify the {string} of pinCode API with negative scenerios")
    public void verify_the_of_pin_code_api_with_negative_scenerios(String statusCode) {
        System.out.println("Verifying the statusCode for negative scenerios");
        Utils.verifyStatusCode(response, Integer.parseInt(statusCode));
    }
    @Then("Verify the response message of PinCode API with negative scenerios")
    public void verify_the_response_message_of_pin_code_api_with_negative_scenerios() {
        System.out.println("Verifying the response message for negative scenerios");
        jsonObject = Utils.extractJsonObjectFromResponse(response);
        jsonArray = Utils.extractJsonArrayFromJsonObject(jsonObject, "errors");
        System.out.println("The errors response is " + jsonArray);
        JSONObject messageForCheck = jsonArray.getJSONObject(0);
        Utils.assertJsonValueEquals("message", "Invalid Pincode", messageForCheck);
    }
    @Then("Verify the response schema of PinCode API with negative scenerios")
    public void verify_the_response_schema_of_pin_code_api_with_negative_scenerios() {
        System.out.println("Verifying the error response schema for pinCode API with negative scenerios");
        jsonObject = Utils.extractJsonObjectFromResponse(response);
        System.out.println(jsonObject);
        jsonArray = Utils.extractJsonArrayFromJsonObject(jsonObject, "errors");
        System.out.println("The jsonArray for pinCode API with negative scenerios is " + jsonArray);
        Utils.jsonSchemaValidator(response, propertyReader.getValueFromConfig("casa.errors.schema"));
    }
    @Then("The response body for PinCode API should be valid with negative scenerios pinCodes {string}")
    public void the_response_body_for_pin_code_api_should_be_valid_with_negative_scenerios_pinCodes(String pinCodes) {
        if(pinCodes.equals("")){
            System.out.println("Verifying the response body for pinCode API with negative scenerios");
            System.out.println("Verifying the response message for negative scenerios");
            jsonObject = Utils.extractJsonObjectFromResponse(response);
            jsonArray = Utils.extractJsonArrayFromJsonObject(jsonObject, "errors");
            System.out.println("The errors response is " + jsonArray);
            JSONObject messageForCheck = jsonArray.getJSONObject(0);
            Utils.assertJsonValueEquals("message", "Invalid Pincode", messageForCheck);

            System.out.println("  ********* code  *********");
            JSONObject codeForCheck = jsonArray.getJSONObject(0);
            Utils.assertJsonValueEquals("code", "NYE-PRS-406", codeForCheck);

            System.out.println("  ********  description  *********");
            JSONObject descriptionForCheck = jsonArray.getJSONObject(0);
            Utils.assertJsonValueEquals("description", "Pincode Can't be Null or Blank", descriptionForCheck);
        }
        else if(response.getStatusCode()==400){
            System.out.println("Verifying the response body for pinCode API with negative scenerios");
            System.out.println("Verifying the response message for negative scenerios");
            jsonObject = Utils.extractJsonObjectFromResponse(response);
            jsonArray = Utils.extractJsonArrayFromJsonObject(jsonObject, "errors");
            System.out.println("The errors response is " + jsonArray);
            JSONObject messageForCheck = jsonArray.getJSONObject(0);
            Utils.assertJsonValueEquals("message", "Invalid Pincode", messageForCheck);

            System.out.println("  ********* code  *********");
            JSONObject codeForCheck = jsonArray.getJSONObject(0);
            Utils.assertJsonValueEquals("code", "NYE-PRS-202", codeForCheck);

            System.out.println("  ********  description  *********");
            JSONObject descriptionForCheck = jsonArray.getJSONObject(0);
            Utils.assertJsonValueEquals("description", "Pincode Not Found", descriptionForCheck);
        }
        else if(response.getStatusCode() == 406){
            System.out.println("Verifying the response body for pinCode API with negative scenerios");
            System.out.println("Verifying the response message for negative scenerios");
            jsonObject = Utils.extractJsonObjectFromResponse(response);
            jsonArray = Utils.extractJsonArrayFromJsonObject(jsonObject, "errors");
            System.out.println("The errors response is " + jsonArray);
            JSONObject messageForCheck = jsonArray.getJSONObject(0);
            Utils.assertJsonValueEquals("message", "Invalid Pincode", messageForCheck);

            System.out.println("  ********* code  *********");
            JSONObject codeForCheck = jsonArray.getJSONObject(0);
            Utils.assertJsonValueEquals("code", "NYE-PRS-407", codeForCheck);

            System.out.println("  ********  description  *********");
            JSONObject descriptionForCheck = jsonArray.getJSONObject(0);
            Utils.assertJsonValueEquals("description", "Invalid Pincode Format", descriptionForCheck);
        }

    }
}
