package stepdef.CASA;

import base.BaseBuilder;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import org.json.JSONArray;
import org.json.JSONObject;
import utilities.*;

import java.io.FileNotFoundException;
import java.util.HashMap;

import static io.restassured.RestAssured.given;

public class CheckAvailableProducts {


    private final PropertyReader propertyReader = new PropertyReader();

    public RequestSpecification requestSpecification;

    BaseBuilder baseBuilder = new BaseBuilder();
    private String access_token;

    private Response response;

    private JSONObject jsonObject;

    private JSONArray jsonArray;

    @Given("The user pass the token in check-available-products API")
    public void the_user_pass_the_token_in_check_available_products_api() throws FileNotFoundException {
        System.out.println("Login with valid credentials");
        String mobileNumber = propertyReader.getValueFromConfig("casa.user.mobile.number");
        String passcode = propertyReader.getValueFromConfig("casa.user.passcode");
        String deviceId = propertyReader.getValueFromConfig("casa.user.deviceId");
        response = CommonStepDef.login(mobileNumber,passcode,deviceId,deviceId);
        access_token = Utils.getAccessTokenResponseData(response,"access_token");
        System.out.println(response.asPrettyString());
        Utils.verifyStatusCode(response, GlobalConstant.HTTP_OK);
    }
    @When("The user hits the check-available-products API")
    public void the_user_hits_the_check_available_products_api() throws FileNotFoundException {

        String dobForPrs = propertyReader.getValueFromConfig("casa.prs.dob");
        String accountTypeForCheckAvailableProducts = null;
        String payloadForCheckAvailableProducts = JSONPayload.payloadForCheckAvailableProducts(dobForPrs, accountTypeForCheckAvailableProducts);
        String results = CommonStepDef.stringToJsonString(payloadForCheckAvailableProducts);
        System.out.println("The results for encrypted data is " + results);
        HashMap<String, String> data = JSONPayload.payloadForEncryption(results);
        String encryptedPayload = CommonStepDef.encryption(data);
        System.out.println("The payloadForEncryption is " + encryptedPayload);

        requestSpecification = baseBuilder.placeSpecBuilder();
        response = given()
                .header("Authorization", access_token)
                .spec(requestSpecification)
                .body(encryptedPayload)
                .when()
                .post(GlobalConstant.checkAvailableProducts);

        System.out.println("The response is " + response);
        String responseData = Utils.stringToJsonString(response, "results");
        System.out.println("The responseData for check-available-products API is " + responseData);

    }
    @Then("Verify the status code of check-available-products API")
    public void verify_the_status_code_of_check_available_products_api() {
        Utils.verifyStatusCode(response, GlobalConstant.HTTP_OK);
    }
    @Then("The response message should be valid for check-available-products API")
    public void the_response_message_should_be_valid_for_check_available_products_api() {
        System.out.println("Verifying the response message for check-available-products API");
        jsonObject = Utils.extractJsonObjectFromResponse(response);
        Utils.assertJsonValueEquals("message", "Available Products", jsonObject);
    }
    @Then("Response schema should be valid for check-available-products API")
    public void response_schema_should_be_valid_for_check_available_products_api() {
        System.out.println("Verifying the response schema for check available products");
        jsonObject = Utils.extractJsonObjectFromResponse(response);
        Utils.jsonSchemaValidator(response, propertyReader.getValueFromConfig("casa.prs.checkAvailableProducts.schema"));
    }
    @Then("Response body should be valid for check-available-products API")
    public void response_body_should_be_valid_for_check_available_products_api() {
        System.out.println("Verifying the response message for checkAvailableProducts API");
        jsonObject = Utils.extractJsonObjectFromResponse(response);
        System.out.println("The jsonObject is " + jsonObject);
        JSONObject results = Utils.extractNestedJsonObject(jsonObject, "results");
        System.out.println("The results is " + results);
        boolean recommendationsFound = Utils.extractBooleanFromJsonObject(results, "recommendationsFound");
        System.out.println("The recommendationsFound value is " + recommendationsFound);
        Utils.jsonSchemaValidator(response, propertyReader.getValueFromConfig("casa.prs.checkAvailableProducts.schema"));
        Utils.assertBooleanValues(recommendationsFound, true);
    }

    @When("Enter the dob {string} and accountType {string} hit the check-available-products API with negative scenerios")
    public void enter_the_dob_and_account_type_hit_the_check_available_products_api_with_negative_scenerios(String dobForPrs, String accountTypeForCheckAvailableProducts) throws FileNotFoundException {

        String payloadForCheckAvailableProducts = JSONPayload.payloadForCheckAvailableProducts(dobForPrs, accountTypeForCheckAvailableProducts);
        String results = CommonStepDef.stringToJsonString(payloadForCheckAvailableProducts);
        System.out.println("The results for encrypted data is " + results);
        HashMap<String, String> data = JSONPayload.payloadForEncryption(results);
        String encryptedPayload = CommonStepDef.encryption(data);
        System.out.println("The payloadForEncryption is " + encryptedPayload);

        requestSpecification = baseBuilder.placeSpecBuilder();
        response = given()
                .header("Authorization", access_token)
                .spec(requestSpecification)
                .body(encryptedPayload)
                .when()
                .post(GlobalConstant.checkAvailableProducts);

        System.out.println("The response is " + response.asString());
    }
    @Then("Verify the {string} of check-available-products API with negative scenerios")
    public void verify_the_of_check_available_products_api_with_negative_scenerios(String statusCode) {
        Utils.verifyStatusCode(response, Integer.parseInt(statusCode));
    }
    @Then("Verify the response message of check-available-products API with negative scenerios on passing dob {string} and account type {string}")
    public void verify_the_response_message_of_check_available_products_api_with_negative_scenerios_on_passing_dob_and_account_type(String dob, String accountType) {
        if(dob.equals("")){
            System.out.println("Verifying the response message for check-available-products negative scenerios for passing space in DOB");
            jsonObject = Utils.extractJsonObjectFromResponse(response);
            jsonArray = Utils.extractJsonArrayFromJsonObject(jsonObject, "errors");
            System.out.println("The errors response is " + jsonArray);
            JSONObject messageForCheck = jsonArray.getJSONObject(0);
            Utils.assertJsonValueEquals("message", "Invalid Dob", messageForCheck);
        }
        else if(accountType.equals("")){
            System.out.println("Verifying the response body for check-available-products API with negative scenerios");
            System.out.println("Verifying the response message for negative scenerios for passing spaces");
            jsonObject = Utils.extractJsonObjectFromResponse(response);
            jsonArray = Utils.extractJsonArrayFromJsonObject(jsonObject, "errors");
            System.out.println("The errors response is " + jsonArray);
            JSONObject messageForCheck = jsonArray.getJSONObject(0);
            Utils.assertJsonValueEquals("message", "Invalid Account Type", messageForCheck);
        }
        else if(accountType.equals("CA") || accountType.equals("SA")){
            System.out.println("Verifying the response message for check-available-products negative scenerios");
            jsonObject = Utils.extractJsonObjectFromResponse(response);
            jsonArray = Utils.extractJsonArrayFromJsonObject(jsonObject, "errors");
            System.out.println("The errors response is " + jsonArray);
            JSONObject messageForCheck = jsonArray.getJSONObject(0);
            Utils.assertJsonValueEquals("message", "Invalid Field Format ", messageForCheck);
        }
        else if(dob.equals("2001-05-27")){
            System.out.println("Verifying the response message for check-available-products negative scenerios");
            jsonObject = Utils.extractJsonObjectFromResponse(response);
            jsonArray = Utils.extractJsonArrayFromJsonObject(jsonObject, "errors");
            System.out.println("The errors response is " + jsonArray);
            JSONObject messageForCheck = jsonArray.getJSONObject(0);
            Utils.assertJsonValueEquals("message", "Invalid Account Type", messageForCheck);
        }

    }
    @Then("Verify the response schema of check-available-products API with negative scenerios")
    public void verify_the_response_schema_of_check_available_products_api_with_negative_scenerios() {
        System.out.println("Verifying the error response schema for check-available-products API with negative scenerios");
        jsonObject = Utils.extractJsonObjectFromResponse(response);
        System.out.println(jsonObject);
        jsonArray = Utils.extractJsonArrayFromJsonObject(jsonObject, "errors");
        System.out.println("The jsonArray for check-available-products API with negative scenerios is " + jsonArray);
        Utils.jsonSchemaValidator(response, propertyReader.getValueFromConfig("casa.errors.schema"));
    }
    @Then("The response body for check-available-products API should be valid with negative scenerios on passing dob {string} and account type {string}")
    public void the_response_body_for_check_available_products_api_should_be_valid_with_negative_scenerios_on_passing_dob_and_accountType(String dob, String accountType) {
        if(dob.equals("")){
            System.out.println("Verifying the response body for check-available-products API with negative scenerios");
            System.out.println("Verifying the response message for negative scenerios for passing spaces");
            jsonObject = Utils.extractJsonObjectFromResponse(response);
            jsonArray = Utils.extractJsonArrayFromJsonObject(jsonObject, "errors");
            System.out.println("The errors response is " + jsonArray);
            JSONObject messageForCheck = jsonArray.getJSONObject(0);
            Utils.assertJsonValueEquals("message", "Invalid Dob", messageForCheck);

            System.out.println("  ********* code  *********");
            JSONObject codeForCheck = jsonArray.getJSONObject(0);
            Utils.assertJsonValueEquals("code", "NYE-PRS-412", codeForCheck);

            System.out.println("  ********  description  *********");
            JSONObject descriptionForCheck = jsonArray.getJSONObject(0);
            Utils.assertJsonValueEquals("description", "Dob Can't bne null or blank", descriptionForCheck);
        }
        else if(accountType.equals("")){
            System.out.println("Verifying the response body for check-available-products API with negative scenerios");
            System.out.println("Verifying the response message for negative scenerios");
            jsonObject = Utils.extractJsonObjectFromResponse(response);
            jsonArray = Utils.extractJsonArrayFromJsonObject(jsonObject, "errors");
            System.out.println("The errors response is " + jsonArray);
            JSONObject messageForCheck = jsonArray.getJSONObject(0);
            Utils.assertJsonValueEquals("message", "Invalid Account Type", messageForCheck);

            System.out.println("  ********* code  *********");
            JSONObject codeForCheck = jsonArray.getJSONObject(0);
            Utils.assertJsonValueEquals("code", "NYE-PRS-411", codeForCheck);

            System.out.println("  ********  description  *********");
            JSONObject descriptionForCheck = jsonArray.getJSONObject(0);
            Utils.assertJsonValueEquals("description", "Account Type Can only be null or SA/CA", descriptionForCheck);
        }
        else if(accountType.equals("CA") || accountType.equals("SA")){
            System.out.println("Verifying the response body for check-available-products API with negative scenerios");
            System.out.println("Verifying the response message for negative scenerios");
            jsonObject = Utils.extractJsonObjectFromResponse(response);
            jsonArray = Utils.extractJsonArrayFromJsonObject(jsonObject, "errors");
            System.out.println("The errors response is " + jsonArray);
            JSONObject messageForCheck = jsonArray.getJSONObject(0);
            Utils.assertJsonValueEquals("message", "Invalid Field Format ", messageForCheck);

            System.out.println("  ********* code  *********");
            JSONObject codeForCheck = jsonArray.getJSONObject(0);
            Utils.assertJsonValueEquals("code", "NYE-PRS-413", codeForCheck);

            System.out.println("  ********  description  *********");
            JSONObject descriptionForCheck = jsonArray.getJSONObject(0);
            Utils.assertJsonValueEquals("description", "Invalid DOB", descriptionForCheck);
        }
        else if (response.getStatusCode() == 406){
            System.out.println("Verifying the response body for check-available-products API with negative scenerios");
            System.out.println("Verifying the response message for negative scenerios");
            jsonObject = Utils.extractJsonObjectFromResponse(response);
            jsonArray = Utils.extractJsonArrayFromJsonObject(jsonObject, "errors");
            System.out.println("The errors response is " + jsonArray);
            JSONObject messageForCheck = jsonArray.getJSONObject(0);
            Utils.assertJsonValueEquals("message", "Invalid Account Type", messageForCheck);

            System.out.println("  ********* code  *********");
            JSONObject codeForCheck = jsonArray.getJSONObject(0);
            Utils.assertJsonValueEquals("code", "NYE-PRS-411", codeForCheck);

            System.out.println("  ********  description  *********");
            JSONObject descriptionForCheck = jsonArray.getJSONObject(0);
            Utils.assertJsonValueEquals("description", "Account Type Can only be null or SA/CA", descriptionForCheck);
        }

    }

    @Given("The user pass the token in check-available-products API for the under18")
    public void the_user_pass_the_token_in_check_available_products_api_for_the_under() throws FileNotFoundException {
        System.out.println("Login with valid credentials");
        String mobileNumber = propertyReader.getValueFromConfig("casa.user.mobile.number");
        String passcode = propertyReader.getValueFromConfig("casa.user.passcode");
        String deviceId = propertyReader.getValueFromConfig("casa.user.deviceId");
        response = CommonStepDef.login(mobileNumber,passcode,deviceId,deviceId);
        access_token = Utils.getAccessTokenResponseData(response,"access_token");
        System.out.println(response.asPrettyString());
        Utils.verifyStatusCode(response, GlobalConstant.HTTP_OK);
    }
    @When("The user hits the check-available-products API for the under18")
    public void the_user_hits_the_check_available_products_api_for_the_under18() throws FileNotFoundException {
        String dobForPrs = propertyReader.getValueFromConfig("casa.prs.under18.dob");
        String accountTypeForCheckAvailableProducts = null;
        String payloadForCheckAvailableProducts = JSONPayload.payloadForCheckAvailableProducts(dobForPrs, accountTypeForCheckAvailableProducts);
        String results = CommonStepDef.stringToJsonString(payloadForCheckAvailableProducts);
        System.out.println("The results for encrypted data is " + results);
        HashMap<String, String> data = JSONPayload.payloadForEncryption(results);
        String encryptedPayload = CommonStepDef.encryption(data);
        System.out.println("The payloadForEncryption is " + encryptedPayload);

        requestSpecification = baseBuilder.placeSpecBuilder();
        response = given()
                .header("Authorization", access_token)
                .spec(requestSpecification)
                .body(encryptedPayload)
                .when()
                .post(GlobalConstant.checkAvailableProducts);

        System.out.println("The response is " + response);
        String responseData = Utils.stringToJsonString(response, "results");
        System.out.println("The responseData for check-available-products API is " + responseData);
    }
    @Then("Verify the status code of check-available-products API for the under18")
    public void verify_the_status_code_of_check_available_products_api_for_the_under18() {
        Utils.verifyStatusCode(response, GlobalConstant.HTTP_OK);
    }
    @Then("The response message should be valid for check-available-products API for the under18")
    public void the_response_message_should_be_valid_for_check_available_products_api_for_the_under18() {
        System.out.println("Verifying the response message for check-available-products API");
        jsonObject = Utils.extractJsonObjectFromResponse(response);
        Utils.assertJsonValueEquals("message", "Available Products", jsonObject);
    }
    @Then("Response schema should be valid for check-available-products API for the under18")
    public void response_schema_should_be_valid_for_check_available_products_api_for_the_under18() {
        System.out.println("Verifying the response schema for check available products");
        jsonObject = Utils.extractJsonObjectFromResponse(response);
        Utils.jsonSchemaValidator(response, propertyReader.getValueFromConfig("casa.prs.under18.schema"));
    }
    @Then("Response body should be valid for check-available-products API for the under18")
    public void response_body_should_be_valid_for_check_available_products_api_for_the_under18() {
        System.out.println("Verifying the response message for checkAvailableProducts API");
        jsonObject = Utils.extractJsonObjectFromResponse(response);
        System.out.println("The jsonObject is " + jsonObject);
        JSONObject results = Utils.extractNestedJsonObject(jsonObject, "results");
        System.out.println("The results is " + results);
        String recommendationsFound = results.get("recommendationsFound").toString();
        System.out.println("The recommendationsFound value is " + recommendationsFound);
        Utils.assertJsonNullValue(recommendationsFound);
    }

}
