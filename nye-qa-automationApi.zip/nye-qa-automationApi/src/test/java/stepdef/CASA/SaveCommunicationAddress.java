package stepdef.CASA;

import base.BaseBuilder;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import org.json.JSONArray;
import org.json.JSONObject;
import utilities.*;

import java.io.FileNotFoundException;
import java.util.HashMap;

import static io.restassured.RestAssured.given;

public class SaveCommunicationAddress {


    private final PropertyReader propertyReader = new PropertyReader();

    public RequestSpecification requestSpecification;

    BaseBuilder baseBuilder = new BaseBuilder();
    private String access_token;

    private Response response;

    private JSONObject jsonObject;


    private JSONArray jsonArray;

    @Given("Pass the token in saveCommunicationAddress API")
    public void pass_the_token_in_save_communication_address_api() throws FileNotFoundException {
        System.out.println("Login with valid credentials");
        String mobileNumber = propertyReader.getValueFromConfig("casa.user.mobile.number");
        String passcode = propertyReader.getValueFromConfig("casa.user.passcode");
        String deviceId = propertyReader.getValueFromConfig("casa.user.deviceId");
        response = CommonStepDef.login(mobileNumber,passcode,deviceId,deviceId);
        access_token = Utils.getAccessTokenResponseData(response,"access_token");
        System.out.println(response.asPrettyString());
        Utils.verifyStatusCode(response, GlobalConstant.HTTP_OK);
    }
    @When("Fill the valid address in line1 and line2 with pinCode, city and state then hit the saveCommunicationAddress API")
    public void fill_the_valid_address_in_line1_and_line2_with_pin_code_city_and_state_then_hit_the_save_communication_address_api() throws FileNotFoundException {
        String addressLine1= propertyReader.getValueFromConfig("casa.prs.address.line1");
        String addressLine2=propertyReader.getValueFromConfig("casa.prs.address.line2");
        String pinCode = propertyReader.getValueFromConfig("casa.prs.address.pincode");
        String city = propertyReader.getValueFromConfig("casa.prs.address.city");
        String state = propertyReader.getValueFromConfig("casa.prs.address.state");

        String payloadForSavingCommunicationAddress = JSONPayload.payloadForSavingCommunicationAddress(addressLine1, addressLine2, city, pinCode, state);
        String results = CommonStepDef.stringToJsonString(payloadForSavingCommunicationAddress);
        System.out.println("The results for encrypted data is " + results);
        HashMap<String, String> data = JSONPayload.payloadForEncryption(results);
        String encryptedPayload = CommonStepDef.encryption(data);
        System.out.println("The payloadForEncryption is " + encryptedPayload);
        requestSpecification = baseBuilder.placeSpecBuilder();
        response = given()
                .header("Authorization", access_token)
                .spec(requestSpecification)
                .body(encryptedPayload)
                .when()
                .log().all()
                .post(GlobalConstant.saveCommunicationAddressAPI);

        System.out.println("The response is " + response);
        String responseData = Utils.stringToJsonString(response, "results");
        System.out.println("The responseData for panValidation API is " + responseData);
    }
    @Then("Verify the status code of saveCommunicationAddress API")
    public void verify_the_status_code_of_save_communication_address_api() {
        Utils.verifyStatusCode(response, GlobalConstant.HTTP_OK);
    }
    @Then("Verify the response message of saveCommunicationAddress API")
    public void verify_the_response_message_of_save_communication_address_api() {
        System.out.println("Verifying the response message for saveCommunication Address API");
        jsonObject = Utils.extractJsonObjectFromResponse(response);
        Utils.assertJsonValueEquals("message", "Communication Data Saved Successfully", jsonObject);
    }
    @Then("Verify the response schema of saveCommunicationAddress API")
    public void verify_the_response_schema_of_save_communication_address_api() {
        System.out.println("Verifying the response schema for saveCommunication Address API");
        jsonObject = Utils.extractJsonObjectFromResponse(response);
        Utils.jsonSchemaValidator(response, propertyReader.getValueFromConfig("casa.prs.saveCommunicationAddress.schema"));
    }
    @Then("The response body for saveCommunicationAddress API should be valid")
    public void the_response_body_for_save_communication_address_api_should_be_valid() {
        System.out.println("Verifying the response message for saveCommunication Address API");
        jsonObject = Utils.extractJsonObjectFromResponse(response);
        System.out.println("The jsonObject is " + jsonObject);
        JSONObject results = Utils.extractNestedJsonObject(jsonObject, "results");
        System.out.println("The results is " + results);
        boolean storedInDb = Utils.extractBooleanFromJsonObject(results, "storedInDb");
        System.out.println("The storedIdDb value is " + storedInDb);
        Utils.jsonSchemaValidator(response, propertyReader.getValueFromConfig("casa.prs.saveCommunicationAddress.schema"));
        Utils.assertBooleanValues(storedInDb, true);
    }


    @When("Fill the valid address in line1 {string} and line2 {string} with pinCode {string}, city {string} and state {string} then hit the saveCommunicationAddress API")
    public void fill_the_valid_address_in_line1_and_line2_with_pin_code_city_and_state_uttar_pradesh_then_hit_the_save_communication_address_api(String addressLine1, String addressLine2, String pinCode, String city, String state) throws FileNotFoundException {

        String payloadForSavingCommunicationAddress = JSONPayload.payloadForSavingCommunicationAddress(addressLine1, addressLine2, city, pinCode, state);
        String results = CommonStepDef.stringToJsonString(payloadForSavingCommunicationAddress);
        System.out.println("The results for encrypted data is " + results);
        HashMap<String, String> data = JSONPayload.payloadForEncryption(results);
        String encryptedPayload = CommonStepDef.encryption(data);
        System.out.println("The payloadForEncryption is " + encryptedPayload);
        requestSpecification = baseBuilder.placeSpecBuilder();
        response = given()
                .header("Authorization", access_token)
                .spec(requestSpecification)
                .body(encryptedPayload)
                .when()
                .log().all()
                .post(GlobalConstant.saveCommunicationAddressAPI);

        System.out.println("The response is " + response.asString());


    }

    @Then("Verify the status code {string} of saveCommunicationAddress API with negative scenerios")
    public void verify_the_status_code_of_save_communication_address_api_with_negative_scenerios(String statusCode) {
        Utils.verifyStatusCode(response, Integer.parseInt(statusCode));
    }

    @Then("Verify the response message of saveCommunicationAddress API on passing address in line1 {string} and line2 {string} with pinCode {string}, city {string} and state {string}")
    public void verify_the_response_message_of_save_communication_address_api_with_negative_scenerios(String addressLine1, String addressLine2, String pinCode, String city, String state) {
        String correctAddressLine1 = propertyReader.getValueFromConfig("casa.prs.addressLine1");
        String correctAddressLine2 = propertyReader.getValueFromConfig("casa.prs.addressLine2");
        String correctCity = propertyReader.getValueFromConfig("casa.prs.city");
        String wrongPinCode = propertyReader.getValueFromConfig("casa.prs.saveAddress.wrongPinCode");
        String wrongCity = propertyReader.getValueFromConfig("casa.prs.saveAddress.wrongCity");
        String addressLine1ForMaxLength = propertyReader.getValueFromConfig("casa.prs.addressLine1.maxLength");
        String addressLine1WithSpecialChars = propertyReader.getValueFromConfig("casa.prs.addressLine1.withSpecialChars");
        String addressLine1OnlySpecialChars = propertyReader.getValueFromConfig("casa.prs.addressLine1.specialChars");
        String addressLine2ForMaxLength = propertyReader.getValueFromConfig("casa.prs.addressLine2.maxLength");
        String addressLine2WithSpecialChars = propertyReader.getValueFromConfig("casa.prs.addressLine2.withSpecialChars");
        String addressLine2OnlySpecialChars = propertyReader.getValueFromConfig("casa.prs.addressLine2.specialChars");
        String correctState = propertyReader.getValueFromConfig("casa.prs.saveAddress.state");
        String numberState = propertyReader.getValueFromConfig("casa.prs.saveAddress.numberState");
        String specialCharState = propertyReader.getValueFromConfig("casa.prs.saveAddress.specialCharState");
        if (addressLine1.equals("")){
            jsonObject = Utils.extractJsonObjectFromResponse(response);
            jsonArray = Utils.extractJsonArrayFromJsonObject(jsonObject, "errors");
            System.out.println("The errors response is " + jsonArray);
            JSONObject messageForCheck = jsonArray.getJSONObject(0);
            Utils.assertJsonValueEquals("message", "Invalid Address", messageForCheck);
        }
        else if (addressLine2.equals("")){
            jsonObject = Utils.extractJsonObjectFromResponse(response);
            jsonArray = Utils.extractJsonArrayFromJsonObject(jsonObject, "errors");
            System.out.println("The errors response is " + jsonArray);
            JSONObject messageForCheck = jsonArray.getJSONObject(0);
            Utils.assertJsonValueEquals("message", "Invalid Address", messageForCheck);
        }
        else if (pinCode.equals("")){
            jsonObject = Utils.extractJsonObjectFromResponse(response);
            jsonArray = Utils.extractJsonArrayFromJsonObject(jsonObject, "errors");
            System.out.println("The errors response is " + jsonArray);
            JSONObject messageForCheck = jsonArray.getJSONObject(0);
            Utils.assertJsonValueEquals("message", "Invalid Pincode", messageForCheck);
        }
        else if (city.equals("")){
            jsonObject = Utils.extractJsonObjectFromResponse(response);
            jsonArray = Utils.extractJsonArrayFromJsonObject(jsonObject, "errors");
            System.out.println("The errors response is " + jsonArray);
            JSONObject messageForCheck = jsonArray.getJSONObject(0);
            Utils.assertJsonValueEquals("message", "Invalid City", messageForCheck);
        }
        else if (state.equals("")){
            jsonObject = Utils.extractJsonObjectFromResponse(response);
            jsonArray = Utils.extractJsonArrayFromJsonObject(jsonObject, "errors");
            System.out.println("The errors response is " + jsonArray);
            JSONObject messageForCheck = jsonArray.getJSONObject(0);
            Utils.assertJsonValueEquals("message", "Invalid State", messageForCheck);
        }
        else if (addressLine1.equals(addressLine1ForMaxLength)){
            jsonObject = Utils.extractJsonObjectFromResponse(response);
            jsonArray = Utils.extractJsonArrayFromJsonObject(jsonObject, "errors");
            System.out.println("The errors response is " + jsonArray);
            JSONObject messageForCheck = jsonArray.getJSONObject(0);
            Utils.assertJsonValueEquals("message", "Invalid Field Format", messageForCheck);
        }
        else if (addressLine1.equals(addressLine1WithSpecialChars)){
            jsonObject = Utils.extractJsonObjectFromResponse(response);
            jsonArray = Utils.extractJsonArrayFromJsonObject(jsonObject, "errors");
            System.out.println("The errors response is " + jsonArray);
            JSONObject messageForCheck = jsonArray.getJSONObject(0);
            Utils.assertJsonValueEquals("message", "Invalid Field Format", messageForCheck);
        }
        else if (addressLine1.equals(addressLine1OnlySpecialChars)){
            jsonObject = Utils.extractJsonObjectFromResponse(response);
            jsonArray = Utils.extractJsonArrayFromJsonObject(jsonObject, "errors");
            System.out.println("The errors response is " + jsonArray);
            JSONObject messageForCheck = jsonArray.getJSONObject(0);
            Utils.assertJsonValueEquals("message", "Invalid Field Format", messageForCheck);
        }
        else if (addressLine2.equals(addressLine2ForMaxLength)){
            jsonObject = Utils.extractJsonObjectFromResponse(response);
            jsonArray = Utils.extractJsonArrayFromJsonObject(jsonObject, "errors");
            System.out.println("The errors response is " + jsonArray);
            JSONObject messageForCheck = jsonArray.getJSONObject(0);
            Utils.assertJsonValueEquals("message", "Invalid Field Format", messageForCheck);
        }
        else if (addressLine2.equals(addressLine2WithSpecialChars)){
            jsonObject = Utils.extractJsonObjectFromResponse(response);
            jsonArray = Utils.extractJsonArrayFromJsonObject(jsonObject, "errors");
            System.out.println("The errors response is " + jsonArray);
            JSONObject messageForCheck = jsonArray.getJSONObject(0);
            Utils.assertJsonValueEquals("message", "Invalid Field Format", messageForCheck);
        }
        else if (addressLine2.equals(addressLine2OnlySpecialChars)){
            jsonObject = Utils.extractJsonObjectFromResponse(response);
            jsonArray = Utils.extractJsonArrayFromJsonObject(jsonObject, "errors");
            System.out.println("The errors response is " + jsonArray);
            JSONObject messageForCheck = jsonArray.getJSONObject(0);
            Utils.assertJsonValueEquals("message", "Invalid Field Format", messageForCheck);
        }
        else if (addressLine1.equals(correctAddressLine1) && addressLine2.equals(correctAddressLine2) && city.equals(correctCity)){
            jsonObject = Utils.extractJsonObjectFromResponse(response);
            jsonArray = Utils.extractJsonArrayFromJsonObject(jsonObject, "errors");
            System.out.println("The errors response is " + jsonArray);
            JSONObject messageForCheck = jsonArray.getJSONObject(0);
            Utils.assertJsonValueEquals("message", "Invalid Pincode", messageForCheck);
        }
        else if (pinCode.equals(wrongPinCode) && city.equals(wrongCity)){
            jsonObject = Utils.extractJsonObjectFromResponse(response);
            jsonArray = Utils.extractJsonArrayFromJsonObject(jsonObject, "errors");
            System.out.println("The errors response is " + jsonArray);
            JSONObject messageForCheck = jsonArray.getJSONObject(0);
            Utils.assertJsonValueEquals("message", "Invalid City", messageForCheck);
        }
        else if (state.equals(correctState)){
            jsonObject = Utils.extractJsonObjectFromResponse(response);
            jsonArray = Utils.extractJsonArrayFromJsonObject(jsonObject, "errors");
            System.out.println("The errors response is " + jsonArray);
            JSONObject messageForCheck = jsonArray.getJSONObject(0);
            Utils.assertJsonValueEquals("message", "Invalid State", messageForCheck);
        }
        else if (state.equals(numberState)){
            jsonObject = Utils.extractJsonObjectFromResponse(response);
            jsonArray = Utils.extractJsonArrayFromJsonObject(jsonObject, "errors");
            System.out.println("The errors response is " + jsonArray);
            JSONObject messageForCheck = jsonArray.getJSONObject(0);
            Utils.assertJsonValueEquals("message", "Invalid Field Format", messageForCheck);
        }
        else if (state.equals(specialCharState)){
            jsonObject = Utils.extractJsonObjectFromResponse(response);
            jsonArray = Utils.extractJsonArrayFromJsonObject(jsonObject, "errors");
            System.out.println("The errors response is " + jsonArray);
            JSONObject messageForCheck = jsonArray.getJSONObject(0);
            Utils.assertJsonValueEquals("message", "Invalid Field Format", messageForCheck);
        }
    }

    @Then("Verify the response schema of saveCommunicationAddress API with negative scenerios")
    public void verify_the_response_schema_of_save_communication_address_api_with_negative_scenerios() {
        System.out.println("Verifying the error response schema for save-communication-address API with negative scenerios");
        jsonObject = Utils.extractJsonObjectFromResponse(response);
        System.out.println(jsonObject);
        jsonArray = Utils.extractJsonArrayFromJsonObject(jsonObject, "errors");
        System.out.println("The jsonArray for save-communication-address API with negative scenerios is " + jsonArray);
        Utils.jsonSchemaValidator(response, propertyReader.getValueFromConfig("casa.errors.schema"));
    }

    @Then("The response body for saveCommunicationAddress API should be valid on passing address in line1 {string} and line2 {string} with pinCode {string}, city {string} and state {string}")
    public void the_response_body_for_save_communication_address_api_should_be_valid_with_negative_scenerios(String addressLine1, String addressLine2, String pinCode, String city, String state) {
        System.out.println("Verifying the response body for save-communication-address API");
        String correctAddressLine1 = propertyReader.getValueFromConfig("casa.prs.addressLine1");
        String correctAddressLine2 = propertyReader.getValueFromConfig("casa.prs.addressLine2");
        String correctCity = propertyReader.getValueFromConfig("casa.prs.city");
        String wrongPinCode = propertyReader.getValueFromConfig("casa.prs.saveAddress.wrongPinCode");
        String wrongCity = propertyReader.getValueFromConfig("casa.prs.saveAddress.wrongCity");
        String addressLine1ForMaxLength = propertyReader.getValueFromConfig("casa.prs.addressLine1.maxLength");
        String addressLine1WithSpecialChars = propertyReader.getValueFromConfig("casa.prs.addressLine1.withSpecialChars");
        String addressLine1OnlySpecialChars = propertyReader.getValueFromConfig("casa.prs.addressLine1.specialChars");
        String addressLine2ForMaxLength = propertyReader.getValueFromConfig("casa.prs.addressLine2.maxLength");
        String addressLine2WithSpecialChars = propertyReader.getValueFromConfig("casa.prs.addressLine2.withSpecialChars");
        String addressLine2OnlySpecialChars = propertyReader.getValueFromConfig("casa.prs.addressLine2.specialChars");
        String correctState = propertyReader.getValueFromConfig("casa.prs.saveAddress.state");
        String numberState = propertyReader.getValueFromConfig("casa.prs.saveAddress.numberState");
        String specialCharState = propertyReader.getValueFromConfig("casa.prs.saveAddress.specialCharState");

        if(addressLine1.equals("")){
        jsonObject = Utils.extractJsonObjectFromResponse(response);
        jsonArray = Utils.extractJsonArrayFromJsonObject(jsonObject, "errors");
        System.out.println("The errors response is " + jsonArray);
        JSONObject messageForCheck = jsonArray.getJSONObject(0);
        Utils.assertJsonValueEquals("message", "Invalid Address", messageForCheck);

        System.out.println("  ********* code  *********");
        JSONObject codeForCheck = jsonArray.getJSONObject(0);
        Utils.assertJsonValueEquals("code", "NYE-PRS-408", codeForCheck);

        System.out.println("  ********  description  *********");
        JSONObject descriptionForCheck = jsonArray.getJSONObject(0);
        Utils.assertJsonValueEquals("description", "Address Line Can't be Null or Blank", descriptionForCheck);

        }
        else if (addressLine2.equals("")){
            jsonObject = Utils.extractJsonObjectFromResponse(response);
            jsonArray = Utils.extractJsonArrayFromJsonObject(jsonObject, "errors");
            System.out.println("The errors response is " + jsonArray);
            JSONObject messageForCheck = jsonArray.getJSONObject(0);
            Utils.assertJsonValueEquals("message", "Invalid Address", messageForCheck);

            System.out.println("  ********* code  *********");
            JSONObject codeForCheck = jsonArray.getJSONObject(0);
            Utils.assertJsonValueEquals("code", "NYE-PRS-408", codeForCheck);

            System.out.println("  ********  description  *********");
            JSONObject descriptionForCheck = jsonArray.getJSONObject(0);
            Utils.assertJsonValueEquals("description", "Address Line Can't be Null or Blank", descriptionForCheck);
        }
        else if (pinCode.equals("")){
            jsonObject = Utils.extractJsonObjectFromResponse(response);
            jsonArray = Utils.extractJsonArrayFromJsonObject(jsonObject, "errors");
            System.out.println("The errors response is " + jsonArray);
            JSONObject messageForCheck = jsonArray.getJSONObject(0);
            Utils.assertJsonValueEquals("message", "Invalid Pincode", messageForCheck);

            System.out.println("  ********* code  *********");
            JSONObject codeForCheck = jsonArray.getJSONObject(0);
            Utils.assertJsonValueEquals("code", "NYE-PRS-406", codeForCheck);

            System.out.println("  ********  description  *********");
            JSONObject descriptionForCheck = jsonArray.getJSONObject(0);
            Utils.assertJsonValueEquals("description", "Pincode Can't be Null or Blank", descriptionForCheck);
        }
        else if (city.equals("")){
            jsonObject = Utils.extractJsonObjectFromResponse(response);
            jsonArray = Utils.extractJsonArrayFromJsonObject(jsonObject, "errors");
            System.out.println("The errors response is " + jsonArray);
            JSONObject messageForCheck = jsonArray.getJSONObject(0);
            Utils.assertJsonValueEquals("message", "Invalid City", messageForCheck);

            System.out.println("  ********* code  *********");
            JSONObject codeForCheck = jsonArray.getJSONObject(0);
            Utils.assertJsonValueEquals("code", "NYE-PRS-409", codeForCheck);

            System.out.println("  ********  description  *********");
            JSONObject descriptionForCheck = jsonArray.getJSONObject(0);
            Utils.assertJsonValueEquals("description", "City Can't be Null or Blank", descriptionForCheck);
        }
        else if (state.equals("")){
            jsonObject = Utils.extractJsonObjectFromResponse(response);
            jsonArray = Utils.extractJsonArrayFromJsonObject(jsonObject, "errors");
            System.out.println("The errors response is " + jsonArray);
            JSONObject messageForCheck = jsonArray.getJSONObject(0);
            Utils.assertJsonValueEquals("message", "Invalid State", messageForCheck);

            System.out.println("  ********* code  *********");
            JSONObject codeForCheck = jsonArray.getJSONObject(0);
            Utils.assertJsonValueEquals("code", "NYE-PRS-410", codeForCheck);

            System.out.println("  ********  description  *********");
            JSONObject descriptionForCheck = jsonArray.getJSONObject(0);
            Utils.assertJsonValueEquals("description", "State Can't be Null or Blank", descriptionForCheck);
        }
        else if (addressLine1.equals(addressLine1ForMaxLength)){
            jsonObject = Utils.extractJsonObjectFromResponse(response);
            jsonArray = Utils.extractJsonArrayFromJsonObject(jsonObject, "errors");
            System.out.println("The errors response is " + jsonArray);
            JSONObject messageForCheck = jsonArray.getJSONObject(0);
            Utils.assertJsonValueEquals("message", "Invalid Field Format", messageForCheck);

            System.out.println("  ********* code  *********");
            JSONObject codeForCheck = jsonArray.getJSONObject(0);
            Utils.assertJsonValueEquals("code", "NYE-PRS-415", codeForCheck);

            System.out.println("  ********  description  *********");
            JSONObject descriptionForCheck = jsonArray.getJSONObject(0);
            Utils.assertJsonValueEquals("description", "Invalid AddressLine1 Field Format Or Length", descriptionForCheck);
        }
        else if (addressLine1.equals(addressLine1WithSpecialChars)){
            jsonObject = Utils.extractJsonObjectFromResponse(response);
            jsonArray = Utils.extractJsonArrayFromJsonObject(jsonObject, "errors");
            System.out.println("The errors response is " + jsonArray);
            JSONObject messageForCheck = jsonArray.getJSONObject(0);
            Utils.assertJsonValueEquals("message", "Invalid Field Format", messageForCheck);

            System.out.println("  ********* code  *********");
            JSONObject codeForCheck = jsonArray.getJSONObject(0);
            Utils.assertJsonValueEquals("code", "NYE-PRS-415", codeForCheck);

            System.out.println("  ********  description  *********");
            JSONObject descriptionForCheck = jsonArray.getJSONObject(0);
            Utils.assertJsonValueEquals("description", "Invalid AddressLine1 Field Format Or Length", descriptionForCheck);
        }
        else if (addressLine1.equals(addressLine1OnlySpecialChars)){
            jsonObject = Utils.extractJsonObjectFromResponse(response);
            jsonArray = Utils.extractJsonArrayFromJsonObject(jsonObject, "errors");
            System.out.println("The errors response is " + jsonArray);
            JSONObject messageForCheck = jsonArray.getJSONObject(0);
            Utils.assertJsonValueEquals("message", "Invalid Field Format", messageForCheck);

            System.out.println("  ********* code  *********");
            JSONObject codeForCheck = jsonArray.getJSONObject(0);
            Utils.assertJsonValueEquals("code", "NYE-PRS-415", codeForCheck);

            System.out.println("  ********  description  *********");
            JSONObject descriptionForCheck = jsonArray.getJSONObject(0);
            Utils.assertJsonValueEquals("description", "Invalid AddressLine1 Field Format Or Length", descriptionForCheck);
        }
        else if (addressLine2.equals(addressLine2ForMaxLength)){
            jsonObject = Utils.extractJsonObjectFromResponse(response);
            jsonArray = Utils.extractJsonArrayFromJsonObject(jsonObject, "errors");
            System.out.println("The errors response is " + jsonArray);
            JSONObject messageForCheck = jsonArray.getJSONObject(0);
            Utils.assertJsonValueEquals("message", "Invalid Field Format", messageForCheck);

            System.out.println("  ********* code  *********");
            JSONObject codeForCheck = jsonArray.getJSONObject(0);
            Utils.assertJsonValueEquals("code", "NYE-PRS-420", codeForCheck);

            System.out.println("  ********  description  *********");
            JSONObject descriptionForCheck = jsonArray.getJSONObject(0);
            Utils.assertJsonValueEquals("description", "Invalid AddressLine2 Field Format Or Length", descriptionForCheck);
        }
        else if (addressLine2.equals(addressLine2WithSpecialChars)){
            jsonObject = Utils.extractJsonObjectFromResponse(response);
            jsonArray = Utils.extractJsonArrayFromJsonObject(jsonObject, "errors");
            System.out.println("The errors response is " + jsonArray);
            JSONObject messageForCheck = jsonArray.getJSONObject(0);
            Utils.assertJsonValueEquals("message", "Invalid Field Format", messageForCheck);

            System.out.println("  ********* code  *********");
            JSONObject codeForCheck = jsonArray.getJSONObject(0);
            Utils.assertJsonValueEquals("code", "NYE-PRS-420", codeForCheck);

            System.out.println("  ********  description  *********");
            JSONObject descriptionForCheck = jsonArray.getJSONObject(0);
            Utils.assertJsonValueEquals("description", "Invalid AddressLine2 Field Format Or Length", descriptionForCheck);

        }
        else if (addressLine2.equals(addressLine2OnlySpecialChars)){
            jsonObject = Utils.extractJsonObjectFromResponse(response);
            jsonArray = Utils.extractJsonArrayFromJsonObject(jsonObject, "errors");
            System.out.println("The errors response is " + jsonArray);
            JSONObject messageForCheck = jsonArray.getJSONObject(0);
            Utils.assertJsonValueEquals("message", "Invalid Field Format", messageForCheck);

            System.out.println("  ********* code  *********");
            JSONObject codeForCheck = jsonArray.getJSONObject(0);
            Utils.assertJsonValueEquals("code", "NYE-PRS-420", codeForCheck);

            System.out.println("  ********  description  *********");
            JSONObject descriptionForCheck = jsonArray.getJSONObject(0);
            Utils.assertJsonValueEquals("description", "Invalid AddressLine2 Field Format Or Length", descriptionForCheck);
        }
        else if (addressLine1.equals(correctAddressLine1) && addressLine2.equals(correctAddressLine2) && city.equals(correctCity)){
            jsonObject = Utils.extractJsonObjectFromResponse(response);
            jsonArray = Utils.extractJsonArrayFromJsonObject(jsonObject, "errors");
            System.out.println("The errors response is " + jsonArray);
            JSONObject messageForCheck = jsonArray.getJSONObject(0);
            Utils.assertJsonValueEquals("message", "Invalid Pincode", messageForCheck);

            System.out.println("  ********* code  *********");
            JSONObject codeForCheck = jsonArray.getJSONObject(0);
            Utils.assertJsonValueEquals("code", "NYE-PRS-407", codeForCheck);

            System.out.println("  ********  description  *********");
            JSONObject descriptionForCheck = jsonArray.getJSONObject(0);
            Utils.assertJsonValueEquals("description", "Invalid Pincode Format", descriptionForCheck);

        }
        else if (pinCode.equals(wrongPinCode) && city.equals(wrongCity)){
            jsonObject = Utils.extractJsonObjectFromResponse(response);
            jsonArray = Utils.extractJsonArrayFromJsonObject(jsonObject, "errors");
            System.out.println("The errors response is " + jsonArray);
            JSONObject messageForCheck = jsonArray.getJSONObject(0);
            Utils.assertJsonValueEquals("message", "Invalid City", messageForCheck);

            System.out.println("  ********* code  *********");
            JSONObject codeForCheck = jsonArray.getJSONObject(0);
            Utils.assertJsonValueEquals("code", "NYE-PRS-423", codeForCheck);

            System.out.println("  ********  description  *********");
            JSONObject descriptionForCheck = jsonArray.getJSONObject(0);
            Utils.assertJsonValueEquals("description", "City And Pincode Don't Match", descriptionForCheck);

        }
        else if (state.equals(correctState)){
            jsonObject = Utils.extractJsonObjectFromResponse(response);
            jsonArray = Utils.extractJsonArrayFromJsonObject(jsonObject, "errors");
            System.out.println("The errors response is " + jsonArray);
            JSONObject messageForCheck = jsonArray.getJSONObject(0);
            Utils.assertJsonValueEquals("message", "Invalid State", messageForCheck);

            System.out.println("  ********* code  *********");
            JSONObject codeForCheck = jsonArray.getJSONObject(0);
            Utils.assertJsonValueEquals("code", "NYE-PRS-424", codeForCheck);

            System.out.println("  ********  description  *********");
            JSONObject descriptionForCheck = jsonArray.getJSONObject(0);
            Utils.assertJsonValueEquals("description", "State And Pincode Don't Match", descriptionForCheck);

        }
        else if (state.equals(numberState)){
            jsonObject = Utils.extractJsonObjectFromResponse(response);
            jsonArray = Utils.extractJsonArrayFromJsonObject(jsonObject, "errors");
            System.out.println("The errors response is " + jsonArray);
            JSONObject messageForCheck = jsonArray.getJSONObject(0);
            Utils.assertJsonValueEquals("message", "Invalid Field Format", messageForCheck);

            System.out.println("  ********* code  *********");
            JSONObject codeForCheck = jsonArray.getJSONObject(0);
            Utils.assertJsonValueEquals("code", "NYE-PRS-419", codeForCheck);

            System.out.println("  ********  description  *********");
            JSONObject descriptionForCheck = jsonArray.getJSONObject(0);
            Utils.assertJsonValueEquals("description", "Invalid State Field Format Or Length", descriptionForCheck);

        }
        else if (state.equals(specialCharState)){
            jsonObject = Utils.extractJsonObjectFromResponse(response);
            jsonArray = Utils.extractJsonArrayFromJsonObject(jsonObject, "errors");
            System.out.println("The errors response is " + jsonArray);
            JSONObject messageForCheck = jsonArray.getJSONObject(0);
            Utils.assertJsonValueEquals("message", "Invalid Field Format", messageForCheck);

            System.out.println("  ********* code  *********");
            JSONObject codeForCheck = jsonArray.getJSONObject(0);
            Utils.assertJsonValueEquals("code", "NYE-PRS-419", codeForCheck);

            System.out.println("  ********  description  *********");
            JSONObject descriptionForCheck = jsonArray.getJSONObject(0);
            Utils.assertJsonValueEquals("description", "Invalid State Field Format Or Length", descriptionForCheck);

        }
        else if (addressLine1.isEmpty()){
            jsonObject = Utils.extractJsonObjectFromResponse(response);
            jsonArray = Utils.extractJsonArrayFromJsonObject(jsonObject, "errors");
            System.out.println("The errors response is " + jsonArray);
            JSONObject messageForCheck = jsonArray.getJSONObject(0);
            Utils.assertJsonValueEquals("message", "Invalid Address", messageForCheck);

            System.out.println("  ********* code  *********");
            JSONObject codeForCheck = jsonArray.getJSONObject(0);
            Utils.assertJsonValueEquals("code", "NYE-PRS-408", codeForCheck);

            System.out.println("  ********  description  *********");
            JSONObject descriptionForCheck = jsonArray.getJSONObject(0);
            Utils.assertJsonValueEquals("description", "Address Line Can't be Null or Blank", descriptionForCheck);
        }
        else if (addressLine2.isEmpty()){
            jsonObject = Utils.extractJsonObjectFromResponse(response);
            jsonArray = Utils.extractJsonArrayFromJsonObject(jsonObject, "errors");
            System.out.println("The errors response is " + jsonArray);
            JSONObject messageForCheck = jsonArray.getJSONObject(0);
            Utils.assertJsonValueEquals("message", "Invalid Address", messageForCheck);

            System.out.println("  ********* code  *********");
            JSONObject codeForCheck = jsonArray.getJSONObject(0);
            Utils.assertJsonValueEquals("code", "NYE-PRS-408", codeForCheck);

            System.out.println("  ********  description  *********");
            JSONObject descriptionForCheck = jsonArray.getJSONObject(0);
            Utils.assertJsonValueEquals("description", "Address Line Can't be Null or Blank", descriptionForCheck);
        }
        else if (city.isEmpty()){
            jsonObject = Utils.extractJsonObjectFromResponse(response);
            jsonArray = Utils.extractJsonArrayFromJsonObject(jsonObject, "errors");
            System.out.println("The errors response is " + jsonArray);
            JSONObject messageForCheck = jsonArray.getJSONObject(0);
            Utils.assertJsonValueEquals("message", "Invalid City", messageForCheck);

            System.out.println("  ********* code  *********");
            JSONObject codeForCheck = jsonArray.getJSONObject(0);
            Utils.assertJsonValueEquals("code", "NYE-PRS-409", codeForCheck);

            System.out.println("  ********  description  *********");
            JSONObject descriptionForCheck = jsonArray.getJSONObject(0);
            Utils.assertJsonValueEquals("description", "City Can't be Null or Blank", descriptionForCheck);
        }
        else if (state.isEmpty()){
            jsonObject = Utils.extractJsonObjectFromResponse(response);
            jsonArray = Utils.extractJsonArrayFromJsonObject(jsonObject, "errors");
            System.out.println("The errors response is " + jsonArray);
            JSONObject messageForCheck = jsonArray.getJSONObject(0);
            Utils.assertJsonValueEquals("message", "Invalid State", messageForCheck);

            System.out.println("  ********* code  *********");
            JSONObject codeForCheck = jsonArray.getJSONObject(0);

            Utils.assertJsonValueEquals("code", "NYE-PRS-410", codeForCheck);
            System.out.println("  ********  description  *********");
            JSONObject descriptionForCheck = jsonArray.getJSONObject(0);
            Utils.assertJsonValueEquals("description", "State Can't be Null or Blank", descriptionForCheck);
        }
    }
}
