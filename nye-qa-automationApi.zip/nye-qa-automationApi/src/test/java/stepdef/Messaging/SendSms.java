package stepdef.Messaging;

import base.BaseBuilder;
import io.cucumber.java.en.*;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import org.json.JSONObject;
import resources.SendSmsPayload;
import utilities.*;
import java.io.FileNotFoundException;
import java.util.HashMap;
import static utilities.Utils.*;

public class SendSms {

    private static RequestSpecification reqspec;
    private static BaseBuilder baseBuilder = new BaseBuilder();
    private Response response;
    private JSONObject responseObject;
    private JSONObject extractedResponse;
    private PropertyReader reader = new PropertyReader();
    private  HashMap<String, Object> sendSmsPayload;
    private  SendSmsPayload sendSms = new SendSmsPayload();


    @Given("I have a valid phone number and message content")
    public void i_have_a_valid_phone_number_and_message_content() {
        sendSms.setReceiverAddress(reader.getValueFromConfig("messaging.validReceiverAddress"));
        sendSms.setTemplateName(reader.getValueFromConfig("messaging.templateName"));
        sendSms.setFirstName(reader.getValueFromConfig("messaging.FirstName"));
        sendSms.setVkyc(reader.getValueFromConfig("messaging.vKYC"));
        sendSms.setPreferredLanguage(reader.getValueFromConfig("messaging.preferredLanguage"));
        sendSms.setCallingService(reader.getValueFromConfig("messaging.callingService"));
        sendSms.setDomain(reader.getValueFromConfig("messaging.domain"));
        sendSmsPayload  = JSONPayload.getSendSmsPayload(sendSms);
    }
    @When("I hit the send sms API")
    public void i_hit_the_send_sms_api() throws FileNotFoundException {
        reqspec = baseBuilder.placeSpecBuilder();
        reqspec = RestAssured.given().spec(reqspec).body(sendSmsPayload);
        response = reqspec.post(GlobalConstant.sendSmsEndpoint);
    }
    @Then("The SMS should be sent successfully")
    public void the_sms_should_be_sent_successfully() {
        responseObject =  extractJsonObjectFromResponse(response);
        verifyStatusCode(response,GlobalConstant.HTTP_OK);
        assertJsonValueEquals("message","Success", responseObject);
        jsonSchemaValidator(response,reader.getValueFromConfig("messaging.validSmsResponseSchemaFilePath"));
    }
    @Given("I have a invalid mobile number and valid message content")
    public void i_have_a_invalid_mobile_number_and_valid_message_content() {
        sendSms.setReceiverAddress(reader.getValueFromConfig("messaging.invalidReceiverAddress"));
        sendSms.setTemplateName(reader.getValueFromConfig("messaging.templateName"));
        sendSms.setFirstName(reader.getValueFromConfig("messaging.FirstName"));
        sendSms.setVkyc(reader.getValueFromConfig("messaging.vKYC"));
        sendSms.setPreferredLanguage(reader.getValueFromConfig("messaging.preferredLanguage"));
        sendSms.setCallingService(reader.getValueFromConfig("messaging.callingService"));
        sendSms.setDomain(reader.getValueFromConfig("messaging.domain"));
        sendSmsPayload  = JSONPayload.getSendSmsPayload(sendSms);
    }
    @Then("The valid error message should be returned")
    public void the_valid_error_message_should_be_returned() {
        responseObject =  extractJsonObjectFromResponse(response);
        extractedResponse = extractJsonValueFromJsonArray(responseObject,"errors",0);
        verifyStatusCode(response,GlobalConstant.HTTP_BAD_REQUEST);
        jsonSchemaValidator(response,reader.getValueFromConfig("messaging.errorResponseSchemaFilePath"));

        if(sendSms.getReceiverAddress().equalsIgnoreCase(reader.getValueFromConfig("messaging.invalidReceiverAddress"))) {
            assertJsonValueEquals("message", "Invalid Receiver Address", extractedResponse);
            assertJsonValueEquals("code","NYE-MSG-002",extractedResponse);
        }

        else if (sendSms.getTemplateName().equalsIgnoreCase(reader.getValueFromConfig("messaging.invalidtemplateName"))) {
            assertJsonValueEquals("message", "Invalid Template Name", extractedResponse);
            assertJsonValueEquals("code","NYE-MSG-008",extractedResponse);
        }

        else if (sendSms.getFirstName().isEmpty() ) {
            assertJsonValueEquals("message", "Invalid Required Parameters value for  the Specified Key(s).", extractedResponse);
            assertJsonValueEquals("code","NYE-MSG-001",extractedResponse);
        }

        else if (sendSms.getVkyc().isEmpty()) {
            assertJsonValueEquals("message", "Invalid Required Parameters value for  the Specified Key(s).", extractedResponse);
            assertJsonValueEquals("code","NYE-MSG-001",extractedResponse);
        }

        else if (sendSms.getPreferredLanguage().isEmpty()) {
            assertJsonValueEquals("message", "Invalid Language", extractedResponse);
            assertJsonValueEquals("code","NYE-MSG-009",extractedResponse);
        }
        else if (sendSms.getCallingService().isEmpty()) {
            assertJsonValueEquals("message", "Calling Service and Template Registered Service Mismatch", extractedResponse);
            assertJsonValueEquals("code","NYE-MSG-010",extractedResponse);
        }
        else if (sendSms.getDomain().isEmpty()) {
            assertJsonValueEquals("message", "Invalid Domain", extractedResponse);
            assertJsonValueEquals("code","NYE-MSG-011",extractedResponse);
        }
        else if (sendSms.getTemplateName().equalsIgnoreCase(reader.getValueFromConfig("messaging.wallettemplateName"))) {
            assertJsonValueEquals("message", "Calling Service and Template Registered Service Mismatch", extractedResponse);
            assertJsonValueEquals("code","NYE-MSG-010",extractedResponse);
        }
        else {
            System.out.println("***Condition not found for this test***");
            assert false;
        }
    }

    @Given("I have a valid mobile number and invalid messaging template")
    public void i_have_a_valid_mobile_number_and_invalid_messaging_template() {
        sendSms.setReceiverAddress(reader.getValueFromConfig("messaging.validReceiverAddress"));
        sendSms.setTemplateName(reader.getValueFromConfig("messaging.invalidtemplateName"));
        sendSms.setFirstName(reader.getValueFromConfig("messaging.FirstName"));
        sendSms.setVkyc(reader.getValueFromConfig("messaging.vKYC"));
        sendSms.setPreferredLanguage(reader.getValueFromConfig("messaging.preferredLanguage"));
        sendSms.setCallingService(reader.getValueFromConfig("messaging.callingService"));
        sendSms.setDomain(reader.getValueFromConfig("messaging.domain"));
        sendSmsPayload  = JSONPayload.getSendSmsPayload(sendSms);
    }
    @Given("I have a valid mobile number and invalid First Name")
    public void i_have_a_valid_mobile_number_and_invalid_first_name() {
        sendSms.setReceiverAddress(reader.getValueFromConfig("messaging.validReceiverAddress"));
        sendSms.setTemplateName(reader.getValueFromConfig("messaging.templateName"));
        sendSms.setFirstName("");
        sendSms.setVkyc(reader.getValueFromConfig("messaging.vKYC"));
        sendSms.setPreferredLanguage(reader.getValueFromConfig("messaging.preferredLanguage"));
        sendSms.setCallingService(reader.getValueFromConfig("messaging.callingService"));
        sendSms.setDomain(reader.getValueFromConfig("messaging.domain"));
        sendSmsPayload  = JSONPayload.getSendSmsPayload(sendSms);
    }

    @Given("I have a valid mobile number and invalid vKYC link")
    public void i_have_a_valid_mobile_number_and_invalid_v_kyc_link() {
        sendSms.setReceiverAddress(reader.getValueFromConfig("messaging.validReceiverAddress"));
        sendSms.setTemplateName(reader.getValueFromConfig("messaging.templateName"));
        sendSms.setFirstName(reader.getValueFromConfig("messaging.FirstName"));
        sendSms.setVkyc("");
        sendSms.setPreferredLanguage(reader.getValueFromConfig("messaging.preferredLanguage"));
        sendSms.setCallingService(reader.getValueFromConfig("messaging.callingService"));
        sendSms.setDomain(reader.getValueFromConfig("messaging.domain"));
        sendSmsPayload  = JSONPayload.getSendSmsPayload(sendSms);
    }

    @Given("I have a valid mobile number and invalid preferred language")
    public void i_have_a_valid_mobile_number_and_invalid_preferred_language() {
        sendSms.setReceiverAddress(reader.getValueFromConfig("messaging.validReceiverAddress"));
        sendSms.setTemplateName(reader.getValueFromConfig("messaging.templateName"));
        sendSms.setFirstName(reader.getValueFromConfig("messaging.FirstName"));
        sendSms.setVkyc(reader.getValueFromConfig("messaging.vKYC"));
        sendSms.setPreferredLanguage("");
        sendSms.setCallingService(reader.getValueFromConfig("messaging.callingService"));
        sendSms.setDomain(reader.getValueFromConfig("messaging.domain"));
        sendSmsPayload  = JSONPayload.getSendSmsPayload(sendSms);
    }

    @Given("I have a valid mobile number and invalid calling service")
    public void i_have_a_valid_mobile_number_and_invalid_calling_service() {
        sendSms.setReceiverAddress(reader.getValueFromConfig("messaging.validReceiverAddress"));
        sendSms.setTemplateName(reader.getValueFromConfig("messaging.templateName"));
        sendSms.setFirstName(reader.getValueFromConfig("messaging.FirstName"));
        sendSms.setVkyc(reader.getValueFromConfig("messaging.vKYC"));
        sendSms.setPreferredLanguage(reader.getValueFromConfig("messaging.preferredLanguage"));
        sendSms.setCallingService("");
        sendSms.setDomain(reader.getValueFromConfig("messaging.domain"));
        sendSmsPayload  = JSONPayload.getSendSmsPayload(sendSms);
    }

    @Given("I have a valid mobile number and invalid domain")
    public void i_have_a_valid_mobile_number_and_invalid_domain() {
        sendSms.setReceiverAddress(reader.getValueFromConfig("messaging.validReceiverAddress"));
        sendSms.setTemplateName(reader.getValueFromConfig("messaging.templateName"));
        sendSms.setFirstName(reader.getValueFromConfig("messaging.FirstName"));
        sendSms.setVkyc(reader.getValueFromConfig("messaging.vKYC"));
        sendSms.setPreferredLanguage(reader.getValueFromConfig("messaging.preferredLanguage"));
        sendSms.setCallingService(reader.getValueFromConfig("messaging.callingService"));
        sendSms.setDomain("");
        sendSmsPayload  = JSONPayload.getSendSmsPayload(sendSms);
    }

    @Given("I have a valid mobile number and mismatched template name & calling service")
    public void i_have_a_valid_mobile_number_and_mismatched_template_name_calling_service() {
        sendSms.setReceiverAddress(reader.getValueFromConfig("messaging.validReceiverAddress"));
        sendSms.setTemplateName(reader.getValueFromConfig("messaging.wallettemplateName"));
        sendSms.setFirstName(reader.getValueFromConfig("messaging.FirstName"));
        sendSms.setVkyc(reader.getValueFromConfig("messaging.vKYC"));
        sendSms.setPreferredLanguage(reader.getValueFromConfig("messaging.preferredLanguage"));
        sendSms.setCallingService(reader.getValueFromConfig("messaging.callingService"));
        sendSms.setDomain(reader.getValueFromConfig("messaging.domain"));
        sendSmsPayload  = JSONPayload.getSendSmsPayload(sendSms);
    }
}
