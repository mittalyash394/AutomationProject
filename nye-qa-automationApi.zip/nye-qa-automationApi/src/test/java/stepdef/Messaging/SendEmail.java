package stepdef.Messaging;

import base.BaseBuilder;
import io.cucumber.java.en.*;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import org.json.JSONObject;
import resources.*;
import utilities.*;
import java.io.FileNotFoundException;
import java.util.*;
import static utilities.Utils.*;

public class SendEmail {
    private static SendEmailPayload sendEmail = new SendEmailPayload();
    private static PropertyReader reader = new PropertyReader();
    private static RequestSpecification reqspec;
    private static BaseBuilder builder = new BaseBuilder();
    private HashMap<String,Object> sendEmailPayload = new HashMap();
    private static Response response;
    JSONObject responseObject;
    private JSONObject extractedResponse;

    @Given("I have a valid EmailId and email content")
    public void i_have_a_valid_email_id_and_email_content() {
        sendEmail.setReceiverAddress(reader.getValueFromConfig("messaging.validEmailAddress"));
        sendEmail.setTemplateName(reader.getValueFromConfig("messaging.EmailTemplateName"));
        sendEmail.setUserName(reader.getValueFromConfig("messaging.UserName"));
        sendEmail.setProductName(reader.getValueFromConfig("messaging.ProductName"));
        sendEmail.setPreferredLanguage(reader.getValueFromConfig("messaging.preferredLanguage"));
        sendEmail.setCallingService(reader.getValueFromConfig("messaging.callingService"));
        sendEmail.setDomain(reader.getValueFromConfig("messaging.domain"));
        List<SendEmailPayloadObjects> list = new ArrayList<>();
        SendEmailPayloadObjects emailObj  = new SendEmailPayloadObjects();
        emailObj.setFileUrl(reader.getValueFromConfig("messaging.fileUrl"));
        emailObj.setFileName(reader.getValueFromConfig("messaging.fileName"));
        list.add(emailObj);
        sendEmail.setFiles(list);
        sendEmailPayload=JSONPayload.getSendEmailPayload(sendEmail);
    }
    @Then("Status Code should be as expected")
    public void status_code_should_be_as_expected() {
        verifyStatusCode(response,GlobalConstant.HTTP_OK);
    }
    @Then("Message returned should be as expected.")
    public void message_returned_should_be_as_expected() {
        responseObject = extractJsonObjectFromResponse(response);
        assertJsonValueEquals("message","Success", responseObject);
    }
    @Given("I have a {string} and email content")
    public void i_have_a_and_email_content(String email) {
        sendEmail.setReceiverAddress(email);
        sendEmail.setTemplateName(reader.getValueFromConfig("messaging.EmailTemplateName"));
        sendEmail.setUserName(reader.getValueFromConfig("messaging.UserName"));
        sendEmail.setProductName(reader.getValueFromConfig("messaging.ProductName"));
        sendEmail.setPreferredLanguage(reader.getValueFromConfig("messaging.preferredLanguage"));
        sendEmail.setCallingService(reader.getValueFromConfig("messaging.callingService"));
        sendEmail.setDomain(reader.getValueFromConfig("messaging.domain"));
        List<SendEmailPayloadObjects> list = new ArrayList<>();
        SendEmailPayloadObjects emailObj  = new SendEmailPayloadObjects();
        emailObj.setFileUrl(reader.getValueFromConfig("messaging.fileUrl"));
        emailObj.setFileName(reader.getValueFromConfig("messaging.fileName"));
        list.add(emailObj);
        sendEmail.setFiles(list);
        sendEmailPayload=JSONPayload.getSendEmailPayload(sendEmail);
    }
    @When("I hit the send email API")
    public void i_hit_the_send_email_api() throws FileNotFoundException {
        reqspec = builder.placeSpecBuilder();
        reqspec= RestAssured.given().spec(reqspec).body(sendEmailPayload);
        response = reqspec.post(GlobalConstant.SendEmailMessagingEndpoint);
    }
    @Then("The schema of response returned should be valid")
    public void the_schema_of_response_returned_should_be_valid() {
        if(response.getStatusCode()==GlobalConstant.HTTP_OK) {
            jsonSchemaValidator(response, reader.getValueFromConfig("messaging.validSmsResponseSchemaFilePath"));
        }
        else {
            jsonSchemaValidator(response, reader.getValueFromConfig("messaging.errorResponseSchemaFilePath"));
        }
    }
    @Then("{int} should be as expected")
    public void should_be_as_expected(Integer statusCode) {
        verifyStatusCode(response,statusCode);
    }

    @Then("{string} should be as expected")
    public void should_be_as_expected(String errorCode) {
        responseObject = extractJsonObjectFromResponse(response);
        extractedResponse =  extractJsonValueFromJsonArray(responseObject,"errors",0);
        assertJsonValueEquals("code",errorCode,extractedResponse);
    }


    @Then("{string} returned should be as expected.")
    public void returned_should_be_as_expected(String message) {
        responseObject =  extractJsonObjectFromResponse(response);
        if(response.getStatusCode()==GlobalConstant.HTTP_OK) {
            assertJsonValueEquals("message",message, responseObject);
        }
        else {
            extractedResponse = extractJsonValueFromJsonArray(responseObject, "errors", 0);
            assertJsonValueEquals("message", message, extractedResponse);
        }
    }

    @Given("I have a valid emailID and {string}")
    public void i_have_a_valid_email_id_and(String templateName) {
        sendEmail.setReceiverAddress(reader.getValueFromConfig("messaging.validEmailAddress"));
        sendEmail.setTemplateName(templateName);
        sendEmail.setUserName(reader.getValueFromConfig("messaging.UserName"));
        sendEmail.setProductName(reader.getValueFromConfig("messaging.ProductName"));
        sendEmail.setPreferredLanguage(reader.getValueFromConfig("messaging.preferredLanguage"));
        sendEmail.setCallingService(reader.getValueFromConfig("messaging.callingService"));
        sendEmail.setDomain(reader.getValueFromConfig("messaging.domain"));
        List<SendEmailPayloadObjects> list = new ArrayList<>();
        SendEmailPayloadObjects emailObj  = new SendEmailPayloadObjects();
        emailObj.setFileUrl(reader.getValueFromConfig("messaging.fileUrl"));
        emailObj.setFileName(reader.getValueFromConfig("messaging.fileName"));
        list.add(emailObj);
        sendEmail.setFiles(list);
        sendEmailPayload=JSONPayload.getSendEmailPayload(sendEmail);
    }
    @Given("I have a valid emailID and valid messaging template")
    public void i_have_a_valid_email_id_and_valid_messaging_template() {
        sendEmail.setReceiverAddress(reader.getValueFromConfig("messaging.validEmailAddress"));
        sendEmail.setTemplateName(reader.getValueFromConfig("messaging.EmailTemplateName"));
        sendEmail.setUserName(reader.getValueFromConfig("messaging.UserName"));
        sendEmail.setProductName(reader.getValueFromConfig("messaging.ProductName"));
        sendEmail.setPreferredLanguage(reader.getValueFromConfig("messaging.preferredLanguage"));
        sendEmail.setCallingService(reader.getValueFromConfig("messaging.callingService"));
        sendEmail.setDomain(reader.getValueFromConfig("messaging.domain"));
        List<SendEmailPayloadObjects> list = new ArrayList<>();
        SendEmailPayloadObjects emailObj  = new SendEmailPayloadObjects();
        emailObj.setFileUrl(reader.getValueFromConfig("messaging.fileUrl"));
        emailObj.setFileName(reader.getValueFromConfig("messaging.fileName"));
        list.add(emailObj);
        sendEmail.setFiles(list);
        sendEmailPayload=JSONPayload.getSendEmailPayload(sendEmail);
    }

    @Given("I have a valid emailID and invalid {string}")
    public void i_have_a_valid_email_id_and_invalid(String userName) {
        sendEmail.setReceiverAddress(reader.getValueFromConfig("messaging.validEmailAddress"));
        sendEmail.setTemplateName(reader.getValueFromConfig("messaging.EmailTemplateName"));
        sendEmail.setUserName(userName);
        sendEmail.setProductName(reader.getValueFromConfig("messaging.ProductName"));
        sendEmail.setPreferredLanguage(reader.getValueFromConfig("messaging.preferredLanguage"));
        sendEmail.setCallingService(reader.getValueFromConfig("messaging.callingService"));
        sendEmail.setDomain(reader.getValueFromConfig("messaging.domain"));
        List<SendEmailPayloadObjects> list = new ArrayList<>();
        SendEmailPayloadObjects emailObj  = new SendEmailPayloadObjects();
        emailObj.setFileUrl(reader.getValueFromConfig("messaging.fileUrl"));
        emailObj.setFileName(reader.getValueFromConfig("messaging.fileName"));
        list.add(emailObj);
        sendEmail.setFiles(list);
        sendEmailPayload=JSONPayload.getSendEmailPayload(sendEmail);
    }
}
