package stepdef.Wallet.tm;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.restassured.response.Response;
import org.json.JSONObject;
import org.junit.Assert;
import resources.Payee;
import resources.Payer;
import resources.TransTypeEnum;
import resources.Transaction;
import utilities.GlobalConstant;
import utilities.PropertyReader;
import java.io.FileNotFoundException;
import java.sql.SQLException;
import static utilities.CommonStepDef.*;
import static utilities.CommonStepDef.pay;
import static utilities.GlobalConstant.HTTP_OK;
import static utilities.Utils.*;

public class WalletToWallet {

    private static Response res;
    private static String payerAccessToken;
    private static Double balance;
    private static Double amount;
    private static JSONObject responseObject;
    private static String transTypeEnum;
    private static String transactionId;
    private static PropertyReader reader = new PropertyReader();
    private static Payee payee = new Payee();
    private static Payer payer = new Payer();


    // ************************* P2P transaction *****************************
    @Given("User login with valid cred to do p2p transaction")
    public void user_login_with_valid_cred_to_do_p2p_transaction() throws FileNotFoundException {
        System.out.println("User login with valid cred to do p2p transaction");
        res = login(reader.getValueFromConfig("wallet.test.user2.mobile.number"),reader.getValueFromConfig("wallet.test.user2.passcode"),reader.getValueFromConfig("wallet.test.user2.device.id"),reader.getValueFromConfig("wallet.test.user2.device.id"));
        payerAccessToken = getAccessTokenResponseData(res,"access_token");

    }
    @Given("User has a valid details of receiver to do p2p transaction")
    public void user_has_a_valid_details_of_receiver_to_do_p2p_transaction() throws FileNotFoundException {
        System.out.println("User has a valid details of receiver to do p2p transaction");
        payee.setReceiverVpa(reader.getValueFromConfig("wallet.test.user1.vpa"));
        payee.setReceiverMobileNumber(reader.getValueFromConfig("wallet.test.user1.mobile.number"));
        res = checkVpa(payerAccessToken,payee.getReceiverMobileNumber()); //calling check vpa api
        responseObject = extractJsonObjectFromResponse(res);  // extracting response object from response
        if(res.getStatusCode()!=HTTP_OK){
            errorValidationOfTM(res,payee,payer);
        }
        else {
            jsonSchemaValidator(res,reader.getValueFromConfig("check.vpa.valid.schema")); //schema validation
            assertJsonValueEquals("message","VPA fetch successfully",responseObject);  // assertions
            payee.setReceiverName((String) getResponseData(res,"results.senderName"));
            payer.setSenderVpa(reader.getValueFromConfig("wallet.test.user2.mobile.number"));
        }

    }

    @Given("User enter amount and other details to do p2p transaction")
    public void user_enter_amount_and_other_details_to_do_p2p_transaction() throws FileNotFoundException {
        System.out.println("User enter amount and other details to do p2p transaction");
        amount = getRandomAmount();
        payee.setAmount(String.valueOf(amount));  //setting amount
        payee.setComment(reader.getValueFromConfig("comment"));
        payer.setAction(reader.getValueFromConfig("wallet.pay.action"));
        payer.setUniqueFrontendId(getUniqueFrontendId());
        payer.setDeviceTypeEnum(reader.getValueFromConfig("device.type.enum"));
        balance = Double.valueOf(getWalletBalance(payerAccessToken)); //calling method to fetch user wallet balance
        payer.setWalletBalance(String.valueOf(balance));
        transTypeEnum = String.valueOf(TransTypeEnum.WALLET_TO_WALLET);
        payer.setPasscode(getEncryptedAuthData(reader.getValueFromConfig("wallet.test.user2.passcode")));
        payer.setSenderAccountId(reader.getValueFromConfig("wallet.test.user2.mobile.number"));
        res = checkRuleApi(payee,payer,transTypeEnum,payerAccessToken);  //calling check rule api
        responseObject = extractJsonObjectFromResponse(res);  // extracting response object from response
        if(res.getStatusCode()!=GlobalConstant.HTTP_OK){
            errorValidationOfTM(res,payee,payer);
        }
        else {
            checkRuleSuccessValidation(res); // calling method to validate check rule
        }
    }

    @Given("User click pay api to do p2p transaction")
    public void user_click_pay_api_to_do_p2p_transaction() throws FileNotFoundException {
        System.out.println("User click pay api to do p2p transaction");
        res = pay(payee,payer,transTypeEnum,payerAccessToken);   //calling pay api
    }

    @Then("Verify p2p transaction status")
    public void verify_p2p_transaction_status() throws FileNotFoundException {
        System.out.println("Verify p2p transaction status");
        if(res.getStatusCode()!=GlobalConstant.HTTP_OK){
            payer.setIsTransactionSuccess(false);
            errorValidationOfTM(res,payee,payer);
        }
        else {
            transactionId =  successTransactionValidation(res,payee,payer,transTypeEnum); // calling method to validate transaction from response
            payer.setIsTransactionSuccess(true);
        }
    }

    @Then("Also verify p2p transaction status from db if transaction has been succeed")
    public void also_verify_p2p_transaction_status_from_db_if_transaction_has_been_succeed() throws SQLException {
        System.out.println("Also verify p2p transaction status from db if transaction has been succeed");
        if(payer.getIsTransactionSuccess() && transactionId!=null){
            Transaction transaction = getTransactionDetails(transactionId);
            System.out.println(transaction);
            successTransactionValidationFromDB(res,transaction,transTypeEnum); // calling method to validate transaction from db
        }
        else {
            System.out.println("Transaction Failed. Transaction not verified from DB!!");
        }
    }

    // ************************* P2P transaction for same vpa *****************************
    @Given("User login with valid cred to do p2p transaction for same vpa")
    public void user_login_with_valid_cred_to_do_p2p_transaction_for_same_vpa() throws FileNotFoundException {
        System.out.println("User login with valid cred to do p2p transaction for same vpa");
        res = login(reader.getValueFromConfig("wallet.test.user1.mobile.number"),reader.getValueFromConfig("wallet.test.user1.passcode"),reader.getValueFromConfig("wallet.test.user1.device.id"),reader.getValueFromConfig("wallet.test.user1.device.id"));
        payerAccessToken = getAccessTokenResponseData(res,"access_token");
    }

    @Given("User enter same vpa to do p2p transaction")
    public void user_enter_same_vpa_to_do_p2p_transaction() throws FileNotFoundException {
        System.out.println("User enter same vpa to do p2p transaction");
        payee.setReceiverVpa(reader.getValueFromConfig("wallet.test.user1.vpa"));
        res = checkVpa(payerAccessToken,reader.getValueFromConfig("wallet.test.user1.mobile.number")); //calling check vpa api
        if(res.getStatusCode()!=HTTP_OK){
            errorValidationOfTM(res,payee,payer);
        }
        else {
            jsonSchemaValidator(res,reader.getValueFromConfig("check.vpa.valid.schema")); //schema validation
            responseObject = extractJsonObjectFromResponse(res);  // extracting response object from response
            assertJsonValueEquals("message","VPA fetch successfully",responseObject);  // assertions
            payee.setReceiverName((String) getResponseData(res,"results.senderName"));
        }
    }
    @Given("User enter amount and other details to do p2p transaction for same vpa")
    public void user_enter_amount_and_other_details_to_do_p2p_transaction_for_same_vpa() throws FileNotFoundException {
        payee.setAmount(String.valueOf(getRandomAmount()));  //setting amount
        payee.setComment(reader.getValueFromConfig("comment"));
        payer.setSenderVpa(reader.getValueFromConfig("wallet.test.user1.mobile.number"));
        payer.setSenderAccountId(reader.getValueFromConfig("wallet.test.user1.mobile.number"));
        payer.setAction(reader.getValueFromConfig("wallet.pay.action"));
        payer.setUniqueFrontendId(getUniqueFrontendId());
        payer.setDeviceTypeEnum(reader.getValueFromConfig("device.type.enum"));
    }
    @Given("User click pay api to do p2p transaction for same vpa")
    public void user_click_pay_api_to_do_p2p_transaction_for_same_vpa() throws FileNotFoundException {
        System.out.println("User click pay api to do p2p transaction for same vpa");
        transTypeEnum = String.valueOf(TransTypeEnum.WALLET_TO_WALLET);
        res = checkRuleApi(payee,payer,transTypeEnum,payerAccessToken);  //calling check rule api
        if(res.getStatusCode()!=HTTP_OK){
            errorValidationOfTM(res,payee,payer);
        }
        else {
            jsonSchemaValidator(res,reader.getValueFromConfig("check.rule.valid.schema")); //schema validation
            assertJsonValueEquals("message","Success",extractJsonObjectFromResponse(res)); // assertion
        }
        payer.setPasscode(getEncryptedAuthData(reader.getValueFromConfig("wallet.test.user1.passcode")));
        res = pay(payee,payer,transTypeEnum,payerAccessToken); // calling pay api method
    }
    @Then("Verify p2p transaction status for same vpa")
    public void verify_p2p_transaction_status_for_same_vpa() throws FileNotFoundException {
        System.out.println("Verify p2p transaction status for same vpa");
        errorValidationOfTM(res,payee,payer);
    }

    // ************************* P2P transaction for invalid amount *****************************
    @Given("User login with valid cred to do p2p transaction for invalid amount")
    public void user_login_with_valid_cred_to_do_p2p_transaction_for_invalid_amount() throws FileNotFoundException {
        System.out.println("User login with valid cred to do p2p transaction for invalid amount");
        res = login(reader.getValueFromConfig("wallet.test.user2.mobile.number"),reader.getValueFromConfig("wallet.test.user2.passcode"),reader.getValueFromConfig("wallet.test.user2.device.id"),reader.getValueFromConfig("wallet.test.user2.device.id"));
        payerAccessToken = getAccessTokenResponseData(res,"access_token");
    }
    @Given("User has a valid details of receiver to do p2p transaction for invalid amount")
    public void user_has_a_valid_details_of_receiver_to_do_p2p_transaction_for_invalid_amount() throws FileNotFoundException {
        System.out.println("User has a valid details of receiver to do p2p transaction for invalid amount");
        payee.setReceiverVpa(reader.getValueFromConfig("wallet.test.user1.vpa"));
        payee.setReceiverMobileNumber(reader.getValueFromConfig("wallet.test.user1.mobile.number"));
        res = checkVpa(payerAccessToken,payee.getReceiverMobileNumber()); //calling check vpa api
        responseObject = extractJsonObjectFromResponse(res);  // extracting response object from response
        if(res.getStatusCode()!=HTTP_OK){
            errorValidationOfTM(res,payee,payer);
        }
        else {
            jsonSchemaValidator(res,reader.getValueFromConfig("check.vpa.valid.schema")); //schema validation
            assertJsonValueEquals("message","VPA fetch successfully",responseObject);  // assertions
            payee.setReceiverName((String) getResponseData(res,"results.senderName"));
            payer.setSenderVpa(reader.getValueFromConfig("wallet.test.user2.mobile.number"));
        }
    }
    @Given("User enter {string} and {string} and other details to do p2p transaction for invalid amount")
    public void user_enter_and_and_other_details_to_do_p2p_transaction_for_invalid_amount(String amountType, String amountValue) throws FileNotFoundException {
        System.out.println("On entering "+amountType+" and "+amountValue+" for P2P Transaction");
        if(amountValue.equalsIgnoreCase("empty")){
            payee.setAmount(" ");
        }
        else if(amountValue.equalsIgnoreCase("null")){
            payee.setAmount(null);
        }
        else {
            payee.setAmount(amountValue);  //setting amount
        }
        payee.setComment(reader.getValueFromConfig("comment")); // setting comment
        transTypeEnum = String.valueOf(TransTypeEnum.WALLET_TO_WALLET);
        payer.setSenderVpa(reader.getValueFromConfig("wallet.test.user2.mobile.number"));
        payer.setSenderAccountId(reader.getValueFromConfig("wallet.test.user2.mobile.number"));
        payer.setPasscode(getEncryptedAuthData(reader.getValueFromConfig("wallet.test.user2.passcode")));
        payer.setAction(reader.getValueFromConfig("wallet.pay.action"));
        payer.setUniqueFrontendId(getUniqueFrontendId());
        payer.setDeviceTypeEnum(reader.getValueFromConfig("device.type.enum"));
        balance = Double.valueOf(getWalletBalance(payerAccessToken));
        payer.setWalletBalance(String.valueOf(balance));
        res = checkRuleApi(payee,payer,transTypeEnum,payerAccessToken);  //calling check rule api
        if(res.getStatusCode()!=GlobalConstant.HTTP_OK){
            errorValidationOfTM(res,payee,payer); // calling error validation method
        }
        else {
            checkRuleSuccessValidation(res); // calling method for check rule validation
        }
    }
    @Given("User click pay api to do p2p transaction for invalid amount")
    public void user_click_pay_api_to_do_p2p_transaction_for_invalid_amount() throws FileNotFoundException {
        System.out.println("User click pay api to do p2p transaction for invalid amount");
        res = pay(payee,payer,transTypeEnum,payerAccessToken);   //calling pay api
    }
    @Then("Verify p2p transaction status for invalid amount")
    public void verify_p2p_transaction_status_for_invalid_amount() throws FileNotFoundException {
        System.out.println("Verify p2p transaction status for invalid amount");
        errorValidationOfTM(res,payee,payer); // calling method for error validation
    }

    // ************************* P2P transaction for valid amount *****************************
    @Given("User login with valid cred to do p2p transaction for valid amount")
    public void user_login_with_valid_cred_to_do_p2p_transaction_for_valid_amount() throws FileNotFoundException {
        System.out.println("User login with valid cred to do p2p transaction for valid amount");
        res = login(reader.getValueFromConfig("wallet.test.user2.mobile.number"),reader.getValueFromConfig("wallet.test.user2.passcode"),reader.getValueFromConfig("wallet.test.user2.device.id"),reader.getValueFromConfig("wallet.test.user2.device.id"));
        payerAccessToken = getAccessTokenResponseData(res,"access_token");
    }
    @Given("User has a valid details of receiver to do p2p transaction for valid amount")
    public void user_has_a_valid_details_of_receiver_to_do_p2p_transaction_for_valid_amount() throws FileNotFoundException {
        System.out.println("User has a valid details of receiver to do p2p transaction for valid amount");
        payee.setReceiverVpa(reader.getValueFromConfig("wallet.test.user1.vpa"));
        payee.setReceiverMobileNumber(reader.getValueFromConfig("wallet.test.user1.mobile.number"));
        res = checkVpa(payerAccessToken,payee.getReceiverMobileNumber()); //calling check vpa api
        responseObject = extractJsonObjectFromResponse(res);  // extracting response object from response
        if(res.getStatusCode()!=HTTP_OK){
            errorValidationOfTM(res,payee,payer);
        }
        else {
            jsonSchemaValidator(res,reader.getValueFromConfig("check.vpa.valid.schema")); //schema validation
            assertJsonValueEquals("message","VPA fetch successfully",responseObject);  // assertions
            payee.setReceiverName((String) getResponseData(res,"results.senderName"));
            payer.setSenderVpa(reader.getValueFromConfig("wallet.test.user2.mobile.number"));
        }
    }
    @Given("User enter amount and other details to do p2p transaction for valid amount")
    public void user_enter_and_and_other_details_to_do_p2p_transaction_for_invalid_amount() throws FileNotFoundException {
        System.out.println("User enter amount and other details to do p2p transaction for valid amount");
        payee.setAmount(String.valueOf(getRandomAmount()));  //setting amount
        payee.setComment(reader.getValueFromConfig("comment")); // setting comment
        transTypeEnum = String.valueOf(TransTypeEnum.WALLET_TO_WALLET);
        payer.setSenderVpa(reader.getValueFromConfig("wallet.test.user2.mobile.number"));
        payer.setSenderAccountId(reader.getValueFromConfig("wallet.test.user2.mobile.number"));
        payer.setPasscode(getEncryptedAuthData(reader.getValueFromConfig("wallet.test.user2.passcode")));
        payer.setAction(reader.getValueFromConfig("wallet.pay.action"));
        payer.setUniqueFrontendId(getUniqueFrontendId());
        payer.setDeviceTypeEnum(reader.getValueFromConfig("device.type.enum"));
        balance = Double.valueOf(getWalletBalance(payerAccessToken));
        payer.setWalletBalance(String.valueOf(balance));
        res = checkRuleApi(payee,payer,transTypeEnum,payerAccessToken);  //calling check rule api
        if(res.getStatusCode()!=GlobalConstant.HTTP_OK){
            errorValidationOfTM(res,payee,payer); // calling error validation method
        }
        else {
            checkRuleSuccessValidation(res); // calling method for check rule validation
        }
    }

    @Given("User click pay api to do p2p transaction for valid amount")
    public void user_click_pay_api_to_do_p2p_transaction_for_valid_amount() throws FileNotFoundException {
        System.out.println("User click pay api to do p2p transaction for valid amount");
        res = pay(payee,payer,transTypeEnum,payerAccessToken);   //calling pay api
    }
    @Then("Verify p2p transaction status for valid amount")
    public void verify_p2p_transaction_status_for_valid_amount() throws FileNotFoundException {
        System.out.println("Verify p2p transaction status for valid amount");
        if(res.getStatusCode()!=GlobalConstant.HTTP_OK){
            payer.setIsTransactionSuccess(false);
            errorValidationOfTM(res,payee,payer);
        }
        else {
            transactionId =  successTransactionValidation(res,payee,payer,transTypeEnum);
            transactionId =  successTransactionValidation(res,payee,payer,transTypeEnum); // calling method to validate transaction from response
            payer.setIsTransactionSuccess(true);
        }
    }
    @Given("Also verify p2p transaction status from db if transaction has been succeed for valid amount")
    public void also_verify_transaction_status_from_db_if_p2b_transaction_is_success_for_valid_amount() throws SQLException {
        System.out.println("Also verify p2p transaction status from db if transaction has been succeed for valid amount");
        if(payer.getIsTransactionSuccess() && transactionId!=null){
            Transaction transaction = getTransactionDetails(transactionId);
            System.out.println(transaction);
            successTransactionValidationFromDB(res,transaction,transTypeEnum); // calling method to validate transaction from db
        }
        else {
            System.out.println("Transaction Failed! Transaction not Verified from DB");
        }
    }

    // ************************* P2P transaction when user has insufficient wallet balance *****************************
    @Given("User login with valid cred to do p2p transaction for insufficient balance")
    public void user_login_with_valid_cred_to_do_p2p_transaction_for_insufficient_balance() throws FileNotFoundException {
        System.out.println("User login with valid cred to do p2p transaction for insufficient balance");
        res = login(reader.getValueFromConfig("wallet.test.user2.mobile.number"),reader.getValueFromConfig("wallet.test.user2.passcode"),reader.getValueFromConfig("wallet.test.user2.device.id"),reader.getValueFromConfig("wallet.test.user2.device.id"));
        payerAccessToken = getAccessTokenResponseData(res,"access_token");
    }
    @Given("User has a valid details of receiver to do p2p transaction for insufficient balance")
    public void user_has_a_valid_details_of_receiver_to_do_p2p_transaction_for_insufficient_balance() throws FileNotFoundException {
        System.out.println("User has a valid details of receiver to do p2p transaction for insufficient balance");
        payee.setReceiverVpa(reader.getValueFromConfig("wallet.test.user1.vpa"));
        payee.setReceiverMobileNumber(reader.getValueFromConfig("wallet.test.user1.mobile.number"));
        res = checkVpa(payerAccessToken,payee.getReceiverMobileNumber()); //calling check vpa api
        responseObject = extractJsonObjectFromResponse(res);  // extracting response object from response
        if(res.getStatusCode()!=HTTP_OK){
            errorValidationOfTM(res,payee,payer);
        }
        else {
            jsonSchemaValidator(res,reader.getValueFromConfig("check.vpa.valid.schema")); //schema validation
            assertJsonValueEquals("message","VPA fetch successfully",responseObject);  // assertions
            payee.setReceiverName((String) getResponseData(res,"results.senderName"));
            payer.setSenderVpa(reader.getValueFromConfig("wallet.test.user2.mobile.number"));
        }
    }
    @Given("User enter amount and other details to do p2p transaction for insufficient balance")
    public void user_enter_amount_and_other_details_to_do_p2p_transaction_for_insufficient_balance() throws FileNotFoundException {
        System.out.println("User enter amount and other details to do p2p transaction for insufficient balance");
        balance = Double.valueOf(getWalletBalance(payerAccessToken)); // fetching user wallet balance
        amount = getRandomAmount();
        if(balance>amount){
            amount = balance+1;
        }
        payer.setWalletBalance(String.valueOf(balance));
        payee.setAmount(String.valueOf(amount));
        payee.setComment(reader.getValueFromConfig("comment"));
        payer.setSenderVpa(reader.getValueFromConfig("wallet.test.user2.mobile.number"));
        payer.setSenderAccountId(reader.getValueFromConfig("wallet.test.user2.mobile.number"));
        payer.setPasscode(getEncryptedAuthData(reader.getValueFromConfig("wallet.test.user2.passcode")));
        payer.setAction(reader.getValueFromConfig("wallet.pay.action"));
        payer.setUniqueFrontendId(getUniqueFrontendId());
        payer.setDeviceTypeEnum(reader.getValueFromConfig("device.type.enum"));
        payer.setWalletBalance(String.valueOf(balance));
        transTypeEnum = String.valueOf(TransTypeEnum.WALLET_TO_WALLET);
        res = checkRuleApi(payee,payer,transTypeEnum,payerAccessToken);  //calling check rule api
        if(res.getStatusCode()!=GlobalConstant.HTTP_OK){
            errorValidationOfTM(res,payee,payer); // calling error validation method
        }
        else {
            checkRuleSuccessValidation(res); // calling method for check rule validation
        }
    }
    @Given("User click pay api to do p2p transaction for insufficient balance")
    public void user_click_pay_api_to_do_p2p_transaction_for_insufficient_balance() throws FileNotFoundException {
        System.out.println("User click pay api to do p2p transaction for insufficient balance");
        res = pay(payee,payer,transTypeEnum,payerAccessToken);   //calling pay api
    }
    @Then("Verify p2p transaction status for insufficient balance")
    public void verify_p2p_transaction_status_for_insufficient_balance() throws FileNotFoundException {
        System.out.println("Verify p2p transaction status for insufficient balance");
        errorValidationOfTM(res,payee,payer); // calling method for error validation
    }

    // ************************* P2P transaction when receiver wallet account is not active *****************************
    @Given("User login with valid cred to do p2p transaction for inactive wallet")
    public void user_login_with_valid_cred_to_do_p2p_transaction_for_inactive_wallet() throws FileNotFoundException {
        System.out.println("User login with valid cred to do p2p transaction for inactive wallet");
        res = login(reader.getValueFromConfig("wallet.test.user2.mobile.number"),reader.getValueFromConfig("wallet.test.user2.passcode"),reader.getValueFromConfig("wallet.test.user2.device.id"),reader.getValueFromConfig("wallet.test.user2.device.id"));
        payerAccessToken = getAccessTokenResponseData(res,"access_token");
    }
    @Given("User has a detail of receiver to do p2p transaction for inactive wallet")
    public void user_has_a_detail_of_receiver_to_do_p2p_transaction_for_inactive_wallet() throws FileNotFoundException {
        System.out.println("User has a detail of receiver to do p2p transaction for inactive wallet");
        payee.setReceiverVpa(reader.getValueFromConfig("wallet.test.user4.inactive.wallet.mobile.number"));
        payee.setReceiverMobileNumber(reader.getValueFromConfig("wallet.test.user4.inactive.wallet.mobile.number"));
        res = checkVpa(payerAccessToken,payee.getReceiverMobileNumber()); //calling check vpa api
        responseObject = extractJsonObjectFromResponse(res);  // extracting response object from response
        if(res.getStatusCode()!=HTTP_OK){
            errorValidationOfTM(res,payee,payer);
        }
        else {
            jsonSchemaValidator(res,reader.getValueFromConfig("check.vpa.valid.schema")); //schema validation
            assertJsonValueEquals("message","VPA fetch successfully",responseObject);  // assertions
            payee.setReceiverName((String) getResponseData(res,"results.senderName"));
            payer.setSenderVpa(reader.getValueFromConfig("wallet.test.user2.mobile.number"));
        }
    }
    @Given("User enter amount and other details to do p2p transaction for inactive wallet")
    public void user_enter_amount_and_other_details_to_do_p2p_transaction_for_inactive_wallet() throws FileNotFoundException {
        System.out.println("User enter amount and other details to do p2p transaction for inactive wallet");
        payee.setAmount(String.valueOf(getRandomAmount()));  //setting amount
        payee.setComment(reader.getValueFromConfig("comment")); // setting comment
        transTypeEnum = String.valueOf(TransTypeEnum.WALLET_TO_WALLET);
        payer.setSenderVpa(reader.getValueFromConfig("wallet.test.user2.mobile.number"));
        payer.setSenderAccountId(reader.getValueFromConfig("wallet.test.user2.mobile.number"));
        payer.setPasscode(getEncryptedAuthData(reader.getValueFromConfig("wallet.test.user2.passcode")));
        payer.setAction(reader.getValueFromConfig("wallet.pay.action"));
        payer.setUniqueFrontendId(getUniqueFrontendId());
        payer.setDeviceTypeEnum(reader.getValueFromConfig("device.type.enum"));
        balance = Double.valueOf(getWalletBalance(payerAccessToken));
        payer.setWalletBalance(String.valueOf(balance));
        res = checkRuleApi(payee,payer,transTypeEnum,payerAccessToken);  //calling check rule api
        if(res.getStatusCode()!=GlobalConstant.HTTP_OK){
            errorValidationOfTM(res,payee,payer); // calling error validation method
        }
        else {
            checkRuleSuccessValidation(res); // calling method for check rule validation
        }
    }
    @Given("User click pay api to do p2p transaction for inactive wallet")
    public void user_click_pay_api_to_do_p2p_transaction_for_inactive_wallet() throws FileNotFoundException {
        System.out.println("User click pay api to do p2p transaction for inactive wallet");
        res = pay(payee,payer,transTypeEnum,payerAccessToken);   //calling pay api
    }
    @Then("Verify p2p transaction status for inactive wallet")
    public void verify_p2p_transaction_status_for_inactive_wallet() throws FileNotFoundException {
        System.out.println("Verify p2p transaction status for inactive wallet");
        errorValidationOfTM(res,payee,payer); // calling method for error validation
    }

    // ************************* P2P transaction when user (Sender) wallet account is not active  *****************************
    @Given("User login with valid cred to do p2p transaction while user wallet account is not active")
    public void user_login_with_valid_cred_to_do_p2p_transaction_while_user_wallet_account_is_not_active() throws FileNotFoundException {
        System.out.println("User login with valid cred to do p2p transaction while user wallet account is not active");
        res = login(reader.getValueFromConfig("wallet.test.user4.inactive.wallet.mobile.number"),reader.getValueFromConfig("wallet.test.user4.inactive.wallet.passcode"),reader.getValueFromConfig("wallet.test.user4.inactive.wallet.device.id"),reader.getValueFromConfig("wallet.test.user4.inactive.wallet.device.id"));
        payerAccessToken = getAccessTokenResponseData(res,"access_token");
    }
    @Given("User has a valid detail of receiver to do p2p transaction while user wallet account is not active")
    public void user_has_a_valid_detail_of_receiver_to_do_p2p_transaction_while_user_wallet_account_is_not_active() throws FileNotFoundException {
        System.out.println("User has a valid detail of receiver to do p2p transaction while user wallet account is not active");
        payee.setReceiverVpa(reader.getValueFromConfig("wallet.test.user1.vpa"));
        payee.setReceiverMobileNumber(reader.getValueFromConfig("wallet.test.user1.mobile.number"));
        res = checkVpa(payerAccessToken,payee.getReceiverMobileNumber()); //calling check vpa api
        responseObject = extractJsonObjectFromResponse(res);  // extracting response object from response
        errorValidationOfTM(res,payee,payer); // calling method for error validation
    }
    @Given("User enter amount and other details to do p2p transaction while user wallet account is not active")
    public void user_enter_amount_and_other_details_to_do_p2p_transaction_while_user_wallet_account_is_not_active() throws FileNotFoundException {
        System.out.println("User enter amount and other details to do p2p transaction while user wallet account is not active");
        payee.setAmount(String.valueOf(getRandomAmount()));  //setting amount
        payee.setComment(reader.getValueFromConfig("comment")); // setting comment
        transTypeEnum = String.valueOf(TransTypeEnum.WALLET_TO_WALLET);
        payer.setPasscode(getEncryptedAuthData(reader.getValueFromConfig("vc.user.passcode.withoutwallet")));
        payer.setAction(reader.getValueFromConfig("wallet.pay.action"));
        payer.setUniqueFrontendId(getUniqueFrontendId());
        payer.setDeviceTypeEnum(reader.getValueFromConfig("device.type.enum"));
        payer.setWalletBalance(String.valueOf(balance));
        res = checkRuleApi(payee,payer,transTypeEnum,payerAccessToken);  //calling check rule api
        errorValidationOfTM(res,payee,payer); // calling error validation method
    }
    @Given("User click pay api to do p2p transaction while user wallet account is not active")
    public void user_click_pay_api_to_do_p2p_transaction_while_user_wallet_account_is_not_active() throws FileNotFoundException {
        System.out.println("User click pay api to do p2p transaction while user wallet account is not active");
        res = pay(payee,payer,transTypeEnum,payerAccessToken);   //calling pay api
    }
    @Then("Verify p2p transaction status while user wallet account is not active")
    public void verify_p2p_transaction_status_while_user_wallet_account_is_not_active() throws FileNotFoundException {
        System.out.println("Verify p2p transaction status while user wallet account is not active");
        errorValidationOfTM(res,payee,payer);
    }

    // ************************* P2P transaction for balance breached *****************************
    @Given("User login with valid cred to do p2p transaction for balance breached")
    public void user_login_with_valid_cred_to_do_p2p_transaction_for_balance_breached() throws FileNotFoundException {
        System.out.println("User login with valid cred to do p2p transaction for balance breached");
        res = login(reader.getValueFromConfig("wallet.test.user2.mobile.number"),reader.getValueFromConfig("wallet.test.user2.passcode"),reader.getValueFromConfig("wallet.test.user2.device.id"),reader.getValueFromConfig("wallet.test.user2.device.id"));
        payerAccessToken = getAccessTokenResponseData(res,"access_token");
    }
    @Given("User has a valid detail of receiver to do p2p transaction while receiver wallet account has already Rs {int}")
    public void user_has_a_valid_detail_of_receiver_to_do_p2p_transaction_while_receiver_wallet_account_has_already_rs(Integer amount) throws FileNotFoundException {
        payee.setReceiverVpa(reader.getValueFromConfig("wallet.test.user3.balance.breached.vpa"));
        payee.setReceiverMobileNumber(reader.getValueFromConfig("wallet.test.user3.balance.breached.mobile.number"));
        res = checkVpa(payerAccessToken,payee.getReceiverMobileNumber()); //calling check vpa api
        responseObject = extractJsonObjectFromResponse(res);  // extracting response object from response
        if(res.getStatusCode()!=HTTP_OK){
            errorValidationOfTM(res,payee,payer);
        }
        else {
            jsonSchemaValidator(res,reader.getValueFromConfig("check.vpa.valid.schema")); //schema validation
            assertJsonValueEquals("message","VPA fetch successfully",responseObject);  // assertions
            payee.setReceiverName((String) getResponseData(res,"results.senderName"));
            payer.setSenderVpa(reader.getValueFromConfig("wallet.test.user2.mobile.number"));
        }
    }
    @Given("User enter amount and other details to do p2p transaction for balance breached")
    public void user_enter_amount_and_other_details_to_do_p2p_transaction_for_balance_breached() throws FileNotFoundException {
        System.out.println("User enter amount and other details to do p2p transaction for balance breached");
        payee.setAmount(String.valueOf(getRandomAmount()));  //setting amount
        payee.setComment(reader.getValueFromConfig("comment")); // setting comment
        transTypeEnum = String.valueOf(TransTypeEnum.WALLET_TO_WALLET);
        payer.setSenderVpa(reader.getValueFromConfig("wallet.test.user2.mobile.number"));
        payer.setSenderAccountId(reader.getValueFromConfig("wallet.test.user2.mobile.number"));
        payer.setPasscode(getEncryptedAuthData(reader.getValueFromConfig("wallet.test.user2.passcode")));
        payer.setAction(reader.getValueFromConfig("wallet.pay.action"));
        payer.setUniqueFrontendId(getUniqueFrontendId());
        payer.setDeviceTypeEnum(reader.getValueFromConfig("device.type.enum"));
        balance = Double.valueOf(getWalletBalance(payerAccessToken));
        payer.setWalletBalance(String.valueOf(balance));
        res = checkRuleApi(payee,payer,transTypeEnum,payerAccessToken);  //calling check rule api
        if(res.getStatusCode()!=GlobalConstant.HTTP_OK){
            errorValidationOfTM(res,payee,payer); // calling error validation method
        }
        else {
            checkRuleSuccessValidation(res); // calling method for check rule validation
        }
    }
    @Given("User click pay api to do p2p transaction for balance breached")
    public void user_click_pay_api_to_do_p2p_transaction_for_balance_breached() throws FileNotFoundException {
        System.out.println("User click pay api to do p2p transaction for balance breached");
        res = pay(payee,payer,transTypeEnum,payerAccessToken);   //calling pay api
    }
    @Then("Verify p2p transaction status for balance breached")
    public void verify_p2p_transaction_status_for_balance_breached() throws FileNotFoundException {
        System.out.println("Verify p2p transaction status for balance breached");
        errorValidationOfTM(res,payee,payer);
    }

    // ************************* P2P transaction for invalid and valid unique frontend id*****************************
    @Given("User login with valid cred to do p2p transaction for invalid unique frontend id")
    public void user_login_with_valid_cred_to_do_p2p_transaction_for_invalid_unique_frontend_id() throws FileNotFoundException {
        System.out.println("User login with valid cred to do p2p transaction for invalid unique frontend id");
        res = login(reader.getValueFromConfig("wallet.test.user1.mobile.number"),reader.getValueFromConfig("wallet.test.user1.passcode"),reader.getValueFromConfig("wallet.test.user1.device.id"),reader.getValueFromConfig("wallet.test.user1.device.id"));
        payerAccessToken = getAccessTokenResponseData(res,"access_token");
    }
    @Given("User has a valid detail of receiver to do p2p transaction for invalid unique frontend id")
    public void user_has_a_valid_detail_of_receiver_to_do_p2p_transaction_for_invalid_unique_frontend_id() throws FileNotFoundException {
        System.out.println("User has a valid detail of receiver to do p2p transaction for invalid unique frontend id");
        payee.setReceiverVpa(reader.getValueFromConfig("wallet.test.user2.vpa"));
        payee.setReceiverMobileNumber(reader.getValueFromConfig("wallet.test.user2.mobile.number"));
        res = checkVpa(payerAccessToken,payee.getReceiverMobileNumber()); //calling check vpa api
        if(res.getStatusCode()!=HTTP_OK){
            errorValidationOfTM(res,payee,payer); // calling method for error validations
        }
        else {
            jsonSchemaValidator(res,reader.getValueFromConfig("check.vpa.valid.schema")); //schema validation
            responseObject = extractJsonObjectFromResponse(res);  // extracting response object from response
            assertJsonValueEquals("message","VPA fetch successfully",responseObject);  // assertions
            payee.setReceiverName((String) getResponseData(res,"results.senderName"));
        }
    }
    @Given("User enter {string} and {string} and other details to do p2p transaction for invalid unique frontend id")
    public void user_enter_and_and_other_details_to_do_p2p_transaction_for_invalid_unique_frontend_id(String uniqueFrontendId, String uniqueFrontendIDValue) throws FileNotFoundException {
        System.out.println("On entering "+uniqueFrontendId+" and "+uniqueFrontendIDValue+" for invalid and valid unique frontend id");
        if(uniqueFrontendIDValue.equalsIgnoreCase("empty")){
            payer.setUniqueFrontendId(" ");
        }
        else if(uniqueFrontendIDValue.equalsIgnoreCase("null")){
            payer.setUniqueFrontendId(null);
        }
        else {
            payer.setUniqueFrontendId(uniqueFrontendIDValue);
        }

        payer.setSenderVpa(reader.getValueFromConfig("wallet.test.user1.mobile.number"));
        payer.setSenderAccountId(reader.getValueFromConfig("wallet.test.user1.mobile.number"));
        payer.setPasscode(getEncryptedAuthData(reader.getValueFromConfig("wallet.test.user1.passcode")));
        payer.setAction(reader.getValueFromConfig("wallet.pay.action"));
        balance = Double.valueOf(getWalletBalance(payerAccessToken));
        payer.setWalletBalance(String.valueOf(balance));
        payee.setAmount(String.valueOf(getRandomAmount())); // setting amount
        payer.setDeviceTypeEnum(reader.getValueFromConfig("device.type.enum"));
        payee.setComment(reader.getValueFromConfig("comment")); // setting comment
        transTypeEnum = String.valueOf(TransTypeEnum.WALLET_TO_WALLET);
        res = checkRuleApi(payee,payer,transTypeEnum,payerAccessToken);  //calling check rule api
        responseObject = extractJsonObjectFromResponse(res);  // extracting response object from response
        if(res.getStatusCode()!=GlobalConstant.HTTP_OK){
            errorValidationOfTM(res,payee,payer);
        }
        else {
            checkRuleSuccessValidation(res);
        }
    }
    @Given("User click pay api to do p2p transaction for invalid unique frontend id")
    public void user_click_pay_api_to_do_p2p_transaction_for_invalid_unique_frontend_id() throws FileNotFoundException {
        System.out.println("User click pay api to do p2p transaction for invalid unique frontend id");
        res = pay(payee,payer,transTypeEnum,payerAccessToken);
    }
    @Then("Verify p2p transaction status for invalid unique frontend id")
    public void verify_p2p_transaction_status_for_invalid_unique_frontend_id() throws FileNotFoundException {
        System.out.println("Verify p2p transaction status for invalid unique frontend id");
        errorValidationOfTM(res,payee,payer); // calling method for error validations
    }

    // ************************* P2P transaction for valid unique frontend id*****************************
    @Given("User login with valid cred to do p2p transaction for valid unique frontend id")
    public void user_login_with_valid_cred_to_do_p2p_transaction_for_valid_unique_frontend_id() throws FileNotFoundException {
        System.out.println("User login with valid cred to do p2p transaction for valid unique frontend id");
        res = login(reader.getValueFromConfig("wallet.test.user1.mobile.number"),reader.getValueFromConfig("wallet.test.user1.passcode"),reader.getValueFromConfig("wallet.test.user1.device.id"),reader.getValueFromConfig("wallet.test.user1.device.id"));
        payerAccessToken = getAccessTokenResponseData(res,"access_token");
    }
    @Given("User has a valid detail of receiver to do p2p transaction for valid unique frontend id")
    public void user_has_a_valid_detail_of_receiver_to_do_p2p_transaction_for_valid_unique_frontend_id() throws FileNotFoundException {
        System.out.println("User has a valid detail of receiver to do p2p transaction for valid unique frontend id");
        payee.setReceiverVpa(reader.getValueFromConfig("wallet.test.user2.vpa"));
        payee.setReceiverMobileNumber(reader.getValueFromConfig("wallet.test.user2.mobile.number"));
        res = checkVpa(payerAccessToken,payee.getReceiverMobileNumber()); //calling check vpa api
        if(res.getStatusCode()!=HTTP_OK){
            errorValidationOfTM(res,payee,payer); // calling method for error validations
        }
        else {
            jsonSchemaValidator(res,reader.getValueFromConfig("check.vpa.valid.schema")); //schema validation
            responseObject = extractJsonObjectFromResponse(res);  // extracting response object from response
            assertJsonValueEquals("message","VPA fetch successfully",responseObject);  // assertions
            payee.setReceiverName((String) getResponseData(res,"results.senderName"));
        }
    }
    @Given("User enter amount and other details to do p2p transaction for valid unique frontend id")
    public void user_enter_and_and_other_details_to_do_p2p_transaction_for_valid_unique_frontend_id() throws FileNotFoundException {
        System.out.println("User enter amount and other details to do p2p transaction for valid unique frontend id");
        payer.setUniqueFrontendId(getUniqueFrontendId());
        payer.setSenderVpa(reader.getValueFromConfig("wallet.test.user1.mobile.number"));
        payer.setSenderAccountId(reader.getValueFromConfig("wallet.test.user1.mobile.number"));
        payer.setPasscode(getEncryptedAuthData(reader.getValueFromConfig("wallet.test.user1.passcode")));
        payer.setAction(reader.getValueFromConfig("wallet.pay.action"));
        balance = Double.valueOf(getWalletBalance(payerAccessToken));
        payer.setWalletBalance(String.valueOf(balance));
        payee.setAmount(String.valueOf(getRandomAmount())); // setting amount
        payer.setDeviceTypeEnum(reader.getValueFromConfig("device.type.enum"));
        payee.setComment(reader.getValueFromConfig("comment")); // setting comment
        transTypeEnum = String.valueOf(TransTypeEnum.WALLET_TO_WALLET);
        res = checkRuleApi(payee,payer,transTypeEnum,payerAccessToken);  //calling check rule api
        responseObject = extractJsonObjectFromResponse(res);  // extracting response object from response
        if(res.getStatusCode()!=GlobalConstant.HTTP_OK){
            errorValidationOfTM(res,payee,payer);
        }
        else {
            checkRuleSuccessValidation(res);
        }
    }
    @Given("User click pay api to do p2p transaction for valid unique frontend id")
    public void user_click_pay_api_to_do_p2p_transaction_for_valid_unique_frontend_id() throws FileNotFoundException {
        System.out.println("User click pay api to do p2p transaction for valid unique frontend id");
        res = pay(payee,payer,transTypeEnum,payerAccessToken);
    }
    @Then("Verify p2p transaction status for valid unique frontend id")
    public void verify_p2p_transaction_status_for_valid_unique_frontend_id() throws FileNotFoundException {
        System.out.println("Verify p2p transaction status for invalid unique frontend id");
        if(res.getStatusCode()!=HTTP_OK){
            payer.setIsTransactionSuccess(false);
            errorValidationOfTM(res,payee,payer); // calling method for error validations
        }
        else {
            transactionId = successTransactionValidation(res,payee,payer,transTypeEnum);
            payer.setIsTransactionSuccess(true);
        }
    }

    @Then("Also verify p2p transaction status from db if transaction has been succeed for valid unique frontend id")
    public void also_verify_p2p_transaction_status_from_db_if_transaction_has_been_succeed_for_valid_unique_frontend_id() throws SQLException {
        System.out.println("Also verify p2p transaction status from db if transaction has been succeed for valid unique frontend id");
        if(payer.getIsTransactionSuccess() && transactionId!=null){
            Transaction transaction = getTransactionDetails(transactionId);
            System.out.println(transaction);
            successTransactionValidationFromDB(res,transaction,transTypeEnum); // calling method to validate transaction from db
        }
        else {
            System.out.println("Transaction Failed! Transaction not Verified from DB");
        }
    }

    // ************************* P2P transaction for invalid action *****************************
    @Given("User login with valid cred to do p2p transaction for invalid action")
    public void user_login_with_valid_cred_to_do_p2p_transaction_for_invalid_action() throws FileNotFoundException {
        System.out.println("User login with valid cred to do p2p transaction for invalid action");
        res = login(reader.getValueFromConfig("wallet.test.user2.mobile.number"),reader.getValueFromConfig("wallet.test.user2.passcode"),reader.getValueFromConfig("wallet.test.user2.device.id"),reader.getValueFromConfig("wallet.test.user2.device.id"));
        payerAccessToken = getAccessTokenResponseData(res,"access_token");
    }
    @Given("User has a valid detail of receiver to do p2p transaction for invalid action")
    public void user_has_a_valid_detail_of_receiver_to_do_p2p_transaction_for_invalid_action() throws FileNotFoundException {
        System.out.println("User has a valid detail of receiver to do p2p transaction for invalid action");
        payee.setReceiverVpa(reader.getValueFromConfig("wallet.test.user1.vpa"));
        payee.setReceiverMobileNumber(reader.getValueFromConfig("wallet.test.user1.mobile.number"));
        res = checkVpa(payerAccessToken,payee.getReceiverMobileNumber()); //calling check vpa api
        responseObject = extractJsonObjectFromResponse(res);  // extracting response object from response
        if(res.getStatusCode()!=HTTP_OK){
            errorValidationOfTM(res,payee,payer); // calling method for error validations
        }
        else {
            jsonSchemaValidator(res,reader.getValueFromConfig("check.vpa.valid.schema")); //schema validation
            assertJsonValueEquals("message","VPA fetch successfully",responseObject);  // assertions
            payee.setReceiverName((String) getResponseData(res,"results.senderName"));
        }
    }
    @Given("User enter {string} and {string} and other details to do p2p transaction for invalid action")
    public void user_enter_and_and_other_details_to_do_p2p_transaction_for_invalid_action(String actionType, String actionValue) throws FileNotFoundException {
        System.out.println("On entering "+actionType+" and "+actionValue+" for invalid and valid action");
        if(actionValue.equalsIgnoreCase("empty")){
            payer.setAction(" ");
        }
        else if(actionValue.equalsIgnoreCase("null")){
            payer.setAction(null);
        }
        else {
            payer.setAction(actionValue);
        }

        payer.setSenderVpa(reader.getValueFromConfig("wallet.test.user2.mobile.number"));
        payer.setSenderAccountId(reader.getValueFromConfig("wallet.test.user2.mobile.number"));
        payer.setPasscode(getEncryptedAuthData(reader.getValueFromConfig("wallet.test.user2.passcode")));
        payer.setUniqueFrontendId(getUniqueFrontendId());
        balance = Double.valueOf(getWalletBalance(payerAccessToken));
        payer.setWalletBalance(String.valueOf(balance));
        payee.setAmount(String.valueOf(getRandomAmount())); // setting amount
        payee.setComment(reader.getValueFromConfig("comment")); // setting comment
        payer.setDeviceTypeEnum(reader.getValueFromConfig("device.type.enum"));
        transTypeEnum = String.valueOf(TransTypeEnum.WALLET_TO_WALLET);
        res = checkRuleApi(payee,payer,transTypeEnum,payerAccessToken);  //calling check rule api
        responseObject = extractJsonObjectFromResponse(res);  // extracting response object from response
        if(res.getStatusCode()!=GlobalConstant.HTTP_OK){
            errorValidationOfTM(res,payee,payer);
        }
        else {
            checkRuleSuccessValidation(res);
        }
    }
    @Given("User click pay api to do p2p transaction for invalid action")
    public void user_click_pay_api_to_do_p2p_transaction_for_invalid_action() throws FileNotFoundException {
        System.out.println("User click pay api to do p2p transaction for invalid action");
        res = pay(payee,payer,transTypeEnum,payerAccessToken);   //calling pay api
    }
    @Then("Verify p2p transaction status for invalid action")
    public void verify_p2p_transaction_status_for_invalid_action() throws FileNotFoundException {
        System.out.println("Verify p2p transaction status for invalid action");
        errorValidationOfTM(res,payee,payer); // calling method for error validations
    }

    // ************************* P2P transaction for valid action *****************************
    @Given("User login with valid cred to do p2p transaction for valid action")
    public void user_login_with_valid_cred_to_do_p2p_transaction_for_valid_action() throws FileNotFoundException {
        System.out.println("User login with valid cred to do p2p transaction for valid action");
        res = login(reader.getValueFromConfig("wallet.test.user2.mobile.number"),reader.getValueFromConfig("wallet.test.user2.passcode"),reader.getValueFromConfig("wallet.test.user2.device.id"),reader.getValueFromConfig("wallet.test.user2.device.id"));
        payerAccessToken = getAccessTokenResponseData(res,"access_token");
    }
    @Given("User has a valid detail of receiver to do p2p transaction for valid action")
    public void user_has_a_valid_detail_of_receiver_to_do_p2p_transaction_for_valid_action() throws FileNotFoundException {
        System.out.println("User has a valid detail of receiver to do p2p transaction for valid action");
        payee.setReceiverVpa(reader.getValueFromConfig("wallet.test.user1.vpa"));
        payee.setReceiverMobileNumber(reader.getValueFromConfig("wallet.test.user1.mobile.number"));
        res = checkVpa(payerAccessToken,payee.getReceiverMobileNumber()); //calling check vpa api
        responseObject = extractJsonObjectFromResponse(res);  // extracting response object from response
        if(res.getStatusCode()!=HTTP_OK){
            errorValidationOfTM(res,payee,payer); // calling method for error validations
        }
        else {
            jsonSchemaValidator(res,reader.getValueFromConfig("check.vpa.valid.schema")); //schema validation
            assertJsonValueEquals("message","VPA fetch successfully",responseObject);  // assertions
            payee.setReceiverName((String) getResponseData(res,"results.senderName"));
        }
    }
    @Given("User enter amount and other details to do p2p transaction for valid action")
    public void user_enter_and_and_other_details_to_do_p2p_transaction_for_valid_action() throws FileNotFoundException {
        System.out.println("User enter amount and other details to do p2p transaction for valid action");
        payer.setAction(reader.getValueFromConfig("wallet.pay.action"));
        payer.setSenderVpa(reader.getValueFromConfig("wallet.test.user2.mobile.number"));
        payer.setSenderAccountId(reader.getValueFromConfig("wallet.test.user2.mobile.number"));
        payer.setPasscode(getEncryptedAuthData(reader.getValueFromConfig("wallet.test.user2.passcode")));
        payer.setUniqueFrontendId(getUniqueFrontendId());
        balance = Double.valueOf(getWalletBalance(payerAccessToken));
        payer.setWalletBalance(String.valueOf(balance));
        payee.setAmount(String.valueOf(getRandomAmount())); // setting amount
        payee.setComment(reader.getValueFromConfig("comment")); // setting comment
        payer.setDeviceTypeEnum(reader.getValueFromConfig("device.type.enum"));
        transTypeEnum = String.valueOf(TransTypeEnum.WALLET_TO_WALLET);
        res = checkRuleApi(payee,payer,transTypeEnum,payerAccessToken);  //calling check rule api
        responseObject = extractJsonObjectFromResponse(res);  // extracting response object from response
        if(res.getStatusCode()!=GlobalConstant.HTTP_OK){
            errorValidationOfTM(res,payee,payer);
        }
        else {
            checkRuleSuccessValidation(res);
        }
    }
    @Given("User click pay api to do p2p transaction for valid action")
    public void user_click_pay_api_to_do_p2p_transaction_for_valid_action() throws FileNotFoundException {
        System.out.println("User click pay api to do p2p transaction for valid action");
        res = pay(payee,payer,transTypeEnum,payerAccessToken);   //calling pay api
    }
    @Then("Verify p2p transaction status for valid action")
    public void verify_p2p_transaction_status_for_valid_action() throws FileNotFoundException {
        System.out.println("Verify p2p transaction status for valid action");
        if(res.getStatusCode()!=HTTP_OK){
            payer.setIsTransactionSuccess(false);
            errorValidationOfTM(res,payee,payer); // calling method for error validations
        }
        else {
            transactionId = successTransactionValidation(res,payee,payer,transTypeEnum);
            payer.setIsTransactionSuccess(true);
        }
    }

    @Then("Also verify p2p transaction status from db if transaction has been succeed for valid action")
    public void also_verify_p2p_transaction_status_from_db_if_transaction_has_been_succeed_for_valid_action() throws SQLException {
        System.out.println("Also verify p2p transaction status from db if transaction has been succeed for valid action");
        if(payer.getIsTransactionSuccess() && transactionId!=null){
            Transaction transaction = getTransactionDetails(transactionId);
            System.out.println(transaction);
            successTransactionValidationFromDB(res,transaction,transTypeEnum); // calling method to validate transaction from db
        }
        else {
            System.out.println("Transaction Failed! Transaction not Verified from DB");
        }
    }

    // ************************* P2P transaction for invalid and valid comment *****************************
    @Given("User login with valid cred to do p2p transaction for invalid and comment")
    public void user_login_with_valid_cred_to_do_p2p_transaction_for_invalid_and_comment() throws FileNotFoundException {
        System.out.println("User login with valid cred to do p2p transaction for invalid and comment");
        res = login(reader.getValueFromConfig("wallet.test.user2.mobile.number"),reader.getValueFromConfig("wallet.test.user2.passcode"),reader.getValueFromConfig("wallet.test.user2.device.id"),reader.getValueFromConfig("wallet.test.user2.device.id"));
        payerAccessToken = getAccessTokenResponseData(res,"access_token");
    }
    @Given("User has a valid detail of receiver to do p2p transaction for invalid and comment")
    public void user_has_a_valid_detail_of_receiver_to_do_p2p_transaction_for_invalid_and_comment() throws FileNotFoundException {
        System.out.println("User has a valid detail of receiver to do p2p transaction for invalid and comment");
        payee.setReceiverVpa(reader.getValueFromConfig("wallet.test.user1.vpa"));
        payee.setReceiverMobileNumber(reader.getValueFromConfig("wallet.test.user1.mobile.number"));
        res = checkVpa(payerAccessToken,payee.getReceiverMobileNumber()); //calling check vpa api
        responseObject = extractJsonObjectFromResponse(res);  // extracting response object from response
        if(res.getStatusCode()!=HTTP_OK){
            errorValidationOfTM(res,payee,payer); // calling method for error validations
        }
        else {
            jsonSchemaValidator(res,reader.getValueFromConfig("check.vpa.valid.schema")); //schema validation
            assertJsonValueEquals("message","VPA fetch successfully",responseObject);  // assertions
            payee.setReceiverName((String) getResponseData(res,"results.senderName"));
        }
    }
    @Given("User enter {string} and {string} and other details to do p2p transaction for invalid and comment")
    public void user_enter_and_and_other_details_to_do_p2p_transaction_for_invalid_and_comment(String commentType, String commentValue) throws FileNotFoundException {
        System.out.println("On entering "+commentType+" and "+commentValue+" for invalid and valid comment");
        if(commentValue.equalsIgnoreCase("validComment")){
            payee.setComment(reader.getValueFromConfig("comment")); // setting comment
        }
        else if(commentValue.equalsIgnoreCase("empty")){
            payer.setComment(" ");
        }
        else if(commentValue.equalsIgnoreCase("null")){
            payer.setComment(null);
        }
        else {
            payer.setComment(commentValue);
        }

        payer.setSenderVpa(reader.getValueFromConfig("wallet.test.user2.mobile.number"));
        payer.setSenderAccountId(reader.getValueFromConfig("wallet.test.user2.mobile.number"));
        payer.setPasscode(getEncryptedAuthData(reader.getValueFromConfig("wallet.test.user2.passcode")));
        payer.setUniqueFrontendId(getUniqueFrontendId());
        balance = Double.valueOf(getWalletBalance(payerAccessToken));
        payer.setWalletBalance(String.valueOf(balance));
        payee.setAmount(String.valueOf(getRandomAmount())); // setting amount
        payer.setAction(reader.getValueFromConfig("wallet.pay.action"));
        payer.setDeviceTypeEnum(reader.getValueFromConfig("device.type.enum"));
        transTypeEnum = String.valueOf(TransTypeEnum.WALLET_TO_WALLET);
        res = checkRuleApi(payee,payer,transTypeEnum,payerAccessToken);  //calling check rule api
        responseObject = extractJsonObjectFromResponse(res);  // extracting response object from response
        if(res.getStatusCode()!=GlobalConstant.HTTP_OK){
            errorValidationOfTM(res,payee,payer);
        }
        else {
            checkRuleSuccessValidation(res);
        }
    }
    @Given("User click pay api to do p2p transaction for invalid and comment")
    public void user_click_pay_api_to_do_p2p_transaction_for_invalid_and_comment() throws FileNotFoundException {
        System.out.println("User click pay api to do p2p transaction for invalid and comment");
        res = pay(payee,payer,transTypeEnum,payerAccessToken);   //calling pay api
    }
    @Then("Verify p2p transaction status for invalid and comment")
    public void verify_p2p_transaction_status_for_invalid_and_comment() throws FileNotFoundException {
        System.out.println("Verify p2p transaction status for invalid and comment");
        if(res.getStatusCode()!=HTTP_OK){
            payer.setIsTransactionSuccess(false);
            errorValidationOfTM(res,payee,payer); // calling method for error validations
        }
        else {
            transactionId = successTransactionValidation(res,payee,payer,transTypeEnum);
            payer.setIsTransactionSuccess(true);
        }
    }
    @Then("Also verify p2p transaction status from db if transaction has been succeed for invalid and comment")
    public void also_verify_p2p_transaction_status_from_db_if_transaction_has_been_succeed_for_invalid_and_comment() throws SQLException {
        System.out.println("Also verify p2p transaction status from db if transaction has been succeed for invalid and comment");
        if(payer.getIsTransactionSuccess() && transactionId!=null){
            Transaction transaction = getTransactionDetails(transactionId);
            System.out.println(transaction);
            successTransactionValidationFromDB(res,transaction,transTypeEnum); // calling method to validate transaction from db
        }
        else {
            System.out.println("Transaction Failed! Transaction not Verified from DB");
        }
    }

    // ************************* P2P transaction for invalid device type *****************************
    @Given("User login with valid cred to do p2p transaction for invalid device type")
    public void user_login_with_valid_cred_to_do_p2p_transaction_for_invalid_device_type() throws FileNotFoundException {
        System.out.println("User login with valid cred to do p2p transaction for invalid device type");
        res = login(reader.getValueFromConfig("wallet.test.user1.mobile.number"),reader.getValueFromConfig("wallet.test.user1.passcode"),reader.getValueFromConfig("wallet.test.user1.device.id"),reader.getValueFromConfig("wallet.test.user1.device.id"));
        payerAccessToken = getAccessTokenResponseData(res,"access_token");
    }
    @Given("User has a valid detail of receiver to do p2p transaction for invalid device type")
    public void user_has_a_valid_detail_of_receiver_to_do_p2p_transaction_for_invalid_device_type() throws FileNotFoundException {
        System.out.println("User has a valid detail of receiver to do p2p transaction for invalid device type");
        payee.setReceiverVpa(reader.getValueFromConfig("wallet.test.user2.vpa"));
        payee.setReceiverMobileNumber(reader.getValueFromConfig("wallet.test.user2.mobile.number"));
        res = checkVpa(payerAccessToken,payee.getReceiverMobileNumber()); //calling check vpa api
        responseObject = extractJsonObjectFromResponse(res);  // extracting response object from response
        if(res.getStatusCode()!=HTTP_OK){
            errorValidationOfTM(res,payee,payer); // calling method for error validations
        }
        else {
            jsonSchemaValidator(res,reader.getValueFromConfig("check.vpa.valid.schema")); //schema validation
            assertJsonValueEquals("message","VPA fetch successfully",responseObject);  // assertions
            payee.setReceiverName((String) getResponseData(res,"results.senderName"));
        }
    }
    @Given("User enter {string} and {string} and other details to do p2p transaction for invalid device type")
    public void user_enter_and_and_other_details_to_do_p2p_transaction_for_invalid_device_type(String deviceType, String deviceTypeValue) throws FileNotFoundException {
        System.out.println("On entering "+deviceType+" and "+deviceTypeValue+" for invalid device type");
        if(deviceTypeValue.equalsIgnoreCase("empty")){
            payer.setDeviceTypeEnum(" ");
        }
        else if(deviceTypeValue.equalsIgnoreCase("null")){
            payer.setDeviceTypeEnum(null);
        }
        else {
            payer.setDeviceTypeEnum(deviceTypeValue);

        }
        payer.setSenderVpa(reader.getValueFromConfig("wallet.test.user1.mobile.number"));
        payer.setSenderAccountId(reader.getValueFromConfig("wallet.test.user1.mobile.number"));
        payer.setPasscode(getEncryptedAuthData(reader.getValueFromConfig("wallet.test.user1.passcode")));
        payer.setUniqueFrontendId(getUniqueFrontendId());
        balance = Double.valueOf(getWalletBalance(payerAccessToken));
        payer.setWalletBalance(String.valueOf(balance));
        payee.setAmount(String.valueOf(getRandomAmount())); // setting amount
        payee.setComment(reader.getValueFromConfig("comment")); // setting comment
        payer.setAction(reader.getValueFromConfig("wallet.pay.action"));
        transTypeEnum = String.valueOf(TransTypeEnum.WALLET_TO_WALLET);
        res = checkRuleApi(payee,payer,transTypeEnum,payerAccessToken);  //calling check rule api
        responseObject = extractJsonObjectFromResponse(res);  // extracting response object from response
        if(res.getStatusCode()!=GlobalConstant.HTTP_OK){
            errorValidationOfTM(res,payee,payer);
        }
        else {
           checkRuleSuccessValidation(res);
        }
    }
    @Given("User click pay api to do p2p transaction for invalid device type")
    public void user_click_pay_api_to_do_p2p_transaction_for_invalid_device_type() throws FileNotFoundException {
        System.out.println("User click pay api to do p2p transaction for invalid device type");
        res = pay(payee,payer,transTypeEnum,payerAccessToken);   //calling pay api
    }
    @Then("Verify p2p transaction status for invalid device type")
    public void verify_p2p_transaction_status_for_invalid_device_type() throws FileNotFoundException {
        System.out.println("Verify p2p transaction status for invalid device type");
       errorValidationOfTM(res,payee,payer); // calling method for error validations
    }

    // ************************* P2P transaction for  valid device type *****************************
    @Given("User login with valid cred to do p2p transaction for valid device type")
    public void user_login_with_valid_cred_to_do_p2p_transaction_for_valid_device_type() throws FileNotFoundException {
        System.out.println("User login with valid cred to do p2p transaction for valid device type");
        res = login(reader.getValueFromConfig("wallet.test.user1.mobile.number"),reader.getValueFromConfig("wallet.test.user1.passcode"),reader.getValueFromConfig("wallet.test.user1.device.id"),reader.getValueFromConfig("wallet.test.user1.device.id"));
        payerAccessToken = getAccessTokenResponseData(res,"access_token");
    }
    @Given("User has a valid detail of receiver to do p2p transaction for valid device type")
    public void user_has_a_valid_detail_of_receiver_to_do_p2p_transaction_for_valid_device_type() throws FileNotFoundException {
        System.out.println("User has a valid detail of receiver to do p2p transaction for valid device type");
        payee.setReceiverVpa(reader.getValueFromConfig("wallet.test.user2.vpa"));
        payee.setReceiverMobileNumber(reader.getValueFromConfig("wallet.test.user2.mobile.number"));
        res = checkVpa(payerAccessToken,payee.getReceiverMobileNumber()); //calling check vpa api
        responseObject = extractJsonObjectFromResponse(res);  // extracting response object from response
        if(res.getStatusCode()!=HTTP_OK){
            errorValidationOfTM(res,payee,payer); // calling method for error validations
        }
        else {
            jsonSchemaValidator(res,reader.getValueFromConfig("check.vpa.valid.schema")); //schema validation
            assertJsonValueEquals("message","VPA fetch successfully",responseObject);  // assertions
            payee.setReceiverName((String) getResponseData(res,"results.senderName"));
        }
    }
    @Given("User enter amount and other details to do p2p transaction for valid device type")
    public void user_enter_and_and_other_details_to_do_p2p_transaction_for_valid_device_type() throws FileNotFoundException {
        System.out.println("User enter amount and other details to do p2p transaction for valid device type");
        payer.setDeviceTypeEnum(reader.getValueFromConfig("device.type.enum"));
        payer.setSenderVpa(reader.getValueFromConfig("wallet.test.user1.mobile.number"));
        payer.setSenderAccountId(reader.getValueFromConfig("wallet.test.user1.mobile.number"));
        payer.setPasscode(getEncryptedAuthData(reader.getValueFromConfig("wallet.test.user1.passcode")));
        payer.setUniqueFrontendId(getUniqueFrontendId());
        balance = Double.valueOf(getWalletBalance(payerAccessToken));
        payer.setWalletBalance(String.valueOf(balance));
        payee.setAmount(String.valueOf(getRandomAmount())); // setting amount
        payee.setComment(reader.getValueFromConfig("comment")); // setting comment
        payer.setAction(reader.getValueFromConfig("wallet.pay.action"));
        transTypeEnum = String.valueOf(TransTypeEnum.WALLET_TO_WALLET);
        res = checkRuleApi(payee,payer,transTypeEnum,payerAccessToken);  //calling check rule api
        responseObject = extractJsonObjectFromResponse(res);  // extracting response object from response
        if(res.getStatusCode()!=GlobalConstant.HTTP_OK){
            errorValidationOfTM(res,payee,payer);
        }
        else {
            checkRuleSuccessValidation(res);
        }
    }
    @Given("User click pay api to do p2p transaction for valid device type")
    public void user_click_pay_api_to_do_p2p_transaction_for_valid_device_type() throws FileNotFoundException {
        System.out.println("User click pay api to do p2p transaction for valid device type");
        res = pay(payee,payer,transTypeEnum,payerAccessToken);   //calling pay api
    }
    @Then("Verify p2p transaction status for valid device type")
    public void verify_p2p_transaction_status_for_valid_device_type() throws FileNotFoundException {
        System.out.println("Verify p2p transaction status for valid device type");
        if(res.getStatusCode()!=HTTP_OK){
            payer.setIsTransactionSuccess(false);
            errorValidationOfTM(res,payee,payer); // calling method for error validations
        }
        else {
            transactionId = successTransactionValidation(res,payee,payer,transTypeEnum);
            payer.setIsTransactionSuccess(true);
        }
    }

    @Then("Also verify p2p transaction status from db if transaction has been succeed for valid device type")
    public void also_verify_p2p_transaction_status_from_db_if_transaction_has_been_succeed_for_valid_device_type() throws SQLException {
        System.out.println("Also verify p2p transaction status from db if transaction has been succeed for valid device type");
        if(payer.getIsTransactionSuccess() && transactionId!=null){
            Transaction transaction = getTransactionDetails(transactionId);
            System.out.println(transaction);
            successTransactionValidationFromDB(res,transaction,transTypeEnum); // calling method to validate transaction from db
        }
        else {
            System.out.println("Transaction Failed! Transaction not Verified from DB");
        }
    }

    // ************************* P2P transaction for invalid  transaction type *****************************
    @Given("User login with valid cred to do p2p transaction for invalid transaction type")
    public void user_login_with_valid_cred_to_do_p2p_transaction_for_invalid_transaction_type() throws FileNotFoundException {
        System.out.println("User login with valid cred to do p2p transaction for invalid transaction type");
        res = login(reader.getValueFromConfig("wallet.test.user2.mobile.number"),reader.getValueFromConfig("wallet.test.user2.passcode"),reader.getValueFromConfig("wallet.test.user2.device.id"),reader.getValueFromConfig("wallet.test.user2.device.id"));
        payerAccessToken = getAccessTokenResponseData(res,"access_token");
    }
    @Given("User has a valid detail of receiver to do p2p transaction for invalid transaction type")
    public void user_has_a_valid_detail_of_receiver_to_do_p2p_transaction_for_invalid_transaction_type() throws FileNotFoundException {
        System.out.println("User has a valid detail of receiver to do p2p transaction for invalid transaction type");
        payee.setReceiverVpa(reader.getValueFromConfig("wallet.test.user1.vpa"));
        payee.setReceiverMobileNumber(reader.getValueFromConfig("wallet.test.user1.mobile.number"));
        res = checkVpa(payerAccessToken,payee.getReceiverMobileNumber()); //calling check vpa api
        responseObject = extractJsonObjectFromResponse(res);  // extracting response object from response
        if(res.getStatusCode()!=HTTP_OK){
            errorValidationOfTM(res,payee,payer); // calling method for error validations
        }
        else {
            jsonSchemaValidator(res,reader.getValueFromConfig("check.vpa.valid.schema")); //schema validation
            assertJsonValueEquals("message","VPA fetch successfully",responseObject);  // assertions
            payee.setReceiverName((String) getResponseData(res,"results.senderName"));
        }
    }
    @Given("User enter {string} and {string} and other details to do p2p transaction for invalid transaction type")
    public void user_enter_and_and_other_details_to_do_p2p_transaction_for_invalid_transaction_type(String transactionType, String transactionTypeValue) throws FileNotFoundException {
        System.out.println("On entering "+transactionType+" and "+transactionTypeValue+" for invalid transaction type");
         if(transactionTypeValue.equalsIgnoreCase("empty")){
            transTypeEnum = " ";
        }
        else if(transactionTypeValue.equalsIgnoreCase("null")){
            transTypeEnum = null;
        }
        else {
            transTypeEnum = transactionTypeValue;
        }
        payer.setSenderVpa(reader.getValueFromConfig("wallet.test.user2.mobile.number"));
        payer.setSenderAccountId(reader.getValueFromConfig("wallet.test.user2.mobile.number"));
        payer.setPasscode(getEncryptedAuthData(reader.getValueFromConfig("wallet.test.user2.passcode")));
        payer.setUniqueFrontendId(getUniqueFrontendId());
        balance = Double.valueOf(getWalletBalance(payerAccessToken));
        payer.setWalletBalance(String.valueOf(balance));
        payee.setAmount(String.valueOf(getRandomAmount())); // setting amount
        payee.setComment(reader.getValueFromConfig("comment")); // setting comment
        payer.setAction(reader.getValueFromConfig("wallet.pay.action"));
        payer.setDeviceTypeEnum(reader.getValueFromConfig("device.type.enum"));
        res = checkRuleApi(payee,payer,transTypeEnum,payerAccessToken);  //calling check rule api
        responseObject = extractJsonObjectFromResponse(res);  // extracting response object from response
        if(res.getStatusCode()!=GlobalConstant.HTTP_OK){
            errorValidationOfTM(res,payee,payer);
        }
        else {
            checkRuleSuccessValidation(res);
        }
    }
    @Given("User click pay api to do p2p transaction for invalid transaction type")
    public void user_click_pay_api_to_do_p2p_transaction_for_invalid_transaction_type() throws FileNotFoundException {
        System.out.println("User click pay api to do p2p transaction for invalid transaction type");
        res = pay(payee,payer,transTypeEnum,payerAccessToken);
    }
    @Then("Verify p2p transaction status for invalid transaction type")
    public void verify_p2p_transaction_status_for_invalid_transaction_type() throws FileNotFoundException {
        System.out.println("Verify p2p transaction status for invalid transaction type");
        errorValidationOfTM(res,payee,payer);  // calling method for error validations
    }

    // ************************* P2P transaction for valid transaction type *****************************
    @Given("User login with valid cred to do p2p transaction for valid transaction type")
    public void user_login_with_valid_cred_to_do_p2p_transaction_for_valid_transaction_type() throws FileNotFoundException {
        System.out.println("User login with valid cred to do p2p transaction for valid transaction type");
        res = login(reader.getValueFromConfig("wallet.test.user2.mobile.number"),reader.getValueFromConfig("wallet.test.user2.passcode"),reader.getValueFromConfig("wallet.test.user2.device.id"),reader.getValueFromConfig("wallet.test.user2.device.id"));
        payerAccessToken = getAccessTokenResponseData(res,"access_token");
    }
    @Given("User has a valid detail of receiver to do p2p transaction for valid transaction type")
    public void user_has_a_valid_detail_of_receiver_to_do_p2p_transaction_for_valid_transaction_type() throws FileNotFoundException {
        System.out.println("User has a valid detail of receiver to do p2p transaction for valid transaction type");
        payee.setReceiverVpa(reader.getValueFromConfig("wallet.test.user1.vpa"));
        payee.setReceiverMobileNumber(reader.getValueFromConfig("wallet.test.user1.mobile.number"));
        res = checkVpa(payerAccessToken,payee.getReceiverMobileNumber()); //calling check vpa api
        responseObject = extractJsonObjectFromResponse(res);  // extracting response object from response
        if(res.getStatusCode()!=HTTP_OK){
            errorValidationOfTM(res,payee,payer); // calling method for error validations
        }
        else {
            jsonSchemaValidator(res,reader.getValueFromConfig("check.vpa.valid.schema")); //schema validation
            assertJsonValueEquals("message","VPA fetch successfully",responseObject);  // assertions
            payee.setReceiverName((String) getResponseData(res,"results.senderName"));
        }
    }
    @Given("User enter amount and other details to do p2p transaction for valid transaction type")
    public void user_enter_and_and_other_details_to_do_p2p_transaction_for_valid_transaction_type() throws FileNotFoundException {
        System.out.println("User enter amount and other details to do p2p transaction for valid transaction type");
        transTypeEnum = String.valueOf(TransTypeEnum.WALLET_TO_WALLET);
        payer.setSenderVpa(reader.getValueFromConfig("wallet.test.user2.mobile.number"));
        payer.setSenderAccountId(reader.getValueFromConfig("wallet.test.user2.mobile.number"));
        payer.setPasscode(getEncryptedAuthData(reader.getValueFromConfig("wallet.test.user2.passcode")));
        payer.setUniqueFrontendId(getUniqueFrontendId());
        balance = Double.valueOf(getWalletBalance(payerAccessToken));
        payer.setWalletBalance(String.valueOf(balance));
        payee.setAmount(String.valueOf(getRandomAmount())); // setting amount
        payee.setComment(reader.getValueFromConfig("comment")); // setting comment
        payer.setAction(reader.getValueFromConfig("wallet.pay.action"));
        payer.setDeviceTypeEnum(reader.getValueFromConfig("device.type.enum"));
        res = checkRuleApi(payee,payer,transTypeEnum,payerAccessToken);  //calling check rule api
        responseObject = extractJsonObjectFromResponse(res);  // extracting response object from response
        if(res.getStatusCode()!=GlobalConstant.HTTP_OK){
            errorValidationOfTM(res,payee,payer);
        }
        else {
            checkRuleSuccessValidation(res);
        }
    }
    @Given("User click pay api to do p2p transaction for valid transaction type")
    public void user_click_pay_api_to_do_p2p_transaction_for_valid_transaction_type() throws FileNotFoundException {
        System.out.println("User click pay api to do p2p transaction for valid transaction type");
        res = pay(payee,payer,transTypeEnum,payerAccessToken);
    }
    @Then("Verify p2p transaction status for valid transaction type")
    public void verify_p2p_transaction_status_for_valid_transaction_type() throws FileNotFoundException {
        System.out.println("Verify p2p transaction status for valid transaction type");
        if(res.getStatusCode()!=HTTP_OK){
            payer.setIsTransactionSuccess(false);
            errorValidationOfTM(res,payee,payer); // calling method for error validations
        }
        else {
            transactionId = successTransactionValidation(res,payee,payer,transTypeEnum);
            payer.setIsTransactionSuccess(true);
        }
    }

    @Then("Also verify p2p transaction status from db if transaction has been succeed for valid transaction type")
    public void also_verify_p2p_transaction_status_from_db_if_transaction_has_been_succeed_for_valid_transaction_type() throws SQLException {
        System.out.println("Also verify p2p transaction status from db if transaction has been succeed for valid transaction type");
        if(payer.getIsTransactionSuccess() && transactionId!=null){
            Transaction transaction = getTransactionDetails(transactionId);
            System.out.println(transaction);
            successTransactionValidationFromDB(res,transaction,transTypeEnum); // calling method to validate transaction from db
        }
        else {
            System.out.println("Transaction Failed! Transaction not Verified from DB");
        }
    }

    // ************************* P2P transaction for same amount to same user *****************************
    @Given("User login with valid cred to do p2p transaction for same amount to same user")
    public void user_login_with_valid_cred_to_do_p2p_transaction_for_same_amount_to_same_user() throws FileNotFoundException {
        System.out.println("User login with valid cred to do p2p transaction for same amount to same user");
        res = login(reader.getValueFromConfig("wallet.test.user5.mobile.number"),reader.getValueFromConfig("wallet.test.user5.passcode"),reader.getValueFromConfig("wallet.test.user5.device.id"),reader.getValueFromConfig("wallet.test.user5.device.id"));
        payerAccessToken = getAccessTokenResponseData(res,"access_token");
    }
    @Given("User has a valid detail of receiver to do p2p transaction for same amount to same user")
    public void user_has_a_valid_detail_of_receiver_to_do_p2p_transaction_for_same_amount_to_same_user() throws FileNotFoundException {
        System.out.println("User has a valid detail of receiver to do p2p transaction for same amount to same user");
        payee.setReceiverVpa(reader.getValueFromConfig("wallet.test.user6.vpa"));
        payee.setReceiverMobileNumber(reader.getValueFromConfig("wallet.test.user6.mobile.number"));
        res = checkVpa(payerAccessToken,payee.getReceiverMobileNumber()); //calling check vpa api
        responseObject = extractJsonObjectFromResponse(res);  // extracting response object from response
        if(res.getStatusCode()!=HTTP_OK){
            errorValidationOfTM(res,payee,payer); // calling method for error validations
        }
        else {
            jsonSchemaValidator(res,reader.getValueFromConfig("check.vpa.valid.schema")); //schema validation
            assertJsonValueEquals("message","VPA fetch successfully",responseObject);  // assertions
            payee.setReceiverName((String) getResponseData(res,"results.senderName"));
        }
    }
    @Given("User enter {string} and other details to do p2p transaction for same amount to same user")
    public void user_enter_and_other_details_to_do_p2p_transaction_for_same_amount_to_same_user(String transactionAmount) throws FileNotFoundException {
        System.out.println("User enter amount ->  "+transactionAmount+" and other details to do p2p transaction for same amount to same user");
        payee.setAmount(transactionAmount); // setting amount
        transTypeEnum = String.valueOf(TransTypeEnum.WALLET_TO_WALLET);
        payer.setSenderVpa(reader.getValueFromConfig("wallet.test.user2.mobile.number"));
        payer.setSenderAccountId(reader.getValueFromConfig("wallet.test.user2.mobile.number"));
        payer.setPasscode(getEncryptedAuthData(reader.getValueFromConfig("wallet.test.user2.passcode")));
        payer.setUniqueFrontendId(getUniqueFrontendId());
        balance = Double.valueOf(getWalletBalance(payerAccessToken));
        payer.setWalletBalance(String.valueOf(balance));
        payee.setComment(reader.getValueFromConfig("comment")); // setting comment
        payer.setAction(reader.getValueFromConfig("wallet.pay.action"));
        payer.setDeviceTypeEnum(reader.getValueFromConfig("device.type.enum"));
        res = checkRuleApi(payee,payer,transTypeEnum,payerAccessToken);  //calling check rule api
        responseObject = extractJsonObjectFromResponse(res);  // extracting response object from response
        if(res.getStatusCode()!=GlobalConstant.HTTP_OK){
            errorValidationOfTM(res,payee,payer);
        }
        else {
            checkRuleSuccessValidation(res);
        }
    }
    @Given("User click pay api to do p2p transaction for same amount to same user")
    public void user_click_pay_api_to_do_p2p_transaction_for_same_amount_to_same_user() throws FileNotFoundException {
        System.out.println("User click pay api to do p2p transaction for same amount to same user");
        res = pay(payee,payer,transTypeEnum,payerAccessToken);
    }
    @Then("Verify p2p transaction status for same amount to same user")
    public void verify_p2p_transaction_status_for_same_amount_to_same_user() throws FileNotFoundException {
        System.out.println("Verify p2p transaction status for same amount to same user");
        if(res.getStatusCode()!=HTTP_OK){
            payer.setIsTransactionSuccess(false);
            errorValidationOfTM(res,payee,payer); // calling method for error validations
        }
        else {
            transactionId = successTransactionValidation(res,payee,payer,transTypeEnum);
            payer.setIsTransactionSuccess(true);
        }
    }
    @Then("Also verify p2p transaction status from db if transaction has been succeed for same amount to same user")
    public void also_verify_p2p_transaction_status_from_db_if_transaction_has_been_succeed_for_same_amount_to_same_user() throws SQLException {
        System.out.println("Also verify p2p transaction status from db if transaction has been succeed for same amount to same user");
        if(payer.getIsTransactionSuccess() && transactionId!=null){
            Transaction transaction = getTransactionDetails(transactionId);
            System.out.println(transaction);
            successTransactionValidationFromDB(res,transaction,transTypeEnum); // calling method to validate transaction from db
        }
        else {
            System.out.println("Transaction Failed! Transaction not Verified from DB");
        }
    }
}
