package stepdef.Wallet.tm;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.restassured.response.Response;
import org.json.JSONObject;
import org.junit.Assert;
import resources.Payee;
import resources.Payer;
import resources.TransTypeEnum;
import resources.Transaction;
import utilities.PropertyReader;
import java.io.FileNotFoundException;
import java.sql.SQLException;
import static utilities.CommonStepDef.*;
import static utilities.GlobalConstant.HTTP_OK;
import static utilities.Utils.*;
import static utilities.Utils.getEncryptedAuthData;

public class WalletToBank {
    private static Response res;
    private static String payerAccessToken;
    private static Double balance;
    private static JSONObject responseObject;
    private static String requestId;
    private static String transTypeEnum;
    private static String beneficiaryId;
    private static String validAccountNumber;
    private static String transactionChargeId;
    private static String ifscCode;
    private static String receiverName;
    private static String transactionId;
    private static PropertyReader reader = new PropertyReader();
    private static Payee payee = new Payee();
    private static Payer payer = new Payer();

    // ************************* P2B Transaction when user has insufficient balance *****************************
    @Given("User login with valid cred which has insufficient balance for transaction")
    public void user_login_with_valid_cred_which_has_insufficient_balance_for_transaction() throws FileNotFoundException {
        System.out.println("User login with valid cred which has insufficient balance for transaction");
        res = login(reader.getValueFromConfig("wallet.test.user2.mobile.number"),reader.getValueFromConfig("wallet.test.user2.passcode"),reader.getValueFromConfig("wallet.test.user2.device.id"),reader.getValueFromConfig("wallet.test.user2.device.id"));
        payerAccessToken = getAccessTokenResponseData(res,"access_token");
    }
    @Given("User has a valid details of beneficiary for insufficient balance transaction")
    public void user_has_a_valid_details_of_beneficiary_for_insufficient_balance_transaction() throws FileNotFoundException {
        System.out.println("User has a valid details of beneficiary for insufficient balance transaction");
        res = getBeneficiaryDetails(payerAccessToken,reader.getValueFromConfig("limit"),reader.getValueFromConfig("offset")); // get beneficiary details
        if(res.getStatusCode()!=HTTP_OK){
            errorValidationOfTM(res,payee,payer);
        }
        else {
            Payee payee1 = setBeneficiaryDetails(res); // calling method to get beneficiary details
            if(payee1.getBankName()!=null){
                payee.setBankName(payee1.getBankName());
                payee.setAccountNumber(payee1.getAccountNumber());
                payee.setReceiverName(payee1.getReceiverName());
                payee.setIfsc(payee1.getIfsc());
            }
        }

    }
    @Given("User enter amount and other details for insufficient balance transaction")
    public void user_enter_amount_and_other_details_for_insufficient_balance_transaction() throws FileNotFoundException {
        System.out.println("User enter amount and other details for insufficient balance transaction");
        String payerVpa = reader.getValueFromConfig("wallet.test.user2.vpa");
        payer.setSenderAccountId(payerVpa);
        payer.setSenderVpa(payerVpa);
        payer.setAction(reader.getValueFromConfig("wallet.pay.action"));
        payer.setDeviceTypeEnum(reader.getValueFromConfig("device.type.enum"));
        balance = Double.valueOf(getWalletBalance(payerAccessToken)); // fetching payer wallet balance
        payer.setWalletBalance(String.valueOf(balance));
        payer.setUniqueFrontendId(getUniqueFrontendId());
        payee.setAmount(String.format("%.2f",getRandomAmount()+balance)); // setting balance greater then wallet balance
        payee.setComment(reader.getValueFromConfig("comment")); // set comment
        payee.setTransactionSubTypeEnum(reader.getValueFromConfig("wallet.transaction.subtype.enum")); // set transaction subtype enum
        transTypeEnum = String.valueOf(TransTypeEnum.WALLET_TO_BANK);
    }
    @Given("After applying transaction charges for insufficient balance transaction")
    public void after_applying_transaction_charges_for_insufficient_balance_transaction() throws FileNotFoundException {
        System.out.println("After applying transaction charges for insufficient balance transaction");
        res = getTransactionCharges(payerAccessToken,payee,transTypeEnum); // calling transaction charge api for transaction charge calculation
        if(res.getStatusCode()!=HTTP_OK){
            errorValidationOfTM(res,payee,payer);
        }
        else {
            System.out.println(res.asPrettyString());
            Payer payer1 = calculateTransactionCharge(res,payee); // calling method for transaction charge id
            payer.setTransactionChargeId(payer1.getTransactionChargeId()); // setting transaction charge id
            payer.setTotalTransactionAmount(payer1.getTotalTransactionAmount()); // setting total transaction amount
        }

    }
    @Given("User click on pay api for insufficient balance transaction")
    public void user_click_on_pay_api_for_insufficient_balance_transaction() throws FileNotFoundException {
        System.out.println("User click on pay api for insufficient balance transaction");
        res = checkRuleApi(payee,payer,transTypeEnum,payerAccessToken);  //calling check rule api
        errorValidationOfTM(res,payee,payer); // calling method for error handling
    }
    @Then("Verify transaction status for insufficient balance transaction")
    public void verify_transaction_status_for_insufficient_balance_transaction() throws FileNotFoundException, SQLException, InterruptedException {
        System.out.println("Verify transaction status for insufficient balance transaction");
        errorValidationOfTM(res,payee,payer); // calling method for error handling
    }

    // ************************* P2B Transaction when user wallet is not active *****************************
    @Given("User login with valid cred which wallet is not active")
    public void user_login_with_valid_cred_which_wallet_is_not_active() throws FileNotFoundException {
        System.out.println("User login with valid cred which wallet is not active");
        res = login(reader.getValueFromConfig("vc.user.mobile.number.withoutwallet"),reader.getValueFromConfig("vc.user.passcode.withoutwallet"),reader.getValueFromConfig("vc.user.deviceid.withoutwallet"),reader.getValueFromConfig("vc.user.deviceid.withoutwallet"));
        payerAccessToken = getAccessTokenResponseData(res,"access_token");
    }
    @Given("User try to do P2B transaction")
    public void user_try_to_do_p2b_transaction() throws FileNotFoundException {
        System.out.println("User try to do P2B transaction");
        res = getBeneficiaryDetails(payerAccessToken,reader.getValueFromConfig("limit"),reader.getValueFromConfig("offset")); // get beneficiary details
        System.out.println(res.getStatusCode());
        System.out.println(res.asPrettyString());
    }
    @Then("Verify P2B transaction status for inactive wallet")
    public void verify_p2b_transaction_status_for_inactive_wallet() throws FileNotFoundException {
        System.out.println("Verify P2B transaction status for inactive wallet");
        if(res.getStatusCode()!=HTTP_OK){
            errorValidationOfTM(res,payee,payer); // calling method for inactive wallet error validation
        }
        else {
            System.out.println(res.asPrettyString());
            Assert.assertEquals("Wallet is not active","Beneficiary fetched successfully");
        }
    }


    // ************************* P2B Transaction for invalid amount *****************************
    @Given("User login with valid cred to do p2b transaction for invalid  amount")
    public void user_login_with_valid_cred_for_p2b_transaction_for_invalid_and_valid_amount() throws FileNotFoundException {
        System.out.println("User login with valid cred to do p2b transaction for invalid  amount");
        res = login(reader.getValueFromConfig("wallet.test.user2.mobile.number"),reader.getValueFromConfig("wallet.test.user2.passcode"),reader.getValueFromConfig("wallet.test.user2.device.id"),reader.getValueFromConfig("wallet.test.user2.device.id"));
        payerAccessToken = getAccessTokenResponseData(res,"access_token");
    }
    @Given("User has a valid details of beneficiary to do p2b transaction for invalid amount")
    public void user_has_a_valid_details_of_beneficiary_for_invalid_and_valid_amount_transaction() throws FileNotFoundException {
        System.out.println("User has a valid details of beneficiary to do p2b transaction for invalid amount");
        res = getBeneficiaryDetails(payerAccessToken,reader.getValueFromConfig("limit"),reader.getValueFromConfig("offset")); // get beneficiary details
        if(res.getStatusCode()!=HTTP_OK){
            errorValidationOfTM(res,payee,payer);
        }
        else {
            Payee payee1 = setBeneficiaryDetails(res); // calling method to get beneficiary details
            if(payee1.getBankName()!=null){
                payee.setBankName(payee1.getBankName());
                payee.setAccountNumber(payee1.getAccountNumber());
                payee.setReceiverName(payee1.getReceiverName());
                payee.setIfsc(payee1.getIfsc());
            }
        }
    }
    @Given("User enter {string} and {string} to do p2b transaction for invalid amount")
    public void user_enter_and_for_invalid_and_valid_amount_transaction(String amountType, String amountValue) throws FileNotFoundException {
        System.out.println("User enter amountType -> "+amountType+" and amountValue -> "+amountValue+" to do p2b transaction for invalid amount");
        if(amountValue.equalsIgnoreCase("null")){
            payee.setAmount(null);
        }
        else if(amountValue.equalsIgnoreCase("empty")){
            payee.setAmount(" ");
        }
        else {
            payee.setAmount(amountValue);
        }
        String payerVpa = reader.getValueFromConfig("wallet.test.user2.vpa");
        payer.setSenderAccountId(payerVpa);
        payer.setSenderVpa(payerVpa);
        payer.setAction(reader.getValueFromConfig("wallet.pay.action"));
        payer.setDeviceTypeEnum(reader.getValueFromConfig("device.type.enum"));
        balance = Double.valueOf(getWalletBalance(payerAccessToken)); // fetching payer wallet balance
        payer.setWalletBalance(String.valueOf(balance));
        payer.setUniqueFrontendId(getUniqueFrontendId());
        payee.setComment(reader.getValueFromConfig("comment")); // set comment
        payee.setTransactionSubTypeEnum(reader.getValueFromConfig("wallet.transaction.subtype.enum")); // set transaction subtype enum
        transTypeEnum = String.valueOf(TransTypeEnum.WALLET_TO_BANK);
        payer.setPasscode(getEncryptedAuthData(reader.getValueFromConfig("wallet.test.user2.passcode")));

    }
    @Given("After applying transaction charges on invalid amount")
    public void after_applying_transaction_charges_on_invalid_amount() throws FileNotFoundException {
        System.out.println("After applying transaction charges on invalid amount");
        res = getTransactionCharges(payerAccessToken,payee,transTypeEnum); // calling transaction charge api for transaction charge calculation
        errorValidationOfTM(res,payee,payer); // calling method for error validation
    }
    @Given("User click on pay api to do p2b transaction for invalid amount")
    public void user_click_on_pay_api_for_invalid_and_invalid_amount_transaction() throws FileNotFoundException {
        System.out.println("User click on pay api to do p2b transaction for invalid amount");
        res = checkRuleApi(payee,payer,transTypeEnum,payerAccessToken);  //calling check rule api
        errorValidationOfTM(res,payee,payer); // calling method for error validation
        res = pay(payee,payer,transTypeEnum,payerAccessToken);  // calling pay api
    }
    @Then("Verify p2b transaction status for invalid amount")
    public void verify_transaction_status_for_invalid_and_valid_amount() throws FileNotFoundException, SQLException, InterruptedException {
        System.out.println("Verify p2b transaction status for invalid amount");
        errorValidationOfTM(res,payee,payer); // calling method for error validation
    }
    @Then("Also verify transaction status from db for invalid and valid amount")
    public void also_verify_transaction_status_from_db_for_invalid_and_valid_amount() throws SQLException {
        System.out.println("Also verify transaction status from db for invalid and valid amount");
        if(payer.getIsTransactionSuccess() && transactionId!=null){
            Transaction transaction = getTransactionDetails(transactionId);
            System.out.println(transaction);
            successTransactionValidationFromDB(res,transaction,transTypeEnum);
        }
    }

    // ************************* P2B Transaction for valid amount *****************************
    @Given("User login with valid cred to do p2b transaction for valid  amount")
    public void user_login_with_valid_cred_for_p2b_transaction_for_valid_and_valid_amount() throws FileNotFoundException {
        System.out.println("User login with valid cred to do p2b transaction for valid  amount");
        res = login(reader.getValueFromConfig("wallet.test.user2.mobile.number"),reader.getValueFromConfig("wallet.test.user2.passcode"),reader.getValueFromConfig("wallet.test.user2.device.id"),reader.getValueFromConfig("wallet.test.user2.device.id"));
        payerAccessToken = getAccessTokenResponseData(res,"access_token");
    }
    @Given("User has a valid details of beneficiary to do p2b transaction for valid amount")
    public void user_has_a_valid_details_of_beneficiary_for_valid_and_valid_amount_transaction() throws FileNotFoundException {
        System.out.println("User has a valid details of beneficiary to do p2b transaction for valid amount");
        res = getBeneficiaryDetails(payerAccessToken,reader.getValueFromConfig("limit"),reader.getValueFromConfig("offset")); // get beneficiary details
        if(res.getStatusCode()!=HTTP_OK){
            errorValidationOfTM(res,payee,payer);
        }
        else {
            Payee payee1 = setBeneficiaryDetails(res); // calling method to get beneficiary details
            if(payee1.getBankName()!=null){
                payee.setBankName(payee1.getBankName());
                payee.setAccountNumber(payee1.getAccountNumber());
                payee.setReceiverName(payee1.getReceiverName());
                payee.setIfsc(payee1.getIfsc());
            }
        }
    }
    @Given("User enter amount and other details to do p2b transaction for valid amount")
    public void user_enter_and_for_valid_and_valid_amount_transaction() throws FileNotFoundException {
        System.out.println("User enter amount and other details to do p2b transaction for valid amount");
        payee.setAmount(String.valueOf(getRandomAmount()));
        String payerVpa = reader.getValueFromConfig("wallet.test.user2.vpa");
        payer.setSenderAccountId(payerVpa);
        payer.setSenderVpa(payerVpa);
        payer.setAction(reader.getValueFromConfig("wallet.pay.action"));
        payer.setDeviceTypeEnum(reader.getValueFromConfig("device.type.enum"));
        balance = Double.valueOf(getWalletBalance(payerAccessToken)); // fetching payer wallet balance
        payer.setWalletBalance(String.valueOf(balance));
        payer.setUniqueFrontendId(getUniqueFrontendId());
        payee.setComment(reader.getValueFromConfig("comment")); // set comment
        payee.setTransactionSubTypeEnum(reader.getValueFromConfig("wallet.transaction.subtype.enum")); // set transaction subtype enum
        transTypeEnum = String.valueOf(TransTypeEnum.WALLET_TO_BANK);
    }
    @Given("After applying transaction charges on valid amount")
    public void after_applying_transaction_charges_on_valid_amount() throws FileNotFoundException {
        System.out.println("After applying transaction charges on valid amount");
        res = getTransactionCharges(payerAccessToken,payee,transTypeEnum); // calling transaction charge api for transaction charge calculation
        if(res.getStatusCode()!=HTTP_OK){
            errorValidationOfTM(res,payee,payer);
        }
        else {
            Payer payer1 = calculateTransactionCharge(res,payee); // calling method for transaction charge id
            payer.setTransactionChargeId(payer1.getTransactionChargeId()); // setting transaction charge id
            payer.setTotalTransactionAmount(payer1.getTotalTransactionAmount()); // setting total transaction amount
        }
    }
    @Given("User click on pay api to do p2b transaction for valid amount")
    public void user_click_on_pay_api_for_invalid_and_valid_amount_transaction() throws FileNotFoundException {
        System.out.println("User click on pay api to do p2b transaction for valid amount");
        res = checkRuleApi(payee,payer,transTypeEnum,payerAccessToken);  //calling check rule api
        if(res.getStatusCode()!=HTTP_OK){
            errorValidationOfTM(res,payee,payer);
        }
        else {
            assertJsonValueEquals("message","Success",extractJsonObjectFromResponse(res)); // assertion
            payer.setPasscode(getEncryptedAuthData(reader.getValueFromConfig("wallet.test.user2.passcode")));
            res = pay(payee,payer,transTypeEnum,payerAccessToken);  // calling pay api
            if(res.getStatusCode()!=HTTP_OK){
                errorValidationOfTM(res,payee,payer);
            }
            else {
                assertJsonValueEquals("message","Success",extractJsonObjectFromResponse(res)); // assertion
                requestId = (String) getResponseData(res,"results.data");
                res = payByRequestId(requestId,payerAccessToken); //calling pay by request id
            }
        }
    }
    @Then("Verify p2b transaction status for valid amount")
    public void verify_transaction_status_for_valid_and_valid_amount() throws FileNotFoundException, SQLException, InterruptedException {
        System.out.println("Verify p2b transaction status for valid amount");
        if(res.getStatusCode()!=HTTP_OK){
            payer.setIsTransactionSuccess(false); // when transaction failed
            errorValidationOfTM(res,payee,payer);
        }
        else {
            transactionId =  successTransactionValidation(res,payee,payer,transTypeEnum);
            payer.setIsTransactionSuccess(true);
        }
    }
    @Then("Also verify p2b transaction status from db if transaction has been succeed for valid amount")
    public void also_verify_transaction_status_from_db_for_valid_and_valid_amount() throws SQLException {
        System.out.println("Also verify p2b transaction status from db if transaction has been succeed for valid amount");
        if(payer.getIsTransactionSuccess() && transactionId!=null){
            Transaction transaction = getTransactionDetails(transactionId);
            System.out.println(transaction);
            successTransactionValidationFromDB(res,transaction,transTypeEnum);
        }
        else {
            System.out.println("Transaction has not verified from DB!!!!");
        }
    }


    // ************************* P2B Transaction for invalid account number *****************************
    @Given("User login with valid cred to do p2b transaction for invalid account number")
    public void user_login_with_valid_cred_for_p2b_transaction_for_invalid_and_valid_account_number() throws FileNotFoundException {
        System.out.println("User login with valid cred to do p2b transaction for invalid account number");
        res = login(reader.getValueFromConfig("wallet.test.user2.mobile.number"),reader.getValueFromConfig("wallet.test.user2.passcode"),reader.getValueFromConfig("wallet.test.user2.device.id"),reader.getValueFromConfig("wallet.test.user2.device.id"));
        payerAccessToken = getAccessTokenResponseData(res,"access_token");
    }
    @Given("User has a valid details of beneficiary to do p2b transaction for invalid account number")
    public void user_has_a_valid_details_of_beneficiary_for_invalid_and_valid_account_number_transaction() throws FileNotFoundException {
        System.out.println("User has a valid details of beneficiary to do p2b transaction for invalid account number");
        res = getBeneficiaryDetails(payerAccessToken,reader.getValueFromConfig("limit"),reader.getValueFromConfig("offset")); // get beneficiary details
        if(res.getStatusCode()!=HTTP_OK){
            errorValidationOfTM(res,payee,payer);
        }
        else {
            Payee payee1 = setBeneficiaryDetails(res);
            if(payee1.getBankName()!=null){
                payee.setBankName(payee1.getBankName());
                //validAccountNumber = payee1.getAccountNumber();
                payee.setReceiverName(payee1.getReceiverName());
                payee.setIfsc(payee1.getIfsc());
            }
        }
    }
    @Given("User enter {string} and {string} to do p2b transaction for invalid account number")
    public void user_enter_and_for_invalid_and_valid_account_number_transaction(String accountNumberType, String accountNumberValue) throws FileNotFoundException {
        System.out.println("User enter accountNumberType -> "+accountNumberType+" and accountNumberValue -> "+accountNumberValue+" to do p2b transaction for invalid account number");
        if(accountNumberValue.equalsIgnoreCase("null")){
            payee.setAccountNumber(null);
        }
        else if(accountNumberValue.equalsIgnoreCase(" ")){
            payee.setAccountNumber(" ");
        }
        else {
            payee.setAccountNumber(accountNumberValue);
        }

        String payerVpa = reader.getValueFromConfig("wallet.test.user2.vpa");
        payer.setSenderAccountId(payerVpa);
        payer.setSenderVpa(payerVpa);
        payer.setAction(reader.getValueFromConfig("wallet.pay.action"));
        payer.setDeviceTypeEnum(reader.getValueFromConfig("device.type.enum"));
        balance = Double.valueOf(getWalletBalance(payerAccessToken)); // fetching payer wallet balance
        payer.setWalletBalance(String.valueOf(balance));
        payer.setUniqueFrontendId(getUniqueFrontendId());
        payee.setAmount(String.valueOf(getRandomAmount()));
        payee.setComment(reader.getValueFromConfig("comment")); // set comment
        payee.setTransactionSubTypeEnum(reader.getValueFromConfig("wallet.transaction.subtype.enum")); // set transaction subtype enum
        transTypeEnum = String.valueOf(TransTypeEnum.WALLET_TO_BANK);
        payer.setPasscode(getEncryptedAuthData(reader.getValueFromConfig("wallet.test.user2.passcode")));
    }
    @Given("After applying transaction charges for invalid account number")
    public void after_applying_transaction_charges_for_invalid_account_number() throws FileNotFoundException {
        System.out.println("After applying transaction charges for invalid account number");
        res = getTransactionCharges(payerAccessToken,payee,transTypeEnum); // calling transaction charge api for transaction charge calculation
        if(res.getStatusCode()!=HTTP_OK){
            errorValidationOfTM(res,payee,payer);
        }
        else {
            Payer payer1 = calculateTransactionCharge(res,payee); // calling method for transaction charge id
            payer.setTransactionChargeId(payer1.getTransactionChargeId()); // setting transaction charge id
            payer.setTotalTransactionAmount(payer1.getTotalTransactionAmount()); // setting total transaction amount
        }
    }
    @Given("User click on pay api to do p2b transaction for invalid account number")
    public void user_click_on_pay_api_for_invalid_and_valid_account_number_transaction() throws FileNotFoundException {
        System.out.println("User click on pay api to do p2b transaction for invalid account number");
        res = checkRuleApi(payee,payer,transTypeEnum,payerAccessToken);  //calling check rule api
        errorValidationOfTM(res,payee,payer); // calling method for error validation
        res = pay(payee,payer,transTypeEnum,payerAccessToken);  // calling pay api
    }
    @Then("Verify p2b transaction status for invalid account number")
    public void verify_transaction_status_for_invalid_and_valid_account_number() throws FileNotFoundException{
        System.out.println("Verify p2b transaction status for invalid account number");
        errorValidationOfTM(res,payee,payer); // calling method for error validation
    }

    // ************************* P2B Transaction for valid account number *****************************
    @Given("User login with valid cred to do p2b transaction for valid  account number")
    public void user_login_with_valid_cred_for_p2b_transaction_for_valid_and_valid_account_number() throws FileNotFoundException {
        System.out.println("User login with valid cred to do p2b transaction for valid  account number");
        res = login(reader.getValueFromConfig("wallet.test.user2.mobile.number"),reader.getValueFromConfig("wallet.test.user2.passcode"),reader.getValueFromConfig("wallet.test.user2.device.id"),reader.getValueFromConfig("wallet.test.user2.device.id"));
        payerAccessToken = getAccessTokenResponseData(res,"access_token");
    }
    @Given("User has a valid details of beneficiary to do p2b transaction for valid account number")
    public void user_has_a_valid_details_of_beneficiary_for_valid_and_valid_account_number_transaction() throws FileNotFoundException {
        System.out.println("User has a valid details of beneficiary to do p2b transaction for valid account number");
        res = getBeneficiaryDetails(payerAccessToken,reader.getValueFromConfig("limit"),reader.getValueFromConfig("offset")); // get beneficiary details
        if(res.getStatusCode()!=HTTP_OK){
            errorValidationOfTM(res,payee,payer);
        }
        else {
            Payee payee1 = setBeneficiaryDetails(res);
            if(payee1.getBankName()!=null){
                payee.setBankName(payee1.getBankName());
                validAccountNumber = payee1.getAccountNumber();
                payee.setReceiverName(payee1.getReceiverName());
                payee.setIfsc(payee1.getIfsc());
            }
        }
    }
    @Given("User enter account number and other details to do p2b transaction")
    public void user_enter_and_for_valid_and_valid_account_number_transaction() throws FileNotFoundException {
        System.out.println("User enter account number and other details to do p2b transaction");
        payee.setAccountNumber(validAccountNumber);
        String payerVpa = reader.getValueFromConfig("wallet.test.user2.vpa");
        payer.setSenderAccountId(payerVpa);
        payer.setSenderVpa(payerVpa);
        payer.setAction(reader.getValueFromConfig("wallet.pay.action"));
        payer.setDeviceTypeEnum(reader.getValueFromConfig("device.type.enum"));
        balance = Double.valueOf(getWalletBalance(payerAccessToken)); // fetching payer wallet balance
        payer.setWalletBalance(String.valueOf(balance));
        payer.setUniqueFrontendId(getUniqueFrontendId());
        payee.setAmount(String.valueOf(getRandomAmount()));
        payee.setComment(reader.getValueFromConfig("comment")); // set comment
        payee.setTransactionSubTypeEnum(reader.getValueFromConfig("wallet.transaction.subtype.enum")); // set transaction subtype enum
        transTypeEnum = String.valueOf(TransTypeEnum.WALLET_TO_BANK);
    }
    @Given("After applying transaction charges for valid account number")
    public void after_applying_transaction_charges_for_valid_account_number() throws FileNotFoundException {
        System.out.println("After applying transaction charges for valid account number");
        res = getTransactionCharges(payerAccessToken,payee,transTypeEnum); // calling transaction charge api for transaction charge calculation
        if(res.getStatusCode()!=HTTP_OK){
            errorValidationOfTM(res,payee,payer);
        }
        else {
            Payer payer1 = calculateTransactionCharge(res,payee); // calling method for transaction charge id
            payer.setTransactionChargeId(payer1.getTransactionChargeId()); // setting transaction charge id
            payer.setTotalTransactionAmount(payer1.getTotalTransactionAmount()); // setting total transaction amount
        }
    }
    @Given("User click on pay api to do p2b transaction for valid account number")
    public void user_click_on_pay_api_for_valid_and_valid_account_number_transaction() throws FileNotFoundException {
        System.out.println("User click on pay api to do p2b transaction for valid account number");
         res = checkRuleApi(payee,payer,transTypeEnum,payerAccessToken);  //calling check rule api
        if(res.getStatusCode()!=HTTP_OK){
            errorValidationOfTM(res,payee,payer);
        }
        else {
            assertJsonValueEquals("message","Success",extractJsonObjectFromResponse(res)); // assertion
            payer.setPasscode(getEncryptedAuthData(reader.getValueFromConfig("wallet.test.user2.passcode")));
            res = pay(payee,payer,transTypeEnum,payerAccessToken);  // calling pay api
            if(res.getStatusCode()!=HTTP_OK){
                errorValidationOfTM(res,payee,payer);
            }
            else {
                assertJsonValueEquals("message","Success",extractJsonObjectFromResponse(res)); // assertion
                requestId = (String) getResponseData(res,"results.data");
                res = payByRequestId(requestId,payerAccessToken); //calling pay by request id
            }
        }
    }
    @Then("Verify p2b transaction status for valid account number")
    public void verify_transaction_status_for_valid_and_valid_account_number() throws FileNotFoundException{
        System.out.println("Verify p2b transaction status for valid account number");
        if(res.getStatusCode()!=HTTP_OK){
            payer.setIsTransactionSuccess(false); // when transaction failed
            errorValidationOfTM(res,payee,payer);
        }
        else {
            transactionId =  successTransactionValidation(res,payee,payer,transTypeEnum);
            payer.setIsTransactionSuccess(true);
        }
    }
    @Then("Also verify p2b transaction status from db if transaction has been succeed for valid account number")
    public void also_verify_transaction_status_from_db_for_valid_and_valid_account_number() throws SQLException {
        System.out.println("Also verify p2b transaction status from db if transaction has been succeed for valid account number");
        if(payer.getIsTransactionSuccess() && transactionId!=null){
            Transaction transaction = getTransactionDetails(transactionId);
            System.out.println(transaction);
            successTransactionValidationFromDB(res,transaction,transTypeEnum);
        }
        else {
            System.out.println("Transaction has not verified from DB!!!!");
        }
    }

    // ************************* P2B Transaction for invalid ifsc code *****************************
    @Given("User login with valid cred to do p2b transaction for invalid ifsc code")
    public void user_login_with_valid_cred_for_p2b_transaction_for_invalid_and_valid_ifsc_code() throws FileNotFoundException {
        System.out.println("User login with valid cred to do p2b transaction for invalid ifsc code");
        res = login(reader.getValueFromConfig("wallet.test.user2.mobile.number"),reader.getValueFromConfig("wallet.test.user2.passcode"),reader.getValueFromConfig("wallet.test.user2.device.id"),reader.getValueFromConfig("wallet.test.user2.device.id"));
        payerAccessToken = getAccessTokenResponseData(res,"access_token");
    }
    @Given("User has a valid details of beneficiary to do p2b transaction for invalid ifsc code")
    public void user_has_a_valid_details_of_beneficiary_for_invalid_and_valid_ifsc_code_transaction() throws FileNotFoundException {
        System.out.println("User has a valid details of beneficiary to do p2b transaction for invalid ifsc code");
        res = getBeneficiaryDetails(payerAccessToken,reader.getValueFromConfig("limit"),reader.getValueFromConfig("offset")); // get beneficiary details
        if(res.getStatusCode()!=HTTP_OK){
            errorValidationOfTM(res,payee,payer);
        }
        else {
            Payee payee1 = setBeneficiaryDetails(res);
            if(payee1!=null){
                payee.setBankName(payee1.getBankName());
                payee.setAccountNumber(payee1.getAccountNumber());
                payee.setReceiverName(payee1.getReceiverName());
            }
        }
    }
    @Given("User enter {string} and {string} to do p2b transaction for invalid ifsc code")
    public void user_enter_and_for_invalid_and_valid_ifsc_code_transaction(String ifscCodeType, String ifscCodeValue) throws FileNotFoundException {
        System.out.println("User enter ifscCodeType -> "+ifscCodeType+" and ifscCodeValue -> "+ifscCodeValue+" to do p2b transaction for invalid ifsc code");
        if(ifscCodeValue.equalsIgnoreCase("null")){
            payee.setIfsc(null);
        }
        else if(ifscCodeValue.equalsIgnoreCase(" ")){
            payee.setIfsc(" ");
        }
        else {
            payee.setIfsc(ifscCodeValue);
        }
        String payerVpa = reader.getValueFromConfig("wallet.test.user2.vpa");
        payer.setSenderAccountId(payerVpa);
        payer.setSenderVpa(payerVpa);
        payer.setAction(reader.getValueFromConfig("wallet.pay.action"));
        payer.setDeviceTypeEnum(reader.getValueFromConfig("device.type.enum"));
        balance = Double.valueOf(getWalletBalance(payerAccessToken)); // fetching payer wallet balance
        payer.setWalletBalance(String.valueOf(balance));
        payer.setUniqueFrontendId(getUniqueFrontendId());
        payee.setAmount(String.valueOf(getRandomAmount()));
        payee.setComment(reader.getValueFromConfig("comment")); // set comment
        payee.setTransactionSubTypeEnum(reader.getValueFromConfig("wallet.transaction.subtype.enum")); // set transaction subtype enum
        transTypeEnum = String.valueOf(TransTypeEnum.WALLET_TO_BANK);
        payer.setPasscode(getEncryptedAuthData(reader.getValueFromConfig("wallet.test.user2.passcode")));
    }
    @Given("After applying transaction charges for invalid ifsc code")
    public void after_applying_transaction_charges_for_invalid_and_valid_ifsc_code() throws FileNotFoundException {
        System.out.println("After applying transaction charges for invalid ifsc code");
        res = getTransactionCharges(payerAccessToken,payee,transTypeEnum); // calling transaction charge api for transaction charge calculation
        if(res.getStatusCode()!=HTTP_OK){
            errorValidationOfTM(res,payee,payer);
        }
        else {
             Payer payer1 = calculateTransactionCharge(res,payee);
             payer.setTransactionChargeId(payer1.getTransactionChargeId()); // setting transaction charge id
             payer.setTotalTransactionAmount(payer1.getTotalTransactionAmount()); // setting total transaction amount
        }
    }
    @Given("User click on pay api to do p2b transaction for invalid ifsc code")
    public void user_click_on_pay_api_for_invalid_and_valid_ifsc_code_transaction() throws FileNotFoundException {
        System.out.println("User click on pay api to do p2b transaction for invalid ifsc code");
        res = checkRuleApi(payee,payer,transTypeEnum,payerAccessToken);  //calling check rule api
        errorValidationOfTM(res,payee,payer); // calling method for error validation
        res = pay(payee,payer,transTypeEnum,payerAccessToken);  // calling pay api
    }
    @Then("Verify p2b transaction status for invalid ifsc code")
    public void verify_transaction_status_for_invalid_and_valid_ifsc_code() throws FileNotFoundException {
        System.out.println("Verify p2b transaction status for invalid ifsc code");
        errorValidationOfTM(res,payee,payer); // calling method for error validation

    }

    // ************************* P2B Transaction for valid ifsc code *****************************
    @Given("User login with valid cred to do p2b transaction for valid ifsc code")
    public void user_login_with_valid_cred_for_p2b_transaction_for_valid_and_valid_ifsc_code() throws FileNotFoundException {
        System.out.println("User login with valid cred to do p2b transaction for valid ifsc code");
        res = login(reader.getValueFromConfig("wallet.test.user2.mobile.number"),reader.getValueFromConfig("wallet.test.user2.passcode"),reader.getValueFromConfig("wallet.test.user2.device.id"),reader.getValueFromConfig("wallet.test.user2.device.id"));
        payerAccessToken = getAccessTokenResponseData(res,"access_token");
    }
    @Given("User has a valid details of beneficiary to do p2b transaction for valid ifsc code")
    public void user_has_a_valid_details_of_beneficiary_for_valid_and_valid_ifsc_code_transaction() throws FileNotFoundException {
        System.out.println("User has a valid details of beneficiary to do p2b transaction for valid ifsc code");
        res = getBeneficiaryDetails(payerAccessToken,reader.getValueFromConfig("limit"),reader.getValueFromConfig("offset")); // get beneficiary details
        if(res.getStatusCode()!=HTTP_OK){
            errorValidationOfTM(res,payee,payer);
        }
        else {
            Payee payee1 = setBeneficiaryDetails(res);
            if(payee1!=null){
                payee.setBankName(payee1.getBankName());
                payee.setAccountNumber(payee1.getAccountNumber());
                payee.setReceiverName(payee1.getReceiverName());
                ifscCode = payee1.getIfsc();
            }
        }
    }
    @Given("User enter ifsc code and other details to do p2b transaction")
    public void user_enter_and_for_valid_and_valid_ifsc_code_transaction() throws FileNotFoundException {
        System.out.println("User enter ifsc code and other details to do p2b transaction");
        payee.setIfsc(ifscCode);
        String payerVpa = reader.getValueFromConfig("wallet.test.user2.vpa");
        payer.setSenderAccountId(payerVpa);
        payer.setSenderVpa(payerVpa);
        payer.setAction(reader.getValueFromConfig("wallet.pay.action"));
        payer.setDeviceTypeEnum(reader.getValueFromConfig("device.type.enum"));
        balance = Double.valueOf(getWalletBalance(payerAccessToken)); // fetching payer wallet balance
        payer.setWalletBalance(String.valueOf(balance));
        payer.setUniqueFrontendId(getUniqueFrontendId());
        payee.setAmount(String.valueOf(getRandomAmount()));
        payee.setComment(reader.getValueFromConfig("comment")); // set comment
        payee.setTransactionSubTypeEnum(reader.getValueFromConfig("wallet.transaction.subtype.enum")); // set transaction subtype enum
        transTypeEnum = String.valueOf(TransTypeEnum.WALLET_TO_BANK);
    }
    @Given("After applying transaction charges for valid ifsc code")
    public void after_applying_transaction_charges_for_valid_and_valid_ifsc_code() throws FileNotFoundException {
        System.out.println("After applying transaction charges for valid ifsc code");
        res = getTransactionCharges(payerAccessToken,payee,transTypeEnum); // calling transaction charge api for transaction charge calculation
        if(res.getStatusCode()!=HTTP_OK){
            errorValidationOfTM(res,payee,payer);
        }
        else {
            Payer payer1 = calculateTransactionCharge(res,payee);
            payer.setTransactionChargeId(payer1.getTransactionChargeId()); // setting transaction charge id
            payer.setTotalTransactionAmount(payer1.getTotalTransactionAmount()); // setting total transaction amount
            payer.setPasscode(getEncryptedAuthData(reader.getValueFromConfig("wallet.test.user2.passcode")));
        }
    }
    @Given("User click on pay api to do p2b transaction for valid ifsc code")
    public void user_click_on_pay_api_for_valid_and_valid_ifsc_code_transaction() throws FileNotFoundException {
        System.out.println("User click on pay api to do p2b transaction for valid ifsc code");
        res = checkRuleApi(payee,payer,transTypeEnum,payerAccessToken);  //calling check rule api
        if(res.getStatusCode()!=HTTP_OK){
            errorValidationOfTM(res,payee,payer);
        }
        else {
            assertJsonValueEquals("message","Success",extractJsonObjectFromResponse(res)); // assertion
            res = pay(payee,payer,transTypeEnum,payerAccessToken);  // calling pay api
            if(res.getStatusCode()!=HTTP_OK){
                errorValidationOfTM(res,payee,payer);
            }
            else {
                assertJsonValueEquals("message","Success",extractJsonObjectFromResponse(res)); // assertion
                requestId = (String) getResponseData(res,"results.data");
                res = payByRequestId(requestId,payerAccessToken); //calling pay by request id
            }
        }
    }
    @Then("Verify p2b transaction status for valid ifsc code")
    public void verify_transaction_status_for_valid_and_valid_ifsc_code() throws FileNotFoundException {
        System.out.println("Verify p2b transaction status for invalid ifsc code");
        if(res.getStatusCode()!=HTTP_OK){
            errorValidationOfTM(res,payee,payer);
            payer.setIsTransactionSuccess(false); // when transaction failed
        }
        else {
          transactionId =  successTransactionValidation(res,payee,payer,transTypeEnum);
          payer.setIsTransactionSuccess(true);
        }

    }
    @Then("Also verify p2b transaction status from db if transaction has been succeed for valid ifsc code")
    public void also_verify_transaction_status_from_db_for_valid_and_valid_ifsc_code() throws SQLException {
        System.out.println("Also verify p2b transaction status from db if transaction has been succeed for valid ifsc code");
        if(payer.getIsTransactionSuccess() && transactionId!=null){
            Transaction transaction = getTransactionDetails(transactionId);
            System.out.println(transaction);
            successTransactionValidationFromDB(res,transaction,transTypeEnum);
        }
        else {
            System.out.println("Transaction has not verified from DB!!!!");
        }
    }

    // ************************* P2B Transaction for invalid and valid receiver name *****************************
    @Given("User login with valid cred for P2B transaction for invalid and valid receiver name")
    public void user_login_with_valid_cred_for_p2b_transaction_for_invalid_and_valid_receiver_name() throws FileNotFoundException {
        System.out.println("User login with valid cred for P2B transaction for invalid and valid receiver name");
        res = login(reader.getValueFromConfig("wallet.test.user2.mobile.number"),reader.getValueFromConfig("wallet.test.user2.passcode"),reader.getValueFromConfig("wallet.test.user2.device.id"),reader.getValueFromConfig("wallet.test.user2.device.id"));
        payerAccessToken = getAccessTokenResponseData(res,"access_token");
    }
    @Given("User has a valid details of beneficiary for invalid and valid receiver name")
    public void user_has_a_valid_details_of_beneficiary_for_invalid_and_valid_receiver_name() throws FileNotFoundException {
        System.out.println("User has a valid details of beneficiary for invalid and valid receiver name");
        res = getBeneficiaryDetails(payerAccessToken,reader.getValueFromConfig("limit"),reader.getValueFromConfig("offset")); // get beneficiary details
        if(res.getStatusCode()!=HTTP_OK){
            errorValidationOfTM(res,payee,payer);
        }
        else {
            Payee payee1 = setBeneficiaryDetails(res);
            if(payee1!=null){
                payee.setBankName(payee1.getBankName());
                payee.setAccountNumber(payee1.getAccountNumber());
                //payee.setReceiverName(payee1.getReceiverName());
                receiverName = payee1.getReceiverName();
                payee.setIfsc(payee1.getIfsc());
            }
        }

    }
    @Given("User enter {string} and {string} for invalid and valid receiver name")
    public void user_enter_and_for_invalid_and_valid_receiver_name(String receiverNameType, String receiverNameValue) throws FileNotFoundException {
        System.out.println("User enter receiverNameType -> "+receiverNameType+" and receiverNameValue -> "+receiverNameValue+" for invalid and valid receiver name");
        if(receiverNameValue.equalsIgnoreCase("validReceiverNameValue")){
           payee.setReceiverName(receiverName);
        }
        else if(receiverNameValue.equalsIgnoreCase("null")){
            payee.setReceiverName(null);
        }
        else if(receiverNameValue.equalsIgnoreCase(" ")){
            payee.setReceiverName(" ");
        }
        else {
            payee.setReceiverName(receiverNameValue);
        }
        String payerVpa = reader.getValueFromConfig("wallet.test.user2.vpa");
        payer.setSenderAccountId(payerVpa);
        payer.setSenderVpa(payerVpa);
        payer.setAction(reader.getValueFromConfig("wallet.pay.action"));
        payer.setDeviceTypeEnum(reader.getValueFromConfig("device.type.enum"));
        balance = Double.valueOf(getWalletBalance(payerAccessToken)); // fetching payer wallet balance
        payer.setWalletBalance(String.valueOf(balance));
        payer.setUniqueFrontendId(getUniqueFrontendId());
        payee.setAmount(String.valueOf(getRandomAmount()));
        payee.setComment(reader.getValueFromConfig("comment")); // set comment
        payee.setTransactionSubTypeEnum(reader.getValueFromConfig("wallet.transaction.subtype.enum")); // set transaction subtype enum
        transTypeEnum = String.valueOf(TransTypeEnum.WALLET_TO_BANK);
    }
    @Given("After applying transaction charges for invalid and valid receiver name")
    public void after_applying_transaction_charges_for_invalid_and_valid_receiver_name() throws FileNotFoundException {
        System.out.println("After applying transaction charges for invalid and valid receiver name");
        res = getTransactionCharges(payerAccessToken,payee,transTypeEnum); // calling transaction charge api for transaction charge calculation
        if(res.getStatusCode()!=HTTP_OK){
            errorValidationOfTM(res,payee,payer);
        }
        else {
            Payer payer1 = calculateTransactionCharge(res,payee);
            payer.setTransactionChargeId(payer1.getTransactionChargeId()); // setting transaction charge id
            payer.setTotalTransactionAmount(payer1.getTotalTransactionAmount()); // setting total transaction amount
        }
    }
    @Given("User click on pay api for invalid and valid receiver name")
    public void user_click_on_pay_api_for_invalid_and_valid_receiver_name() throws FileNotFoundException {
        System.out.println("User click on pay api for invalid and valid receiver name");
        res = checkRuleApi(payee,payer,transTypeEnum,payerAccessToken);  //calling check rule api
        if(res.getStatusCode()!=HTTP_OK){
            errorValidationOfTM(res,payee,payer);
        }
        else {
            assertJsonValueEquals("message","Success",extractJsonObjectFromResponse(res)); // assertion
            payer.setPasscode(getEncryptedAuthData(reader.getValueFromConfig("wallet.test.user2.passcode")));
            res = pay(payee,payer,transTypeEnum,payerAccessToken);  // calling pay api
            if(res.getStatusCode()!=HTTP_OK){
                errorValidationOfTM(res,payee,payer);
            }
            else {
                assertJsonValueEquals("message","Success",extractJsonObjectFromResponse(res)); // assertion
                requestId = (String) getResponseData(res,"results.data");
                res = payByRequestId(requestId,payerAccessToken); //calling pay by request id
            }
        }
    }
    @Then("Verify transaction status for invalid and valid receiver name")
    public void verify_transaction_status_for_invalid_and_valid_receiver_name() throws FileNotFoundException{
        System.out.println("Verify transaction status for invalid and valid receiver name");
        if(res.getStatusCode()!=HTTP_OK){
            errorValidationOfTM(res,payee,payer);
            payer.setIsTransactionSuccess(false); // when transaction failed
        }
        else {
            transactionId =  successTransactionValidation(res,payee,payer,transTypeEnum);
            payer.setIsTransactionSuccess(true);
        }
    }
    @Then("Also verify transaction status from db for invalid and valid receiver name")
    public void also_verify_transaction_status_from_db_for_invalid_and_valid_receiver_name() throws SQLException {
        System.out.println("Also verify transaction status from db for invalid and valid receiver name");
        if(payer.getIsTransactionSuccess() && transactionId!=null){
            Transaction transaction = getTransactionDetails(transactionId);
            System.out.println(transaction);
            successTransactionValidationFromDB(res,transaction,transTypeEnum);
        }
        else {
            System.out.println("Transaction has not verified from DB!!!!");
        }
    }

    // ************************* P2B Transaction for invalid and valid account type *****************************
    @Given("User login with valid cred for P2B transaction for invalid and valid account type")
    public void user_login_with_valid_cred_for_p2b_transaction_for_invalid_and_valid_account_type() throws FileNotFoundException {
        System.out.println("User login with valid cred for P2B transaction for invalid and valid account type");
        res = login(reader.getValueFromConfig("wallet.test.user2.mobile.number"),reader.getValueFromConfig("wallet.test.user2.passcode"),reader.getValueFromConfig("wallet.test.user2.device.id"),reader.getValueFromConfig("wallet.test.user2.device.id"));
        payerAccessToken = getAccessTokenResponseData(res,"access_token");
    }
    @Given("User has a valid details of beneficiary for invalid and valid account type")
    public void user_has_a_valid_details_of_beneficiary_for_invalid_and_valid_account_type() throws FileNotFoundException {
        System.out.println("User has a valid details of beneficiary for invalid and valid account type");
        res = getBeneficiaryDetails(payerAccessToken,reader.getValueFromConfig("limit"),reader.getValueFromConfig("offset")); // get beneficiary details
        if(res.getStatusCode()!=HTTP_OK){
            errorValidationOfTM(res,payee,payer);
        }
        else {
            Payee payee1 = setBeneficiaryDetails(res);
            if(payee1!=null){
                payee.setBankName(payee1.getBankName());
                payee.setAccountNumber(payee1.getAccountNumber());
                payee.setReceiverName(payee1.getReceiverName());
                payee.setIfsc(payee1.getIfsc());
            }
        }
    }
    @Given("User enter {string} and {string} for invalid and valid account type")
    public void user_enter_and_for_invalid_and_valid_account_type(String accountType, String accountTypeValue) throws FileNotFoundException {
        System.out.println("User enter accountType -> "+accountType+" and accountTypeValue -> "+accountTypeValue+" for invalid and valid account type");
        if(accountTypeValue.equalsIgnoreCase("validAccountType")){
            payer.setAccountType(reader.getValueFromConfig("wallet.b2b.account.type"));
        }
        else if(accountTypeValue.equalsIgnoreCase("null")){
            payer.setAccountType(null);
        }
        else if(accountTypeValue.equalsIgnoreCase(" ")){
            payer.setAccountType(" ");
        }
        else {
            payer.setAccountType(accountTypeValue);
        }
        String payerVpa = reader.getValueFromConfig("wallet.test.user2.vpa");
        payer.setSenderAccountId(payerVpa);
        payer.setSenderVpa(payerVpa);
        payer.setAction(reader.getValueFromConfig("wallet.pay.action"));
        payer.setDeviceTypeEnum(reader.getValueFromConfig("device.type.enum"));
        balance = Double.valueOf(getWalletBalance(payerAccessToken)); // fetching payer wallet balance
        payer.setWalletBalance(String.valueOf(balance));
        payer.setUniqueFrontendId(getUniqueFrontendId());
        payee.setAmount(String.valueOf(getRandomAmount()));
        payee.setComment(reader.getValueFromConfig("comment")); // set comment
        payee.setTransactionSubTypeEnum(reader.getValueFromConfig("wallet.transaction.subtype.enum")); // set transaction subtype enum
        transTypeEnum = String.valueOf(TransTypeEnum.WALLET_TO_BANK);
    }
    @Given("After applying transaction charges for invalid and valid account type")
    public void after_applying_transaction_charges_for_invalid_and_valid_account_type() throws FileNotFoundException {
        System.out.println("After applying transaction charges for invalid and valid account type");
        res = getTransactionCharges(payerAccessToken,payee,transTypeEnum); // calling transaction charge api for transaction charge calculation
        if(res.getStatusCode()!=HTTP_OK){
            errorValidationOfTM(res,payee,payer);
        }
        else {
            Payer payer1 = calculateTransactionCharge(res,payee);
            payer.setTransactionChargeId(payer1.getTransactionChargeId()); // setting transaction charge id
            payer.setTotalTransactionAmount(payer1.getTotalTransactionAmount()); // setting total transaction amount
        }
    }
    @Given("User click on pay api for invalid and valid account type")
    public void user_click_on_pay_api_for_invalid_and_valid_account_type() throws FileNotFoundException {
        System.out.println("User click on pay api for invalid and valid account type");
        res = checkRuleApi(payee,payer,transTypeEnum,payerAccessToken);  //calling check rule api
        if(res.getStatusCode()!=HTTP_OK){
            errorValidationOfTM(res,payee,payer);
        }
        else {
            assertJsonValueEquals("message","Success",extractJsonObjectFromResponse(res)); // assertion
            payer.setPasscode(getEncryptedAuthData(reader.getValueFromConfig("wallet.test.user2.passcode")));
            res = pay(payee,payer,transTypeEnum,payerAccessToken);  // calling pay api
            if(res.getStatusCode()!=HTTP_OK){
                errorValidationOfTM(res,payee,payer);
            }
            else {
                assertJsonValueEquals("message","Success",extractJsonObjectFromResponse(res)); // assertion
                requestId = (String) getResponseData(res,"results.data");
                res = payByRequestId(requestId,payerAccessToken); //calling pay by request id
            }
        }
    }
    @Then("Verify transaction status for invalid and valid account type")
    public void verify_transaction_status_for_invalid_and_valid_account_type() throws FileNotFoundException {
        System.out.println("Verify transaction status for invalid and valid account type");
        if(res.getStatusCode()!=HTTP_OK){
            errorValidationOfTM(res,payee,payer);
            payer.setIsTransactionSuccess(false); // when transaction failed
        }
        else {
            transactionId =  successTransactionValidation(res,payee,payer,transTypeEnum);
            payer.setIsTransactionSuccess(true);
        }
    }
    @Then("Also verify transaction status from db for invalid and valid account type")
    public void also_verify_transaction_status_from_db_for_invalid_and_valid_account_type() throws SQLException {
        System.out.println("Also verify transaction status from db for invalid and valid account type");
        if(payer.getIsTransactionSuccess() && transactionId!=null){
            Transaction transaction = getTransactionDetails(transactionId);
            System.out.println(transaction);
            successTransactionValidationFromDB(res,transaction,transTypeEnum);
        }
        else {
            System.out.println("Transaction has not verified from DB!!!!");
        }
    }

    // ************************* P2B Transaction for invalid passcode *****************************
    @Given("User login with valid cred to do p2b transaction for invalid passcode")
    public void user_login_with_valid_cred_for_p2b_transaction_for_invalid_and_valid_passcode() throws FileNotFoundException {
        System.out.println("User login with valid cred to do p2b transaction for invalid passcode");
        res = login(reader.getValueFromConfig("wallet.test.user2.mobile.number"),reader.getValueFromConfig("wallet.test.user2.passcode"),reader.getValueFromConfig("wallet.test.user2.device.id"),reader.getValueFromConfig("wallet.test.user2.device.id"));
        payerAccessToken = getAccessTokenResponseData(res,"access_token");
    }
    @Given("User has a valid details of beneficiary to do p2b transaction for invalid passcode")
    public void user_has_a_valid_details_of_beneficiary_for_invalid_and_valid_passcode() throws FileNotFoundException {
        System.out.println("User has a valid details of beneficiary to do p2b transaction for invalid passcode");
        res = getBeneficiaryDetails(payerAccessToken,reader.getValueFromConfig("limit"),reader.getValueFromConfig("offset")); // get beneficiary details
        if(res.getStatusCode()!=HTTP_OK){
            errorValidationOfTM(res,payee,payer);
        }
        else {
            Payee payee1 = setBeneficiaryDetails(res);
            if(payee1!=null){
                payee.setBankName(payee1.getBankName());
                payee.setAccountNumber(payee1.getAccountNumber());
                payee.setReceiverName(payee1.getReceiverName());
                payee.setIfsc(payee1.getIfsc());
            }
        }
    }
    @Given("User enter {string} and {string} to do p2b transaction for invalid passcode")
    public void user_enter_and_for_invalid_and_valid_passcode(String passcodeType, String passcodeValue) throws FileNotFoundException {
        System.out.println("User enter passcodeType -> "+passcodeType+" and passcodeValue -> "+passcodeValue+" to do p2b transaction for invalid passcode");
        if(passcodeValue.equalsIgnoreCase("null")){
            payer.setPasscode(null);
        }
        else if(passcodeValue.equalsIgnoreCase("empty")){
            payer.setPasscode(" ");
        }
        else {
            payer.setPasscode(passcodeValue);
        }
        String payerVpa = reader.getValueFromConfig("wallet.test.user2.vpa");
        payer.setSenderAccountId(payerVpa);
        payer.setSenderVpa(payerVpa);
        payer.setAccountType(reader.getValueFromConfig("wallet.b2b.account.type"));
        payer.setAction(reader.getValueFromConfig("wallet.pay.action"));
        payer.setDeviceTypeEnum(reader.getValueFromConfig("device.type.enum"));
        balance = Double.valueOf(getWalletBalance(payerAccessToken)); // fetching payer wallet balance
        payer.setWalletBalance(String.valueOf(balance));
        payer.setUniqueFrontendId(getUniqueFrontendId());
        payee.setAmount(String.valueOf(getRandomAmount()));
        payee.setComment(reader.getValueFromConfig("comment")); // set comment
        payee.setTransactionSubTypeEnum(reader.getValueFromConfig("wallet.transaction.subtype.enum")); // set transaction subtype enum
        transTypeEnum = String.valueOf(TransTypeEnum.WALLET_TO_BANK);
    }
    @Given("After applying transaction charges for invalid passcode")
    public void after_applying_transaction_charges_for_invalid_and_valid_passcode() throws FileNotFoundException {
        System.out.println("After applying transaction charges for invalid passcode");
        res = getTransactionCharges(payerAccessToken,payee,transTypeEnum); // calling transaction charge api for transaction charge calculation
        if(res.getStatusCode()!=HTTP_OK){
            errorValidationOfTM(res,payee,payer);
        }
        else {
            Payer payer1 = calculateTransactionCharge(res,payee); // calling method for transaction charge validation and calculating transaction charge
            payer.setTransactionChargeId(payer1.getTransactionChargeId()); // setting transaction charge id
            payer.setTotalTransactionAmount(payer1.getTotalTransactionAmount()); // setting total transaction amount
        }
    }
    @Given("User click on pay api to do p2b transaction for invalid passcode")
    public void user_click_on_pay_api_for_invalid_and_valid_passcode() throws FileNotFoundException {
        System.out.println("User click on pay api to do p2b transaction for invalid passcode");
        res = checkRuleApi(payee,payer,transTypeEnum,payerAccessToken);  //calling check rule api
        if(res.getStatusCode()!=HTTP_OK){
            errorValidationOfTM(res,payee,payer);
        }
        else {
            assertJsonValueEquals("message","Success",extractJsonObjectFromResponse(res)); // assertion
            res = pay(payee,payer,transTypeEnum,payerAccessToken);  // calling pay api
        }
    }
    @Then("Verify p2b transaction status for invalid passcode")
    public void verify_transaction_status_for_invalid_and_valid_passcode() throws FileNotFoundException {
        System.out.println("Verify p2b transaction status for invalid passcode");
        errorValidationOfTM(res,payee,payer);
    }
    @Then("Also verify transaction status from db for invalid and valid passcode")
    public void also_verify_transaction_status_from_db_for_invalid_and_valid_passcode() throws SQLException {
        System.out.println("Also verify transaction status from db for invalid and valid passcode");
        if(payer.getIsTransactionSuccess() && transactionId!=null){
            Transaction transaction = getTransactionDetails(transactionId);
            System.out.println(transaction);
            successTransactionValidationFromDB(res,transaction,transTypeEnum);
        }
        else {
            System.out.println("Transaction has not verified from DB!!!!");
        }
    }

    // ************************* P2B Transaction for valid passcode *****************************
    @Given("User login with valid cred to do p2b transaction for valid passcode")
    public void user_login_with_valid_cred_for_p2b_transaction_for_valid_and_valid_passcode() throws FileNotFoundException {
        System.out.println("User login with valid cred to do p2b transaction for valid passcode");
        res = login(reader.getValueFromConfig("wallet.test.user2.mobile.number"),reader.getValueFromConfig("wallet.test.user2.passcode"),reader.getValueFromConfig("wallet.test.user2.device.id"),reader.getValueFromConfig("wallet.test.user2.device.id"));
        payerAccessToken = getAccessTokenResponseData(res,"access_token");
    }
    @Given("User has a valid details of beneficiary to do p2b transaction for valid passcode")
    public void user_has_a_valid_details_of_beneficiary_for_valid_and_valid_passcode() throws FileNotFoundException {
        System.out.println("User has a valid details of beneficiary to do p2b transaction for valid passcode");
        res = getBeneficiaryDetails(payerAccessToken,reader.getValueFromConfig("limit"),reader.getValueFromConfig("offset")); // get beneficiary details
        if(res.getStatusCode()!=HTTP_OK){
            errorValidationOfTM(res,payee,payer);
        }
        else {
            Payee payee1 = setBeneficiaryDetails(res);
            if(payee1!=null){
                payee.setBankName(payee1.getBankName());
                payee.setAccountNumber(payee1.getAccountNumber());
                payee.setReceiverName(payee1.getReceiverName());
                payee.setIfsc(payee1.getIfsc());
            }
        }
    }
    @Given("User enter passcode and other details to do p2b transaction")
    public void user_enter_and_for_valid_and_valid_passcode() throws FileNotFoundException {
        System.out.println("User enter passcode and other details to do p2b transaction");
        payer.setPasscode(getEncryptedAuthData(reader.getValueFromConfig("wallet.test.user2.passcode")));
        String payerVpa = reader.getValueFromConfig("wallet.test.user2.vpa");
        payer.setSenderAccountId(payerVpa);
        payer.setSenderVpa(payerVpa);
        payer.setAccountType(reader.getValueFromConfig("wallet.b2b.account.type"));
        payer.setAction(reader.getValueFromConfig("wallet.pay.action"));
        payer.setDeviceTypeEnum(reader.getValueFromConfig("device.type.enum"));
        balance = Double.valueOf(getWalletBalance(payerAccessToken)); // fetching payer wallet balance
        payer.setWalletBalance(String.valueOf(balance));
        payer.setUniqueFrontendId(getUniqueFrontendId());
        payee.setAmount(String.valueOf(getRandomAmount()));
        payee.setComment(reader.getValueFromConfig("comment")); // set comment
        payee.setTransactionSubTypeEnum(reader.getValueFromConfig("wallet.transaction.subtype.enum")); // set transaction subtype enum
        transTypeEnum = String.valueOf(TransTypeEnum.WALLET_TO_BANK);
    }
    @Given("After applying transaction charges for valid passcode")
    public void after_applying_transaction_charges_for_valid_and_valid_passcode() throws FileNotFoundException {
        System.out.println("After applying transaction charges for valid passcode");
        res = getTransactionCharges(payerAccessToken,payee,transTypeEnum); // calling transaction charge api for transaction charge calculation
        if(res.getStatusCode()!=HTTP_OK){
            errorValidationOfTM(res,payee,payer);
        }
        else {
            Payer payer1 = calculateTransactionCharge(res,payee); // calling method for transaction charge validation and calculating transaction charge
            payer.setTransactionChargeId(payer1.getTransactionChargeId()); // setting transaction charge id
            payer.setTotalTransactionAmount(payer1.getTotalTransactionAmount()); // setting total transaction amount
        }
    }
    @Given("User click on pay api to do p2b transaction for valid passcode")
    public void user_click_on_pay_api_for_valid_and_valid_passcode() throws FileNotFoundException {
        System.out.println("User click on pay api to do p2b transaction for valid passcode");
        res = checkRuleApi(payee,payer,transTypeEnum,payerAccessToken);  //calling check rule api
        if(res.getStatusCode()!=HTTP_OK){
            errorValidationOfTM(res,payee,payer);
        }
        else {
            assertJsonValueEquals("message","Success",extractJsonObjectFromResponse(res)); // assertion
            res = pay(payee,payer,transTypeEnum,payerAccessToken);  // calling pay api
            if(res.getStatusCode()!=HTTP_OK){
                errorValidationOfTM(res,payee,payer);
            }
            else {
                assertJsonValueEquals("message","Success",extractJsonObjectFromResponse(res)); // assertion
                requestId = (String) getResponseData(res,"results.data");
                res = payByRequestId(requestId,payerAccessToken); //calling pay by request id
            }
        }
    }
    @Then("Verify p2b transaction status for valid passcode")
    public void verify_transaction_status_for_valid_and_valid_passcode() throws FileNotFoundException {
        System.out.println("Verify p2b transaction status for valid passcode");
        if(res.getStatusCode()!=HTTP_OK){
            errorValidationOfTM(res,payee,payer);
            payer.setIsTransactionSuccess(false); // when transaction failed
        }
        else {
            transactionId =  successTransactionValidation(res,payee,payer,transTypeEnum);
            payer.setIsTransactionSuccess(true);
        }
    }
    @Then("Also verify p2b transaction status from db if transaction has been succeed for valid passcode")
    public void also_verify_transaction_status_from_db_for_valid_and_valid_passcode() throws SQLException {
        System.out.println("Also verify p2b transaction status from db if transaction has been succeed for valid passcode");
        if(payer.getIsTransactionSuccess() && transactionId!=null){
            Transaction transaction = getTransactionDetails(transactionId);
            System.out.println(transaction);
            successTransactionValidationFromDB(res,transaction,transTypeEnum);
        }
        else {
            System.out.println("Transaction has not verified from DB!!!!");
        }
    }

    // ************************* P2B Transaction for invalid and valid comment *****************************
    @Given("User login with valid cred for P2B transaction for invalid and valid comment")
    public void user_login_with_valid_cred_for_p2b_transaction_for_invalid_and_valid_comment() throws FileNotFoundException {
        System.out.println("User login with valid cred for P2B transaction for invalid and valid comment");
        res = login(reader.getValueFromConfig("wallet.test.user2.mobile.number"),reader.getValueFromConfig("wallet.test.user2.passcode"),reader.getValueFromConfig("wallet.test.user2.device.id"),reader.getValueFromConfig("wallet.test.user2.device.id"));
        payerAccessToken = getAccessTokenResponseData(res,"access_token");
    }
    @Given("User has a valid details of beneficiary for invalid and valid comment")
    public void user_has_a_valid_details_of_beneficiary_for_invalid_and_valid_comment() throws FileNotFoundException {
        System.out.println("User has a valid details of beneficiary for invalid and valid comment");
        res = getBeneficiaryDetails(payerAccessToken,reader.getValueFromConfig("limit"),reader.getValueFromConfig("offset")); // get beneficiary details
        if(res.getStatusCode()!=HTTP_OK){
            errorValidationOfTM(res,payee,payer);
        }
        else {
            Payee payee1 = setBeneficiaryDetails(res);
            if(payee1!=null){
                payee.setBankName(payee1.getBankName());
                payee.setAccountNumber(payee1.getAccountNumber());
                payee.setReceiverName(payee1.getReceiverName());
                payee.setIfsc(payee1.getIfsc());
            }
        }
    }
    @Given("User enter {string} and {string} for invalid and valid comment")
    public void user_enter_and_for_invalid_and_valid_comment(String commentType, String commentValue) throws FileNotFoundException {
        System.out.println("User enter commentType -> "+commentType+" and commentValue -> "+commentValue+" for invalid and valid comment");
        if(commentValue.equalsIgnoreCase("validComment")){
            payee.setComment(reader.getValueFromConfig("comment")); // set comment
        }
        else if(commentValue.equalsIgnoreCase("null")){
            payee.setComment(null);
        }
        else if(commentValue.equalsIgnoreCase("empty")){
            payee.setComment(" ");
        }
        else {
            payee.setComment(commentValue);
        }
        String payerVpa = reader.getValueFromConfig("wallet.test.user2.vpa");
        payer.setSenderAccountId(payerVpa);
        payer.setSenderVpa(payerVpa);
        payer.setAccountType(reader.getValueFromConfig("wallet.b2b.account.type"));
        payer.setAction(reader.getValueFromConfig("wallet.pay.action"));
        payer.setDeviceTypeEnum(reader.getValueFromConfig("device.type.enum"));
        balance = Double.valueOf(getWalletBalance(payerAccessToken)); // fetching payer wallet balance
        payer.setWalletBalance(String.valueOf(balance));
        payer.setUniqueFrontendId(getUniqueFrontendId());
        payee.setAmount(String.valueOf(getRandomAmount()));
        //payee.setComment(reader.getValueFromConfig("comment")); // set comment
        payee.setTransactionSubTypeEnum(reader.getValueFromConfig("wallet.transaction.subtype.enum")); // set transaction subtype enum
        transTypeEnum = String.valueOf(TransTypeEnum.WALLET_TO_BANK);
    }
    @Given("After applying transaction charges for invalid and valid comment")
    public void after_applying_transaction_charges_for_invalid_and_valid_comment() throws FileNotFoundException {
        System.out.println("After applying transaction charges for invalid and valid comment");
        res = getTransactionCharges(payerAccessToken,payee,transTypeEnum); // calling transaction charge api for transaction charge calculation
        if(res.getStatusCode()!=HTTP_OK){
            errorValidationOfTM(res,payee,payer);
        }
        else {
            Payer payer1 = calculateTransactionCharge(res,payee);
            payer.setTransactionChargeId(payer1.getTransactionChargeId()); // setting transaction charge id
            payer.setTotalTransactionAmount(payer1.getTotalTransactionAmount()); // setting total transaction amount
        }
    }
    @Given("User click on pay api for invalid and valid comment")
    public void user_click_on_pay_api_for_invalid_and_valid_comment() throws FileNotFoundException {
        System.out.println("User click on pay api for invalid and valid comment");
        res = checkRuleApi(payee,payer,transTypeEnum,payerAccessToken);  //calling check rule api
        if(res.getStatusCode()!=HTTP_OK){
            errorValidationOfTM(res,payee,payer);
        }
        else {
            assertJsonValueEquals("message","Success",extractJsonObjectFromResponse(res)); // assertion
            payer.setPasscode(getEncryptedAuthData(reader.getValueFromConfig("wallet.test.user2.passcode")));
            res = pay(payee,payer,transTypeEnum,payerAccessToken);  // calling pay api
            if(res.getStatusCode()!=HTTP_OK){
                errorValidationOfTM(res,payee,payer);
            }
            else {
                assertJsonValueEquals("message","Success",extractJsonObjectFromResponse(res)); // assertion
                requestId = (String) getResponseData(res,"results.data");
                res = payByRequestId(requestId,payerAccessToken); //calling pay by request id
            }
        }
    }
    @Then("Verify transaction status for invalid and valid comment")
    public void verify_transaction_status_for_invalid_and_valid_comment() throws FileNotFoundException {
        System.out.println("Verify transaction status for invalid and valid comment");
        if(res.getStatusCode()!=HTTP_OK){
            errorValidationOfTM(res,payee,payer);
            payer.setIsTransactionSuccess(false); // when transaction failed
        }
        else {
            transactionId =  successTransactionValidation(res,payee,payer,transTypeEnum);
            payer.setIsTransactionSuccess(true);
        }
    }
    @Then("Also verify transaction status from db for invalid and valid comment")
    public void also_verify_transaction_status_from_db_for_invalid_and_valid_comment() throws SQLException {
        System.out.println("Also verify transaction status from db for invalid and valid comment");
        if(payer.getIsTransactionSuccess() && transactionId!=null){
            Transaction transaction = getTransactionDetails(transactionId);
            System.out.println(transaction);
            successTransactionValidationFromDB(res,transaction,transTypeEnum);
        }
        else {
            System.out.println("Transaction has not verified from DB!!!!");
        }
    }

    // ************************* P2B Transaction for invalid and valid action *****************************
    @Given("User login with valid cred for P2B transaction for invalid and valid action")
    public void user_login_with_valid_cred_for_p2b_transaction_for_invalid_and_valid_action() throws FileNotFoundException {
        System.out.println("User login with valid cred for P2B transaction for invalid and valid action");
        res = login(reader.getValueFromConfig("wallet.test.user2.mobile.number"),reader.getValueFromConfig("wallet.test.user2.passcode"),reader.getValueFromConfig("wallet.test.user2.device.id"),reader.getValueFromConfig("wallet.test.user2.device.id"));
        payerAccessToken = getAccessTokenResponseData(res,"access_token");
    }
    @Given("User has a valid details of beneficiary for invalid and valid action")
    public void user_has_a_valid_details_of_beneficiary_for_invalid_and_valid_action() throws FileNotFoundException {
        System.out.println("User has a valid details of beneficiary for invalid and valid action");
        res = getBeneficiaryDetails(payerAccessToken,reader.getValueFromConfig("limit"),reader.getValueFromConfig("offset")); // get beneficiary details
        if(res.getStatusCode()!=HTTP_OK){
            errorValidationOfTM(res,payee,payer);
        }
        else {
            Payee payee1 = setBeneficiaryDetails(res);
            if(payee1!=null){
                payee.setBankName(payee1.getBankName());
                payee.setAccountNumber(payee1.getAccountNumber());
                payee.setReceiverName(payee1.getReceiverName());
                payee.setIfsc(payee1.getIfsc());
            }
        }

    }
    @Given("User enter {string} and {string} for invalid and valid action")
    public void user_enter_and_for_invalid_and_valid_action(String actionType, String actionValue) throws FileNotFoundException {
        System.out.println("User enter actionType -> "+actionType+" and actionValue -> "+actionValue+" for invalid and valid action");
        if(actionValue.equalsIgnoreCase("validAction")){
            payer.setAction(reader.getValueFromConfig("wallet.pay.action"));
        }
        else if(actionValue.equalsIgnoreCase("null")){
            payer.setAction(null);
        }
        else if(actionValue.equalsIgnoreCase("empty")){
            payer.setAction(" ");
        }
        else {
            payer.setAction(actionValue);
        }
        String payerVpa = reader.getValueFromConfig("wallet.test.user2.vpa");
        payer.setSenderAccountId(payerVpa);
        payer.setSenderVpa(payerVpa);
        payer.setAccountType(reader.getValueFromConfig("wallet.b2b.account.type"));
        //payer.setAction(reader.getValueFromConfig("wallet.pay.action"));
        payer.setDeviceTypeEnum(reader.getValueFromConfig("device.type.enum"));
        balance = Double.valueOf(getWalletBalance(payerAccessToken)); // fetching payer wallet balance
        payer.setWalletBalance(String.valueOf(balance));
        payer.setUniqueFrontendId(getUniqueFrontendId());
        payee.setAmount(String.valueOf(getRandomAmount()));
        payee.setComment(reader.getValueFromConfig("comment")); // set comment
        payee.setTransactionSubTypeEnum(reader.getValueFromConfig("wallet.transaction.subtype.enum")); // set transaction subtype enum
        transTypeEnum = String.valueOf(TransTypeEnum.WALLET_TO_BANK);
    }
    @Given("After applying transaction charges for invalid and valid action")
    public void after_applying_transaction_charges_for_invalid_and_valid_action() throws FileNotFoundException {
        System.out.println("After applying transaction charges for invalid and valid action");
        res = getTransactionCharges(payerAccessToken,payee,transTypeEnum); // calling transaction charge api for transaction charge calculation
        if(res.getStatusCode()!=HTTP_OK){
            errorValidationOfTM(res,payee,payer);
        }
        else {
            Payer payer1 = calculateTransactionCharge(res,payee);
            payer.setTransactionChargeId(payer1.getTransactionChargeId()); // setting transaction charge id
            payer.setTotalTransactionAmount(payer1.getTotalTransactionAmount()); // setting total transaction amount
        }

    }
    @Given("User click on pay api for invalid and valid action")
    public void user_click_on_pay_api_for_invalid_and_valid_action() throws FileNotFoundException {
        System.out.println("User click on pay api for invalid and valid action");
        res = checkRuleApi(payee,payer,transTypeEnum,payerAccessToken);  //calling check rule api
        if(res.getStatusCode()!=HTTP_OK){
            errorValidationOfTM(res,payee,payer);
        }
        else {
            assertJsonValueEquals("message","Success",extractJsonObjectFromResponse(res)); // assertion
            payer.setPasscode(getEncryptedAuthData(reader.getValueFromConfig("wallet.test.user2.passcode")));
            res = pay(payee,payer,transTypeEnum,payerAccessToken);  // calling pay api
            if(res.getStatusCode()!=HTTP_OK){
                errorValidationOfTM(res,payee,payer);
            }
            else {
                assertJsonValueEquals("message","Success",extractJsonObjectFromResponse(res)); // assertion
                requestId = (String) getResponseData(res,"results.data");
                res = payByRequestId(requestId,payerAccessToken); //calling pay by request id
            }
        }
    }
    @Then("Verify transaction status for invalid and valid action")
    public void verify_transaction_status_for_invalid_and_valid_action() throws FileNotFoundException {
        System.out.println("Verify transaction status for invalid and valid action");
        if(res.getStatusCode()!=HTTP_OK){
            errorValidationOfTM(res,payee,payer);
            payer.setIsTransactionSuccess(false); // when transaction failed
        }
        else {
            transactionId =  successTransactionValidation(res,payee,payer,transTypeEnum);
            payer.setIsTransactionSuccess(true);
        }
    }
    @Then("Also verify transaction status from db for invalid and valid action")
    public void also_verify_transaction_status_from_db_for_invalid_and_valid_action() throws SQLException {
        System.out.println("Also verify transaction status from db for invalid and valid action");
        if(payer.getIsTransactionSuccess() && transactionId!=null){
            Transaction transaction = getTransactionDetails(transactionId);
            System.out.println(transaction);
            successTransactionValidationFromDB(res,transaction,transTypeEnum);
        }
        else {
            System.out.println("Transaction has not verified from DB!!!!");
        }
    }


    // ************************* P2B Transaction for invalid and valid device type *****************************
    @Given("User login with valid cred for P2B transaction for invalid and valid device type")
    public void user_login_with_valid_cred_for_p2b_transaction_for_invalid_and_valid_device_type() throws FileNotFoundException {
        System.out.println("User login with valid cred for P2B transaction for invalid and valid device type");
        res = login(reader.getValueFromConfig("wallet.test.user2.mobile.number"),reader.getValueFromConfig("wallet.test.user2.passcode"),reader.getValueFromConfig("wallet.test.user2.device.id"),reader.getValueFromConfig("wallet.test.user2.device.id"));
        payerAccessToken = getAccessTokenResponseData(res,"access_token");

    }
    @Given("User has a valid details of beneficiary for invalid and valid device type")
    public void user_has_a_valid_details_of_beneficiary_for_invalid_and_valid_device_type() throws FileNotFoundException {
        System.out.println("User has a valid details of beneficiary for invalid and valid device type");
        res = getBeneficiaryDetails(payerAccessToken,reader.getValueFromConfig("limit"),reader.getValueFromConfig("offset")); // get beneficiary details
        if(res.getStatusCode()!=HTTP_OK){
            errorValidationOfTM(res,payee,payer);
        }
        else {
            Payee payee1 = setBeneficiaryDetails(res);
            if(payee1!=null){
                payee.setBankName(payee1.getBankName());
                payee.setAccountNumber(payee1.getAccountNumber());
                payee.setReceiverName(payee1.getReceiverName());
                payee.setIfsc(payee1.getIfsc());
            }
        }
    }
    @Given("User enter {string} and {string} for invalid and valid device type")
    public void user_enter_and_for_invalid_and_valid_device_type(String deviceType, String deviceTypeValue) throws FileNotFoundException {
        System.out.println("User enter deviceType -> "+deviceType+" and deviceTypeValue -> "+deviceTypeValue+" for invalid and valid device type");
        if(deviceTypeValue.equalsIgnoreCase("validDeviceType")){
            payer.setDeviceTypeEnum(reader.getValueFromConfig("device.type.enum"));
        }
        else if(deviceTypeValue.equalsIgnoreCase("null")){
            payer.setDeviceTypeEnum(null);
        }
        else if(deviceTypeValue.equalsIgnoreCase("empty")){
            payer.setDeviceTypeEnum(" ");
        }
        else {
            payer.setDeviceTypeEnum(deviceTypeValue);
        }
        String payerVpa = reader.getValueFromConfig("wallet.test.user2.vpa");
        payer.setSenderAccountId(payerVpa);
        payer.setSenderVpa(payerVpa);
        payer.setAccountType(reader.getValueFromConfig("wallet.b2b.account.type"));
        payer.setAction(reader.getValueFromConfig("wallet.pay.action"));
        //payer.setDeviceTypeEnum(reader.getValueFromConfig("device.type.enum"));
        balance = Double.valueOf(getWalletBalance(payerAccessToken)); // fetching payer wallet balance
        payer.setWalletBalance(String.valueOf(balance));
        payer.setUniqueFrontendId(getUniqueFrontendId());
        payee.setAmount(String.valueOf(getRandomAmount()));
        payee.setComment(reader.getValueFromConfig("comment")); // set comment
        payee.setTransactionSubTypeEnum(reader.getValueFromConfig("wallet.transaction.subtype.enum")); // set transaction subtype enum
        transTypeEnum = String.valueOf(TransTypeEnum.WALLET_TO_BANK);
    }
    @Given("After applying transaction charges for invalid and valid device type")
    public void after_applying_transaction_charges_for_invalid_and_valid_device_type() throws FileNotFoundException {
        System.out.println("After applying transaction charges for invalid and valid device type");
        res = getTransactionCharges(payerAccessToken,payee,transTypeEnum); // calling transaction charge api for transaction charge calculation
        if(res.getStatusCode()!=HTTP_OK){
            errorValidationOfTM(res,payee,payer);
        }
        else {
            Payer payer1 = calculateTransactionCharge(res,payee);
            payer.setTransactionChargeId(payer1.getTransactionChargeId()); // setting transaction charge id
            payer.setTotalTransactionAmount(payer1.getTotalTransactionAmount()); // setting total transaction amount
        }
    }
    @Given("User click on pay api for invalid and valid device type")
    public void user_click_on_pay_api_for_invalid_and_valid_device_type() throws FileNotFoundException {
        System.out.println("User click on pay api for invalid and valid device type");
        res = checkRuleApi(payee,payer,transTypeEnum,payerAccessToken);  //calling check rule api
        if(res.getStatusCode()!=HTTP_OK){
            errorValidationOfTM(res,payee,payer);
        }
        else {
            assertJsonValueEquals("message","Success",extractJsonObjectFromResponse(res)); // assertion
            payer.setPasscode(getEncryptedAuthData(reader.getValueFromConfig("wallet.test.user2.passcode")));
            res = pay(payee,payer,transTypeEnum,payerAccessToken);  // calling pay api
            if(res.getStatusCode()!=HTTP_OK){
                errorValidationOfTM(res,payee,payer);
            }
            else {
                assertJsonValueEquals("message","Success",extractJsonObjectFromResponse(res)); // assertion
                requestId = (String) getResponseData(res,"results.data");
                res = payByRequestId(requestId,payerAccessToken); //calling pay by request id
            }
        }
    }
    @Then("Verify transaction status for invalid and valid device type")
    public void verify_transaction_status_for_invalid_and_valid_device_type() throws FileNotFoundException {
        System.out.println("Verify transaction status for invalid and valid device type");
        if(res.getStatusCode()!=HTTP_OK){
            errorValidationOfTM(res,payee,payer);
            payer.setIsTransactionSuccess(false); // when transaction failed
        }
        else {
            transactionId =  successTransactionValidation(res,payee,payer,transTypeEnum);
            payer.setIsTransactionSuccess(true);
        }
    }
    @Then("Also verify transaction status from db for invalid and valid device type")
    public void also_verify_transaction_status_from_db_for_invalid_and_valid_device_type() throws SQLException {
        System.out.println("Also verify transaction status from db for invalid and valid device type");
        if(payer.getIsTransactionSuccess() && transactionId!=null){
            Transaction transaction = getTransactionDetails(transactionId);
            System.out.println(transaction);
            successTransactionValidationFromDB(res,transaction,transTypeEnum);
        }
        else {
            System.out.println("Transaction has not verified from DB!!!!");
        }
    }


    // ************************* P2B Transaction for invalid and valid unique frontend id *****************************
    @Given("User login with valid cred for P2B transaction for invalid and valid unique frontend id")
    public void user_login_with_valid_cred_for_p2b_transaction_for_invalid_and_valid_unique_frontend_id() throws FileNotFoundException {
        System.out.println("User login with valid cred for P2B transaction for invalid and valid unique frontend id");
        res = login(reader.getValueFromConfig("wallet.test.user2.mobile.number"),reader.getValueFromConfig("wallet.test.user2.passcode"),reader.getValueFromConfig("wallet.test.user2.device.id"),reader.getValueFromConfig("wallet.test.user2.device.id"));
        payerAccessToken = getAccessTokenResponseData(res,"access_token");
    }
    @Given("User has a valid details of beneficiary for invalid and valid unique frontend id")
    public void user_has_a_valid_details_of_beneficiary_for_invalid_and_valid_unique_frontend_id() throws FileNotFoundException {
        System.out.println("User has a valid details of beneficiary for invalid and valid unique frontend id");
        res = getBeneficiaryDetails(payerAccessToken,reader.getValueFromConfig("limit"),reader.getValueFromConfig("offset")); // get beneficiary details
        if(res.getStatusCode()!=HTTP_OK){
            errorValidationOfTM(res,payee,payer);
        }
        else {
            Payee payee1 = setBeneficiaryDetails(res);
            if(payee1!=null){
                payee.setBankName(payee1.getBankName());
                payee.setAccountNumber(payee1.getAccountNumber());
                payee.setReceiverName(payee1.getReceiverName());
                payee.setIfsc(payee1.getIfsc());
            }
        }
    }
    @Given("User enter {string} and {string} for invalid and valid unique frontend id")
    public void user_enter_and_for_invalid_and_valid_unique_frontend_id(String uniqueFrontEndIdType, String uniqueFrontendIdValue) throws FileNotFoundException {
        System.out.println("User enter uniqueFrontEndIdType -> "+uniqueFrontEndIdType+" and uniqueFrontendIdValue -> "+uniqueFrontendIdValue+" for invalid and valid unique frontend id");
        if(uniqueFrontendIdValue.equalsIgnoreCase("validUniqueFrontendId")){
            payer.setUniqueFrontendId(getUniqueFrontendId());
        }
        else if(uniqueFrontendIdValue.equalsIgnoreCase("null")){
            payer.setUniqueFrontendId(null);
        }
        else if(uniqueFrontendIdValue.equalsIgnoreCase("empty")){
            payer.setUniqueFrontendId(" ");
        }
        else {
            payer.setUniqueFrontendId(uniqueFrontendIdValue);;
        }
        String payerVpa = reader.getValueFromConfig("wallet.test.user2.vpa");
        payer.setSenderAccountId(payerVpa);
        payer.setSenderVpa(payerVpa);
        payer.setAccountType(reader.getValueFromConfig("wallet.b2b.account.type"));
        payer.setAction(reader.getValueFromConfig("wallet.pay.action"));
        payer.setDeviceTypeEnum(reader.getValueFromConfig("device.type.enum"));
        balance = Double.valueOf(getWalletBalance(payerAccessToken)); // fetching payer wallet balance
        payer.setWalletBalance(String.valueOf(balance));
        //payer.setUniqueFrontendId(getUniqueFrontendId());
        payee.setAmount(String.valueOf(getRandomAmount()));
        payee.setComment(reader.getValueFromConfig("comment")); // set comment
        payee.setTransactionSubTypeEnum(reader.getValueFromConfig("wallet.transaction.subtype.enum")); // set transaction subtype enum
        transTypeEnum = String.valueOf(TransTypeEnum.WALLET_TO_BANK);

    }
    @Given("After applying transaction charges for invalid and valid unique frontend id")
    public void after_applying_transaction_charges_for_invalid_and_valid_unique_frontend_id() throws FileNotFoundException {
        System.out.println("After applying transaction charges for invalid and valid unique frontend id");
        res = getTransactionCharges(payerAccessToken,payee,transTypeEnum); // calling transaction charge api for transaction charge calculation
        if(res.getStatusCode()!=HTTP_OK){
            errorValidationOfTM(res,payee,payer);
        }
        else {
            Payer payer1 = calculateTransactionCharge(res,payee);
            payer.setTransactionChargeId(payer1.getTransactionChargeId()); // setting transaction charge id
            payer.setTotalTransactionAmount(payer1.getTotalTransactionAmount()); // setting total transaction amount
        }
    }
    @Given("User click on pay api for invalid and valid unique frontend id")
    public void user_click_on_pay_api_for_invalid_and_valid_unique_frontend_id() throws FileNotFoundException {
        System.out.println("User click on pay api for invalid and valid unique frontend id");
        res = checkRuleApi(payee,payer,transTypeEnum,payerAccessToken);  //calling check rule api
        if(res.getStatusCode()!=HTTP_OK){
            errorValidationOfTM(res,payee,payer);
        }
        else {
            assertJsonValueEquals("message","Success",extractJsonObjectFromResponse(res)); // assertion
            payer.setPasscode(getEncryptedAuthData(reader.getValueFromConfig("wallet.test.user2.passcode")));
            res = pay(payee,payer,transTypeEnum,payerAccessToken);  // calling pay api
            if(res.getStatusCode()!=HTTP_OK){
                errorValidationOfTM(res,payee,payer);
            }
            else {
                assertJsonValueEquals("message","Success",extractJsonObjectFromResponse(res)); // assertion
                requestId = (String) getResponseData(res,"results.data");
                res = payByRequestId(requestId,payerAccessToken); //calling pay by request id
            }
        }

    }
    @Then("Verify transaction status for invalid and valid unique frontend id")
    public void verify_transaction_status_for_invalid_and_valid_unique_frontend_id() throws FileNotFoundException {
        System.out.println("Verify transaction status for invalid and valid unique frontend id");
        if(res.getStatusCode()!=HTTP_OK){
            errorValidationOfTM(res,payee,payer);
            payer.setIsTransactionSuccess(false); // when transaction failed
        }
        else {
            transactionId =  successTransactionValidation(res,payee,payer,transTypeEnum);
            payer.setIsTransactionSuccess(true);
        }
    }
    @Then("Also verify transaction status from db for invalid and valid unique frontend id")
    public void also_verify_transaction_status_from_db_for_invalid_and_valid_unique_frontend_id() throws SQLException {
        System.out.println("Also verify transaction status from db for invalid and valid unique frontend id");
        if(payer.getIsTransactionSuccess() && transactionId!=null){
            Transaction transaction = getTransactionDetails(transactionId);
            System.out.println(transaction);
            successTransactionValidationFromDB(res,transaction,transTypeEnum);
        }
        else {
            System.out.println("Transaction has not verified from DB!!!!");
        }
    }

    // ************************* P2B Transaction for invalid and valid transaction type *****************************
    @Given("User login with valid cred for P2B transaction for invalid and valid transaction type")
    public void user_login_with_valid_cred_for_p2b_transaction_for_invalid_and_valid_transaction_type() throws FileNotFoundException {
        System.out.println("User login with valid cred for P2B transaction for invalid and valid transaction type");
        res = login(reader.getValueFromConfig("wallet.test.user2.mobile.number"),reader.getValueFromConfig("wallet.test.user2.passcode"),reader.getValueFromConfig("wallet.test.user2.device.id"),reader.getValueFromConfig("wallet.test.user2.device.id"));
        payerAccessToken = getAccessTokenResponseData(res,"access_token");

    }
    @Given("User has a valid details of beneficiary for invalid and valid transaction type")
    public void user_has_a_valid_details_of_beneficiary_for_invalid_and_valid_transaction_type() throws FileNotFoundException {
        System.out.println("User has a valid details of beneficiary for invalid and valid transaction type");
        res = getBeneficiaryDetails(payerAccessToken,reader.getValueFromConfig("limit"),reader.getValueFromConfig("offset")); // get beneficiary details
        if(res.getStatusCode()!=HTTP_OK){
            errorValidationOfTM(res,payee,payer);
        }
        else {
            Payee payee1 = setBeneficiaryDetails(res);
            if(payee1!=null){
                payee.setBankName(payee1.getBankName());
                payee.setAccountNumber(payee1.getAccountNumber());
                payee.setReceiverName(payee1.getReceiverName());
                payee.setIfsc(payee1.getIfsc());
            }
        }
    }
    @Given("User enter {string} and {string} for invalid and valid transaction type")
    public void user_enter_and_for_invalid_and_valid_transaction_type(String transactionType, String transactionTypeValue) throws FileNotFoundException {
        System.out.println("User enter transactionType -> "+transactionType+" and transactionTypeValue -> "+transactionTypeValue+" for invalid and valid transaction type");
        if(transactionTypeValue.equalsIgnoreCase("validTransactionType")){
            transTypeEnum = String.valueOf(TransTypeEnum.WALLET_TO_BANK);
        }
        else if(transactionTypeValue.equalsIgnoreCase("null")){
            transTypeEnum = null;
        }
        else if(transactionTypeValue.equalsIgnoreCase("empty")){
            transTypeEnum = " ";
        }
        else {
            transTypeEnum = transactionTypeValue;
        }
        String payerVpa = reader.getValueFromConfig("wallet.test.user2.vpa");
        payer.setSenderAccountId(payerVpa);
        payer.setSenderVpa(payerVpa);
        payer.setAccountType(reader.getValueFromConfig("wallet.b2b.account.type"));
        payer.setAction(reader.getValueFromConfig("wallet.pay.action"));
        payer.setDeviceTypeEnum(reader.getValueFromConfig("device.type.enum"));
        String walletBalance = getWalletBalance(payerAccessToken); // fetching payer wallet balance
        if(walletBalance!=null){
            balance = Double.valueOf(walletBalance);
        }
        else {
            System.out.println("Something went wrong!!");
        }
        payer.setWalletBalance(String.valueOf(balance));
        payer.setUniqueFrontendId(getUniqueFrontendId());
        payee.setAmount(String.valueOf(getRandomAmount()));
        payee.setComment(reader.getValueFromConfig("comment")); // set comment
        payee.setTransactionSubTypeEnum(reader.getValueFromConfig("wallet.transaction.subtype.enum")); // set transaction subtype enum
        //transTypeEnum = String.valueOf(TransTypeEnum.WALLET_TO_BANK);

    }
    @Given("After applying transaction charges for invalid and valid transaction type")
    public void after_applying_transaction_charges_for_invalid_and_valid_transaction_type() throws FileNotFoundException {
        System.out.println("After applying transaction charges for invalid and valid transaction type");
        res = getTransactionCharges(payerAccessToken,payee,transTypeEnum); // calling transaction charge api for transaction charge calculation
        if(res.getStatusCode()!=HTTP_OK){
            errorValidationOfTM(res,payee,payer);
        }
        else {
            Payer payer1 = calculateTransactionCharge(res,payee);
            payer.setTransactionChargeId(payer1.getTransactionChargeId()); // setting transaction charge id
            payer.setTotalTransactionAmount(payer1.getTotalTransactionAmount()); // setting total transaction amount
        }
    }
    @Given("User click on pay api for invalid and valid transaction type")
    public void user_click_on_pay_api_for_invalid_and_valid_transaction_type() throws FileNotFoundException {
        System.out.println("User click on pay api for invalid and valid transaction type");
        res = checkRuleApi(payee,payer,transTypeEnum,payerAccessToken);  //calling check rule api
        if(res.getStatusCode()!=HTTP_OK){
            errorValidationOfTM(res,payee,payer);
        }
        else {
            assertJsonValueEquals("message","Success",extractJsonObjectFromResponse(res)); // assertion
            payer.setPasscode(getEncryptedAuthData(reader.getValueFromConfig("wallet.test.user2.passcode")));
            res = pay(payee,payer,transTypeEnum,payerAccessToken);  // calling pay api
            if(res.getStatusCode()!=HTTP_OK){
                errorValidationOfTM(res,payee,payer);
            }
            else {
                assertJsonValueEquals("message","Success",extractJsonObjectFromResponse(res)); // assertion
                requestId = (String) getResponseData(res,"results.data");
                res = payByRequestId(requestId,payerAccessToken); //calling pay by request id
            }
        }
    }
    @Then("Verify transaction status for invalid and valid transaction type")
    public void verify_transaction_status_for_invalid_and_valid_transaction_type() throws FileNotFoundException {
        System.out.println("Verify transaction status for invalid and valid transaction type");
        if(res.getStatusCode()!=HTTP_OK){
            errorValidationOfTM(res,payee,payer);
            payer.setIsTransactionSuccess(false); // when transaction failed
        }
        else {
            transactionId =  successTransactionValidation(res,payee,payer,transTypeEnum);
            payer.setIsTransactionSuccess(true);
        }
    }
    @Then("Also verify transaction status from db for invalid and valid transaction type")
    public void also_verify_transaction_status_from_db_for_invalid_and_valid_transaction_type() throws SQLException {
        System.out.println("Also verify transaction status from db for invalid and valid transaction type");
        if(payer.getIsTransactionSuccess() && transactionId!=null){
            Transaction transaction = getTransactionDetails(transactionId);
            System.out.println(transaction);
            successTransactionValidationFromDB(res,transaction,transTypeEnum);
        }
        else {
            System.out.println("Transaction has not verified from DB!!!!");
        }
    }

    // ************************* P2B Transaction for invalid and valid transaction sub type *****************************
    @Given("User login with valid cred for P2B transaction for invalid and valid transaction sub type")
    public void user_login_with_valid_cred_for_p2b_transaction_for_invalid_and_valid_transaction_sub_type() throws FileNotFoundException {
        System.out.println("User login with valid cred for P2B transaction for invalid and valid transaction sub type");
        res = login(reader.getValueFromConfig("wallet.test.user2.mobile.number"),reader.getValueFromConfig("wallet.test.user2.passcode"),reader.getValueFromConfig("wallet.test.user2.device.id"),reader.getValueFromConfig("wallet.test.user2.device.id"));
        payerAccessToken = getAccessTokenResponseData(res,"access_token");

    }
    @Given("User has a valid details of beneficiary for invalid and valid transaction sub type")
    public void user_has_a_valid_details_of_beneficiary_for_invalid_and_valid_transaction_sub_type() throws FileNotFoundException {
        System.out.println("User has a valid details of beneficiary for invalid and valid transaction sub type");
        res = getBeneficiaryDetails(payerAccessToken,reader.getValueFromConfig("limit"),reader.getValueFromConfig("offset")); // get beneficiary details
        if(res.getStatusCode()!=HTTP_OK){
            errorValidationOfTM(res,payee,payer);
        }
        else {
            Payee payee1 = setBeneficiaryDetails(res);
            if(payee1!=null){
                payee.setBankName(payee1.getBankName());
                payee.setAccountNumber(payee1.getAccountNumber());
                payee.setReceiverName(payee1.getReceiverName());
                payee.setIfsc(payee1.getIfsc());
            }
        }
    }
    @Given("User enter {string} and {string} for invalid and valid transaction sub type")
    public void user_enter_and_for_invalid_and_valid_transaction_sub_type(String transactionSubType, String transactionSubTypeValue) throws FileNotFoundException {
        System.out.println("User enter transactionSubType -> "+transactionSubType+" and transactionSubTypeValue -> "+transactionSubTypeValue+" for invalid and valid transaction sub type");
        if(transactionSubType.equalsIgnoreCase("validTransactionSubType")){
            payee.setTransactionSubTypeEnum(reader.getValueFromConfig("wallet.transaction.subtype.enum")); // set transaction subtype enum
        }
        else if(transactionSubTypeValue.equalsIgnoreCase("null")){
            payee.setTransactionSubTypeEnum(null);
        }
        else if(transactionSubTypeValue.equalsIgnoreCase("empty")){
            payee.setTransactionSubTypeEnum(" ");
        }
        else {
            payee.setTransactionSubTypeEnum(transactionSubTypeValue);;
        }
        String payerVpa = reader.getValueFromConfig("wallet.test.user2.vpa");
        payer.setSenderAccountId(payerVpa);
        payer.setSenderVpa(payerVpa);
        payer.setAccountType(reader.getValueFromConfig("wallet.b2b.account.type"));
        payer.setAction(reader.getValueFromConfig("wallet.pay.action"));
        payer.setDeviceTypeEnum(reader.getValueFromConfig("device.type.enum"));
        String walletBalance = getWalletBalance(payerAccessToken); // fetching payer wallet balance
        if(walletBalance!=null){
            balance = Double.valueOf(walletBalance);
        }
        else {
            System.out.println("Something went wrong!!");
        }
        payer.setWalletBalance(String.valueOf(balance));
        payer.setUniqueFrontendId(getUniqueFrontendId());
        payee.setAmount(String.valueOf(getRandomAmount()));
        payee.setComment(reader.getValueFromConfig("comment")); // set comment
        //payee.setTransactionSubTypeEnum(reader.getValueFromConfig("wallet.transaction.subtype.enum")); // set transaction subtype enum
        transTypeEnum = String.valueOf(TransTypeEnum.WALLET_TO_BANK);

    }
    @Given("After applying transaction charges for invalid and valid transaction sub type")
    public void after_applying_transaction_charges_for_invalid_and_valid_transaction_sub_type() throws FileNotFoundException {
        System.out.println("After applying transaction charges for invalid and valid transaction sub type");
        res = getTransactionCharges(payerAccessToken,payee,transTypeEnum); // calling transaction charge api for transaction charge calculation
        if(res.getStatusCode()!=HTTP_OK){
            errorValidationOfTM(res,payee,payer);
        }
        else {
            Payer payer1 = calculateTransactionCharge(res,payee);
            payer.setTransactionChargeId(payer1.getTransactionChargeId()); // setting transaction charge id
            payer.setTotalTransactionAmount(payer1.getTotalTransactionAmount()); // setting total transaction amount
        }
    }
    @Given("User click on pay api for invalid and valid transaction sub type")
    public void user_click_on_pay_api_for_invalid_and_valid_transaction_sub_type() throws FileNotFoundException {
        System.out.println("User click on pay api for invalid and valid transaction sub type");
        res = checkRuleApi(payee,payer,transTypeEnum,payerAccessToken);  //calling check rule api
        if(res.getStatusCode()!=HTTP_OK){
            errorValidationOfTM(res,payee,payer);
        }
        else {
            assertJsonValueEquals("message","Success",extractJsonObjectFromResponse(res)); // assertion
            payer.setPasscode(getEncryptedAuthData(reader.getValueFromConfig("wallet.test.user2.passcode")));
            res = pay(payee,payer,transTypeEnum,payerAccessToken);  // calling pay api
            if(res.getStatusCode()!=HTTP_OK){
                errorValidationOfTM(res,payee,payer);
            }
            else {
                assertJsonValueEquals("message","Success",extractJsonObjectFromResponse(res)); // assertion
                requestId = (String) getResponseData(res,"results.data");
                res = payByRequestId(requestId,payerAccessToken); //calling pay by request id
            }
        }
    }
    @Then("Verify transaction status for invalid and valid transaction sub type")
    public void verify_transaction_status_for_invalid_and_valid_transaction_sub_type() throws FileNotFoundException {
        System.out.println("Verify transaction status for invalid and valid transaction sub type");
        if(res.getStatusCode()!=HTTP_OK){
            errorValidationOfTM(res,payee,payer);
            payer.setIsTransactionSuccess(false); // when transaction failed
        }
        else {
            transactionId =  successTransactionValidation(res,payee,payer,transTypeEnum);
            payer.setIsTransactionSuccess(true);
        }
    }
    @Then("Also verify transaction status from db for invalid and valid transaction sub type")
    public void also_verify_transaction_status_from_db_for_invalid_and_valid_transaction_sub_type() throws SQLException {
        System.out.println("Also verify transaction status from db for invalid and valid transaction sub type");
        if(payer.getIsTransactionSuccess() && transactionId!=null){
            Transaction transaction = getTransactionDetails(transactionId);
            System.out.println(transaction);
            successTransactionValidationFromDB(res,transaction,transTypeEnum);
        }
        else {
            System.out.println("Transaction has not verified from DB!!!!");
        }
    }

    // ************************* P2B Transaction for invalid and valid action *****************************
    @Given("User login with valid cred for P2B transaction for invalid and valid transaction charge id")
    public void user_login_with_valid_cred_for_p2b_transaction_for_invalid_and_valid_transaction_charge_id() throws FileNotFoundException {
        System.out.println("User login with valid cred for P2B transaction for invalid and valid transaction charge id");
        res = login(reader.getValueFromConfig("wallet.test.user2.mobile.number"),reader.getValueFromConfig("wallet.test.user2.passcode"),reader.getValueFromConfig("wallet.test.user2.device.id"),reader.getValueFromConfig("wallet.test.user2.device.id"));
        payerAccessToken = getAccessTokenResponseData(res,"access_token");

    }
    @Given("User has a valid details of beneficiary for invalid and valid transaction charge id")
    public void user_has_a_valid_details_of_beneficiary_for_invalid_and_valid_transaction_charge_id() throws FileNotFoundException {
        System.out.println("User has a valid details of beneficiary for invalid and valid transaction charge id");
        res = getBeneficiaryDetails(payerAccessToken,reader.getValueFromConfig("limit"),reader.getValueFromConfig("offset")); // get beneficiary details
        if(res.getStatusCode()!=HTTP_OK){
            errorValidationOfTM(res,payee,payer);
        }
        else {
            Payee payee1 = setBeneficiaryDetails(res);
            if(payee1!=null){
                payee.setBankName(payee1.getBankName());
                payee.setAccountNumber(payee1.getAccountNumber());
                payee.setReceiverName(payee1.getReceiverName());
                payee.setIfsc(payee1.getIfsc());
            }
        }
    }
    @Given("User enter all details of beneficiary for invalid and valid transaction charge id")
    public void user_enter_all_details_of_beneficiary_for_invalid_and_valid_transaction_charge_id() throws FileNotFoundException {
        System.out.println("User enter all details of beneficiary for invalid and valid transaction charge id");
        String payerVpa = reader.getValueFromConfig("wallet.test.user2.vpa");
        payer.setSenderAccountId(payerVpa);
        payer.setSenderVpa(payerVpa);
        payer.setAccountType(reader.getValueFromConfig("wallet.b2b.account.type"));
        payer.setAction(reader.getValueFromConfig("wallet.pay.action"));
        payer.setDeviceTypeEnum(reader.getValueFromConfig("device.type.enum"));
        String walletBalance = getWalletBalance(payerAccessToken); // fetching payer wallet balance
        if(walletBalance!=null){
            balance = Double.valueOf(walletBalance);
        }
        else {
            System.out.println("Something went wrong!!");
        }
        payer.setWalletBalance(String.valueOf(balance));
        payer.setUniqueFrontendId(getUniqueFrontendId());
        payee.setAmount(String.valueOf(getRandomAmount()));
        payee.setComment(reader.getValueFromConfig("comment")); // set comment
        payee.setTransactionSubTypeEnum(reader.getValueFromConfig("wallet.transaction.subtype.enum")); // set transaction subtype enum
        transTypeEnum = String.valueOf(TransTypeEnum.WALLET_TO_BANK);
    }
    @Given("After applying transaction charges for invalid and valid transaction charge id")
    public void after_applying_transaction_charges_for_invalid_and_valid_transaction_charge_id() throws FileNotFoundException {
        System.out.println("After applying transaction charges for invalid and valid transaction charge id");
        res = getTransactionCharges(payerAccessToken,payee,transTypeEnum); // calling transaction charge api for transaction charge calculation
        if(res.getStatusCode()!=HTTP_OK){
            errorValidationOfTM(res,payee,payer);
        }
        else {
            Payer payer1 = calculateTransactionCharge(res,payee);
            //payer.setTransactionChargeId(payer1.getTransactionChargeId()); // setting transaction charge id
            transactionChargeId = payer1.getTransactionChargeId();
            payer.setTotalTransactionAmount(payer1.getTotalTransactionAmount()); // setting total transaction amount
        }
    }
    @Given("User enter {string} and {string} for invalid and valid transaction charge id")
    public void user_enter_and_for_invalid_and_valid_transaction_charge_id(String transactionChargeIdType, String transactionChargeIdValue) {
        System.out.println("User enter transactionChargeIdType -> "+transactionChargeIdType+" and transactionChargeIdValue -> "+transactionChargeIdValue+" for invalid and valid transaction charge id");
        if(transactionChargeIdValue.equalsIgnoreCase("validTransactionChargeId")){
            payer.setTransactionChargeId(transactionChargeId); // setting transaction charge id
        }
        else if(transactionChargeIdValue.equalsIgnoreCase("null")){
            payer.setTransactionChargeId(null);
        }
        else if(transactionChargeIdValue.equalsIgnoreCase("empty")){
            payer.setTransactionChargeId(" ");;
        }
        else {
            payer.setTransactionChargeId(transactionChargeIdValue);;
        }
    }
    @Given("User click on pay api for invalid and valid for invalid and valid transaction charge id")
    public void user_click_on_pay_api_for_invalid_and_valid_for_invalid_and_valid_transaction_charge_id() throws FileNotFoundException {
        System.out.println("User click on pay api for invalid and valid for invalid and valid transaction charge id");
        res = checkRuleApi(payee,payer,transTypeEnum,payerAccessToken);  //calling check rule api
        if(res.getStatusCode()!=HTTP_OK){
            errorValidationOfTM(res,payee,payer);
        }
        else {
            assertJsonValueEquals("message","Success",extractJsonObjectFromResponse(res)); // assertion
            payer.setPasscode(getEncryptedAuthData(reader.getValueFromConfig("wallet.test.user2.passcode")));
            res = pay(payee,payer,transTypeEnum,payerAccessToken);  // calling pay api
            if(res.getStatusCode()!=HTTP_OK){
                errorValidationOfTM(res,payee,payer);
            }
            else {
                assertJsonValueEquals("message","Success",extractJsonObjectFromResponse(res)); // assertion
                requestId = (String) getResponseData(res,"results.data");
                res = payByRequestId(requestId,payerAccessToken); //calling pay by request id
            }
        }

    }
    @Then("Verify transaction status for invalid and valid for invalid and valid transaction charge id")
    public void verify_transaction_status_for_invalid_and_valid_for_invalid_and_valid_transaction_charge_id() throws FileNotFoundException {
        System.out.println("Verify transaction status for invalid and valid for invalid and valid transaction charge id");
        if(res.getStatusCode()!=HTTP_OK){
            errorValidationOfTM(res,payee,payer);
            payer.setIsTransactionSuccess(false); // when transaction failed
        }
        else {
            transactionId =  successTransactionValidation(res,payee,payer,transTypeEnum);
            payer.setIsTransactionSuccess(true);
        }

    }
    @Then("Also verify transaction status from db for invalid and valid for invalid and valid transaction charge id")
    public void also_verify_transaction_status_from_db_for_invalid_and_valid_for_invalid_and_valid_transaction_charge_id() throws SQLException {
        System.out.println("Also verify transaction status from db for invalid and valid for invalid and valid transaction charge id");
        if(payer.getIsTransactionSuccess() && transactionId!=null){
            Transaction transaction = getTransactionDetails(transactionId);
            System.out.println(transaction);
            successTransactionValidationFromDB(res,transaction,transTypeEnum);
        }
        else {
            System.out.println("Transaction has not verified from DB!!!!");
        }
    }

    // ************************* P2B Transaction for all valid details *****************************
    @Given("User login with valid cred for P2B transaction")
    public void user_login_with_valid_cred_for_p2b_transaction() throws FileNotFoundException {
        System.out.println("User login with valid cred for P2B transaction");
        res = login(reader.getValueFromConfig("wallet.test.user2.mobile.number"),reader.getValueFromConfig("wallet.test.user2.passcode"),reader.getValueFromConfig("wallet.test.user2.device.id"),reader.getValueFromConfig("wallet.test.user2.device.id"));
        payerAccessToken = getAccessTokenResponseData(res,"access_token");

    }
    @Given("User has a valid details of beneficiary for P2B transaction")
    public void user_has_a_valid_details_of_beneficiary_for_p2b_transaction() throws FileNotFoundException {
        System.out.println("User has a valid details of beneficiary for P2B transaction");
        res = getBeneficiaryDetails(payerAccessToken,reader.getValueFromConfig("limit"),reader.getValueFromConfig("offset")); // get beneficiary details
        if(res.getStatusCode()!=HTTP_OK){
            errorValidationOfTM(res,payee,payer);
        }
        else {
            Payee payee1 = setBeneficiaryDetails(res);
            if(payee1!=null){
                payee.setBankName(payee1.getBankName());
                payee.setAccountNumber(payee1.getAccountNumber());
                payee.setReceiverName(payee1.getReceiverName());
                payee.setIfsc(payee1.getIfsc());
            }
        }
    }
    @Given("User enter valid details of beneficiary for P2B transaction")
    public void user_enter_valid_details_of_beneficiary_for_p2b_transaction() throws FileNotFoundException {
        System.out.println("User enter valid details of beneficiary for P2B transaction");
        String payerVpa = reader.getValueFromConfig("wallet.test.user2.vpa");
        payer.setSenderAccountId(payerVpa);
        payer.setSenderVpa(payerVpa);
        payer.setAccountType(reader.getValueFromConfig("wallet.b2b.account.type"));
        payer.setAction(reader.getValueFromConfig("wallet.pay.action"));
        payer.setDeviceTypeEnum(reader.getValueFromConfig("device.type.enum"));
        String walletBalance = getWalletBalance(payerAccessToken); // fetching payer wallet balance
        if(walletBalance!=null){
            balance = Double.valueOf(walletBalance);
        }
        else {
            System.out.println("Something went wrong!!");
        }
        payer.setWalletBalance(String.valueOf(balance));
        payer.setUniqueFrontendId(getUniqueFrontendId());
        payee.setAmount(String.valueOf(getRandomAmount()));
        payee.setComment(reader.getValueFromConfig("comment")); // set comment
        payee.setTransactionSubTypeEnum(reader.getValueFromConfig("wallet.transaction.subtype.enum")); // set transaction subtype enum
        transTypeEnum = String.valueOf(TransTypeEnum.WALLET_TO_BANK);

    }
    @Given("After applying transaction charges for P2B transaction")
    public void after_applying_transaction_charges_for_p2b_transaction() throws FileNotFoundException {
        System.out.println("After applying transaction charges for P2B transaction");
        res = getTransactionCharges(payerAccessToken,payee,transTypeEnum); // calling transaction charge api for transaction charge calculation
        if(res.getStatusCode()!=HTTP_OK){
            errorValidationOfTM(res,payee,payer);
        }
        else {
            Payer payer1 = calculateTransactionCharge(res,payee);
            payer.setTransactionChargeId(payer1.getTransactionChargeId()); // setting transaction charge id
            payer.setTotalTransactionAmount(payer1.getTotalTransactionAmount()); // setting total transaction amount
        }
    }
    @Given("User click on pay api for P2B transaction")
    public void user_click_on_pay_api_for_p2b_transaction() throws FileNotFoundException {
        System.out.println("User click on pay api for P2B transaction");
        res = checkRuleApi(payee,payer,transTypeEnum,payerAccessToken);  //calling check rule api
        if(res.getStatusCode()!=HTTP_OK){
            errorValidationOfTM(res,payee,payer);
        }
        else {
            assertJsonValueEquals("message","Success",extractJsonObjectFromResponse(res)); // assertion
            payer.setPasscode(getEncryptedAuthData(reader.getValueFromConfig("wallet.test.user2.passcode")));
            res = pay(payee,payer,transTypeEnum,payerAccessToken);  // calling pay api
            if(res.getStatusCode()!=HTTP_OK){
                errorValidationOfTM(res,payee,payer);
            }
            else {
                assertJsonValueEquals("message","Success",extractJsonObjectFromResponse(res)); // assertion
                requestId = (String) getResponseData(res,"results.data");
                res = payByRequestId(requestId,payerAccessToken); //calling pay by request id
            }
        }
    }
    @Then("Verify transaction status of P2B transaction")
    public void verify_transaction_status_of_p2b_transaction() throws FileNotFoundException {
        System.out.println("Verify transaction status of P2B transaction");
        if(res.getStatusCode()!=HTTP_OK){
            errorValidationOfTM(res,payee,payer);
            payer.setIsTransactionSuccess(false); // when transaction failed
        }
        else {
            transactionId =  successTransactionValidation(res,payee,payer,transTypeEnum);
            payer.setIsTransactionSuccess(true);
        }
    }
    @Then("Also verify transaction status from db if P2B transaction is success")
    public void also_verify_transaction_status_from_db_if_p2b_transaction_is_success() throws SQLException {
        System.out.println("Also verify transaction status from db if P2B transaction is success");
        if(payer.getIsTransactionSuccess() && transactionId!=null){
            Transaction transaction = getTransactionDetails(transactionId);
            System.out.println(transaction);
            successTransactionValidationFromDB(res,transaction,transTypeEnum);
        }
        else {
            System.out.println("Transaction has not verified from DB!!!!");
        }
    }


    // ************************* Delete beneficiary *****************************
    @Given("Payer have valid beneficiary detail")
    public void payer_have_valid_beneficiary_detail() throws FileNotFoundException {
        System.out.println("Payer have valid beneficiary detail");
        res = login(reader.getValueFromConfig("wallet.test.user2.mobile.number"),reader.getValueFromConfig("wallet.test.user2.passcode"),reader.getValueFromConfig("wallet.test.user2.device.id"),reader.getValueFromConfig("wallet.test.user2.device.id"));
        payerAccessToken = getAccessTokenResponseData(res,"access_token");
        res = getBeneficiaryDetails(payerAccessToken,reader.getValueFromConfig("limit"),reader.getValueFromConfig("offset")); // get beneficiary details

    }
    @Given("On entering beneficiary detail")
    public void on_entering_beneficiary_detail() {
        System.out.println("On entering beneficiary detail");
        responseObject = extractJsonObjectFromResponse(res);  // extracting data from response
        JSONObject results = extractNestedJsonObject(responseObject,"results");
        JSONObject dataFromResponse = extractJsonValueFromJsonArray(results,"data",0);
        beneficiaryId = getValueFromJSONObject(dataFromResponse,"id");
    }
    @Given("On initiating delete beneficiary")
    public void on_initiating_delete_beneficiary() throws FileNotFoundException {
        System.out.println("On initiating delete beneficiary");
//        res = deleteBeneficiary(beneficiaryId,getEncryptedAuthData(reader.getValueFromConfig("payer.passcode")), payerAccessToken);
//        jsonSchemaValidator(res,reader.getValueFromConfig("wallet.delete.beneficiary.valid.schema"));
//        responseObject = extractJsonObjectFromResponse(res);
//        assertJsonValueEquals("message","Beneficiary deleted successfully",responseObject);
    }
    @Given("Verify delete beneficiary status")
    public void verify_delete_beneficiary_status() {
        System.out.println("On initiating delete beneficiary");
        verifyStatusCode(res, HTTP_OK);
    }





}
