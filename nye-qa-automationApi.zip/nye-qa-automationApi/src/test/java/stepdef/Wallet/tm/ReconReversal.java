package stepdef.Wallet.tm;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.restassured.response.Response;
import org.json.JSONArray;
import org.json.JSONObject;
import org.junit.Assert;
import resources.Payee;
import resources.Payer;
import resources.TransTypeEnum;
import resources.Transaction;
import utilities.PropertyReader;

import java.io.FileNotFoundException;
import java.sql.SQLException;
import java.util.ArrayList;

import static utilities.CommonStepDef.*;
import static utilities.GlobalConstant.HTTP_OK;
import static utilities.Utils.*;

public class ReconReversal {
    private String adminAccessToken;
    private ArrayList<Transaction> transactions;
    private static Response res;
    private static String transactionType;
    private PropertyReader reader = new PropertyReader();
    private static Payee payee = new Payee();
    private static Payer payer = new Payer();

    // ************************* Recon Reversal for card transaction *****************************
    @Given("Admin has a valid cred for login to do recon reversal of card transaction")
    public void admin_has_a_valid_cred_for_login_to_do_recon_reversal_of_card_transaction() throws FileNotFoundException {
        System.out.println("Admin has a valid cred for login to do recon reversal of card transaction");
        adminAccessToken = adminLogin(reader.getValueFromConfig("wallet.recon.reversal.admin.email"),reader.getValueFromConfig("wallet.recon.reversal.admin.password"));
    }
    @Given("Admin enter transaction details for recon reversal of card transaction")
    public void admin_enter_transaction_details_for_recon_reversal_of_card_transaction() throws SQLException {
        System.out.println("Admin enter transaction details for recon reversal of card transaction");
        transactionType = String.valueOf(TransTypeEnum.CARD_PAYMENT);
        transactions = getReconReversalData(transactionType); // calling method to fetch recon data
    }
    @Given("Admin click recon reversal api to do recon reversal of card transaction")
    public void admin_click_recon_reversal_api_to_do_recon_reversal_of_card_transaction() throws FileNotFoundException {
        System.out.println("Admin click recon reversal api to do recon reversal of card transaction");
        res = reconReversal(adminAccessToken,transactions); // calling method for recon reversal
    }
    @Then("Verify recon reversal status of card transaction")
    public void verify_recon_reversal_status_of_card_transaction() throws FileNotFoundException {
        System.out.println("Verify recon reversal status of card transaction");
        if(res.getStatusCode()!=HTTP_OK){
            errorValidationOfTM(res,payee,payer); // calling method for tm error validation
        }
        else {
            successReconReversalValidation(res,transactions,transactionType); //calling method to validate transaction
        }
    }

    // ************************* Recon Reversal for P2P Transaction *****************************
    @Given("Admin has a valid cred for login to do recon reversal of P2P transaction")
    public void admin_has_a_valid_cred_for_login_to_do_recon_reversal_of_p2p_transaction() throws FileNotFoundException {
        System.out.println("Admin has a valid cred for login to do recon reversal of P2P transaction");
        adminAccessToken = adminLogin(reader.getValueFromConfig("wallet.recon.reversal.admin.email"),reader.getValueFromConfig("wallet.recon.reversal.admin.password"));
    }
    @Given("Admin enter transaction details for recon reversal of P2P transaction")
    public void admin_enter_transaction_details_for_recon_reversal_of_p2p_transaction() throws SQLException {
        System.out.println("Admin enter transaction details for recon reversal of P2P transaction");
        transactionType = String.valueOf(TransTypeEnum.WALLET_TO_WALLET);
        transactions = getReconReversalData(transactionType); // calling method to fetch recon data
    }
    @Given("Admin click recon reversal api to do recon reversal of P2P transaction")
    public void admin_click_recon_reversal_api_to_do_recon_reversal_of_p2p_transaction() throws FileNotFoundException {
        System.out.println("Admin click recon reversal api to do recon reversal of P2P transaction");
        res = reconReversal(adminAccessToken,transactions); // calling method for recon reversal
    }
    @Then("Verify recon reversal status of P2P transaction")
    public void verify_recon_reversal_status_of_p2p_transaction() throws FileNotFoundException {
        System.out.println("Verify recon reversal status of P2P transaction");
        if(res.getStatusCode()!=HTTP_OK){
            errorValidationOfTM(res,payee,payer); // calling method for tm error validation
        }
        else {
            successReconReversalValidation(res,transactions,transactionType); //calling method to validate transaction
        }
    }

    // ************************* Recon Reversal for P2B Transaction *****************************
    @Given("Admin has a valid cred for login to do recon reversal of P2B transaction")
    public void admin_has_a_valid_cred_for_login_to_do_recon_reversal_of_p2b_transaction() throws FileNotFoundException {
        System.out.println("Admin has a valid cred for login to do recon reversal of P2B transaction");
        adminAccessToken = adminLogin(reader.getValueFromConfig("wallet.recon.reversal.admin.email"),reader.getValueFromConfig("wallet.recon.reversal.admin.password"));
    }
    @Given("Admin enter transaction details for recon reversal of P2B transaction")
    public void admin_enter_transaction_details_for_recon_reversal_of_p2b_transaction() throws SQLException {
        System.out.println("Admin enter transaction details for recon reversal of P2B transaction");
        transactionType = String.valueOf(TransTypeEnum.WALLET_TO_BANK);
        transactions = getReconReversalData(transactionType); // calling method to fetch recon data
    }
    @Given("Admin click recon reversal api to do recon reversal of P2B transaction")
    public void admin_click_recon_reversal_api_to_do_recon_reversal_of_p2b_transaction() throws FileNotFoundException {
        System.out.println("Admin click recon reversal api to do recon reversal of P2B transaction");
        res = reconReversal(adminAccessToken,transactions); // calling method for recon reversal
    }
    @Then("Verify recon reversal status of P2B transaction")
    public void verify_recon_reversal_status_of_p2b_transaction() throws FileNotFoundException {
        System.out.println("Verify recon reversal status of P2B transaction");
        if(res.getStatusCode()!=HTTP_OK){
            errorValidationOfTM(res,payee,payer); // calling method for tm error validation
        }
        else {
            successReconReversalValidation(res,transactions,transactionType); //calling method to validate transaction
        }
    }

    // ************************* Recon Reversal for Wallet to wallet cashback Transaction *****************************
    @Given("Admin has a valid cred for login to do recon reversal of Wallet to Wallet Cashback transaction")
    public void admin_has_a_valid_cred_for_login_to_do_recon_reversal_of_Wallet_to_Wallet_Cashback_transaction() throws FileNotFoundException {
        System.out.println("Admin has a valid cred for login to do recon reversal of Wallet to Wallet Cashback transaction");
        adminAccessToken = adminLogin(reader.getValueFromConfig("wallet.recon.reversal.admin.email"),reader.getValueFromConfig("wallet.recon.reversal.admin.password"));
    }
    @Given("Admin enter transaction details for recon reversal of Wallet to Wallet Cashback transaction")
    public void admin_enter_transaction_details_for_recon_reversal_of_Wallet_to_Wallet_Cashback_transaction() throws SQLException {
        System.out.println("Admin enter transaction details for recon reversal of Wallet to Wallet Cashback transaction");
        transactionType = String.valueOf(TransTypeEnum.WALLET_TO_WALLET_CHASHBACK);
        transactions = getReconReversalData(transactionType); // calling method to fetch recon data
    }
    @Given("Admin click recon reversal api to do recon reversal of Wallet to Wallet Cashback transaction")
    public void admin_click_recon_reversal_api_to_do_recon_reversal_of_Wallet_to_Wallet_Cashback_transaction() throws FileNotFoundException {
        System.out.println("Admin click recon reversal api to do recon reversal of Wallet to Wallet Cashback transaction");
        res = reconReversal(adminAccessToken,transactions); // calling method for recon reversal
    }
    @Then("Verify recon reversal status of Wallet to Wallet Cashback transaction")
    public void verify_recon_reversal_status_of_Wallet_to_Wallet_Cashback_transaction() throws FileNotFoundException {
        System.out.println("Verify recon reversal status of Wallet to Wallet Cashback transaction");
        if(res.getStatusCode()!=HTTP_OK){
            errorValidationOfTM(res,payee,payer); // calling method for tm error validation
        }
        else {
            successReconReversalValidation(res,transactions,transactionType); //calling method to validate transaction
        }
    }

    // ************************* Recon Reversal for Wallet to other wallet Transaction *****************************
    @Given("Admin has a valid cred for login to do recon reversal of Wallet to other Wallet transaction")
    public void admin_has_a_valid_cred_for_login_to_do_recon_reversal_of_wallet_to_other_wallet_transaction() throws FileNotFoundException {
        System.out.println("Admin has a valid cred for login to do recon reversal of Wallet to other Wallet transaction");
        adminAccessToken = adminLogin(reader.getValueFromConfig("wallet.recon.reversal.admin.email"),reader.getValueFromConfig("wallet.recon.reversal.admin.password"));
    }
    @Given("Admin enter transaction details for recon reversal of Wallet to other Wallet transaction")
    public void admin_enter_transaction_details_for_recon_reversal_of_wallet_to_other_wallet_transaction() throws SQLException {
        System.out.println("Admin enter transaction details for recon reversal of Wallet to other Wallet transaction");
        transactionType = String.valueOf(TransTypeEnum.WALLET_TO_OTHER_WALLET);
        transactions = getReconReversalData(transactionType); // calling method to fetch recon data
    }
    @Given("Admin click recon reversal api to do recon reversal of Wallet to other Wallet transaction")
    public void admin_click_recon_reversal_api_to_do_recon_reversal_of_wallet_to_other_wallet_transaction() throws FileNotFoundException {
        System.out.println("Admin click recon reversal api to do recon reversal of Wallet to other Wallet transaction");
        res = reconReversal(adminAccessToken,transactions); // calling method for recon reversal
    }
    @Then("Verify recon reversal status of Wallet to other Wallet transaction")
    public void verify_recon_reversal_status_of_wallet_to_other_wallet_transaction() throws FileNotFoundException {
        System.out.println("Verify recon reversal status of Wallet to other Wallet transaction");
        if(res.getStatusCode()!=HTTP_OK){
            errorValidationOfTM(res,payee,payer); // calling method for tm error validation
        }
        else {
            successReconReversalValidation(res,transactions,transactionType); //calling method to validate transaction
        }
    }

    // ************************* Recon Reversal for Wallet to other wallet reversal Transaction *****************************
    @Given("Admin has a valid cred for login to do recon reversal of Wallet to other Wallet reversal transaction")
    public void admin_has_a_valid_cred_for_login_to_do_recon_reversal_of_wallet_to_other_wallet_reversal_transaction() throws FileNotFoundException {
        System.out.println("Admin has a valid cred for login to do recon reversal of Wallet to other Wallet reversal transaction");
        adminAccessToken = adminLogin(reader.getValueFromConfig("wallet.recon.reversal.admin.email"),reader.getValueFromConfig("wallet.recon.reversal.admin.password"));
    }
    @Given("Admin enter transaction details for recon reversal of Wallet to other Wallet reversal transaction")
    public void admin_enter_transaction_details_for_recon_reversal_of_wallet_to_other_wallet_reversal_transaction() throws SQLException {
        System.out.println("Admin enter transaction details for recon reversal of Wallet to other Wallet reversal transaction");
        transactionType = String.valueOf(TransTypeEnum.WALLET_TO_OTHER_WALLET_REVERSAL);
        transactions = getReconReversalData(transactionType); // calling method to fetch recon data
        if(transactions.size()==0){
            System.out.println("There is no transaction!!!!");
        }
    }
    @Given("Admin click recon reversal api to do recon reversal of Wallet to other Wallet reversal transaction")
    public void admin_click_recon_reversal_api_to_do_recon_reversal_of_wallet_to_other_wallet_reversal_transaction() throws FileNotFoundException {
        System.out.println("Admin click recon reversal api to do recon reversal of Wallet to other Wallet reversal transaction");
        res = reconReversal(adminAccessToken,transactions); // calling method for recon reversal
    }
    @Then("Verify recon reversal status of Wallet to other Wallet reversal transaction")
    public void verify_recon_reversal_status_of_wallet_to_other_wallet_reversal_transaction() throws FileNotFoundException {
        System.out.println("Verify recon reversal status of Wallet to other Wallet reversal transaction");
        if(res.getStatusCode()!=HTTP_OK){
            errorValidationOfTM(res,payee,payer); // calling method for tm error validation
        }
        else {
            successReconReversalValidation(res,transactions,transactionType); //calling method to validate transaction
        }
    }

    // ************************* Recon Reversal for reversal Transaction *****************************
    @Given("Admin has a valid cred for login to do recon reversal of reversal transaction")
    public void admin_has_a_valid_cred_for_login_to_do_recon_reversal_of_reversal_transaction() throws FileNotFoundException {
        System.out.println("Admin has a valid cred for login to do recon reversal of reversal transaction");
        adminAccessToken = adminLogin(reader.getValueFromConfig("wallet.recon.reversal.admin.email"),reader.getValueFromConfig("wallet.recon.reversal.admin.password"));

    }
    @Given("Admin enter transaction details for recon reversal of reversal transaction")
    public void admin_enter_transaction_details_for_recon_reversal_of_reversal_transaction() throws SQLException {
        System.out.println("Admin enter transaction details for recon reversal of reversal transaction");
        transactionType = String.valueOf(TransTypeEnum.REVERSAL);
        transactions = getReconReversalData(transactionType); // calling method to fetch recon data
        if(transactions.size()==0){
            System.out.println("There is no transaction!!!!");
        }
    }
    @Given("Admin click recon reversal api to do recon reversal of reversal transaction")
    public void admin_click_recon_reversal_api_to_do_recon_reversal_of_reversal_transaction() throws FileNotFoundException {
        System.out.println("Admin click recon reversal api to do recon reversal of reversal transaction");
        res = reconReversal(adminAccessToken,transactions); // calling method for recon reversal
    }
    @Then("Verify recon reversal status of reversal transaction")
    public void verify_recon_reversal_status_of_reversal_transaction() throws FileNotFoundException {
        System.out.println("Verify recon reversal status of reversal transaction");
        if(res.getStatusCode()!=HTTP_OK){
            errorValidationOfTM(res,payee,payer); // calling method for tm error validation
        }
        else {
            successReconReversalValidation(res,transactions,transactionType); //calling method to validate transaction
        }
    }

    // ************************* Recon Reversal for add money to wallet Transaction *****************************
    @Given("Admin has a valid cred for login to do recon reversal of add money to wallet transaction")
    public void admin_has_a_valid_cred_for_login_to_do_recon_reversal_of_add_money_to_wallet_transaction() throws FileNotFoundException {
        System.out.println("Admin has a valid cred for login to do recon reversal of add money to wallet transaction");
        adminAccessToken = adminLogin(reader.getValueFromConfig("wallet.recon.reversal.admin.email"),reader.getValueFromConfig("wallet.recon.reversal.admin.password"));

    }
    @Given("Admin enter transaction details for recon reversal of add money to wallet transaction")
    public void admin_enter_transaction_details_for_recon_reversal_of_add_money_to_wallet_transaction() throws SQLException {
        System.out.println("Admin enter transaction details for recon reversal of add money to wallet transaction");
        transactionType = String.valueOf(TransTypeEnum.ADD_MONEY_TO_WALLET);
        transactions = getReconReversalData(transactionType); // calling method to fetch recon data
        if(transactions.size()==0){
            System.out.println("There is no transaction!!!!");
        }
    }
    @Given("Admin click recon reversal api to do recon reversal of add money to wallet transaction")
    public void admin_click_recon_reversal_api_to_do_recon_reversal_of_add_money_to_wallet_transaction() throws FileNotFoundException {
        System.out.println("Admin click recon reversal api to do recon reversal of add money to wallet transaction");
        res = reconReversal(adminAccessToken,transactions); // calling method for recon reversal
    }
    @Then("Verify recon reversal status of add money to wallet transaction")
    public void verify_recon_reversal_status_of_add_money_to_wallet_transaction() throws FileNotFoundException {
        System.out.println("Verify recon reversal status of add money to wallet transaction");
        if(res.getStatusCode()!=HTTP_OK){
            errorValidationOfTM(res,payee,payer); // calling method for tm error validation
        }
        else {
            successReconReversalValidation(res,transactions,transactionType); //calling method to validate transaction
        }
    }

    // ************************* Recon Reversal for recon reversal Transaction *****************************
    @Given("Admin has a valid cred for login to do recon reversal of recon reversal transaction")
    public void admin_has_a_valid_cred_for_login_to_do_recon_reversal_of_recon_reversal_transaction() throws FileNotFoundException {
        System.out.println("Admin has a valid cred for login to do recon reversal of recon reversal transaction");
        adminAccessToken = adminLogin(reader.getValueFromConfig("wallet.recon.reversal.admin.email"),reader.getValueFromConfig("wallet.recon.reversal.admin.password"));

    }
    @Given("Admin enter transaction details for recon reversal of recon reversal transaction")
    public void admin_enter_transaction_details_for_recon_reversal_of_recon_reversal_transaction() throws SQLException {
        System.out.println("Admin enter transaction details for recon reversal of recon reversal transaction");
        transactionType = String.valueOf(TransTypeEnum.RECON_REVERSAL);
        transactions = getReconReversalData(transactionType); // calling method to fetch recon data
        if(transactions.size()==0){
            System.out.println("There is no transaction!!!!");
        }
    }
    @Given("Admin click recon reversal api to do recon reversal of recon reversal transaction")
    public void admin_click_recon_reversal_api_to_do_recon_reversal_of_recon_reversal_transaction() throws FileNotFoundException {
        System.out.println("Admin click recon reversal api to do recon reversal of recon reversal transaction");
        res = reconReversal(adminAccessToken,transactions); // calling method for recon reversal
    }
    @Then("Verify recon reversal status of recon reversal transaction")
    public void verify_recon_reversal_status_of_recon_reversal_transaction() throws FileNotFoundException {
        System.out.println("Verify recon reversal status of recon reversal transaction");
        if(res.getStatusCode()!=HTTP_OK){
            errorValidationOfTM(res,payee,payer); // calling method for tm error validation
        }
        else {
            successReconReversalValidation(res,transactions,transactionType); //calling method to validate transaction
        }
    }

    // ************************* Recon Reversal for add money to wallet ecollect Transaction *****************************
    @Given("Admin has a valid cred for login to do recon reversal of add money to wallet via ecollect transaction")
    public void admin_has_a_valid_cred_for_login_to_do_recon_reversal_of_add_money_to_wallet_ecollect_transaction() throws FileNotFoundException {
        System.out.println("Admin has a valid cred for login to do recon reversal of add money to wallet via ecollect transaction");
        adminAccessToken = adminLogin(reader.getValueFromConfig("wallet.recon.reversal.admin.email"),reader.getValueFromConfig("wallet.recon.reversal.admin.password"));

    }
    @Given("Admin enter transaction details for recon reversal of add money to wallet via ecollect transaction")
    public void admin_enter_transaction_details_for_recon_reversal_of_add_money_to_wallet_ecollect_transaction() throws SQLException {
        System.out.println("Admin enter transaction details for recon reversal of add money to wallet via ecollect transaction");
        transactionType = String.valueOf(TransTypeEnum.ADD_MONEY_TO_WALLET_ECOLLECT);
        transactions = getReconReversalData(transactionType); // calling method to fetch recon data
        if(transactions.size()==0){
            System.out.println("There is no transaction!!!!");
        }

    }
    @Given("Admin click recon reversal api to do recon reversal of add money to wallet via ecollect transaction")
    public void admin_click_recon_reversal_api_to_do_recon_reversal_of_add_money_to_wallet_ecollect_transaction() throws FileNotFoundException {
        System.out.println("Admin click recon reversal api to do recon reversal of add money to wallet via ecollect transaction");
        res = reconReversal(adminAccessToken,transactions); // calling method for recon reversal
    }
    @Then("Verify recon reversal status of add money to wallet via ecollect transaction")
    public void verify_recon_reversal_status_of_add_money_to_wallet_ecollect_transaction() throws FileNotFoundException {
        System.out.println("Verify recon reversal status of add money to wallet via  ecollect transaction");
        if(res.getStatusCode()!=HTTP_OK){
            errorValidationOfTM(res,payee,payer); // calling method for tm error validation
        }
        else {
            successReconReversalValidation(res,transactions,transactionType); //calling method to validate transaction
        }
    }

    // ************************* Recon Reversal for cashback reversal Transaction *****************************
    @Given("Admin has a valid cred for login to do recon reversal of cashback reversal transaction")
    public void admin_has_a_valid_cred_for_login_to_do_recon_reversal_of_cashback_reversal_transaction() throws FileNotFoundException {
        System.out.println("Admin has a valid cred for login to do recon reversal of cashback reversal transaction");
        adminAccessToken = adminLogin(reader.getValueFromConfig("wallet.recon.reversal.admin.email"),reader.getValueFromConfig("wallet.recon.reversal.admin.password"));

    }
    @Given("Admin enter transaction details for recon reversal of cashback reversal transaction")
    public void admin_enter_transaction_details_for_recon_reversal_of_cashback_reversal_transaction() throws SQLException {
        System.out.println("Admin enter transaction details for recon reversal of cashback reversal transaction");
        transactionType = String.valueOf(TransTypeEnum.CASHBACK_REVERSAL);
        transactions = getReconReversalData(transactionType); // calling method to fetch recon data
        if(transactions.size()==0){
            System.out.println("There is no transaction!!!!");
        }
    }
    @Given("Admin click recon reversal api to do recon reversal of cashback reversal transaction")
    public void admin_click_recon_reversal_api_to_do_recon_reversal_of_cashback_reversal_transaction() throws FileNotFoundException {
        System.out.println("Admin click recon reversal api to do recon reversal of cashback reversal transaction");
        res = reconReversal(adminAccessToken,transactions); // calling method for recon reversal
    }
    @Then("Verify recon reversal status of cashback reversal transaction")
    public void verify_recon_reversal_status_of_cashback_reversal_transaction() throws FileNotFoundException {
        System.out.println("Verify recon reversal status of cashback reversal transaction");
        if(res.getStatusCode()!=HTTP_OK){
            errorValidationOfTM(res,payee,payer); // calling method for tm error validation
        }
        else {
            successReconReversalValidation(res,transactions,transactionType); //calling method to validate transaction
        }
    }

    // ************************* Recon Reversal for cash loading Transaction *****************************
    @Given("Admin has a valid cred for login to do recon reversal of cash loading transaction")
    public void admin_has_a_valid_cred_for_login_to_do_recon_reversal_of_cash_loading_transaction() throws FileNotFoundException {
        System.out.println("Admin has a valid cred for login to do recon reversal of cash loading transaction");
        adminAccessToken = adminLogin(reader.getValueFromConfig("wallet.recon.reversal.admin.email"),reader.getValueFromConfig("wallet.recon.reversal.admin.password"));

    }
    @Given("Admin enter transaction details for recon reversal of cash loading transaction")
    public void admin_enter_transaction_details_for_recon_reversal_of_cash_loading_transaction() throws SQLException {
        System.out.println("Admin enter transaction details for recon reversal of cash loading transaction");
        transactionType = String.valueOf(TransTypeEnum.CASH_TO_WALLET);
        transactions = getReconReversalData(transactionType); // calling method to fetch recon data
        System.out.println(transactions);
        if(transactions.size()==0){
            System.out.println("There is no transaction!!!!");
        }
    }
    @Given("Admin click recon reversal api to do recon reversal of cash loading transaction")
    public void admin_click_recon_reversal_api_to_do_recon_reversal_of_cash_loading_transaction() throws FileNotFoundException {
        System.out.println("Admin click recon reversal api to do recon reversal of cash loading transaction");
        res = reconReversal(adminAccessToken,transactions); // calling method for recon reversal
    }
    @Then("Verify recon reversal status of cash loading transaction")
    public void verify_recon_reversal_status_of_cash_loading_transaction() throws FileNotFoundException {
        System.out.println("Verify recon reversal status of cash loading transaction");
        if(res.getStatusCode()!=HTTP_OK){
            errorValidationOfTM(res,payee,payer); // calling method for tm error validation
        }
        else {
            successReconReversalValidation(res,transactions,transactionType); //calling method to validate transaction
        }

    }

}
