package stepdef.Wallet.tm;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.restassured.response.Response;
import org.json.JSONObject;
import resources.Payee;
import resources.Payer;
import utilities.PropertyReader;

import java.io.FileNotFoundException;

import static utilities.CommonStepDef.*;
import static utilities.CommonStepDef.addBeneficiary;
import static utilities.GlobalConstant.HTTP_CREATED;
import static utilities.GlobalConstant.HTTP_OK;
import static utilities.Utils.*;
import static utilities.Utils.getEncryptedAuthData;

public class AddBeneficiary {
    private static Response res;
    private static String payerAccessToken;
    private static JSONObject responseObject;
    private static PropertyReader reader = new PropertyReader();
    private static Payee payee = new Payee();
    private static Payer payer = new Payer();


    // ************************* Add beneficiary for invalid bank name *****************************
    @Given("User login with valid cred for add beneficiary for invalid bank name")
    public void user_login_with_valid_cred_for_add_beneficiary_for_invalid_bank_name() throws FileNotFoundException {
        System.out.println("User login with valid cred for add beneficiary for invalid bank name");
        res = login(reader.getValueFromConfig("wallet.test.user2.mobile.number"),reader.getValueFromConfig("wallet.test.user2.passcode"),reader.getValueFromConfig("wallet.test.user2.device.id"),reader.getValueFromConfig("wallet.test.user2.device.id"));
        payerAccessToken = getAccessTokenResponseData(res,"access_token");
    }
    @Given("User enter {string} and {string} for add beneficiary for invalid bank name")
    public void user_enter_and_for_add_beneficiary_for_invalid_bank_name(String bankType, String bankName) throws FileNotFoundException {
        System.out.println("On entering bankType -> "+bankType+" and bankName -> "+bankName+" for add beneficiary for invalid bank name");
        String ifsc = reader.getValueFromConfig("wallet.ifsc.code");
        res = verifyIFSCCode(ifsc,payerAccessToken); // calling method for verifying ifsc code
        if(res.getStatusCode()!= HTTP_OK){
            errorValidationOfTM(res,payee,payer);
        }
        else{
            responseObject = extractJsonObjectFromResponse(res);  // extracting data from response
            assertJsonValueEquals("message","global ifsc to elastic search",responseObject);
            payee.setIfsc(ifsc);
        }
        if(bankName.equalsIgnoreCase("empty")){
            payee.setBankName(" ");
        }
        else if(bankName.equalsIgnoreCase("null")){
            payee.setBankName(null);
        }
        else {
            payee.setBankName(bankName);
        }
        payee.setReceiverName(reader.getValueFromConfig("wallet.account.holder.name"));
        payee.setAccountNumber(getRandomAccountNumber()); //account number 9-18 digit
    }
    @Given("User click add beneficiary api for add beneficiary for invalid bank name")
    public void user_click_add_beneficiary_api_for_add_beneficiary_for_invalid_bank_name() throws FileNotFoundException {
        System.out.println("User click add beneficiary api for add beneficiary for invalid bank name");
        res = addBeneficiary(payee,getEncryptedAuthData(reader.getValueFromConfig("wallet.test.user2.passcode")),payerAccessToken);
    }
    @Then("Verify add beneficiary status for invalid bank name")
    public void verify_add_beneficiary_status_for_invalid_bank_name() throws FileNotFoundException {
        System.out.println("Verify add beneficiary status for invalid bank name");
        errorValidationOfTM(res,payee,payer); // calling method for error validation
    }

    // ************************* Add beneficiary for valid bank name *****************************
    @Given("User login with valid cred to add beneficiary for valid bank name")
    public void user_login_with_valid_cred_for_add_beneficiary_for_valid_bank_name() throws FileNotFoundException {
        System.out.println("User login with valid cred for add beneficiary for invalid bank name");
        res = login(reader.getValueFromConfig("wallet.test.user2.mobile.number"),reader.getValueFromConfig("wallet.test.user2.passcode"),reader.getValueFromConfig("wallet.test.user2.device.id"),reader.getValueFromConfig("wallet.test.user2.device.id"));
        payerAccessToken = getAccessTokenResponseData(res,"access_token");
    }
    @Given("User enter bank name and other details to add beneficiary for valid bank name")
    public void user_enter_and_for_add_beneficiary_for_valid_bank_name() throws FileNotFoundException {
        System.out.println("User enter bank name and other details to add beneficiary for valid bank name");
        String ifsc = reader.getValueFromConfig("wallet.ifsc.code");
        res = verifyIFSCCode(ifsc,payerAccessToken); // calling method for verifying ifsc code
        if(res.getStatusCode()!= HTTP_OK){
            errorValidationOfTM(res,payee,payer);
        }
        else{
            responseObject = extractJsonObjectFromResponse(res);  // extracting data from response
            assertJsonValueEquals("message","global ifsc to elastic search",responseObject);
            payee.setIfsc(ifsc);
            String bankName1 = reader.getValueFromConfig("wallet.bank.name");  //extracting bank name from config
            JSONObject results = extractNestedJsonObject(responseObject,"results");
            JSONObject dataFromResponse = extractJsonValueFromJsonArray(results,"data",0);
            assertJsonValueEquals("bankName",bankName1,dataFromResponse); // verifying bank name
            payee.setBankName(bankName1); // setting bank name
            payee.setReceiverName(reader.getValueFromConfig("wallet.account.holder.name")); // setting receiver name
            payee.setAccountNumber(getRandomAccountNumber()); // setting account number 9-18 digit
        }

    }
    @Given("User click add beneficiary api to add beneficiary for valid bank name")
    public void user_click_add_beneficiary_api_for_add_beneficiary_for_valid_bank_name() throws FileNotFoundException {
        System.out.println("User click add beneficiary api to add beneficiary for valid bank name");
        res = addBeneficiary(payee,getEncryptedAuthData(reader.getValueFromConfig("wallet.test.user2.passcode")),payerAccessToken); // calling method to add beneficiary
    }
    @Then("Verify add beneficiary status for valid bank name")
    public void verify_add_beneficiary_status_for_valid_bank_name() throws FileNotFoundException {
        System.out.println("Verify add beneficiary status for valid bank name");
        if(res.getStatusCode()!=HTTP_CREATED){
            errorValidationOfTM(res,payee,payer);
        }
        else {
            System.out.println(res.asPrettyString());
            responseObject = extractJsonObjectFromResponse(res);
            jsonSchemaValidator(res,reader.getValueFromConfig("wallet.add.beneficiary.valid.schema"));
            assertJsonValueEquals("message","Beneficiary Added Successfully",responseObject);
        }
    }

    // ************************* Add beneficiary for invalid passcode *****************************
    @Given("User login with valid cred to add beneficiary for invalid passcode")
    public void user_login_with_valid_cred_to_add_beneficiary_for_invalid_passcode() throws FileNotFoundException {
        System.out.println("User login with valid cred to add beneficiary for invalid passcode");
        res = login(reader.getValueFromConfig("wallet.test.user2.mobile.number"),reader.getValueFromConfig("wallet.test.user2.passcode"),reader.getValueFromConfig("wallet.test.user2.device.id"),reader.getValueFromConfig("wallet.test.user2.device.id"));
        payerAccessToken = getAccessTokenResponseData(res,"access_token");
    }
    @Given("User enter {string} and {string} to add beneficiary for invalid passcode")
    public void user_enter_and_to_add_beneficiary_for_invalid_passcode(String passcodeType, String passcodeValue) throws FileNotFoundException {
        System.out.println("User enter passcodeType -> "+passcodeType+" and passcodeValue -> "+passcodeValue+" fo add beneficiary for invalid passcode");
        String ifsc = reader.getValueFromConfig("wallet.ifsc.code");
        res = verifyIFSCCode(ifsc,payerAccessToken); // verifying ifsc code
        if(res.getStatusCode()!= HTTP_OK){
            errorValidationOfTM(res,payee,payer);
        }
        else{
            responseObject = extractJsonObjectFromResponse(res);  // extracting data from response
            assertJsonValueEquals("message","global ifsc to elastic search",responseObject);
            payee.setIfsc(ifsc);
            String bankName = reader.getValueFromConfig("wallet.bank.name");  //extracting bank name from config
            JSONObject results = extractNestedJsonObject(responseObject,"results");
            JSONObject dataFromResponse = extractJsonValueFromJsonArray(results,"data",0);
            assertJsonValueEquals("bankName",bankName,dataFromResponse); // verifying bank name
            payee.setBankName(bankName);
        }
        if(passcodeValue.equalsIgnoreCase("empty")){
            payer.setPasscode(" ");
        }
        else if(passcodeValue.equalsIgnoreCase("null")){
            payer.setPasscode(null);
        }
        else {
            payer.setPasscode(passcodeValue);
        }
        payee.setReceiverName(reader.getValueFromConfig("wallet.account.holder.name"));
        payee.setAccountNumber(getRandomAccountNumber()); //account number 9-18 digit
    }
    @Given("User click add beneficiary api to add beneficiary for invalid passcode")
    public void user_click_add_beneficiary_api_to_add_beneficiary_for_invalid_passcode() throws FileNotFoundException {
        System.out.println("User click add beneficiary api to add beneficiary for invalid passcode");
        res = addBeneficiary(payee,payer.getPasscode(),payerAccessToken);
    }
    @Then("Verify add beneficiary status for invalid passcode")
    public void verify_add_beneficiary_status_for_invalid_passcode() throws FileNotFoundException {
        System.out.println("Verify add beneficiary status for invalid passcode");
        errorValidationOfTM(res,payee,payer); // calling method for error validating
    }

    // ************************* Add beneficiary for valid passcode *****************************
    @Given("User login with valid cred to add beneficiary for valid passcode")
    public void user_login_with_valid_cred_to_add_beneficiary_for_valid_passcode() throws FileNotFoundException {
        System.out.println("User login with valid cred to add beneficiary for invalid passcode");
        res = login(reader.getValueFromConfig("wallet.test.user2.mobile.number"),reader.getValueFromConfig("wallet.test.user2.passcode"),reader.getValueFromConfig("wallet.test.user2.device.id"),reader.getValueFromConfig("wallet.test.user2.device.id"));
        payerAccessToken = getAccessTokenResponseData(res,"access_token");
    }
    @Given("User enter passcode and other details to add beneficiary for valid passcode")
    public void user_enter_and_to_add_beneficiary_for_valid_passcode() throws FileNotFoundException {
        System.out.println("User enter passcode and other details to add beneficiary for valid passcode");
        String ifsc = reader.getValueFromConfig("wallet.ifsc.code");
        res = verifyIFSCCode(ifsc,payerAccessToken); // verifying ifsc code
        if(res.getStatusCode()!= HTTP_OK){
            errorValidationOfTM(res,payee,payer);
        }
        else{
            responseObject = extractJsonObjectFromResponse(res);  // extracting data from response
            assertJsonValueEquals("message","global ifsc to elastic search",responseObject);
            payee.setIfsc(ifsc);
            String bankName = reader.getValueFromConfig("wallet.bank.name");  //extracting bank name from config
            JSONObject results = extractNestedJsonObject(responseObject,"results");
            JSONObject dataFromResponse = extractJsonValueFromJsonArray(results,"data",0);
            assertJsonValueEquals("bankName",bankName,dataFromResponse); // verifying bank name
            payee.setBankName(bankName);
        }
        payer.setPasscode(getEncryptedAuthData(reader.getValueFromConfig("wallet.test.user2.passcode"))); // setting passcode
        payee.setReceiverName(reader.getValueFromConfig("wallet.account.holder.name"));
        payee.setAccountNumber(getRandomAccountNumber()); //account number 9-18 digit
    }
    @Given("User click add beneficiary api to add beneficiary for valid passcode")
    public void user_click_add_beneficiary_api_to_add_beneficiary_for_valid_passcode() throws FileNotFoundException {
        System.out.println("User click add beneficiary api to add beneficiary for valid passcode");
        res = addBeneficiary(payee,payer.getPasscode(),payerAccessToken);
    }
    @Then("Verify add beneficiary status for valid passcode")
    public void verify_add_beneficiary_status_for_valid_passcode() throws FileNotFoundException {
        System.out.println("Verify add beneficiary status for valid passcode");
        if(res.getStatusCode()!=HTTP_CREATED){
            errorValidationOfTM(res,payee,payer);
        }
        else {
            System.out.println(res.asPrettyString());
            responseObject = extractJsonObjectFromResponse(res);
            jsonSchemaValidator(res,reader.getValueFromConfig("wallet.add.beneficiary.valid.schema"));
            assertJsonValueEquals("message","Beneficiary Added Successfully",responseObject);
        }
    }


    // ************************* Add beneficiary for invalid account number *****************************
    @Given("User login with valid cred to add beneficiary for invalid account number")
    public void user_login_with_valid_cred_to_add_beneficiary_for_invalid_account_number() throws FileNotFoundException {
        System.out.println("User login with valid cred to add beneficiary for invalid account number");
        res = login(reader.getValueFromConfig("wallet.test.user2.mobile.number"),reader.getValueFromConfig("wallet.test.user2.passcode"),reader.getValueFromConfig("wallet.test.user2.device.id"),reader.getValueFromConfig("wallet.test.user2.device.id"));
        payerAccessToken = getAccessTokenResponseData(res,"access_token");
    }
    @Given("User enter {string} and {string} to add beneficiary for invalid account number")
    public void user_enter_and_to_add_beneficiary_for_invalid_account_number(String accountNumber, String accountNumberValue) throws FileNotFoundException {
        System.out.println("User enter accountNumber -> "+accountNumber+" and passcodeValue -> "+accountNumberValue+" to add beneficiary for invalid account number");
        String ifsc = reader.getValueFromConfig("wallet.ifsc.code");
        res = verifyIFSCCode(ifsc,payerAccessToken); // verifying ifsc code
        if(res.getStatusCode()!= HTTP_OK){
            errorValidationOfTM(res,payee,payer);
        }
        else{
            responseObject = extractJsonObjectFromResponse(res);  // extracting data from response
            assertJsonValueEquals("message","global ifsc to elastic search",responseObject);
            payee.setIfsc(ifsc);
            String bankName = reader.getValueFromConfig("wallet.bank.name");  //extracting bank name from response
            JSONObject results = extractNestedJsonObject(responseObject,"results");
            JSONObject dataFromResponse = extractJsonValueFromJsonArray(results,"data",0);
            assertJsonValueEquals("bankName",bankName,dataFromResponse); // verifying bank name
            payee.setBankName(bankName);
        }
        if(accountNumberValue.equalsIgnoreCase("empty")){
            payee.setAccountNumber(" ");
        }
        else if(accountNumberValue.equalsIgnoreCase("null")){
            payee.setAccountNumber(null);
        }
        else {
            payee.setAccountNumber(accountNumberValue);
        }
        payee.setReceiverName(reader.getValueFromConfig("wallet.account.holder.name"));
        payer.setPasscode(getEncryptedAuthData(reader.getValueFromConfig("wallet.test.user2.passcode")));
    }
    @Given("User click add beneficiary api to add beneficiary for invalid account number")
    public void user_click_add_beneficiary_api_to_add_beneficiary_for_invalid_account_number() throws FileNotFoundException {
        System.out.println("User click add beneficiary api to add beneficiary for invalid account number");
        res = addBeneficiary(payee,payer.getPasscode(),payerAccessToken); // calling method to add beneficiary
    }
    @Then("Verify add beneficiary status for invalid account number")
    public void verify_add_beneficiary_status_for_invalid_account_number() throws FileNotFoundException {
        System.out.println("Verify add beneficiary status for invalid account number");
        errorValidationOfTM(res,payee,payer); // calling method for error validation
    }

    // ************************* Add beneficiary for valid account number *****************************
    @Given("User login with valid cred to add beneficiary for valid account number")
    public void user_login_with_valid_cred_to_add_beneficiary_for_valid_account_number() throws FileNotFoundException {
        System.out.println("User login with valid cred to add beneficiary for valid account number");
        res = login(reader.getValueFromConfig("wallet.test.user2.mobile.number"),reader.getValueFromConfig("wallet.test.user2.passcode"),reader.getValueFromConfig("wallet.test.user2.device.id"),reader.getValueFromConfig("wallet.test.user2.device.id"));
        payerAccessToken = getAccessTokenResponseData(res,"access_token");
    }
    @Given("User enter account number and other details to add beneficiary for valid account number")
    public void user_enter_and_to_add_beneficiary_for_valid_account_number() throws FileNotFoundException {
        System.out.println("User enter account number and other details to add beneficiary for valid account number");
        String ifsc = reader.getValueFromConfig("wallet.ifsc.code");
        res = verifyIFSCCode(ifsc,payerAccessToken); // verifying ifsc code
        if(res.getStatusCode()!= HTTP_OK){
            errorValidationOfTM(res,payee,payer);
        }
        else{
            responseObject = extractJsonObjectFromResponse(res);  // extracting data from response
            assertJsonValueEquals("message","global ifsc to elastic search",responseObject);
            payee.setIfsc(ifsc);
            String bankName = reader.getValueFromConfig("wallet.bank.name");  //extracting bank name from response
            JSONObject results = extractNestedJsonObject(responseObject,"results");
            JSONObject dataFromResponse = extractJsonValueFromJsonArray(results,"data",0);
            assertJsonValueEquals("bankName",bankName,dataFromResponse); // verifying bank name
            payee.setBankName(bankName);
        }
        payee.setAccountNumber(getRandomAccountNumber()); //setting account number 9-18 digit
        payee.setReceiverName(reader.getValueFromConfig("wallet.account.holder.name"));
        payer.setPasscode(getEncryptedAuthData(reader.getValueFromConfig("wallet.test.user2.passcode")));
    }
    @Given("User click add beneficiary api to add beneficiary for valid account number")
    public void user_click_add_beneficiary_api_to_add_beneficiary_for_valid_account_number() throws FileNotFoundException {
        System.out.println("User click add beneficiary api to add beneficiary for valid account number");
        res = addBeneficiary(payee,payer.getPasscode(),payerAccessToken); // calling method to add beneficiary
    }
    @Then("Verify add beneficiary status for valid account number")
    public void verify_add_beneficiary_status_for_valid_account_number() throws FileNotFoundException {
        System.out.println("Verify add beneficiary status for valid account number");
        if(res.getStatusCode()!=HTTP_CREATED){
            errorValidationOfTM(res,payee,payer); // calling method for error validation
        }
        else {
            System.out.println(res.asPrettyString());
            responseObject = extractJsonObjectFromResponse(res);
            jsonSchemaValidator(res,reader.getValueFromConfig("wallet.add.beneficiary.valid.schema"));
            assertJsonValueEquals("message","Beneficiary Added Successfully",responseObject);
        }
    }


    // ************************* Add beneficiary for invalid ifsc code *****************************
    @Given("User login with valid cred to add beneficiary for invalid ifsc code")
    public void user_login_with_valid_cred_to_add_beneficiary_for_invalid_ifsc_code() throws FileNotFoundException {
        System.out.println("User login with valid cred to add beneficiary for invalid ifsc code");
        res = login(reader.getValueFromConfig("wallet.test.user2.mobile.number"),reader.getValueFromConfig("wallet.test.user2.passcode"),reader.getValueFromConfig("wallet.test.user2.device.id"),reader.getValueFromConfig("wallet.test.user2.device.id"));
        payerAccessToken = getAccessTokenResponseData(res,"access_token");
    }
    @Given("User enter {string} and {string} to add beneficiary for invalid ifsc code")
    public void user_enter_and_to_add_beneficiary_for_invalid_ifsc_code(String ifscCodeType, String ifscCodeValue) throws FileNotFoundException {
        System.out.println("User enter ifscCodeType -> "+ifscCodeType+" and ifscCodeValue -> "+ifscCodeValue+" to add beneficiary for invalid ifsc code");
        if(ifscCodeValue.equalsIgnoreCase("empty")){
            payee.setIfsc(" ");
        }
        else if(ifscCodeValue.equalsIgnoreCase("null")){
            payee.setIfsc(null);
        }
        else {
            payee.setIfsc(ifscCodeValue);
        }
        payee.setBankName(reader.getValueFromConfig("wallet.bank.name"));
        payee.setReceiverName(reader.getValueFromConfig("wallet.account.holder.name"));
        payer.setPasscode(getEncryptedAuthData(reader.getValueFromConfig("wallet.test.user2.passcode")));
        payee.setAccountNumber(getRandomAccountNumber()); //account number 9-18 digit
    }
    @Given("User click add beneficiary api to add beneficiary for invalid ifsc code")
    public void user_click_add_beneficiary_api_to_add_beneficiary_for_invalid_ifsc_code() throws FileNotFoundException {
        System.out.println("User click add beneficiary api to add beneficiary for invalid ifsc code");
        res = addBeneficiary(payee,payer.getPasscode(),payerAccessToken);
    }
    @Then("Verify add beneficiary status for invalid ifsc code")
    public void verify_add_beneficiary_status_for_invalid_ifsc_code() throws FileNotFoundException {
        System.out.println("Verify add beneficiary status for invalid ifsc code");
        errorValidationOfTM(res,payee,payer); // calling method for error validation
    }

    // ************************* Add beneficiary for valid ifsc code *****************************
    @Given("User login with valid cred to add beneficiary for valid ifsc code")
    public void user_login_with_valid_cred_to_add_beneficiary_for_valid_ifsc_code() throws FileNotFoundException {
        System.out.println("User login with valid cred to add beneficiary for invalid ifsc code");
        res = login(reader.getValueFromConfig("wallet.test.user2.mobile.number"),reader.getValueFromConfig("wallet.test.user2.passcode"),reader.getValueFromConfig("wallet.test.user2.device.id"),reader.getValueFromConfig("wallet.test.user2.device.id"));
        payerAccessToken = getAccessTokenResponseData(res,"access_token");
    }
    @Given("User enter ifsc code and other details to add beneficiary for valid ifsc code")
    public void user_enter_and_to_add_beneficiary_for_valid_ifsc_code() throws FileNotFoundException {
        System.out.println("User enter ifsc code and other details to add beneficiary for valid ifsc code");
        String ifsc = reader.getValueFromConfig("wallet.ifsc.code");
        res = verifyIFSCCode(ifsc,payerAccessToken); // verifying ifsc code
        if(res.getStatusCode()!= HTTP_OK){
            errorValidationOfTM(res,payee,payer);
        }
        else{
            responseObject = extractJsonObjectFromResponse(res);  // extracting data from response
            assertJsonValueEquals("message","global ifsc to elastic search",responseObject);
            payee.setIfsc(ifsc);
            String bankName = reader.getValueFromConfig("wallet.bank.name");  //extracting bank name from response
            JSONObject results = extractNestedJsonObject(responseObject,"results");
            JSONObject dataFromResponse = extractJsonValueFromJsonArray(results,"data",0);
            assertJsonValueEquals("bankName",bankName,dataFromResponse); // verifying bank name
            payee.setBankName(bankName);
        }
        payee.setReceiverName(reader.getValueFromConfig("wallet.account.holder.name"));
        payer.setPasscode(getEncryptedAuthData(reader.getValueFromConfig("wallet.test.user2.passcode")));
        payee.setAccountNumber(getRandomAccountNumber()); //account number 9-18 digit
    }
    @Given("User click add beneficiary api to add beneficiary for valid ifsc code")
    public void user_click_add_beneficiary_api_to_add_beneficiary_for_valid_ifsc_code() throws FileNotFoundException {
        System.out.println("User click add beneficiary api to add beneficiary for valid ifsc code");
        res = addBeneficiary(payee,payer.getPasscode(),payerAccessToken);
    }
    @Then("Verify add beneficiary status for valid ifsc code")
    public void verify_add_beneficiary_status_for_valid_ifsc_code() throws FileNotFoundException {
        System.out.println("Verify add beneficiary status for valid ifsc code");
        if(res.getStatusCode()!=HTTP_CREATED){
            errorValidationOfTM(res,payee,payer); // calling method for error validation
        }
        else {
            System.out.println(res.asPrettyString());
            responseObject = extractJsonObjectFromResponse(res);
            jsonSchemaValidator(res,reader.getValueFromConfig("wallet.add.beneficiary.valid.schema"));
            assertJsonValueEquals("message","Beneficiary Added Successfully",responseObject);
        }
    }

    // ************************* Add beneficiary for invalid account holder name *****************************
    @Given("User login with valid cred to add beneficiary for invalid account holder name")
    public void user_login_with_valid_cred_to_add_beneficiary_for_invalid_account_holder_name() throws FileNotFoundException {
        System.out.println("User login with valid cred to add beneficiary for invalid account holder name");
        res = login(reader.getValueFromConfig("wallet.test.user2.mobile.number"),reader.getValueFromConfig("wallet.test.user2.passcode"),reader.getValueFromConfig("wallet.test.user2.device.id"),reader.getValueFromConfig("wallet.test.user2.device.id"));
        payerAccessToken = getAccessTokenResponseData(res,"access_token");
    }
    @Given("User enter {string} and {string} to add beneficiary for invalid account holder name")
    public void user_enter_and_to_add_beneficiary_for_invalid_account_holder_name(String accountHolderNameType, String accountHolderNameValue) throws FileNotFoundException {
        System.out.println("On entering accountHolderNameType -> "+accountHolderNameType+" and accountHolderNameValue -> "+accountHolderNameValue+" for add beneficiary - account holder name");
        String ifsc = reader.getValueFromConfig("wallet.ifsc.code");
        res = verifyIFSCCode(ifsc,payerAccessToken); // verifying ifsc code
        if(res.getStatusCode()!= HTTP_OK){
            errorValidationOfTM(res,payee,payer);
        }
        else{
            responseObject = extractJsonObjectFromResponse(res);  // extracting data from response
            assertJsonValueEquals("message","global ifsc to elastic search",responseObject);
            payee.setIfsc(ifsc);
            String bankName = reader.getValueFromConfig("wallet.bank.name");  //extracting bank name from response
            JSONObject results = extractNestedJsonObject(responseObject,"results");
            JSONObject dataFromResponse = extractJsonValueFromJsonArray(results,"data",0);
            assertJsonValueEquals("bankName",bankName,dataFromResponse); // verifying bank name
            payee.setBankName(bankName);
        }
        if(accountHolderNameValue.equalsIgnoreCase("empty")){
            payee.setReceiverName(" ");
        }
        else if(accountHolderNameValue.equalsIgnoreCase("null")){
            payee.setReceiverName(null);
        }
        else {
            payee.setReceiverName(accountHolderNameValue);
        }
        payee.setAccountNumber(getRandomAccountNumber()); //account number 9-18 digit
        payer.setPasscode(getEncryptedAuthData(reader.getValueFromConfig("wallet.test.user2.passcode")));
    }
    @Given("User click add beneficiary api to add beneficiary for invalid account holder name")
    public void user_click_add_beneficiary_api_to_add_beneficiary_for_invalid_account_holder_name() throws FileNotFoundException {
        System.out.println("User click add beneficiary api to add beneficiary for invalid account holder name");
        res = addBeneficiary(payee,payer.getPasscode(),payerAccessToken);
    }
    @Then("Verify add beneficiary status for invalid account holder name")
    public void verify_add_beneficiary_status_for_invalid_account_holder_name() throws FileNotFoundException {
        System.out.println("Verify add beneficiary status for invalid account holder name");
        errorValidationOfTM(res,payee,payer); // calling method for error handling
    }

    // ************************* Add beneficiary for valid account holder name *****************************
    @Given("User login with valid cred to add beneficiary for valid account holder name")
    public void user_login_with_valid_cred_to_add_beneficiary_for_valid_account_holder_name() throws FileNotFoundException {
        System.out.println("User login with valid cred to add beneficiary for invalid account holder name");
        res = login(reader.getValueFromConfig("wallet.test.user2.mobile.number"),reader.getValueFromConfig("wallet.test.user2.passcode"),reader.getValueFromConfig("wallet.test.user2.device.id"),reader.getValueFromConfig("wallet.test.user2.device.id"));
        payerAccessToken = getAccessTokenResponseData(res,"access_token");
    }
    @Given("User enter account holder name and other details to add beneficiary for valid account holder name")
    public void user_enter_and_to_add_beneficiary_for_valid_account_holder_name() throws FileNotFoundException {
        System.out.println("User enter account holder name and other details to add beneficiary for valid account holder name");
        String ifsc = reader.getValueFromConfig("wallet.ifsc.code");
        res = verifyIFSCCode(ifsc,payerAccessToken); // verifying ifsc code
        if(res.getStatusCode()!= HTTP_OK){
            errorValidationOfTM(res,payee,payer);
        }
        else{
            responseObject = extractJsonObjectFromResponse(res);  // extracting data from response
            assertJsonValueEquals("message","global ifsc to elastic search",responseObject);
            payee.setIfsc(ifsc);
            String bankName = reader.getValueFromConfig("wallet.bank.name");  //extracting bank name from response
            JSONObject results = extractNestedJsonObject(responseObject,"results");
            JSONObject dataFromResponse = extractJsonValueFromJsonArray(results,"data",0);
            assertJsonValueEquals("bankName",bankName,dataFromResponse); // verifying bank name
            payee.setBankName(bankName);
        }
        payee.setReceiverName(reader.getValueFromConfig("wallet.account.holder.name"));
        payee.setAccountNumber(getRandomAccountNumber()); //account number 9-18 digit
        payer.setPasscode(getEncryptedAuthData(reader.getValueFromConfig("wallet.test.user2.passcode")));
    }
    @Given("User click add beneficiary api to add beneficiary for valid account holder name")
    public void user_click_add_beneficiary_api_to_add_beneficiary_for_valid_account_holder_name() throws FileNotFoundException {
        System.out.println("User click add beneficiary api to add beneficiary for valid account holder name");
        res = addBeneficiary(payee,payer.getPasscode(),payerAccessToken);
    }
    @Then("Verify add beneficiary status for valid account holder name")
    public void verify_add_beneficiary_status_for_valid_account_holder_name() throws FileNotFoundException {
        System.out.println("Verify add beneficiary status for valid account holder name");
        if(res.getStatusCode()!=HTTP_CREATED){
            errorValidationOfTM(res,payee,payer);
        }
        else {
            System.out.println(res.asPrettyString());
            responseObject = extractJsonObjectFromResponse(res);
            jsonSchemaValidator(res,reader.getValueFromConfig("wallet.add.beneficiary.valid.schema"));
            assertJsonValueEquals("message","Beneficiary Added Successfully",responseObject);
        }
    }
}

