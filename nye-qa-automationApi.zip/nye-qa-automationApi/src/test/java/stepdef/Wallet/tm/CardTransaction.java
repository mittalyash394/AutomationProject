package stepdef.Wallet.tm;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.restassured.response.Response;
import org.json.JSONObject;
import org.junit.Assert;
import resources.Card;
import resources.Payer;
import resources.TransTypeEnum;
import utilities.PropertyReader;

import java.io.FileNotFoundException;
import java.sql.SQLException;

import static utilities.CommonStepDef.*;
import static utilities.GlobalConstant.HTTP_OK;
import static utilities.Utils.*;

public class CardTransaction {
    private static Response res;
    private static String payerAccessToken;
    private static JSONObject responseObject;
    private static Double balance;
    private static String transactionHeaderId;
    private static PropertyReader reader = new PropertyReader();
    private static Card card = new Card();
    private static Payer payer = new Payer();

    // ************************* Card Transaction (Sanity)  *****************************
    @Given("User login with valid cred to do card transaction")
    public void user_login_with_valid_cred_to_do_card_transaction() throws FileNotFoundException {
        System.out.println("User login with valid cred to do card transaction");
        res = login(reader.getValueFromConfig("wallet.test.user2.mobile.number"),reader.getValueFromConfig("wallet.test.user2.passcode"),reader.getValueFromConfig("wallet.test.user2.device.id"),reader.getValueFromConfig("wallet.test.user2.device.id"));
        payerAccessToken = getAccessTokenResponseData(res,"access_token");
        payer.setSenderAccountId(reader.getValueFromConfig("wallet.test.user2.mobile.number"));
    }
    @Given("User has a valid card details to do card transaction")
    public void user_has_a_valid_card_details_to_do_card_transaction() throws FileNotFoundException {
        System.out.println("User has a valid card details to do card transaction");
        balance = Double.valueOf(getWalletBalance(payerAccessToken)); // fetching payer wallet balance
        card.setWalletBalance(String.valueOf(balance));
        card.setCustomerId(reader.getValueFromConfig("wallet.card.customer.id")); // setting card customer id
        card.setCardToken(reader.getValueFromConfig("wallet.card.token")); // setting card token
    }
    @Given("User select merchant category to do card transaction")
    public void user_select_merchant_category_to_do_card_transaction() {
        System.out.println("User select merchant category to do card transaction");
        card.setMerchantCategoryCode(reader.getValueFromConfig("wallet.card.merchant.category.code")); // setting merchant category code
        card.setMerchantId(reader.getValueFromConfig("wallet.card.merchant.id"));  //setting merchant id
        card.setLocation(reader.getValueFromConfig("wallet.card.location")); // setting transaction platform
        card.setChannel(reader.getValueFromConfig("wallet.card.channel"));
        card.setTransactionType(String.valueOf(TransTypeEnum.CARD_PAYMENT));
    }
    @Given("User enter amount to do card transaction")
    public void user_enter_amount_to_do_card_transaction() {
        System.out.println("User enter amount to do card transaction");
        card.setTransactionAmount(String.valueOf(getRandomAmount())); // setting amount to do transaction
    }
    @Given("After entering card details user click send otp button to send otp to do card transaction")
    public void after_entering_card_details_user_click_send_otp_button_to_send_otp_to_do_card_transaction() throws FileNotFoundException {
        System.out.println("After entering card details user click send otp button to send otp to do card transaction");
        card.setTransactionId(generateRandomNumber()); //setting transaction id
        card.setOtp(generateRandomNumber()); // setting otp
        res = sendCardTransactionOtp(card,payerAccessToken); // calling method to send otp
        if(res.getStatusCode()!=HTTP_OK){
            cardTransactionErrorValidation(res,card);
        }
        else {
            jsonSchemaValidator(res,reader.getValueFromConfig("wallet.card.send.card.otp.success.valid.schema"));
            responseObject = extractJsonObjectFromResponse(res);
            assertJsonValueEquals("message","Success",responseObject);
        }
    }
    @Given("After entering correct otp user click pay button to do card transaction")
    public void after_entering_correct_otp_user_click_pay_button_to_do_card_transaction() throws FileNotFoundException {
        System.out.println("After entering correct otp user click pay button to do card transaction");
        card.setTransactionNumber(generateRandomNumber());
        res = payCard(card,payerAccessToken); // calling method for card transaction
        System.out.println(res.asPrettyString());
    }
    @Then("Verify card transaction status")
    public void verify_card_transaction_status() {
        System.out.println("Verify card transaction status");
        if(res.getStatusCode()!=HTTP_OK){
            card.setIsCardTransactionSuccess(false);
            cardTransactionErrorValidation(res,card); // calling method for card transaction error validation
        }
        else {
            transactionHeaderId = successCardTransactionValidation(res,card); // calling method to validate card transaction from response
            card.setIsCardTransactionSuccess(true);
            card.setTransactionHeaderId(transactionHeaderId);
        }
    }
    @Then("Also verify card transaction status from db if transaction has been succeed")
    public void also_verify_card_transaction_status_from_db_if_transaction_has_been_succeed() throws SQLException {
        System.out.println("Also verify card transaction status from db if transaction has been succeed");
        if(card.getIsCardTransactionSuccess()){
            successCardTransactionValidationFromDB(payer,card); // calling method to validate card transaction from DB
        }
        else {
            System.out.println("Card Transaction failed");
        }
    }

    // ************************* Card Transaction for invalid amount  *****************************
    @Given("User login with valid cred to do card transaction for invalid amount")
    public void user_login_with_valid_cred_to_do_card_transaction_for_invalid_and_valid_amount() throws FileNotFoundException {
        System.out.println("User login with valid cred to do card transaction for invalid amount");
        res = login(reader.getValueFromConfig("wallet.test.user2.mobile.number"),reader.getValueFromConfig("wallet.test.user2.passcode"),reader.getValueFromConfig("wallet.test.user2.device.id"),reader.getValueFromConfig("wallet.test.user2.device.id"));
        payerAccessToken = getAccessTokenResponseData(res,"access_token");
        payer.setSenderAccountId(reader.getValueFromConfig("wallet.test.user2.mobile.number"));
    }
    @Given("User has a valid card details to do card transaction for invalid amount")
    public void user_has_a_valid_card_details_to_do_card_transaction_for_invalid_and_valid_amount() throws FileNotFoundException {
        System.out.println("User has a valid card details to do card transaction for invalid amount");
        balance = Double.valueOf(getWalletBalance(payerAccessToken)); // fetching payer wallet balance
        card.setWalletBalance(String.valueOf(balance));
        card.setCustomerId(reader.getValueFromConfig("wallet.card.customer.id")); // setting card customer id
        card.setCardToken(reader.getValueFromConfig("wallet.card.token")); // setting card token
    }
    @Given("User select merchant category to do card transaction for invalid amount")
    public void user_select_merchant_category_to_do_card_transaction_for_invalid_and_valid_amount() {
        System.out.println("User select merchant category to do card transaction for invalid amount");
        card.setMerchantCategoryCode(reader.getValueFromConfig("wallet.card.merchant.category.code")); // setting merchant category code
        card.setMerchantId(reader.getValueFromConfig("wallet.card.merchant.id"));  //setting merchant id
        card.setLocation(reader.getValueFromConfig("wallet.card.location")); // setting transaction platform
        card.setChannel(reader.getValueFromConfig("wallet.card.channel"));
        card.setTransactionType(String.valueOf(TransTypeEnum.CARD_PAYMENT));
    }
    @Given("User enter {string} and {string} to do card transaction for invalid amount")
    public void user_enter_and_to_do_card_transaction_for_invalid_and_valid_amount(String amountType, String amountValue) {
        System.out.println("User enter amountType -> "+amountType+" and amountValue -> "+amountValue+" to do card transaction for invalid amount");
         if(amountValue.equalsIgnoreCase("null")){
            card.setTransactionAmount(null);
        }
        else if(amountValue.equalsIgnoreCase("empty")){
            card.setTransactionAmount(" ");
        }
        else {
            card.setTransactionAmount(amountValue);
        }
    }
    @Given("After entering card details user click send otp button to send otp to do card transaction for invalid amount")
    public void after_entering_card_details_user_click_send_otp_button_to_send_otp_to_to_card_transaction_for_invalid_and_valid_amount() throws FileNotFoundException {
        System.out.println("After entering card details user click send otp button to send otp to to card transaction for invalid amount");
        card.setTransactionId(generateRandomNumber()); //setting transaction id
        card.setOtp(generateRandomNumber()); // setting otp
        res = sendCardTransactionOtp(card,payerAccessToken);
        if(res.getStatusCode()!=HTTP_OK){
            cardTransactionErrorValidation(res,card);
        }
        else {
            responseObject = extractJsonObjectFromResponse(res);
            assertJsonValueEquals("message","Success",responseObject);
        }

    }
    @Given("After entering correct otp user click pay button to do card transaction for invalid amount")
    public void after_entering_correct_otp_user_click_pay_button_to_to_card_transaction_for_invalid_and_valid_amount() throws FileNotFoundException {
        System.out.println("After entering correct otp user click pay button to to card transaction for invalid amount");
        card.setTransactionNumber(generateRandomNumber());
        res = payCard(card,payerAccessToken); // calling method for card transaction
        System.out.println(res.asPrettyString());
    }
    @Then("Verify card transaction status for invalid amount")
    public void verify_card_transaction_status_for_invalid_and_valid_amount() {
        System.out.println("Verify card transaction status for invalid amount");
        cardTransactionErrorValidation(res,card); // calling method for card transaction error validation
    }

    // ************************* Card Transaction for valid amount  *****************************
    @Given("User login with valid cred to do card transaction for valid amount")
    public void user_login_with_valid_cred_to_do_card_transaction_for_valid_and_valid_amount() throws FileNotFoundException {
        System.out.println("User login with valid cred to do card transaction for valid amount");
        res = login(reader.getValueFromConfig("wallet.test.user2.mobile.number"),reader.getValueFromConfig("wallet.test.user2.passcode"),reader.getValueFromConfig("wallet.test.user2.device.id"),reader.getValueFromConfig("wallet.test.user2.device.id"));
        payerAccessToken = getAccessTokenResponseData(res,"access_token");
        payer.setSenderAccountId(reader.getValueFromConfig("wallet.test.user2.mobile.number"));
    }
    @Given("User has a valid card details to do card transaction for valid amount")
    public void user_has_a_valid_card_details_to_do_card_transaction_for_valid_and_valid_amount() throws FileNotFoundException {
        System.out.println("User has a valid card details to do card transaction for valid amount");
        balance = Double.valueOf(getWalletBalance(payerAccessToken)); // fetching payer wallet balance
        card.setWalletBalance(String.valueOf(balance));
        card.setCustomerId(reader.getValueFromConfig("wallet.card.customer.id")); // setting card customer id
        card.setCardToken(reader.getValueFromConfig("wallet.card.token")); // setting card token
    }
    @Given("User select merchant category to do card transaction for valid amount")
    public void user_select_merchant_category_to_do_card_transaction_for_valid_and_valid_amount() {
        System.out.println("User select merchant category to do card transaction for valid amount");
        card.setMerchantCategoryCode(reader.getValueFromConfig("wallet.card.merchant.category.code")); // setting merchant category code
        card.setMerchantId(reader.getValueFromConfig("wallet.card.merchant.id"));  //setting merchant id
        card.setLocation(reader.getValueFromConfig("wallet.card.location")); // setting transaction platform
        card.setChannel(reader.getValueFromConfig("wallet.card.channel"));
        card.setTransactionType(String.valueOf(TransTypeEnum.CARD_PAYMENT));
    }
    @Given("User enter amount to do card transaction for valid amount")
    public void user_enter_and_to_do_card_transaction_for_valid_and_valid_amount() {
        System.out.println("User enter amount and other details to do card transaction for valid amount");
        card.setTransactionAmount(String.valueOf(getRandomAmount())); // setting amount to do transaction
    }
    @Given("After entering card details user click send otp button to send otp to do card transaction for valid amount")
    public void after_entering_card_details_user_click_send_otp_button_to_send_otp_to_to_card_transaction_for_valid_and_valid_amount() throws FileNotFoundException {
        System.out.println("After entering card details user click send otp button to send otp to to card transaction for valid amount");
        card.setTransactionId(generateRandomNumber()); //setting transaction id
        card.setOtp(generateRandomNumber()); // setting otp
        res = sendCardTransactionOtp(card,payerAccessToken);
        if(res.getStatusCode()!=HTTP_OK){
            cardTransactionErrorValidation(res,card);
        }
        else {
            responseObject = extractJsonObjectFromResponse(res);
            assertJsonValueEquals("message","Success",responseObject);
        }
    }
    @Given("After entering correct otp user click pay button to do card transaction for valid amount")
    public void after_entering_correct_otp_user_click_pay_button_to_to_card_transaction_for_valid_and_valid_amount() throws FileNotFoundException {
        System.out.println("After entering correct otp user click pay button to to card transaction for valid amount");
        card.setTransactionNumber(generateRandomNumber());
        res = payCard(card,payerAccessToken); // calling method for card transaction
    }
    @Then("Verify card transaction status for valid amount")
    public void verify_card_transaction_status_for_valid_and_valid_amount() {
        System.out.println("Verify card transaction status for invalid amount");
        if(res.getStatusCode()!=HTTP_OK){
            card.setIsCardTransactionSuccess(false);
            cardTransactionErrorValidation(res,card); // calling method for card transaction error validation
        }
        else {
            transactionHeaderId = successCardTransactionValidation(res,card); // calling method to validate card transaction from response
            card.setIsCardTransactionSuccess(true);
            card.setTransactionHeaderId(transactionHeaderId);
        }
    }
    @Then("Also verify card transaction status from db if transaction has been succeed for valid amount")
    public void also_verify_card_transaction_status_from_db_if_transaction_has_succeed_for_valid_and_valid_amount() throws SQLException {
        System.out.println("Also verify card transaction status from db if transaction has been succeed for valid amount");
        if(card.getIsCardTransactionSuccess()){
            successCardTransactionValidationFromDB(payer,card); // calling method to validate card transaction from DB
        }
        else {
            System.out.println("Transaction not verify from DB!!!!");
        }
    }

    // ************************* Card Transaction for invalid transaction id  *****************************
    @Given("User login with valid cred to do card transaction for invalid transaction id")
    public void user_login_with_valid_cred_to_do_card_transaction_for_invalid_and_valid_transaction_id() throws FileNotFoundException {
        System.out.println("User login with valid cred to do card transaction for invalid transaction id");
        res = login(reader.getValueFromConfig("wallet.test.user2.mobile.number"),reader.getValueFromConfig("wallet.test.user2.passcode"),reader.getValueFromConfig("wallet.test.user2.device.id"),reader.getValueFromConfig("wallet.test.user2.device.id"));
        payerAccessToken = getAccessTokenResponseData(res,"access_token");
        payer.setSenderAccountId(reader.getValueFromConfig("wallet.test.user2.mobile.number"));
    }
    @Given("User has a valid card details to do card transaction for invalid transaction id")
    public void user_has_a_valid_card_details_to_do_card_transaction_for_invalid_and_valid_transaction_id() throws FileNotFoundException {
        System.out.println("User has a valid card details to do card transaction for invalid transaction id");
        balance = Double.valueOf(getWalletBalance(payerAccessToken)); // fetching payer wallet balance
        card.setWalletBalance(String.valueOf(balance));
        card.setCustomerId(reader.getValueFromConfig("wallet.card.customer.id")); // setting card customer id
        card.setCardToken(reader.getValueFromConfig("wallet.card.token")); // setting card token
    }
    @Given("User select merchant category to do card transaction for invalid transaction id")
    public void user_select_merchant_category_to_do_card_transaction_for_invalid_and_valid_transaction_id() {
        System.out.println("User select merchant category to do card transaction for invalid transaction id");
        card.setMerchantCategoryCode(reader.getValueFromConfig("wallet.card.merchant.category.code")); // setting merchant category code
        card.setMerchantId(reader.getValueFromConfig("wallet.card.merchant.id"));  //setting merchant id
        card.setLocation(reader.getValueFromConfig("wallet.card.location")); // setting transaction platform
        card.setChannel(reader.getValueFromConfig("wallet.card.channel"));
        card.setTransactionType(String.valueOf(TransTypeEnum.CARD_PAYMENT));
    }
    @Given("User enter {string} and {string} to do card transaction for invalid transaction id")
    public void user_enter_and_to_do_card_transaction_for_invalid_and_valid_transaction_id(String transactionIdType, String transactionIdValue) {
        System.out.println("User enter transactionIdType -> "+transactionIdType+" and transactionIdValue -> "+transactionIdValue+" to do card transaction for invalid transaction id");
        if(transactionIdValue.equalsIgnoreCase("null")){
            card.setTransactionId(null);
        }
        else if(transactionIdValue.equalsIgnoreCase("empty")){
            card.setTransactionId(" ");
        }
        else {
            card.setTransactionId(transactionIdValue);;
        }
    }
    @Given("After entering card details user click send otp button to send otp to do card transaction for invalid transaction id")
    public void after_entering_card_details_user_click_send_otp_button_to_send_otp_to_to_card_transaction_for_invalid_and_valid_transaction_id() throws FileNotFoundException {
        System.out.println("After entering card details user click send otp button to send otp to to card transaction for invalid transaction id");
        card.setTransactionAmount(String.valueOf(getRandomAmount())); // setting amount to do transaction
        card.setOtp(generateRandomNumber()); // setting otp
        res = sendCardTransactionOtp(card,payerAccessToken); // calling method to send otp
        if(res.getStatusCode()!=HTTP_OK){
            cardTransactionErrorValidation(res,card);
        }
        else {
            responseObject = extractJsonObjectFromResponse(res);
            assertJsonValueEquals("message","Success",responseObject);
        }
    }
    @Given("After entering correct otp user click pay button to do card transaction for invalid transaction id")
    public void after_entering_correct_otp_user_click_pay_button_to_to_card_transaction_for_invalid_and_valid_transaction_id() throws FileNotFoundException {
        System.out.println("After entering correct otp user click pay button to to card transaction for invalid transaction id");
        card.setTransactionNumber(generateRandomNumber());
        res = payCard(card,payerAccessToken); // calling method for card transaction
    }
    @Then("Verify card transaction status for invalid transaction id")
    public void verify_card_transaction_status_for_invalid_and_valid_transaction_id() {
        System.out.println("Verify card transaction status for invalid and valid transaction id");
        cardTransactionErrorValidation(res,card); // calling method for card transaction error validation
    }

    // ************************* Card Transaction for valid transaction id  *****************************
    @Given("User login with valid cred to do card transaction for valid transaction id")
    public void user_login_with_valid_cred_to_do_card_transaction_for_valid_and_valid_transaction_id() throws FileNotFoundException {
        System.out.println("User login with valid cred to do card transaction for valid transaction id");
        res = login(reader.getValueFromConfig("wallet.test.user2.mobile.number"),reader.getValueFromConfig("wallet.test.user2.passcode"),reader.getValueFromConfig("wallet.test.user2.device.id"),reader.getValueFromConfig("wallet.test.user2.device.id"));
        payerAccessToken = getAccessTokenResponseData(res,"access_token");
        payer.setSenderAccountId(reader.getValueFromConfig("wallet.test.user2.mobile.number"));
    }
    @Given("User has a valid card details to do card transaction for valid transaction id")
    public void user_has_a_valid_card_details_to_do_card_transaction_for_valid_and_valid_transaction_id() throws FileNotFoundException {
        System.out.println("User has a valid card details to do card transaction for valid transaction id");
        balance = Double.valueOf(getWalletBalance(payerAccessToken)); // fetching payer wallet balance
        card.setWalletBalance(String.valueOf(balance));
        card.setCustomerId(reader.getValueFromConfig("wallet.card.customer.id")); // setting card customer id
        card.setCardToken(reader.getValueFromConfig("wallet.card.token")); // setting card token
    }
    @Given("User select merchant category to do card transaction for valid transaction id")
    public void user_select_merchant_category_to_do_card_transaction_for_valid_and_valid_transaction_id() {
        System.out.println("User select merchant category to do card transaction for valid transaction id");
        card.setMerchantCategoryCode(reader.getValueFromConfig("wallet.card.merchant.category.code")); // setting merchant category code
        card.setMerchantId(reader.getValueFromConfig("wallet.card.merchant.id"));  //setting merchant id
        card.setLocation(reader.getValueFromConfig("wallet.card.location")); // setting transaction platform
        card.setChannel(reader.getValueFromConfig("wallet.card.channel"));
        card.setTransactionType(String.valueOf(TransTypeEnum.CARD_PAYMENT));
    }
    @Given("User enter transaction id to do card transaction for valid transaction id")
    public void user_enter_and_to_do_card_transaction_for_valid_and_valid_transaction_id() {
        System.out.println("User enter transaction id to do card transaction for valid transaction id");
        card.setTransactionId(generateRandomNumber());
    }
    @Given("After entering card details user click send otp button to send otp to do card transaction for valid transaction id")
    public void after_entering_card_details_user_click_send_otp_button_to_send_otp_to_to_card_transaction_for_valid_and_valid_transaction_id() throws FileNotFoundException {
        System.out.println("After entering card details user click send otp button to send otp to to card transaction for valid transaction id");
        card.setTransactionAmount(String.valueOf(getRandomAmount())); // setting amount to do transaction
        card.setOtp(generateRandomNumber()); // setting otp
        res = sendCardTransactionOtp(card,payerAccessToken); // calling method to send otp
        if(res.getStatusCode()!=HTTP_OK){
            cardTransactionErrorValidation(res,card);
        }
        else {
            responseObject = extractJsonObjectFromResponse(res);
            assertJsonValueEquals("message","Success",responseObject);
        }
    }
    @Given("After entering correct otp user click pay button to do card transaction for valid transaction id")
    public void after_entering_correct_otp_user_click_pay_button_to_to_card_transaction_for_valid_and_valid_transaction_id() throws FileNotFoundException {
        System.out.println("After entering correct otp user click pay button to to card transaction for valid transaction id");
        card.setTransactionNumber(generateRandomNumber());
        res = payCard(card,payerAccessToken); // calling method for card transaction
    }
    @Then("Verify card transaction status for valid transaction id")
    public void verify_card_transaction_status_for_valid_and_valid_transaction_id() {
        System.out.println("Verify card transaction status for invalid and valid transaction id");
        if(res.getStatusCode()!=HTTP_OK){
            card.setIsCardTransactionSuccess(false);
            cardTransactionErrorValidation(res,card); // calling method for card transaction error validation
        }
        else {
            transactionHeaderId = successCardTransactionValidation(res,card); // calling method to validate card transaction from response
            card.setIsCardTransactionSuccess(true);
            card.setTransactionHeaderId(transactionHeaderId);
        }
    }
    @Then("Also verify card transaction status from db if transaction has been succeed for valid transaction id")
    public void also_verify_card_transaction_status_from_db_if_transaction_has_succeed_for_valid_and_valid_transaction_id() throws SQLException {
        System.out.println("Also verify card transaction status from db if transaction has succeed for valid transaction id");
        if(card.getIsCardTransactionSuccess()){
            successCardTransactionValidationFromDB(payer,card); // calling method to validate card transaction from DB
        }
        else {
            System.out.println("Transaction not verify from DB!!!!");
        }
    }

    // ************************* Card Transaction for invalid customer id  *****************************
    @Given("User login with valid cred to do card transaction for invalid customer id")
    public void user_login_with_valid_cred_to_do_card_transaction_for_invalid_and_valid_customer_id() throws FileNotFoundException {
        System.out.println("User login with valid cred to do card transaction for invalid customer id");
        res = login(reader.getValueFromConfig("wallet.test.user2.mobile.number"),reader.getValueFromConfig("wallet.test.user2.passcode"),reader.getValueFromConfig("wallet.test.user2.device.id"),reader.getValueFromConfig("wallet.test.user2.device.id"));
        payerAccessToken = getAccessTokenResponseData(res,"access_token");
        payer.setSenderAccountId(reader.getValueFromConfig("wallet.test.user2.mobile.number"));

    }
    @Given("User has a valid card details to do card transaction for invalid customer id")
    public void user_has_a_valid_card_details_to_do_card_transaction_for_invalid_and_valid_customer_id() throws FileNotFoundException {
        System.out.println("User has a valid card details to do card transaction for invalid customer id");
        balance = Double.valueOf(getWalletBalance(payerAccessToken)); // fetching payer wallet balance
        card.setWalletBalance(String.valueOf(balance));
        card.setCardToken(reader.getValueFromConfig("wallet.card.token")); // setting card token
    }
    @Given("User select merchant category to do card transaction for invalid customer id")
    public void user_select_merchant_category_to_do_card_transaction_for_invalid_and_valid_customer_id() {
        System.out.println("User select merchant category to do card transaction for invalid customer id");
        card.setMerchantCategoryCode(reader.getValueFromConfig("wallet.card.merchant.category.code")); // setting merchant category code
        card.setMerchantId(reader.getValueFromConfig("wallet.card.merchant.id"));  //setting merchant id
        card.setLocation(reader.getValueFromConfig("wallet.card.location")); // setting transaction platform
        card.setChannel(reader.getValueFromConfig("wallet.card.channel"));
        card.setTransactionType(String.valueOf(TransTypeEnum.CARD_PAYMENT));

    }
    @Given("User enter {string} and {string} to do card transaction for invalid customer id")
    public void user_enter_and_to_do_card_transaction_for_invalid_and_valid_customer_id(String customerIdType, String customerIdValue) {
        System.out.println("User enter customerIdType -> "+customerIdType+" and customerIdValue -> "+customerIdValue+" to do card transaction for invalid customer id");
        if(customerIdValue.equalsIgnoreCase("null")){
            card.setCustomerId(null);
        }
        else if(customerIdValue.equalsIgnoreCase("empty")){
            card.setCustomerId(" ");
        }
        else {
            card.setCustomerId(customerIdValue);
        }
    }
    @Given("After entering card details user click send otp button to send otp to do card transaction for invalid customer id")
    public void after_entering_card_details_user_click_send_otp_button_to_send_otp_to_to_card_transaction_for_invalid_and_valid_customer_id() throws FileNotFoundException {
        System.out.println("After entering card details user click send otp button to send otp to to card transaction for invalid customer id");
        card.setTransactionAmount(String.valueOf(getRandomAmount())); // setting amount to do transaction
        card.setTransactionId(generateRandomNumber()); //setting transaction id
        card.setOtp(generateRandomNumber()); // setting otp
        res = sendCardTransactionOtp(card,payerAccessToken);
        if(res.getStatusCode()!=HTTP_OK){
            cardTransactionErrorValidation(res,card);
        }
        else {
            responseObject = extractJsonObjectFromResponse(res);
            assertJsonValueEquals("message","Success",responseObject);
        }
    }
    @Given("After entering correct otp user click pay button to do card transaction for invalid customer id")
    public void after_entering_correct_otp_user_click_pay_button_to_to_card_transaction_for_invalid_and_valid_customer_id() throws FileNotFoundException {
        System.out.println("After entering correct otp user click pay button to to card transaction for invalid customer id");
        card.setTransactionNumber(generateRandomNumber());
        res = payCard(card,payerAccessToken); // calling method for card transaction
    }
    @Then("Verify card transaction status for invalid customer id")
    public void verify_card_transaction_status_for_invalid_and_valid_customer_id() {
        System.out.println("Verify card transaction status for invalid customer id");
        cardTransactionErrorValidation(res,card); // calling method for card transaction error validation
    }

    // ************************* Card Transaction for valid customer id  *****************************
    @Given("User login with valid cred to do card transaction for valid customer id")
    public void user_login_with_valid_cred_to_do_card_transaction_for_valid_and_valid_customer_id() throws FileNotFoundException {
        System.out.println("User login with valid cred to do card transaction for valid customer id");
        res = login(reader.getValueFromConfig("wallet.test.user2.mobile.number"),reader.getValueFromConfig("wallet.test.user2.passcode"),reader.getValueFromConfig("wallet.test.user2.device.id"),reader.getValueFromConfig("wallet.test.user2.device.id"));
        payerAccessToken = getAccessTokenResponseData(res,"access_token");
        payer.setSenderAccountId(reader.getValueFromConfig("wallet.test.user2.mobile.number"));

    }
    @Given("User has a valid card details to do card transaction for valid customer id")
    public void user_has_a_valid_card_details_to_do_card_transaction_for_valid_and_valid_customer_id() throws FileNotFoundException {
        System.out.println("User has a valid card details to do card transaction for valid customer id");
        balance = Double.valueOf(getWalletBalance(payerAccessToken)); // fetching payer wallet balance
        card.setWalletBalance(String.valueOf(balance));
        card.setCardToken(reader.getValueFromConfig("wallet.card.token")); // setting card token
    }
    @Given("User select merchant category to do card transaction for valid customer id")
    public void user_select_merchant_category_to_do_card_transaction_for_valid_and_valid_customer_id() {
        System.out.println("User select merchant category to do card transaction for valid customer id");
        card.setMerchantCategoryCode(reader.getValueFromConfig("wallet.card.merchant.category.code")); // setting merchant category code
        card.setMerchantId(reader.getValueFromConfig("wallet.card.merchant.id"));  //setting merchant id
        card.setLocation(reader.getValueFromConfig("wallet.card.location")); // setting transaction platform
        card.setChannel(reader.getValueFromConfig("wallet.card.channel"));
        card.setTransactionType(String.valueOf(TransTypeEnum.CARD_PAYMENT));

    }
    @Given("User enter customer id to do card transaction for valid customer id")
    public void user_enter_and_to_do_card_transaction_for_valid_and_valid_customer_id() {
        System.out.println("User enter customer id to do card transaction for valid customer id");
        card.setCustomerId(reader.getValueFromConfig("wallet.card.customer.id"));
    }
    @Given("After entering card details user click send otp button to send otp to do card transaction for valid customer id")
    public void after_entering_card_details_user_click_send_otp_button_to_send_otp_to_to_card_transaction_for_valid_and_valid_customer_id() throws FileNotFoundException {
        System.out.println("After entering card details user click send otp button to send otp to to card transaction for valid customer id");
        card.setTransactionAmount(String.valueOf(getRandomAmount())); // setting amount to do transaction
        card.setTransactionId(generateRandomNumber()); //setting transaction id
        card.setOtp(generateRandomNumber()); // setting otp
        res = sendCardTransactionOtp(card,payerAccessToken);
        if(res.getStatusCode()!=HTTP_OK){
            cardTransactionErrorValidation(res,card);
        }
        else {
            responseObject = extractJsonObjectFromResponse(res);
            assertJsonValueEquals("message","Success",responseObject);
        }
    }
    @Given("After entering correct otp user click pay button to do card transaction for valid customer id")
    public void after_entering_correct_otp_user_click_pay_button_to_to_card_transaction_for_valid_and_valid_customer_id() throws FileNotFoundException {
        System.out.println("After entering correct otp user click pay button to to card transaction for valid customer id");
        card.setTransactionNumber(generateRandomNumber());
        res = payCard(card,payerAccessToken); // calling method for card transaction
    }
    @Then("Verify card transaction status for valid customer id")
    public void verify_card_transaction_status_for_valid_and_valid_customer_id() {
        System.out.println("Verify card transaction status for valid customer id");
        if(res.getStatusCode()!=HTTP_OK){
            card.setIsCardTransactionSuccess(false);
            cardTransactionErrorValidation(res,card); // calling method for card transaction error validation
        }
        else {
            transactionHeaderId = successCardTransactionValidation(res,card); // calling method to validate card transaction from response
            card.setIsCardTransactionSuccess(true);
            card.setTransactionHeaderId(transactionHeaderId);
        }
    }
    @Then("Also verify card transaction status from db if transaction has been succeed for valid customer id")
    public void also_verify_card_transaction_status_from_db_if_transaction_has_succeed_for_valid_and_valid_customer_id() throws SQLException {
        System.out.println("Also verify card transaction status from db if transaction has succeed for valid customer id");
        if(card.getIsCardTransactionSuccess()){
            successCardTransactionValidationFromDB(payer,card); // calling method to validate card transaction from DB
        }
        else {
            System.out.println("Card Transaction failed");
        }
    }


    // ************************* Card Transaction for invalid card token  *****************************
    @Given("User login with valid cred to do card transaction for invalid card token")
    public void user_login_with_valid_cred_to_do_card_transaction_for_invalid_and_valid_card_token() throws FileNotFoundException {
        System.out.println("User login with valid cred to do card transaction for invalid card token");
        res = login(reader.getValueFromConfig("wallet.test.user2.mobile.number"),reader.getValueFromConfig("wallet.test.user2.passcode"),reader.getValueFromConfig("wallet.test.user2.device.id"),reader.getValueFromConfig("wallet.test.user2.device.id"));
        payerAccessToken = getAccessTokenResponseData(res,"access_token");
        payer.setSenderAccountId(reader.getValueFromConfig("wallet.test.user2.mobile.number"));
    }
    @Given("User has a valid card details to do card transaction for invalid card token")
    public void user_has_a_valid_card_details_to_do_card_transaction_for_invalid_and_valid_card_token() throws FileNotFoundException {
        System.out.println("User has a valid card details to do card transaction for invalid card token");
        balance = Double.valueOf(getWalletBalance(payerAccessToken)); // fetching payer wallet balance
        card.setWalletBalance(String.valueOf(balance));
        card.setCustomerId(reader.getValueFromConfig("wallet.card.customer.id")); // setting card customer id
    }
    @Given("User select merchant category to do card transaction for invalid card token")
    public void user_select_merchant_category_to_do_card_transaction_for_invalid_and_valid_card_token() {
        System.out.println("User select merchant category to do card transaction for invalid card token");
        card.setMerchantCategoryCode(reader.getValueFromConfig("wallet.card.merchant.category.code")); // setting merchant category code
        card.setMerchantId(reader.getValueFromConfig("wallet.card.merchant.id"));  //setting merchant id
        card.setLocation(reader.getValueFromConfig("wallet.card.location")); // setting transaction platform
        card.setChannel(reader.getValueFromConfig("wallet.card.channel"));
        card.setTransactionType(String.valueOf(TransTypeEnum.CARD_PAYMENT));

    }
    @Given("User enter {string} and {string} to do card transaction for invalid card token")
    public void user_enter_and_to_do_card_transaction_for_invalid_and_valid_card_token(String cardTokenType, String cardTokenValue) {
        System.out.println("User enter cardTokenType -> "+cardTokenType+" and cardTokenValue -> "+cardTokenValue+" to do card transaction for invalid card token");
        if(cardTokenValue.equalsIgnoreCase("null")){
            card.setCardToken(null);
        }
        else if(cardTokenValue.equalsIgnoreCase("empty")){
            card.setCardToken(" ");
        }
        else {
            card.setCardToken(cardTokenValue);
        }

    }
    @Given("After entering card details user click send otp button to send otp to do card transaction for invalid card token")
    public void after_entering_card_details_user_click_send_otp_button_to_send_otp_to_to_card_transaction_for_invalid_and_valid_card_token() throws FileNotFoundException {
        System.out.println("After entering card details user click send otp button to send otp to to card transaction for invalid card token");
        card.setTransactionAmount(String.valueOf(getRandomAmount())); // setting amount to do transaction
        card.setTransactionId(generateRandomNumber()); //setting transaction id
        card.setOtp(generateRandomNumber()); // setting otp
        res = sendCardTransactionOtp(card,payerAccessToken);
        if(res.getStatusCode()!=HTTP_OK){
            cardTransactionErrorValidation(res,card);
        }
        else {
            responseObject = extractJsonObjectFromResponse(res);
            assertJsonValueEquals("message","Success",responseObject);
        }
    }
    @Given("After entering correct otp user click pay button to do card transaction for invalid card token")
    public void after_entering_correct_otp_user_click_pay_button_to_to_card_transaction_for_invalid_and_valid_card_token() throws FileNotFoundException {
        System.out.println("After entering correct otp user click pay button to to card transaction for invalid card token");
        card.setTransactionNumber(generateRandomNumber());
        res = payCard(card,payerAccessToken); // calling method for card transaction
    }
    @Then("Verify card transaction status for invalid card token")
    public void verify_card_transaction_status_for_invalid_and_valid_card_token() {
        System.out.println("Verify card transaction status for invalid card token");
        cardTransactionErrorValidation(res,card); // calling method for card transaction error validation
    }

    // ************************* Card Transaction for valid card token  *****************************
    @Given("User login with valid cred to do card transaction for valid card token")
    public void user_login_with_valid_cred_to_do_card_transaction_for_valid_and_valid_card_token() throws FileNotFoundException {
        System.out.println("User login with valid cred to do card transaction for valid card token");
        res = login(reader.getValueFromConfig("wallet.test.user2.mobile.number"),reader.getValueFromConfig("wallet.test.user2.passcode"),reader.getValueFromConfig("wallet.test.user2.device.id"),reader.getValueFromConfig("wallet.test.user2.device.id"));
        payerAccessToken = getAccessTokenResponseData(res,"access_token");
        payer.setSenderAccountId(reader.getValueFromConfig("wallet.test.user2.mobile.number"));
    }
    @Given("User has a valid card details to do card transaction for valid card token")
    public void user_has_a_valid_card_details_to_do_card_transaction_for_valid_and_valid_card_token() throws FileNotFoundException {
        System.out.println("User has a valid card details to do card transaction for valid card token");
        balance = Double.valueOf(getWalletBalance(payerAccessToken)); // fetching payer wallet balance
        card.setWalletBalance(String.valueOf(balance));
        card.setCustomerId(reader.getValueFromConfig("wallet.card.customer.id")); // setting card customer id
    }
    @Given("User select merchant category to do card transaction for valid card token")
    public void user_select_merchant_category_to_do_card_transaction_for_valid_and_valid_card_token() {
        System.out.println("User select merchant category to do card transaction for valid card token");
        card.setMerchantCategoryCode(reader.getValueFromConfig("wallet.card.merchant.category.code")); // setting merchant category code
        card.setMerchantId(reader.getValueFromConfig("wallet.card.merchant.id"));  //setting merchant id
        card.setLocation(reader.getValueFromConfig("wallet.card.location")); // setting transaction platform
        card.setChannel(reader.getValueFromConfig("wallet.card.channel"));
        card.setTransactionType(String.valueOf(TransTypeEnum.CARD_PAYMENT));

    }
    @Given("User enter card token to do card transaction for valid card token")
    public void user_enter_and_to_do_card_transaction_for_valid_and_valid_card_token() {
        System.out.println("User enter card token to do card transaction for valid card token");
        card.setCardToken(reader.getValueFromConfig("wallet.card.token"));
    }
    @Given("After entering card details user click send otp button to send otp to do card transaction for valid card token")
    public void after_entering_card_details_user_click_send_otp_button_to_send_otp_to_to_card_transaction_for_valid_and_valid_card_token() throws FileNotFoundException {
        System.out.println("After entering card details user click send otp button to send otp to to card transaction for valid card token");
        card.setTransactionAmount(String.valueOf(getRandomAmount())); // setting amount to do transaction
        card.setTransactionId(generateRandomNumber()); //setting transaction id
        card.setOtp(generateRandomNumber()); // setting otp
        res = sendCardTransactionOtp(card,payerAccessToken);
        if(res.getStatusCode()!=HTTP_OK){
            cardTransactionErrorValidation(res,card);
        }
        else {
            responseObject = extractJsonObjectFromResponse(res);
            assertJsonValueEquals("message","Success",responseObject);
        }
    }
    @Given("After entering correct otp user click pay button to do card transaction for valid card token")
    public void after_entering_correct_otp_user_click_pay_button_to_to_card_transaction_for_valid_and_valid_card_token() throws FileNotFoundException {
        System.out.println("After entering correct otp user click pay button to to card transaction for valid card token");
        card.setTransactionNumber(generateRandomNumber());
        res = payCard(card,payerAccessToken); // calling method for card transaction
    }
    @Then("Verify card transaction status for valid card token")
    public void verify_card_transaction_status_for_valid_and_valid_card_token() {
        System.out.println("Verify card transaction status for valid card token");
        if(res.getStatusCode()!=HTTP_OK){
            card.setIsCardTransactionSuccess(false);
            cardTransactionErrorValidation(res,card); // calling method for card transaction error validation
        }
        else {
            transactionHeaderId = successCardTransactionValidation(res,card); // calling method to validate card transaction from response
            card.setIsCardTransactionSuccess(true);
            card.setTransactionHeaderId(transactionHeaderId);
        }
    }
    @Then("Also verify card transaction status from db if transaction has been succeed for valid card token")
    public void also_verify_card_transaction_status_from_db_if_transaction_has_succeed_for_valid_and_valid_card_token() throws SQLException {
        System.out.println("Also verify card transaction status from db if transaction has succeed for valid card token");
        if(card.getIsCardTransactionSuccess()){
            successCardTransactionValidationFromDB(payer,card); // calling method to validate card transaction from DB
        }
        else {
            System.out.println("Card Transaction failed");
        }
    }

    // ************************* Card Transaction for invalid merchant category code  *****************************
    @Given("User login with valid cred to do card transaction for invalid merchant category code")
    public void user_login_with_valid_cred_to_do_card_transaction_for_invalid_and_valid_merchant_category_code() throws FileNotFoundException {
        System.out.println("User login with valid cred to do card transaction for invalid merchant category code");
        res = login(reader.getValueFromConfig("wallet.test.user2.mobile.number"),reader.getValueFromConfig("wallet.test.user2.passcode"),reader.getValueFromConfig("wallet.test.user2.device.id"),reader.getValueFromConfig("wallet.test.user2.device.id"));
        payerAccessToken = getAccessTokenResponseData(res,"access_token");
        payer.setSenderAccountId(reader.getValueFromConfig("wallet.test.user2.mobile.number"));

    }
    @Given("User has a valid card details to do card transaction for invalid merchant category code")
    public void user_has_a_valid_card_details_to_do_card_transaction_for_invalid_and_valid_merchant_category_code() throws FileNotFoundException {
        System.out.println("User has a valid card details to do card transaction for invalid merchant category code");
        balance = Double.valueOf(getWalletBalance(payerAccessToken)); // fetching payer wallet balance
        card.setWalletBalance(String.valueOf(balance));
        card.setCustomerId(reader.getValueFromConfig("wallet.card.customer.id")); // setting card customer id
        card.setCardToken(reader.getValueFromConfig("wallet.card.token")); // setting card token

    }
    @Given("User select merchant category to do card transaction for invalid merchant category code")
    public void user_select_merchant_category_to_do_card_transaction_for_invalid_and_valid_merchant_category_code() {
        System.out.println("User select merchant category to do card transaction for invalid merchant category code");
        card.setMerchantId(reader.getValueFromConfig("wallet.card.merchant.id"));  //setting merchant id
        card.setLocation(reader.getValueFromConfig("wallet.card.location")); // setting transaction platform
        card.setChannel(reader.getValueFromConfig("wallet.card.channel"));
        card.setTransactionType(String.valueOf(TransTypeEnum.CARD_PAYMENT));
    }
    @Given("User enter {string} and {string} to do card transaction for invalid merchant category code")
    public void user_enter_and_to_do_card_transaction_for_invalid_and_valid_merchant_category_code(String merchantCategoryType, String merchantCategoryValue) {
        System.out.println("User enter merchantCategoryType -> "+merchantCategoryType+" and merchantCategoryValue -> "+merchantCategoryValue+" to do card transaction for invalid amount");
        if(merchantCategoryValue.equalsIgnoreCase("null")){
            card.setMerchantCategoryCode(null);
        }
        else if(merchantCategoryValue.equalsIgnoreCase("empty")){
            card.setMerchantCategoryCode(" ");
        }
        else {
            card.setMerchantCategoryCode(merchantCategoryValue);
        }
    }
    @Given("After entering card details user click send otp button to send otp to do card transaction for invalid merchant category code")
    public void after_entering_card_details_user_click_send_otp_button_to_send_otp_to_to_card_transaction_for_invalid_and_valid_merchant_category_code() throws FileNotFoundException {
        System.out.println("After entering card details user click send otp button to send otp to to card transaction for invalid merchant category code");
        card.setTransactionAmount(String.valueOf(getRandomAmount())); // setting amount to do transaction
        card.setTransactionId(generateRandomNumber()); //setting transaction id
        card.setOtp(generateRandomNumber()); // setting otp
        res = sendCardTransactionOtp(card,payerAccessToken);
        if(res.getStatusCode()!=HTTP_OK){
            cardTransactionErrorValidation(res,card);
        }
        else {
            responseObject = extractJsonObjectFromResponse(res);
            assertJsonValueEquals("message","Success",responseObject);
        }
    }
    @Given("After entering correct otp user click pay button to do card transaction for invalid merchant category code")
    public void after_entering_correct_otp_user_click_pay_button_to_to_card_transaction_for_invalid_and_valid_merchant_category_code() throws FileNotFoundException {
        System.out.println("After entering correct otp user click pay button to to card transaction for invalid merchant category code");
        card.setTransactionNumber(generateRandomNumber());
        res = payCard(card,payerAccessToken); // calling method for card transaction
    }
    @Then("Verify card transaction status for invalid merchant category code")
    public void verify_card_transaction_status_for_invalid_and_valid_merchant_category_code() {
        System.out.println("Verify card transaction status for invalid merchant category code");
        cardTransactionErrorValidation(res,card); // calling method for card transaction error validation
    }
    @Then("Also verify card transaction status from db if transaction has been succeed for invalid and valid merchant category code")
    public void also_verify_card_transaction_status_from_db_if_transaction_has_succeed_for_invalid_and_valid_merchant_category_code() throws SQLException {
        System.out.println("Also verify card transaction status from db if transaction has succeed for invalid and valid merchant category code");
        if(card.getIsCardTransactionSuccess()){
            successCardTransactionValidationFromDB(payer,card); // calling method to validate card transaction from DB
        }
        else {
            System.out.println("Card Transaction failed");
        }
    }

    // ************************* Card Transaction for valid merchant category code  *****************************
    @Given("User login with valid cred to do card transaction for valid merchant category code")
    public void user_login_with_valid_cred_to_do_card_transaction_for_valid_and_valid_merchant_category_code() throws FileNotFoundException {
        System.out.println("User login with valid cred to do card transaction for valid merchant category code");
        res = login(reader.getValueFromConfig("wallet.test.user2.mobile.number"),reader.getValueFromConfig("wallet.test.user2.passcode"),reader.getValueFromConfig("wallet.test.user2.device.id"),reader.getValueFromConfig("wallet.test.user2.device.id"));
        payerAccessToken = getAccessTokenResponseData(res,"access_token");
        payer.setSenderAccountId(reader.getValueFromConfig("wallet.test.user2.mobile.number"));

    }
    @Given("User has a valid card details to do card transaction for valid merchant category code")
    public void user_has_a_valid_card_details_to_do_card_transaction_for_valid_and_valid_merchant_category_code() throws FileNotFoundException {
        System.out.println("User has a valid card details to do card transaction for valid merchant category code");
        balance = Double.valueOf(getWalletBalance(payerAccessToken)); // fetching payer wallet balance
        card.setWalletBalance(String.valueOf(balance));
        card.setCustomerId(reader.getValueFromConfig("wallet.card.customer.id")); // setting card customer id
        card.setCardToken(reader.getValueFromConfig("wallet.card.token")); // setting card token

    }
    @Given("User select merchant category to do card transaction for valid merchant category code")
    public void user_select_merchant_category_to_do_card_transaction_for_valid_and_valid_merchant_category_code() {
        System.out.println("User select merchant category to do card transaction for valid merchant category code");
        card.setMerchantId(reader.getValueFromConfig("wallet.card.merchant.id"));  //setting merchant id
        card.setLocation(reader.getValueFromConfig("wallet.card.location")); // setting transaction platform
        card.setChannel(reader.getValueFromConfig("wallet.card.channel"));
        card.setTransactionType(String.valueOf(TransTypeEnum.CARD_PAYMENT));
    }
    @Given("User enter merchant category code to do card transaction for valid merchant category code")
    public void user_enter_and_to_do_card_transaction_for_valid_and_valid_merchant_category_code() {
        System.out.println("User enter merchant category code to do card transaction for valid merchant category code");
        card.setMerchantCategoryCode(reader.getValueFromConfig("wallet.card.merchant.category.code")); // setting merchant category code
    }
    @Given("After entering card details user click send otp button to send otp to do card transaction for valid merchant category code")
    public void after_entering_card_details_user_click_send_otp_button_to_send_otp_to_to_card_transaction_for_valid_and_valid_merchant_category_code() throws FileNotFoundException {
        System.out.println("After entering card details user click send otp button to send otp to to card transaction for valid merchant category code");
        card.setTransactionAmount(String.valueOf(getRandomAmount())); // setting amount to do transaction
        card.setTransactionId(generateRandomNumber()); //setting transaction id
        card.setOtp(generateRandomNumber()); // setting otp
        res = sendCardTransactionOtp(card,payerAccessToken);
        if(res.getStatusCode()!=HTTP_OK){
            cardTransactionErrorValidation(res,card);
        }
        else {
            responseObject = extractJsonObjectFromResponse(res);
            assertJsonValueEquals("message","Success",responseObject);
        }
    }
    @Given("After entering correct otp user click pay button to do card transaction for valid merchant category code")
    public void after_entering_correct_otp_user_click_pay_button_to_to_card_transaction_for_valid_and_valid_merchant_category_code() throws FileNotFoundException {
        System.out.println("After entering correct otp user click pay button to to card transaction for valid merchant category code");
        card.setTransactionNumber(generateRandomNumber());
        res = payCard(card,payerAccessToken); // calling method for card transaction
    }
    @Then("Verify card transaction status for valid merchant category code")
    public void verify_card_transaction_status_for_valid_and_valid_merchant_category_code() {
        System.out.println("Verify card transaction status for valid merchant category code");
        if(res.getStatusCode()!=HTTP_OK){
            card.setIsCardTransactionSuccess(false);
            cardTransactionErrorValidation(res,card); // calling method for card transaction error validation
        }
        else {
            transactionHeaderId = successCardTransactionValidation(res,card); // calling method to validate card transaction from response
            card.setIsCardTransactionSuccess(true);
            card.setTransactionHeaderId(transactionHeaderId);
        }
    }
    @Then("Also verify card transaction status from db if transaction has been succeed for valid merchant category code")
    public void also_verify_card_transaction_status_from_db_if_transaction_has_succeed_for_valid_and_valid_merchant_category_code() throws SQLException {
        System.out.println("Also verify card transaction status from db if transaction has succeed for valid merchant category code");
        if(card.getIsCardTransactionSuccess()){
            successCardTransactionValidationFromDB(payer,card); // calling method to validate card transaction from DB
        }
        else {
            System.out.println("Card Transaction failed");
        }
    }


    // ************************* Card Transaction for invalid merchant id *****************************
    @Given("User login with valid cred to do card transaction for invalid merchant id")
    public void user_login_with_valid_cred_to_do_card_transaction_for_invalid_and_valid_merchant_id() throws FileNotFoundException {
        System.out.println("User login with valid cred to do card transaction for invalid merchant id");
        res = login(reader.getValueFromConfig("wallet.test.user2.mobile.number"),reader.getValueFromConfig("wallet.test.user2.passcode"),reader.getValueFromConfig("wallet.test.user2.device.id"),reader.getValueFromConfig("wallet.test.user2.device.id"));
        payerAccessToken = getAccessTokenResponseData(res,"access_token");
        payer.setSenderAccountId(reader.getValueFromConfig("wallet.test.user2.mobile.number"));

    }
    @Given("User has a valid card details to do card transaction for invalid merchant id")
    public void user_has_a_valid_card_details_to_do_card_transaction_for_invalid_and_valid_merchant_id() throws FileNotFoundException {
        System.out.println("User has a valid card details to do card transaction for invalid merchant id");
        balance = Double.valueOf(getWalletBalance(payerAccessToken)); // fetching payer wallet balance
        card.setWalletBalance(String.valueOf(balance));
        card.setCustomerId(reader.getValueFromConfig("wallet.card.customer.id")); // setting card customer id
        card.setCardToken(reader.getValueFromConfig("wallet.card.token")); // setting card token
    }
    @Given("User select merchant category to do card transaction for invalid merchant id")
    public void user_select_merchant_category_to_do_card_transaction_for_invalid_and_valid_merchant_id() throws FileNotFoundException {
        System.out.println("User select merchant category to do card transaction for invalid merchant id");
        card.setMerchantCategoryCode(reader.getValueFromConfig("wallet.card.merchant.category.code")); // setting merchant category code
        card.setLocation(reader.getValueFromConfig("wallet.card.location")); // setting transaction platform
        card.setChannel(reader.getValueFromConfig("wallet.card.channel"));
        card.setTransactionType(String.valueOf(TransTypeEnum.CARD_PAYMENT));

    }
    @Given("User enter {string} and {string} to do card transaction for invalid merchant id")
    public void user_enter_and_to_do_card_transaction_for_invalid_and_valid_merchant_id(String merchantIdType, String merchantIdValue) {
        System.out.println("User enter merchantIdType -> "+merchantIdType+" and merchantIdValue -> "+merchantIdValue+" to do card transaction for invalid merchant id");
        if(merchantIdValue.equalsIgnoreCase("null")){
            card.setMerchantId(null);
        }
        else if(merchantIdValue.equalsIgnoreCase("empty")){
            card.setMerchantId(" ");
        }
        else {
            card.setMerchantId(merchantIdValue);
        }

    }
    @Given("After entering card details user click send otp button to send otp to do card transaction for invalid merchant id")
    public void after_entering_card_details_user_click_send_otp_button_to_send_otp_to_to_card_transaction_for_invalid_and_valid_merchant_id() throws FileNotFoundException {
        System.out.println("After entering card details user click send otp button to send otp to to card transaction for invalid merchant id");
        card.setTransactionAmount(String.valueOf(getRandomAmount())); // setting amount to do transaction
        card.setTransactionId(generateRandomNumber()); //setting transaction id
        card.setOtp(generateRandomNumber()); // setting otp
        res = sendCardTransactionOtp(card,payerAccessToken);
        if(res.getStatusCode()!=HTTP_OK){
            cardTransactionErrorValidation(res,card);
        }
        else {
            responseObject = extractJsonObjectFromResponse(res);
            assertJsonValueEquals("message","Success",responseObject);
        }
    }
    @Given("After entering correct otp user click pay button to do card transaction for invalid merchant id")
    public void after_entering_correct_otp_user_click_pay_button_to_to_card_transaction_for_invalid_and_valid_merchant_id() throws FileNotFoundException {
        System.out.println("After entering correct otp user click pay button to to card transaction for invalid merchant id");
        card.setTransactionNumber(generateRandomNumber());
        res = payCard(card,payerAccessToken); // calling method for card transaction
    }
    @Then("Verify card transaction status for invalid merchant id")
    public void verify_card_transaction_status_for_invalid_and_valid_merchant_id() {
        System.out.println("Verify card transaction status for invalid merchant id");
        cardTransactionErrorValidation(res,card); // calling method for card transaction error validation
    }
    @Then("Also verify card transaction status from db if transaction has been succeed for invalid merchant id")
    public void also_verify_card_transaction_status_from_db_if_transaction_has_succeed_for_invalid_and_valid_merchant_id() throws SQLException {
        System.out.println("Also verify card transaction status from db if transaction has succeed for invalid merchant id");
        if(card.getIsCardTransactionSuccess()){
            successCardTransactionValidationFromDB(payer,card); // calling method to validate card transaction from DB
        }
        else {
            System.out.println("Card Transaction failed");
        }
    }

    // ************************* Card Transaction for valid merchant id *****************************
    @Given("User login with valid cred to do card transaction for valid merchant id")
    public void user_login_with_valid_cred_to_do_card_transaction_for_valid_and_valid_merchant_id() throws FileNotFoundException {
        System.out.println("User login with valid cred to do card transaction for valid merchant id");
        res = login(reader.getValueFromConfig("wallet.test.user2.mobile.number"),reader.getValueFromConfig("wallet.test.user2.passcode"),reader.getValueFromConfig("wallet.test.user2.device.id"),reader.getValueFromConfig("wallet.test.user2.device.id"));
        payerAccessToken = getAccessTokenResponseData(res,"access_token");
        payer.setSenderAccountId(reader.getValueFromConfig("wallet.test.user2.mobile.number"));

    }
    @Given("User has a valid card details to do card transaction for valid merchant id")
    public void user_has_a_valid_card_details_to_do_card_transaction_for_valid_and_valid_merchant_id() throws FileNotFoundException {
        System.out.println("User has a valid card details to do card transaction for valid merchant id");
        balance = Double.valueOf(getWalletBalance(payerAccessToken)); // fetching payer wallet balance
        card.setWalletBalance(String.valueOf(balance));
        card.setCustomerId(reader.getValueFromConfig("wallet.card.customer.id")); // setting card customer id
        card.setCardToken(reader.getValueFromConfig("wallet.card.token")); // setting card token
    }
    @Given("User select merchant category to do card transaction for valid merchant id")
    public void user_select_merchant_category_to_do_card_transaction_for_valid_and_valid_merchant_id() throws FileNotFoundException {
        System.out.println("User select merchant category to do card transaction for valid merchant id");
        card.setMerchantCategoryCode(reader.getValueFromConfig("wallet.card.merchant.category.code")); // setting merchant category code
        card.setLocation(reader.getValueFromConfig("wallet.card.location")); // setting transaction platform
        card.setChannel(reader.getValueFromConfig("wallet.card.channel"));
        card.setTransactionType(String.valueOf(TransTypeEnum.CARD_PAYMENT));

    }
    @Given("User enter merchant id to do card transaction for valid merchant id")
    public void user_enter_and_to_do_card_transaction_for_valid_and_valid_merchant_id() {
        System.out.println("User enter merchant id to do card transaction for valid merchant id");
        card.setMerchantId(reader.getValueFromConfig("wallet.card.merchant.id"));  //setting merchant id

    }
    @Given("After entering card details user click send otp button to send otp to do card transaction for valid merchant id")
    public void after_entering_card_details_user_click_send_otp_button_to_send_otp_to_to_card_transaction_for_valid_and_valid_merchant_id() throws FileNotFoundException {
        System.out.println("After entering card details user click send otp button to send otp to to card transaction for valid merchant id");
        card.setTransactionAmount(String.valueOf(getRandomAmount())); // setting amount to do transaction
        card.setTransactionId(generateRandomNumber()); //setting transaction id
        card.setOtp(generateRandomNumber()); // setting otp
        res = sendCardTransactionOtp(card,payerAccessToken);
        if(res.getStatusCode()!=HTTP_OK){
            cardTransactionErrorValidation(res,card);
        }
        else {
            responseObject = extractJsonObjectFromResponse(res);
            assertJsonValueEquals("message","Success",responseObject);
        }
    }
    @Given("After entering correct otp user click pay button to do card transaction for valid merchant id")
    public void after_entering_correct_otp_user_click_pay_button_to_to_card_transaction_for_valid_and_valid_merchant_id() throws FileNotFoundException {
        System.out.println("After entering correct otp user click pay button to to card transaction for valid merchant id");
        card.setTransactionNumber(generateRandomNumber());
        res = payCard(card,payerAccessToken); // calling method for card transaction
    }
    @Then("Verify card transaction status for valid merchant id")
    public void verify_card_transaction_status_for_valid_and_valid_merchant_id() {
        System.out.println("Verify card transaction status for invalid merchant id");
        if(res.getStatusCode()!=HTTP_OK){
            card.setIsCardTransactionSuccess(false);
            cardTransactionErrorValidation(res,card); // calling method for card transaction error validation
        }
        else {
            transactionHeaderId = successCardTransactionValidation(res,card); // calling method to validate card transaction from response
            card.setIsCardTransactionSuccess(true);
            card.setTransactionHeaderId(transactionHeaderId);
        }
    }
    @Then("Also verify card transaction status from db if transaction has been succeed for valid merchant id")
    public void also_verify_card_transaction_status_from_db_if_transaction_has_succeed_for_valid_and_valid_merchant_id() throws SQLException {
        System.out.println("Also verify card transaction status from db if transaction has succeed for valid merchant id");
        if(card.getIsCardTransactionSuccess()){
            successCardTransactionValidationFromDB(payer,card); // calling method to validate card transaction from DB
        }
        else {
            System.out.println("Card Transaction failed");
        }
    }

    // ************************* Card Transaction for invalid location *****************************
    @Given("User login with valid cred to do card transaction for invalid location")
    public void user_login_with_valid_cred_to_do_card_transaction_for_invalid_and_valid_location() throws FileNotFoundException {
        System.out.println("User login with valid cred to do card transaction for invalid location");
        res = login(reader.getValueFromConfig("wallet.test.user2.mobile.number"),reader.getValueFromConfig("wallet.test.user2.passcode"),reader.getValueFromConfig("wallet.test.user2.device.id"),reader.getValueFromConfig("wallet.test.user2.device.id"));
        payerAccessToken = getAccessTokenResponseData(res,"access_token");
        payer.setSenderAccountId(reader.getValueFromConfig("wallet.test.user2.mobile.number"));

    }
    @Given("User has a valid card details to do card transaction for invalid location")
    public void user_has_a_valid_card_details_to_do_card_transaction_for_invalid_and_valid_location() throws FileNotFoundException {
        System.out.println("User has a valid card details to do card transaction for invalid location");
        balance = Double.valueOf(getWalletBalance(payerAccessToken)); // fetching payer wallet balance
        card.setWalletBalance(String.valueOf(balance));
        card.setCustomerId(reader.getValueFromConfig("wallet.card.customer.id")); // setting card customer id
        card.setCardToken(reader.getValueFromConfig("wallet.card.token")); // setting card token

    }
    @Given("User select merchant category to do card transaction for invalid location")
    public void user_select_merchant_category_to_do_card_transaction_for_invalid_and_valid_location() {
        System.out.println("User select merchant category to do card transaction for invalid location");
        card.setMerchantCategoryCode(reader.getValueFromConfig("wallet.card.merchant.category.code")); // setting merchant category code
        card.setMerchantId(reader.getValueFromConfig("wallet.card.merchant.id"));  //setting merchant id
        card.setChannel(reader.getValueFromConfig("wallet.card.channel"));
        card.setTransactionType(String.valueOf(TransTypeEnum.CARD_PAYMENT));

    }
    @Given("User enter {string} and {string} to do card transaction for invalid location")
    public void user_enter_and_to_do_card_transaction_for_invalid_and_valid_location(String locationType, String locationValue) {
        System.out.println("User enter locationType -> "+locationType+" and locationValue -> "+locationValue+" to do card transaction for invalid location");
        if(locationValue.equalsIgnoreCase("null")){
            card.setLocation(null);
        }
        else if(locationValue.equalsIgnoreCase("empty")){
            card.setTransactionAmount(" ");
        }
        else {
            card.setLocation(locationValue);
        }
    }
    @Given("After entering card details user click send otp button to send otp to do card transaction for invalid location")
    public void after_entering_card_details_user_click_send_otp_button_to_send_otp_to_to_card_transaction_for_invalid_and_valid_location() throws FileNotFoundException {
        System.out.println("After entering card details user click send otp button to send otp to to card transaction for invalid location");
        card.setTransactionAmount(String.valueOf(getRandomAmount())); // setting amount to do transaction
        card.setTransactionId(generateRandomNumber()); //setting transaction id
        card.setOtp(generateRandomNumber()); // setting otp
        res = sendCardTransactionOtp(card,payerAccessToken);
        if(res.getStatusCode()!=HTTP_OK){
            cardTransactionErrorValidation(res,card);
        }
        else {
            responseObject = extractJsonObjectFromResponse(res);
            assertJsonValueEquals("message","Success",responseObject);
        }
    }
    @Given("After entering correct otp user click pay button to do card transaction for invalid location")
    public void after_entering_correct_otp_user_click_pay_button_to_to_card_transaction_for_invalid_and_valid_location() throws FileNotFoundException {
        System.out.println("After entering correct otp user click pay button to to card transaction for invalid location");
        card.setTransactionNumber(generateRandomNumber());
        res = payCard(card,payerAccessToken); // calling method for card transaction
        System.out.println(res.asPrettyString());

    }
    @Then("Verify card transaction status for invalid location")
    public void verify_card_transaction_status_for_invalid_and_valid_location() {
        System.out.println("Verify card transaction status for invalid location");
        cardTransactionErrorValidation(res,card); // calling method for card transaction error validation
    }

    // ************************* Card Transaction for valid location *****************************
    @Given("User login with valid cred to do card transaction for valid location")
    public void user_login_with_valid_cred_to_do_card_transaction_for_valid_and_valid_location() throws FileNotFoundException {
        System.out.println("User login with valid cred to do card transaction for valid location");
        res = login(reader.getValueFromConfig("wallet.test.user2.mobile.number"),reader.getValueFromConfig("wallet.test.user2.passcode"),reader.getValueFromConfig("wallet.test.user2.device.id"),reader.getValueFromConfig("wallet.test.user2.device.id"));
        payerAccessToken = getAccessTokenResponseData(res,"access_token");
        payer.setSenderAccountId(reader.getValueFromConfig("wallet.test.user2.mobile.number"));

    }
    @Given("User has a valid card details to do card transaction for valid location")
    public void user_has_a_valid_card_details_to_do_card_transaction_for_valid_and_valid_location() throws FileNotFoundException {
        System.out.println("User has a valid card details to do card transaction for valid location");
        balance = Double.valueOf(getWalletBalance(payerAccessToken)); // fetching payer wallet balance
        card.setWalletBalance(String.valueOf(balance));
        card.setCustomerId(reader.getValueFromConfig("wallet.card.customer.id")); // setting card customer id
        card.setCardToken(reader.getValueFromConfig("wallet.card.token")); // setting card token

    }
    @Given("User select merchant category to do card transaction for valid location")
    public void user_select_merchant_category_to_do_card_transaction_for_valid_and_valid_location() {
        System.out.println("User select merchant category to do card transaction for valid location");
        card.setMerchantCategoryCode(reader.getValueFromConfig("wallet.card.merchant.category.code")); // setting merchant category code
        card.setMerchantId(reader.getValueFromConfig("wallet.card.merchant.id"));  //setting merchant id
        //card.setLocation(reader.getValueFromConfig("wallet.card.location")); // setting transaction platform
        card.setChannel(reader.getValueFromConfig("wallet.card.channel"));
        card.setTransactionType(String.valueOf(TransTypeEnum.CARD_PAYMENT));

    }
    @Given("User enter card-transaction-location to do card transaction for valid location")
    public void user_enter_and_to_do_card_transaction_for_valid_and_valid_location() {
        System.out.println("User enter card-transaction-location to do card transaction for valid location");
        card.setLocation(reader.getValueFromConfig("wallet.card.location")); // setting transaction platform
    }
    @Given("After entering card details user click send otp button to send otp to do card transaction for valid location")
    public void after_entering_card_details_user_click_send_otp_button_to_send_otp_to_to_card_transaction_for_valid_and_valid_location() throws FileNotFoundException {
        System.out.println("After entering card details user click send otp button to send otp to to card transaction for valid location");
        card.setTransactionAmount(String.valueOf(getRandomAmount())); // setting amount to do transaction
        card.setTransactionId(generateRandomNumber()); //setting transaction id
        card.setOtp(generateRandomNumber()); // setting otp
        res = sendCardTransactionOtp(card,payerAccessToken);
        if(res.getStatusCode()!=HTTP_OK){
            cardTransactionErrorValidation(res,card);
        }
        else {
            responseObject = extractJsonObjectFromResponse(res);
            assertJsonValueEquals("message","Success",responseObject);
        }
    }
    @Given("After entering correct otp user click pay button to do card transaction for valid location")
    public void after_entering_correct_otp_user_click_pay_button_to_to_card_transaction_for_valid_and_valid_location() throws FileNotFoundException {
        System.out.println("After entering correct otp user click pay button to to card transaction for valid location");
        card.setTransactionNumber(generateRandomNumber());
        res = payCard(card,payerAccessToken); // calling method for card transaction
        System.out.println(res.asPrettyString());

    }
    @Then("Verify card transaction status for valid location")
    public void verify_card_transaction_status_for_valid_and_valid_location() {
        System.out.println("Verify card transaction status for valid location");
        if(res.getStatusCode()!=HTTP_OK){
            card.setIsCardTransactionSuccess(false);
            cardTransactionErrorValidation(res,card); // calling method for card transaction error validation
        }
        else {
            transactionHeaderId = successCardTransactionValidation(res,card); // calling method to validate card transaction from response
            card.setIsCardTransactionSuccess(true);
            card.setTransactionHeaderId(transactionHeaderId);
        }
    }
    @Then("Also verify card transaction status from db if transaction has been succeed for valid location")
    public void also_verify_card_transaction_status_from_db_if_transaction_has_succeed_for_invalid_and_valid_location() throws SQLException {
        System.out.println("Also verify card transaction status from db if transaction has succeed for valid location");
        if(card.getIsCardTransactionSuccess()){
            successCardTransactionValidationFromDB(payer,card); // calling method to validate card transaction from DB
        }
        else {
            System.out.println("Card Transaction failed");
        }
    }

    // ************************* Card Transaction for invalid channel *****************************
    @Given("User login with valid cred to do card transaction for invalid channel")
    public void user_login_with_valid_cred_to_do_card_transaction_for_invalid_and_valid_channel() throws FileNotFoundException {
        System.out.println("User login with valid cred to do card transaction for invalid channel");
        res = login(reader.getValueFromConfig("wallet.test.user2.mobile.number"),reader.getValueFromConfig("wallet.test.user2.passcode"),reader.getValueFromConfig("wallet.test.user2.device.id"),reader.getValueFromConfig("wallet.test.user2.device.id"));
        payerAccessToken = getAccessTokenResponseData(res,"access_token");
        payer.setSenderAccountId(reader.getValueFromConfig("wallet.test.user2.mobile.number"));

    }
    @Given("User has a valid card details to do card transaction for invalid channel")
    public void user_has_a_valid_card_details_to_do_card_transaction_for_invalid_and_valid_channel() throws FileNotFoundException {
        System.out.println("User has a valid card details to do card transaction for invalid channel");
        balance = Double.valueOf(getWalletBalance(payerAccessToken)); // fetching payer wallet balance
        card.setWalletBalance(String.valueOf(balance));
        card.setCustomerId(reader.getValueFromConfig("wallet.card.customer.id")); // setting card customer id
        card.setCardToken(reader.getValueFromConfig("wallet.card.token")); // setting card token
    }
    @Given("User select merchant category to do card transaction for invalid channel")
    public void user_select_merchant_category_to_do_card_transaction_for_invalid_and_valid_channel() {
        System.out.println("User select merchant category to do card transaction for invalid channel");
        card.setMerchantCategoryCode(reader.getValueFromConfig("wallet.card.merchant.category.code")); // setting merchant category code
        card.setMerchantId(reader.getValueFromConfig("wallet.card.merchant.id"));  //setting merchant id
        card.setLocation(reader.getValueFromConfig("wallet.card.location")); // setting transaction platform
        card.setTransactionType(String.valueOf(TransTypeEnum.CARD_PAYMENT));
    }
    @Given("User enter {string} and {string} to do card transaction for invalid channel")
    public void user_enter_and_to_do_card_transaction_for_invalid_and_valid_channel(String channelType, String channelValue) {
        System.out.println("User enter channelType -> "+channelType+" and channelValue -> "+channelValue+" to do card transaction for invalid channel");
        if(channelValue.equalsIgnoreCase("null")){
            card.setChannel(null);
        }
        else if(channelValue.equalsIgnoreCase("empty")){
            card.setChannel(" ");
        }
        else {
            card.setChannel(channelValue);
        }
    }
    @Given("After entering card details user click send otp button to send otp to do card transaction for invalid channel")
    public void after_entering_card_details_user_click_send_otp_button_to_send_otp_to_do_card_transaction_for_invalid_and_valid_channel() throws FileNotFoundException {
        System.out.println("After entering card details user click send otp button to send otp to do card transaction for invalid channel");
        card.setTransactionAmount(String.valueOf(getRandomAmount())); // setting amount to do transaction
        card.setTransactionId(generateRandomNumber()); //setting transaction id
        card.setOtp(generateRandomNumber()); // setting otp
        res = sendCardTransactionOtp(card,payerAccessToken);
        if(res.getStatusCode()!=HTTP_OK){
            cardTransactionErrorValidation(res,card);
        }
        else {
            responseObject = extractJsonObjectFromResponse(res);
            assertJsonValueEquals("message","Success",responseObject);
        }
    }
    @Given("After entering correct otp user click pay button to do card transaction for invalid channel")
    public void after_entering_correct_otp_user_click_pay_button_to_do_card_transaction_for_invalid_and_valid_channel() throws FileNotFoundException {
        System.out.println("After entering correct otp user click pay button to do card transaction for invalid channel");
        card.setTransactionNumber(generateRandomNumber());
        res = payCard(card,payerAccessToken); // calling method for card transaction
        System.out.println(res.asPrettyString());
    }
    @Then("Verify card transaction status for invalid channel")
    public void verify_card_transaction_status_for_invalid_and_valid_channel() {
        System.out.println("Verify card transaction status for invalid channel");
        cardTransactionErrorValidation(res,card); // calling method for card transaction error validation
    }
    @Then("Also verify card transaction status from db if transaction has been succeed for invalid and valid channel")
    public void also_verify_card_transaction_status_from_db_if_transaction_has_succeed_for_invalid_and_valid_channel() throws SQLException {
        System.out.println("Also verify card transaction status from db if transaction has succeed for invalid and valid channel");
        if(card.getIsCardTransactionSuccess()){
            successCardTransactionValidationFromDB(payer,card); // calling method to validate card transaction from DB
        }
        else {
            System.out.println("Card Transaction failed");
        }
    }

    // ************************* Card Transaction for valid channel *****************************
    @Given("User login with valid cred to do card transaction for valid channel")
    public void user_login_with_valid_cred_to_do_card_transaction_for_valid_and_valid_channel() throws FileNotFoundException {
        System.out.println("User login with valid cred to do card transaction for valid channel");
        res = login(reader.getValueFromConfig("wallet.test.user2.mobile.number"),reader.getValueFromConfig("wallet.test.user2.passcode"),reader.getValueFromConfig("wallet.test.user2.device.id"),reader.getValueFromConfig("wallet.test.user2.device.id"));
        payerAccessToken = getAccessTokenResponseData(res,"access_token");
        payer.setSenderAccountId(reader.getValueFromConfig("wallet.test.user2.mobile.number"));

    }
    @Given("User has a valid card details to do card transaction for valid channel")
    public void user_has_a_valid_card_details_to_do_card_transaction_for_valid_and_valid_channel() throws FileNotFoundException {
        System.out.println("User has a valid card details to do card transaction for invalid channel");
        balance = Double.valueOf(getWalletBalance(payerAccessToken)); // fetching payer wallet balance
        card.setWalletBalance(String.valueOf(balance));
        card.setCustomerId(reader.getValueFromConfig("wallet.card.customer.id")); // setting card customer id
        card.setCardToken(reader.getValueFromConfig("wallet.card.token")); // setting card token
    }
    @Given("User select merchant category to do card transaction for valid channel")
    public void user_select_merchant_category_to_do_card_transaction_for_valid_and_valid_channel() {
        System.out.println("User select merchant category to do card transaction for invalid channel");
        card.setMerchantCategoryCode(reader.getValueFromConfig("wallet.card.merchant.category.code")); // setting merchant category code
        card.setMerchantId(reader.getValueFromConfig("wallet.card.merchant.id"));  //setting merchant id
        card.setLocation(reader.getValueFromConfig("wallet.card.location")); // setting transaction platform
        card.setTransactionType(String.valueOf(TransTypeEnum.CARD_PAYMENT));
    }
    @Given("User enter channel to do card transaction for valid channel")
    public void user_enter_and_to_do_card_transaction_for_valid_and_valid_channel() {
        System.out.println("User enter channel to do card transaction for valid channel");
        card.setChannel(reader.getValueFromConfig("wallet.card.channel"));
    }
    @Given("After entering card details user click send otp button to send otp to do card transaction for valid channel")
    public void after_entering_card_details_user_click_send_otp_button_to_send_otp_to_do_card_transaction_for_valid_and_valid_channel() throws FileNotFoundException {
        System.out.println("After entering card details user click send otp button to send otp to do card transaction for valid channel");
        card.setTransactionAmount(String.valueOf(getRandomAmount())); // setting amount to do transaction
        card.setTransactionId(generateRandomNumber()); //setting transaction id
        card.setOtp(generateRandomNumber()); // setting otp
        res = sendCardTransactionOtp(card,payerAccessToken);
        if(res.getStatusCode()!=HTTP_OK){
            cardTransactionErrorValidation(res,card);
        }
        else {
            responseObject = extractJsonObjectFromResponse(res);
            assertJsonValueEquals("message","Success",responseObject);
        }
    }
    @Given("After entering correct otp user click pay button to do card transaction for valid channel")
    public void after_entering_correct_otp_user_click_pay_button_to_do_card_transaction_for_valid_and_valid_channel() throws FileNotFoundException {
        System.out.println("After entering correct otp user click pay button to do card transaction for valid channel");
        card.setTransactionNumber(generateRandomNumber());
        res = payCard(card,payerAccessToken); // calling method for card transaction
        System.out.println(res.asPrettyString());
    }
    @Then("Verify card transaction status for valid channel")
    public void verify_card_transaction_status_for_valid_and_valid_channel() {
        System.out.println("Verify card transaction status for invalid channel");
        if(res.getStatusCode()!=HTTP_OK){
            card.setIsCardTransactionSuccess(false);
            cardTransactionErrorValidation(res,card); // calling method for card transaction error validation
        }
        else {
            transactionHeaderId = successCardTransactionValidation(res,card); // calling method to validate card transaction from response
            card.setIsCardTransactionSuccess(true);
            card.setTransactionHeaderId(transactionHeaderId);
        }
    }
    @Then("Also verify card transaction status from db if transaction has been succeed for valid channel")
    public void also_verify_card_transaction_status_from_db_if_transaction_has_succeed_for_valid_and_valid_channel() throws SQLException {
        System.out.println("Also verify card transaction status from db if transaction has succeed for valid channel");
        if(card.getIsCardTransactionSuccess()){
            successCardTransactionValidationFromDB(payer,card); // calling method to validate card transaction from DB
        }
        else {
            System.out.println("Card Transaction failed");
        }
    }

    // ************************* Card Transaction when user has insufficient wallet balance *****************************
    @Given("User login with valid cred to do card transaction when user has insufficient wallet balance")
    public void user_login_with_valid_cred_to_do_card_transaction_when_user_has_insufficient_wallet_balance() throws FileNotFoundException {
        System.out.println("User login with valid cred to do card transaction when user has insufficient wallet balance");
        res = login(reader.getValueFromConfig("wallet.test.user2.mobile.number"),reader.getValueFromConfig("wallet.test.user2.passcode"),reader.getValueFromConfig("wallet.test.user2.device.id"),reader.getValueFromConfig("wallet.test.user2.device.id"));
        payerAccessToken = getAccessTokenResponseData(res,"access_token");
        payer.setSenderAccountId(reader.getValueFromConfig("wallet.test.user2.mobile.number"));

    }
    @Given("User has a valid card details to do card transaction when user has insufficient wallet balance")
    public void user_has_a_valid_card_details_to_do_card_transaction_when_user_has_insufficient_wallet_balance() throws FileNotFoundException {
        System.out.println("User has a valid card details to do card transaction when user has insufficient wallet balance");
        balance = Double.valueOf(getWalletBalance(payerAccessToken)); // fetching payer wallet balance
        card.setWalletBalance(String.valueOf(balance));
        card.setCustomerId(reader.getValueFromConfig("wallet.card.customer.id")); // setting card customer id
        card.setCardToken(reader.getValueFromConfig("wallet.card.token")); // setting card token
    }
    @Given("User select merchant category to do card transaction when user has insufficient wallet balance")
    public void user_select_merchant_category_to_do_card_transaction_when_user_has_insufficient_wallet_balance() {
        System.out.println("User select merchant category to do card transaction when user has insufficient wallet balance");
        card.setMerchantCategoryCode(reader.getValueFromConfig("wallet.card.merchant.category.code")); // setting merchant category code
        card.setMerchantId(reader.getValueFromConfig("wallet.card.merchant.id"));  //setting merchant id
        card.setLocation(reader.getValueFromConfig("wallet.card.location")); // setting transaction platform
        card.setChannel(reader.getValueFromConfig("wallet.card.channel"));
        card.setTransactionType(String.valueOf(TransTypeEnum.CARD_PAYMENT));

    }
    @Given("User enter amount to do card transaction when user has insufficient wallet balance")
    public void user_enter_amount_to_do_card_transaction_when_user_has_insufficient_wallet_balance() {
        System.out.println("User enter amount to do card transaction when user has insufficient wallet balance");
        Double amount = Double.parseDouble(card.getWalletBalance())+ getRandomAmount();
        card.setTransactionAmount(String.valueOf(amount)); // setting amount greater then wallet balance
    }
    @Given("After entering card details user click send otp button to send otp to do card transaction when user has insufficient wallet balance")
    public void after_entering_card_details_user_click_send_otp_button_to_send_otp_to_do_card_transaction_when_user_has_insufficient_wallet_balance() throws FileNotFoundException {
        System.out.println("After entering card details user click send otp button to send otp to do card transaction when user has insufficient wallet balance");
        card.setTransactionId(generateRandomNumber()); //setting transaction id
        card.setOtp(generateRandomNumber()); // setting otp
        res = sendCardTransactionOtp(card,payerAccessToken);
        if(res.getStatusCode()!=HTTP_OK){
            cardTransactionErrorValidation(res,card);
        }
        else {
            responseObject = extractJsonObjectFromResponse(res);
            assertJsonValueEquals("message","Success",responseObject);
        }
    }
    @Given("After entering correct otp user click pay button to do card transaction when user has insufficient wallet balance")
    public void after_entering_correct_otp_user_click_pay_button_to_do_card_transaction_when_user_has_insufficient_wallet_balance() throws FileNotFoundException {
        System.out.println("After entering correct otp user click pay button to do card transaction when user has insufficient wallet balance");
        card.setTransactionNumber(generateRandomNumber());
        res = payCard(card,payerAccessToken); // calling method for card transaction
        System.out.println(res.asPrettyString());
    }
    @Then("Verify card transaction status when user has insufficient wallet balance")
    public void verify_card_transaction_status_when_user_has_insufficient_wallet_balance() {
        System.out.println("Verify card transaction status when user has insufficient wallet balance");
        if(res.getStatusCode()!=HTTP_OK){
            card.setIsCardTransactionSuccess(false);
            cardTransactionErrorValidation(res,card); // calling method for card transaction error validation
        }
        else {
            transactionHeaderId = successCardTransactionValidation(res,card); // calling method to validate card transaction from response
            card.setIsCardTransactionSuccess(true);
            card.setTransactionHeaderId(transactionHeaderId);
        }
    }
    @Then("Also verify card transaction status from db if transaction has been succeed when user has insufficient wallet balance")
    public void also_verify_card_transaction_status_from_db_if_transaction_has_been_succeed_when_user_has_insufficient_wallet_balance() throws SQLException {
        System.out.println("Also verify card transaction status from db if transaction has been succeed when user has insufficient wallet balance");
        if(card.getIsCardTransactionSuccess()){
            successCardTransactionValidationFromDB(payer,card); // calling method to validate card transaction from DB
        }
        else {
            System.out.println("Card Transaction failed");
        }
    }

    // ************************* Card Transaction when user's card is not activated *****************************
    @Given("User login with valid cred to do card transaction when user's card is not activated")
    public void user_login_with_valid_cred_to_do_card_transaction_when_user_s_card_is_not_activated() throws FileNotFoundException {
        System.out.println("User login with valid cred to do card transaction when user's card is not activated");
        res = login(reader.getValueFromConfig("wallet.test.user1.mobile.number"),reader.getValueFromConfig("wallet.test.user1.passcode"),reader.getValueFromConfig("wallet.test.user1.device.id"),reader.getValueFromConfig("wallet.test.user1.device.id"));
        payerAccessToken = getAccessTokenResponseData(res,"access_token");
        payer.setSenderAccountId(reader.getValueFromConfig("wallet.test.user1.mobile.number"));
    }
    @Given("User has a valid card details to do card transaction when user's card is not activated")
    public void user_has_a_valid_card_details_to_do_card_transaction_when_user_s_card_is_not_activated() throws FileNotFoundException {
        System.out.println("User has a valid card details to do card transaction when user's card is not activated");
        balance = Double.valueOf(getWalletBalance(payerAccessToken)); // fetching payer wallet balance
        card.setWalletBalance(String.valueOf(balance));
        card.setCustomerId(reader.getValueFromConfig("wallet.block.card.customer.id")); // setting card customer id
        card.setCardToken(reader.getValueFromConfig("wallet.block.card.token")); // setting card token

    }
    @Given("User select merchant category to do card transaction when user's card is not activated")
    public void user_select_merchant_category_to_do_card_transaction_when_user_s_card_is_not_activated() {
        System.out.println("User select merchant category to do card transaction when user's card is not activated");
        card.setMerchantCategoryCode(reader.getValueFromConfig("wallet.card.merchant.category.code")); // setting merchant category code
        card.setMerchantId(reader.getValueFromConfig("wallet.card.merchant.id"));  //setting merchant id
        card.setLocation(reader.getValueFromConfig("wallet.card.location")); // setting transaction platform
        card.setChannel(reader.getValueFromConfig("wallet.card.channel"));
        card.setTransactionType(String.valueOf(TransTypeEnum.CARD_PAYMENT));
    }
    @Given("User enter amount to do card transaction when user's card is not activated")
    public void user_enter_amount_to_do_card_transaction_when_user_s_card_is_not_activated() {
        System.out.println("User enter amount to do card transaction when user's card is not activated");
        card.setTransactionAmount(String.valueOf(getRandomAmount())); // setting amount to do transaction
    }
    @Given("After entering card details user click send otp button to send otp to do card transaction when user's card is not activated")
    public void after_entering_card_details_user_click_send_otp_button_to_send_otp_to_do_card_transaction_when_user_s_card_is_not_activated() throws FileNotFoundException {
        System.out.println("After entering card details user click send otp button to send otp to do card transaction when user's card is not activated");
        card.setTransactionId(generateRandomNumber()); //setting transaction id
        card.setOtp(generateRandomNumber()); // setting otp
        res = sendCardTransactionOtp(card,payerAccessToken);
        if(res.getStatusCode()!=HTTP_OK){
            cardTransactionErrorValidation(res,card);
        }
        else {
            responseObject = extractJsonObjectFromResponse(res);
            assertJsonValueEquals("message","Success",responseObject);
        }
    }
    @Given("After entering correct otp user click pay button to do card transaction when user's card is not activated")
    public void after_entering_correct_otp_user_click_pay_button_to_do_card_transaction_when_user_s_card_is_not_activated() throws FileNotFoundException {
        System.out.println("After entering correct otp user click pay button to do card transaction when user's card is not activated");
        card.setTransactionNumber(generateRandomNumber());
        res = payCard(card,payerAccessToken); // calling method for card transaction
        System.out.println(res.asPrettyString());
    }
    @Then("Verify card transaction status when user's card is not activated")
    public void verify_card_transaction_status_when_user_s_card_is_not_activated() {
        System.out.println("Verify card transaction status when user's card is not activated");
        if(res.getStatusCode()!=HTTP_OK){
            card.setIsCardTransactionSuccess(false);
            cardTransactionErrorValidation(res,card); // calling method for card transaction error validation
        }
        else {
            transactionHeaderId = successCardTransactionValidation(res,card); // calling method to validate card transaction from response
            card.setIsCardTransactionSuccess(true);
            card.setTransactionHeaderId(transactionHeaderId);
        }
    }
    @Then("Also verify card transaction status from db if transaction has been succeed when user's card is not activated")
    public void also_verify_card_transaction_status_from_db_if_transaction_has_been_succeed_when_user_s_card_is_not_activated() throws SQLException {
        System.out.println("Also verify card transaction status from db if transaction has been succeed when user's card is not activated");
        if(card.getIsCardTransactionSuccess()){
            successCardTransactionValidationFromDB(payer,card); // calling method to validate card transaction from DB
        }
        else {
            System.out.println("Card Transaction failed");
        }
    }

    // ************************* Card Transaction when user's wallet account is not activated *****************************
    @Given("User login with valid cred to do card transaction when user's wallet account is not activated")
    public void user_login_with_valid_cred_to_do_card_transaction_when_user_s_wallet_account_is_not_activated() throws FileNotFoundException {
        System.out.println("User login with valid cred to do card transaction when user's wallet account is not activated");
        res = login(reader.getValueFromConfig("vc.user.mobile.number.withoutwallet"),reader.getValueFromConfig("vc.user.passcode.withoutwallet"),reader.getValueFromConfig("vc.user.deviceid.withoutwallet"),reader.getValueFromConfig("vc.user.deviceid.withoutwallet"));
        payerAccessToken = getAccessTokenResponseData(res,"access_token");
        payer.setSenderAccountId(reader.getValueFromConfig("vc.user.mobile.number.withoutwallet"));
    }
    @Given("After entering card details user try to proceed card transaction")
    public void after_entering_card_details_user_try_to_proceed_card_transaction() throws FileNotFoundException {
        System.out.println("After entering card details user try to proceed card transaction");
        card.setCustomerId(reader.getValueFromConfig("wallet.card.customer.id")); // setting card customer id
        card.setCardToken(reader.getValueFromConfig("wallet.card.token")); // setting card token
        card.setMerchantCategoryCode(reader.getValueFromConfig("wallet.card.merchant.category.code")); // setting merchant category code
        card.setMerchantId(reader.getValueFromConfig("wallet.card.merchant.id"));  //setting merchant id
        card.setLocation(reader.getValueFromConfig("wallet.card.location")); // setting transaction platform
        card.setChannel(reader.getValueFromConfig("wallet.card.channel"));
        card.setTransactionType(String.valueOf(TransTypeEnum.CARD_PAYMENT));
        card.setTransactionAmount(String.valueOf(getRandomAmount())); // setting amount to do transaction
    }
    @Then("Verify card transaction status when user's wallet account is not activated")
    public void verify_card_transaction_status_when_user_s_wallet_account_is_not_activated() throws FileNotFoundException {
        System.out.println("Verify card transaction status when user's wallet account is not activated");
        card.setTransactionId(generateRandomNumber()); //setting transaction id
        card.setOtp(generateRandomNumber()); // setting otp
        res = sendCardTransactionOtp(card,payerAccessToken);
        System.out.println(res.asPrettyString());
        if(res.getStatusCode()!=HTTP_OK){
            cardTransactionErrorValidation(res,card);
        }
        else {
            responseObject = extractJsonObjectFromResponse(res);
            assertJsonValueEquals("message","Success",responseObject);
        }
        card.setTransactionNumber(generateRandomNumber());
        res = payCard(card,payerAccessToken); // calling method for card transaction
        System.out.println(res.asPrettyString());
        if(res.getStatusCode()!=HTTP_OK){
            card.setIsCardTransactionSuccess(false);
            cardTransactionErrorValidation(res,card); // calling method for card transaction error validation
        }
        else {
            Assert.assertEquals("FAILED","SUCCESS");
        }
    }
}
