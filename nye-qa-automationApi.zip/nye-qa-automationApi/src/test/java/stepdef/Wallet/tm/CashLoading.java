package stepdef.Wallet.tm;

import base.BaseBuilder;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.restassured.response.Response;
import org.json.JSONObject;
import org.junit.Assert;
import utilities.CommonStepDef;
import utilities.PropertyReader;
import utilities.Utils;

import java.io.FileNotFoundException;

import static utilities.CommonStepDef.*;
import static utilities.GlobalConstant.HTTP_OK;
import static utilities.Utils.*;

public class CashLoading {

    private static Response res;
    private static String idToken;
    private static String amount;
    private static String userMobileNumber;
    private static JSONObject jsonObject;
    private static String transactionHeaderId;
    private static PropertyReader reader = new PropertyReader();


    @Given("Admin has a valid cred for login to do cash loading transaction")
    public void admin_has_a_valid_cred_for_login_to_do_cash_loading_transaction() throws FileNotFoundException {
        System.out.println("Admin has a valid cred for login to do cash loading transaction");
        res = cashLoadingLogin(); // calling login admin method
        if(res.getStatusCode()!=HTTP_OK){
            System.out.println(res.asPrettyString());
            Assert.assertEquals("Login success","Login Failed");
        }
        else {
            jsonSchemaValidator(res,reader.getValueFromConfig("wallet.cash.loading.login.valid.schema"));
            jsonObject = extractJsonObjectFromResponse(res);
            assertJsonValueEquals("expiresIn",reader.getValueFromConfig("wallet.cash.loading.login.expires.in"),jsonObject);
            assertJsonValueEquals("tokenType",reader.getValueFromConfig("wallet.cash.loading.login.token.type"),jsonObject);
        }
    }
    @Given("After login admin get a valid id token to do cash loading transaction")
    public void after_login_admin_get_a_valid_id_token_to_do_cash_loading_transaction() {
        System.out.println("After login admin get a valid id token to do cash loading transaction");
        idToken = (String) getResponseData(res,"idToken");
    }
    @Given("Admin enter beneficiary account number to do cash loading transaction")
    public void admin_enter_beneficiary_account_number_to_do_cash_loading_transaction() {
        System.out.println("Admin enter beneficiary account number to do cash loading transaction");
        userMobileNumber = reader.getValueFromConfig("wallet.cash.loading.user.mobile.number");
    }
    @Given("Admin enter amount for cash loading transaction")
    public void admin_enter_amount_for_cash_loading_transaction() {
        System.out.println("Admin enter amount for cash loading transaction");
        amount = reader.getValueFromConfig("wallet.cash.loading.amount");
    }
    @Given("Admin click cash loading api to do cash loading transaction")
    public void admin_click_cash_loading_api_to_do_cash_loading_transaction() throws FileNotFoundException {
        System.out.println("Admin click cash loading api to do cash loading transaction");
        res = cashLoadingPayment(userMobileNumber,amount,idToken);
        System.out.println(res.asPrettyString());
    }
    @Then("Verify cash loading transaction status")
    public void verify_cash_loading_transaction_status() {
        System.out.println("Verify cash loading transaction status");
        jsonObject = extractJsonObjectFromResponse(res);
        if(res.getStatusCode()!=HTTP_OK){
            System.out.println(res.asPrettyString());
            jsonSchemaValidator(res,reader.getValueFromConfig("wallet.cash.loading.payment.limit.exceed.valid.schema"));
            JSONObject errors = extractJsonValueFromJsonArray(jsonObject,"errors",0);
            if(getValueFromJSONObject(errors,"code").equals("NYE-TM-223")){
                assertJsonValueEquals("message","No of cash load attempts reached",errors);
                assertJsonValueEquals("description","Limit exceeded,only 3 cash load transaction allowed in 24 hours",errors);
            }
            else if(getValueFromJSONObject(errors,"code").equals("NYE-TM-214")){
                assertJsonValueEquals("message","Cash loading limit breached",errors);
                assertJsonValueEquals("description","Monthly cash load limit exceeded",errors);
            }

            else {   //if(getValueFromJSONObject(errors,"code").equals("NYE-TM-247")){
                assertJsonValueEquals("message","Maximum limit breached",errors);
                assertJsonValueEquals("description","Limit exceeded,only 1 cash load transaction allowed in 30 minutes",errors);
            }
        }
        else {
            jsonSchemaValidator(res,reader.getValueFromConfig("wallet.cash.loading.payment.success.valid.schema"));
            assertJsonValueEquals("result","Success",jsonObject);
            transactionHeaderId = getValueFromJSONObject(jsonObject,"paymentRefId");
        }
    }
    @Then("Also verify cash loading transaction status from db if transaction has been succeed")
    public void also_verify_cash_loading_transaction_status_from_db_if_transaction_has_been_succeed() {
        System.out.println("Also verify cash loading transaction status from db if transaction has been succeed");
        System.out.println(transactionHeaderId);
        if(transactionHeaderId!=null){

        }
        else {
            System.out.println("Cash loading transaction not success and not verified from DB!!!!");
        }
    }
}
