package stepdef.Wallet.Mandate;

import base.BaseBuilder;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.restassured.response.Response;
import org.joda.time.LocalDate;
import org.json.JSONArray;
import org.json.JSONObject;
import org.junit.Assert;
import resources.*;
import utilities.*;

import java.io.FileNotFoundException;
import static utilities.CommonStepDef.*;
import static utilities.GlobalConstant.HTTP_CREATED;
import static utilities.GlobalConstant.HTTP_OK;
import static utilities.Utils.*;

public class UPIMandate {

    private String accessToken;
    private PropertyReader reader = new PropertyReader();
    private static BaseBuilder baseBuilder = new BaseBuilder();
    private Response res;
    private static String payeeAccessToken;
    private static String payerAccessToken;
    private static String requestId;
    private static JSONObject responseObject;
    private static String payeeVpa;
    private static String payeeName;
    private static Boolean flag = false;

    private static Payer payer = new Payer();
    private static Payee payee = new Payee();



    // ************************* Create Payee Initiated mandate *****************************
    @Given("Payee login with valid credentials")
    public void login_with_valid_credentials() throws FileNotFoundException {
        System.out.println("Payee login with valid credentials");
        res = login(reader.getValueFromConfig("payee.mobile.number"),reader.getValueFromConfig("payee.passcode"),reader.getValueFromConfig("payee.device.id"),reader.getValueFromConfig("payee.device.id"));
        if(res.getStatusCode()!=HTTP_OK){
            System.out.println(res.asPrettyString());
        }
        else {
            payeeAccessToken = getAccessTokenResponseData(res,"access_token");
        }
    }

    @Given("Payee have a valid details of payer for mandate request")
    public void payee_have_a_valid_details_of_payer_for_mandate_request() throws FileNotFoundException, InterruptedException {
        System.out.println("Payee have a valid details of payer for mandate request");
        // verify payer vpa
        String payerVpa = reader.getValueFromConfig("payer.vpa");
        res = verifyUPI(payerVpa,payeeAccessToken); // calling verify by requestId method
        if(res.getStatusCode()!=HTTP_OK){
            System.out.println(res.asPrettyString());
            responseObject = extractJsonObjectFromResponse(res);
            jsonSchemaValidator(res,reader.getValueFromConfig("wallet.transaction.error.valid.schema"));
            JSONObject errorsFromResponse = extractJsonValueFromJsonArray(responseObject,"errors",0);
            if(getValueFromJSONObject(errorsFromResponse,"code").equals("NYE-PPI-046")){ // assertion for invalid vpa
                assertJsonValueEquals("message","Invalid Vpa",errorsFromResponse);
                assertJsonValueEquals("description","Please enter correct Vpa",errorsFromResponse);
            }
            else {
                // assertion for other condition
                Assert.assertTrue(false);
            }

        }
        else {
            jsonSchemaValidator(res,reader.getValueFromConfig("wallet.common.valid.schema"));
            requestId = (String) getResponseData(res,"results.data");
            res = verifyByRequestId(requestId,payeeAccessToken,false); // calling verify by requestId method
            responseObject = extractJsonObjectFromResponse(res);
            if(res.getStatusCode()!=HTTP_OK){
                System.out.println(res.asPrettyString());
                responseObject = extractJsonObjectFromResponse(res);
                jsonSchemaValidator(res,reader.getValueFromConfig("wallet.transaction.error.valid.schema"));
                JSONObject errorsFromResponse = extractJsonValueFromJsonArray(responseObject,"errors",0);
                if(getValueFromJSONObject(errorsFromResponse,"code").equals("NYE-PPI-023")){  // assertion for invalid vpa
                    assertJsonValueEquals("message","UPI not found",errorsFromResponse);
                    assertJsonValueEquals("description","UPI not found",errorsFromResponse);
                }
                else {
                    // assertion for other condition
                    Assert.assertTrue(false);
                }

            }
            else {
                jsonSchemaValidator(res,reader.getValueFromConfig("wallet.verify.vpa.request.id.valid.schema"));
                assertJsonValueEquals("message","Success",responseObject);
                payer.setSenderVpa(payerVpa);
                payer.setSenderName((String) getResponseData(res,"results.vpaHoldername"));
                payer.setRecurrencePattern(String.valueOf(RecurrencePatternEnum.ASPRESENTED));
            }
        }
    }
    @Given("Payee raised mandate request to payer")
    public void raised_mandate_request_to_payer() throws FileNotFoundException {
        System.out.println("Payee raised mandate request to payer");
        payee.setAmount(reader.getValueFromConfig("amount"));
        payee.setTriggerAmount(reader.getValueFromConfig("trigger.amount"));
        res = createMandate(payee,payer,payeeAccessToken);
    }

    @Given("Verify the payee initiated mandate creation status")
    public void verify_the_mandate_creation_status() {
        System.out.println("Verify the payee initiated mandate creation status");
        responseObject = extractJsonObjectFromResponse(res);
        if(res.getStatusCode()!=HTTP_CREATED){
            // condition for other cases
            System.out.println(res.asPrettyString());
            JSONObject errorsFromResponse = extractJsonValueFromJsonArray(responseObject,"errors",0);
            if(getValueFromJSONObject(errorsFromResponse,"code").equals("NYE-PPI-MANDATE-017")){  // assertion for no mandate list
                assertJsonValueEquals("message","You have already created AutoPay",errorsFromResponse);
                assertJsonValueEquals("description","Please verify your credential",errorsFromResponse);
            }
            else {
                // assertion for other condition
                Assert.assertTrue(false);
            }
        }
        else {
            jsonSchemaValidator(res,reader.getValueFromConfig("wallet.mandate.valid.schema"));
            JSONObject results = extractNestedJsonObject(responseObject,"results");
            assertJsonValueEquals("amount",payee.getAmount(),results);
            assertJsonValueEquals("vpa",payer.getSenderVpa(),results);
            assertJsonValueEquals("name",payer.getSenderName(),results);
            assertJsonValueEquals("recurrencePattern", String.valueOf(RecurrencePatternEnum.ASPRESENTED),results);
            assertJsonValueEquals("amountRule", reader.getValueFromConfig("wallet.amount.rule"),results);
        }
    }


    // ************************* Decline Payee Initiated Mandate *****************************

    @Given("Payer have all pending mandate list for decline")
    public void payer_have_all_pending_mandate_list_for_decline() throws FileNotFoundException {
        System.out.println("Payer have all pending mandate list for decline");
        res = login(reader.getValueFromConfig("payer.mobile.number"),reader.getValueFromConfig("payer.passcode"),reader.getValueFromConfig("payer.device.id"),reader.getValueFromConfig("payer.device.id"));
        if(res.getStatusCode()!=HTTP_OK){
            // condition for unauthorized user
            System.out.println(res.asPrettyString());
        }
        else {
            payerAccessToken = getAccessTokenResponseData(res,"access_token");
        }
        res = getPendingMandateList(payerAccessToken);
    }
    @Given("Payer decline mandate of payee")
    public void payer_decline_mandate_of_payee() throws FileNotFoundException {
        System.out.println("Payer decline mandate of payee");
        responseObject = extractJsonObjectFromResponse(res);
        if(res.getStatusCode()!=HTTP_OK){
            System.out.println(res.asPrettyString());

            Assert.assertTrue(false);
        }
        else {
            JSONObject results = extractNestedJsonObject(responseObject,"results");
            assertJsonValueEquals("message","Pending Mandate Executed",responseObject);
            if(getValueFromJSONObject(results,"totalCount").equals("0")){
                // condition for no mandate list
                flag = true;
                System.out.println("No pending mandate");
                jsonSchemaValidator(res,reader.getValueFromConfig("wallet.no.pending.mandate.list.valid.schema"));
            }
            else {
                JSONObject data = extractJsonValueFromJsonArray(results,"data",0);
                payer.setAmount(getValueFromJSONObject(data,"amount"));
                payer.setBeneName(getValueFromJSONObject(data,"beneName"));
                payer.setTxnId(getValueFromJSONObject(data,"txnid"));
                payer.setValidityEnd(getValueFromJSONObject(data,"validityEnd"));
                payer.setAmountRule(reader.getValueFromConfig("wallet.amount.rule"));
                payer.setRecurrencePattern(String.valueOf(RecurrencePatternEnum.ASPRESENTED));
                payer.setPasscode(getEncryptedAuthData(reader.getValueFromConfig("payer.passcode")));
                res = approveDeclineModifyMandate(payer, String.valueOf(TransTypeEnum.DECLINE),payerAccessToken);  // passing enum for decline
            }
        }

    }
    @Given("Verify mandate decline status")
    public void verify_mandate_decline_status() {
        System.out.println("Verify mandate decline status");
        responseObject = extractJsonObjectFromResponse(res);
        if(res.getStatusCode()!=HTTP_OK){
            System.out.println(res.asPrettyString());
            JSONObject errorsFromResponse = extractJsonValueFromJsonArray(responseObject,"errors",0);
            if(getValueFromJSONObject(errorsFromResponse,"code").equals("NYE-PPI-MANDATE-012")){  // assertion for no mandate list
                assertJsonValueEquals("message","No AutoPay for this walletId",errorsFromResponse);
                assertJsonValueEquals("description","Please verify your credential",errorsFromResponse);
            }
            else {
                Assert.assertTrue(false);
            }
        }
        else {
            JSONObject results = extractNestedJsonObject(responseObject,"results");
            if(flag && getValueFromJSONObject(results,"totalCount").equals("0")){
                // condition for no mandate list
                assertJsonValueEquals("message","Pending Mandate Executed",responseObject);
                System.out.println("No pending mandate");
                jsonSchemaValidator(res,reader.getValueFromConfig("wallet.no.pending.mandate.list.valid.schema"));
            }
            else {
                jsonSchemaValidator(res,reader.getValueFromConfig("wallet.decline.mandate.valid.schema"));
                assertJsonValueEquals("message","Mandate Authorized",responseObject);
                assertJsonValueEquals("amount",payer.getAmount(),results);
                assertJsonValueEquals("vpa",reader.getValueFromConfig("payee.vpa"),results);
                assertJsonValueEquals("validityEnd",payer.getValidityEnd(),results);
                assertJsonValueEquals("recurrencePattern",payer.getRecurrencePattern(),results);
                assertJsonValueEquals("amountRule",payer.getAmountRule(),results);
            }
        }
    }



    // ************************* Approve Payee Initiated Mandate *****************************
    @Given("Payer have all pending mandate list")
    public void all_pending_mandate_list() throws FileNotFoundException {
        System.out.println("Payer have all pending mandate list");
        res = login(reader.getValueFromConfig("payer.mobile.number"),reader.getValueFromConfig("payer.passcode"),reader.getValueFromConfig("payer.device.id"),reader.getValueFromConfig("payer.device.id"));
        if(res.getStatusCode()!=HTTP_OK){
            // condition for unauthorized user
            System.out.println(res.asPrettyString());
        }
        else {
            payerAccessToken = getAccessTokenResponseData(res,"access_token");
        }
        res = getPendingMandateList(payerAccessToken);

    }
    @Given("Payer approved mandate of payee")
    public void approve_payee_initiated_mandate() throws FileNotFoundException {
        System.out.println("Payer approved mandate of payee");
        responseObject = extractJsonObjectFromResponse(res);
        if(res.getStatusCode()!=HTTP_OK){
            System.out.println(res.asPrettyString());
            Assert.assertTrue(false);
        }
        else {
            JSONObject results = extractNestedJsonObject(responseObject,"results");
            assertJsonValueEquals("message","Pending Mandate Executed",responseObject);
            if(getValueFromJSONObject(results,"totalCount").equals("0")){
                // condition for no mandate list
                flag = true;
                System.out.println("No pending mandate");
                jsonSchemaValidator(res,reader.getValueFromConfig("wallet.no.pending.mandate.list.valid.schema"));
            }
            else {
                JSONObject data = extractJsonValueFromJsonArray(results,"data",0);
                payer.setAmount(getValueFromJSONObject(data,"amount"));
                payer.setBeneName(getValueFromJSONObject(data,"beneName"));
                payer.setTxnId(getValueFromJSONObject(data,"txnid"));
                payer.setValidityEnd(getValueFromJSONObject(data,"validityEnd"));
                payer.setAmountRule(reader.getValueFromConfig("wallet.amount.rule"));
                payer.setRecurrencePattern(String.valueOf(RecurrencePatternEnum.ASPRESENTED));
                payer.setPasscode(getEncryptedAuthData(reader.getValueFromConfig("payer.passcode")));
                res = approveDeclineModifyMandate(payer, String.valueOf(TransTypeEnum.APPROVE),payerAccessToken);
            }
        }



    }
    @Given("Verify mandate approval status")
    public void verify_mandate_approval_state() {
        System.out.println("Verify mandate approval status");
        responseObject = extractJsonObjectFromResponse(res);
        if(res.getStatusCode()!=HTTP_OK) {
            System.out.println(res.asPrettyString());
            JSONObject errorsFromResponse = extractJsonValueFromJsonArray(responseObject, "errors", 0);
            if (getValueFromJSONObject(errorsFromResponse, "code").equals("NYE-PPI-MANDATE-012")) {  // assertion for no mandate list
                assertJsonValueEquals("message", "No AutoPay for this walletId", errorsFromResponse);
                assertJsonValueEquals("description", "Please verify your credential", errorsFromResponse);
            } else {
                Assert.assertTrue(false);
            }
        }
        else {
            JSONObject results = extractNestedJsonObject(responseObject, "results");
            if (flag && getValueFromJSONObject(results, "totalCount").equals("0")) {
                // condition for no mandate list
                assertJsonValueEquals("message","Pending Mandate Executed",responseObject);
                System.out.println("No pending mandate");
                jsonSchemaValidator(res, reader.getValueFromConfig("wallet.no.pending.mandate.list.valid.schema"));
            } else {
                jsonSchemaValidator(res, reader.getValueFromConfig("wallet.decline.mandate.valid.schema"));
                assertJsonValueEquals("message","Mandate Authorized",responseObject);
                assertJsonValueEquals("amount", payer.getAmount(), results);
                assertJsonValueEquals("vpa", reader.getValueFromConfig("payee.vpa"), results);
                assertJsonValueEquals("validityEnd", payer.getValidityEnd(), results);
                assertJsonValueEquals("recurrencePattern", payer.getRecurrencePattern(), results);
                assertJsonValueEquals("amountRule", payer.getAmountRule(), results);
            }
        }
    }

    // ************************* Modify Payee Initiated Mandate - Decline , Approve*****************************
    @Given("Payee have a valid active mandate for modify")
    public void payee_have_a_valid_active_mandate_for_modify() throws FileNotFoundException {
        System.out.println("Payee have a valid active mandate for modify");
        //login and get payee access token
        res = login(reader.getValueFromConfig("payee.mobile.number"),reader.getValueFromConfig("payee.passcode"),reader.getValueFromConfig("payee.device.id"),reader.getValueFromConfig("payee.device.id"));
        if(res.getStatusCode()!=HTTP_OK){
            //conditions for unauthorized users
            System.out.println(res.asPrettyString());
        }
        else {
            payeeAccessToken = getAccessTokenResponseData(res,"access_token");
        }
        res = getMandateByEnum(payeeAccessToken, String.valueOf(MandateEnum.BY_ME));  //calling mandate by me api
        responseObject = extractJsonObjectFromResponse(res);
        JSONArray results = extractJsonArrayFromJsonObject(responseObject,"results"); // extraction results from response
       boolean temp = false;
        for(Object resultObject : results){  // searching payee initiated mandate
            if((getValueFromJSONObject((JSONObject) resultObject,"status").equals(String.valueOf(MandateEnum.ACTIVE))) && (getValueFromJSONObject((JSONObject) resultObject,"recurrencePattern").equals(String.valueOf(RecurrencePatternEnum.ASPRESENTED))) ){
                flag = true;
                String validity = getValueFromJSONObject((JSONObject) resultObject,"validityEnd");
                payer.setModifiedAmount(String.valueOf(getRandomAmount()));  // setting modified amount
                payer.setModifiedValidity(getModifyValidity(validity));   // setting modified validity
                payer.setTxnId(getValueFromJSONObject((JSONObject) resultObject,"mandateCreationId"));
                payer.setPasscode(getEncryptedAuthData(reader.getValueFromConfig("payee.passcode")));
                payer.setSenderVpa(getValueFromJSONObject((JSONObject) resultObject,"vpa"));
                temp = true;
            }
        }
        if(!temp){
            flag = false;
        }

    }
    @Given("Payee raised mandate modification request to payer {string}")
    public void payee_raised_mandate_modification_request_to_payer(String transTypeEnum) throws FileNotFoundException {
        System.out.println("Payee raised mandate modification request to payer");
        if(flag){
            res = approveDeclineModifyMandate(payer,transTypeEnum,payeeAccessToken);  // call modify mandate method
        }
        else {
            System.out.println("There is no payee initiated active mandate!   First create mandate then try to modify");
            Assert.assertTrue(true);
        }
    }
    @Then("Verify mandate modification request status")
    public void verify_mandate_modification_request_status() {
        System.out.println("Verify mandate modification request status");
        if(flag){
            responseObject = extractJsonObjectFromResponse(res);
            if(res.getStatusCode()!=HTTP_OK){
                // other conditions
                System.out.println(res.asPrettyString());
                Assert.assertTrue(false);

            }
            else {
                jsonSchemaValidator(res,reader.getValueFromConfig("wallet.modify.mandate.valid.schema"));
                JSONObject results = extractNestedJsonObject(responseObject,"results");
                assertJsonValueEquals("amount",payer.getModifiedAmount(),results);
                assertJsonValueEquals("vpa",payer.getSenderVpa(),results);
                assertJsonValueEquals("refId",payer.getTxnId(),results);
                assertJsonValueEquals("validityEnd",payer.getModifiedValidity(),results);
                assertJsonValueEquals("recurrencePattern", String.valueOf(RecurrencePatternEnum.ASPRESENTED),results);

            }
        }
        else {
            System.out.println("There is no payee initiated active mandate!   First create mandate then try to modify");
            Assert.assertTrue(true);
        }
    }
    @Then("Payer received mandate modification request from payee")
    public void payer_received_mandate_modification_request_from_payee() throws FileNotFoundException {
        System.out.println("Payer received mandate modification request from payee");
        //payer login
        res = login(reader.getValueFromConfig("payer.mobile.number"),reader.getValueFromConfig("payer.passcode"),reader.getValueFromConfig("payer.device.id"),reader.getValueFromConfig("payer.device.id"));
        if(res.getStatusCode()!=HTTP_OK){
            // condition for unauthorized user
            System.out.println(res.asPrettyString());
        }
        else {
            payerAccessToken = getAccessTokenResponseData(res,"access_token");
        }
        res = getPendingMandateList(payerAccessToken);   //call pending mandate list
        responseObject = extractJsonObjectFromResponse(res);
        if(res.getStatusCode()!=HTTP_OK){
            System.out.println(res.asPrettyString());
            Assert.assertTrue(false);
        }
        else {
            JSONObject results = extractNestedJsonObject(responseObject,"results");
            assertJsonValueEquals("message","Pending Mandate Executed",responseObject);
            if(getValueFromJSONObject(results,"totalCount").equals("0")){
                // condition for no mandate list
                flag = false;
                System.out.println("No pending mandate");
                jsonSchemaValidator(res,reader.getValueFromConfig("wallet.no.pending.mandate.list.valid.schema"));
            }
            else {
                JSONObject data = extractJsonValueFromJsonArray(results,"data",0);
                payer.setAmount(getValueFromJSONObject(data,"amount"));
                payer.setBeneName(getValueFromJSONObject(data,"beneName"));
                payer.setTxnId(getValueFromJSONObject(data,"txnid"));
                payer.setValidityEnd(getValueFromJSONObject(data,"validityEnd"));
                payer.setAmountRule(reader.getValueFromConfig("wallet.amount.rule"));
                payer.setRecurrencePattern(String.valueOf(RecurrencePatternEnum.ASPRESENTED));
                payer.setPasscode(getEncryptedAuthData(reader.getValueFromConfig("payer.passcode")));
            }
        }
    }
    @Then("Payer mandate modification request of payee {string}")
    public void payer_approve_mandate_modification_request_of_payee(String transTypeEnum) throws FileNotFoundException {
        System.out.println("Payer approve mandate modification request of payee");
        if(flag){
            res = approveDeclineModifyMandate(payer, transTypeEnum,payerAccessToken);  // calling approve mandate method
        }
        else {
            System.out.println("There is no Pending Mandate! First create mandate then try to modify");
            Assert.assertTrue(true);
        }

    }
    @Then("Verify mandate modification status")
    public void verify_mandate_modification_status() {
        System.out.println("Verify mandate  modification status");
        if(flag){
            responseObject = extractJsonObjectFromResponse(res);
            if(res.getStatusCode()!=HTTP_OK) {
                System.out.println(res.asPrettyString());
                JSONObject errorsFromResponse = extractJsonValueFromJsonArray(responseObject, "errors", 0);
                if (getValueFromJSONObject(errorsFromResponse, "code").equals("NYE-PPI-MANDATE-012")) {  // assertion for no mandate list
                    assertJsonValueEquals("message", "No AutoPay for this walletId", errorsFromResponse);
                    assertJsonValueEquals("description", "Please verify your credential", errorsFromResponse);
                } else {
                    Assert.assertTrue(false);
                }
            }
            else {
                jsonSchemaValidator(res,reader.getValueFromConfig("wallet.modify.approve.mandate.valid.schema"));
                JSONObject results = extractNestedJsonObject(responseObject,"results");
                assertJsonValueEquals("amount",payer.getAmount(),results);
                assertJsonValueEquals("vpa",reader.getValueFromConfig("payee.vpa"),results);
                assertJsonValueEquals("validityEnd",payer.getValidityEnd(),results);
                assertJsonValueEquals("recurrencePattern",payer.getRecurrencePattern(),results);
                assertJsonValueEquals("amountRule",payer.getAmountRule(),results);
            }
        }
        else {
            System.out.println("There is no Pending Mandate! First create mandate then try to modify");
            Assert.assertTrue(true);
        }
    }

    // ************************* Cancelled Payee Initiated Mandate *****************************
    @Given("{string} have a valid active mandate for cancel with valid {string}")
    public void have_a_valid_active_mandate_for_cancel_with_valid(String userType, String mandateTypeEnum) throws FileNotFoundException {
        System.out.println(userType+" have a valid active mandate for cancel with valid "+mandateTypeEnum);
        if(userType.equals("PAYEE")){
            // get payee access token
            res = login(reader.getValueFromConfig("payee.mobile.number"),reader.getValueFromConfig("payee.passcode"),reader.getValueFromConfig("payee.device.id"),reader.getValueFromConfig("payee.device.id"));
            if(res.getStatusCode()!=HTTP_OK){
                //conditions for unauthorized users
                System.out.println(res.asPrettyString());
                Assert.assertTrue(false);
            }
            else {
                accessToken = getAccessTokenResponseData(res,"access_token");
            }
        }
        else {
            // get payer access token
            res = login(reader.getValueFromConfig("payer.mobile.number"),reader.getValueFromConfig("payer.passcode"),reader.getValueFromConfig("payer.device.id"),reader.getValueFromConfig("payer.device.id"));
            if(res.getStatusCode()!=HTTP_OK){
                //conditions for unauthorized users
                System.out.println(res.asPrettyString());
                Assert.assertTrue(false);
            }
            else {
                accessToken = getAccessTokenResponseData(res,"access_token");
            }
        }

        res = getMandateByEnum(accessToken, mandateTypeEnum);  //calling mandate by others api
        responseObject = extractJsonObjectFromResponse(res);
        JSONArray results = extractJsonArrayFromJsonObject(responseObject,"results"); // extraction results from response
        boolean temp = false;
        for(Object resultObject : results){  // searching payee initiated mandate
            if((getValueFromJSONObject((JSONObject) resultObject,"status").equals(String.valueOf(MandateEnum.ACTIVE))) && (getValueFromJSONObject((JSONObject) resultObject,"recurrencePattern").equals(String.valueOf(RecurrencePatternEnum.ASPRESENTED))) ){
                flag = true;
                String id = getValueFromJSONObject((JSONObject) resultObject,"mandateCreationId");
                res = getMandateById(accessToken,id);  // calling get mandate by id api
                if(res.getStatusCode()!=HTTP_OK){
                    // conditions for failed scenario
                    System.out.println(res.asPrettyString());
                    Assert.assertTrue(false);
                }
                else {
                    temp = true;
                    payer.setTxnId((String) getResponseData(res,"results.mandateCreationId"));
                    if(userType.equals("PAYEE")){
                        payer.setPasscode(getEncryptedAuthData(reader.getValueFromConfig("payee.passcode"))); // setting payee cred
                    }
                    else {
                        payer.setPasscode(getEncryptedAuthData(reader.getValueFromConfig("payer.passcode"))); // setting payer cred
                    }
                    payer.setSenderVpa((String) getResponseData(res,"results.vpa"));
                    payer.setAmount((String) getResponseData(res,"results.amount"));
                    payer.setUmn((String) getResponseData(res,"results.umn"));
                    payer.setSenderName((String) getResponseData(res,"results.name"));
                    payer.setValidityStart((String) getResponseData(res,"results.validityStart"));
                    payer.setValidityEnd((String) getResponseData(res,"results.validityEnd"));
                    payer.setRecurrencePattern((String) getResponseData(res,"results.recurrencePattern"));
                    payer.setAmountRule((String) getResponseData(res,"results.amountRule"));
                }
            }

        }
        if(!temp){
            flag = false;
        }

    }

    @Given("User cancelled the mandate")
    public void user_cancelled_the_mandate() throws FileNotFoundException {
        System.out.println("User cancelled the mandate");
        if(flag){
            res = approveDeclineModifyMandate(payer,String.valueOf(TransTypeEnum.REVOKE),accessToken);  // call modify mandate method
        }
        else {
            System.out.println("There is no payee initiated active mandate!   First create mandate then try to modify");
            Assert.assertTrue(true);
        }
    }
    @Then("Verify payee initiated mandate cancel status")
    public void verify_payee_initiated_mandate_cancel_status() {
        System.out.println("Verify payee initiated mandate cancel status");
        if(flag){
            responseObject = extractJsonObjectFromResponse(res);
            if(res.getStatusCode()!=HTTP_OK){
                System.out.println(res.asPrettyString());
                JSONObject errorsFromResponse = extractJsonValueFromJsonArray(responseObject, "errors", 0);
                if(getValueFromJSONObject(errorsFromResponse,"code").equals("NYE-PPI-MANDATE-016")){
                    assertJsonValueEquals("message","Only Approved AutoPay can be modified",errorsFromResponse);
                    assertJsonValueEquals("description","Please verify your mandate status",errorsFromResponse);
                }
                else {
                    Assert.assertTrue(false);
                }

            }
            else {
                System.out.println(res.asPrettyString());
                jsonSchemaValidator(res,reader.getValueFromConfig("wallet.modify.mandate.valid.schema"));
                JSONObject results = extractNestedJsonObject(responseObject,"results");
                assertJsonValueEquals("amount",payer.getAmount(),results);
                assertJsonValueEquals("vpa",payer.getSenderVpa(),results);
                assertJsonValueEquals("refId",payer.getTxnId(),results);
                assertJsonValueEquals("validityStart",payer.getValidityStart(),results);
                assertJsonValueEquals("validityEnd",payer.getValidityEnd(),results);
                assertJsonValueEquals("recurrencePattern", payer.getRecurrencePattern(),results);
                assertJsonValueEquals("name",payer.getSenderName(),results);
                assertJsonValueEquals("umn",payer.getUmn(),results);
                assertJsonValueEquals("amountRule",payer.getAmountRule(),results);

            }
        }
        else {
            System.out.println("There is no payee initiated active mandate!   First create mandate then try to modify");
            Assert.assertTrue(true);
        }
    }


    // ************************* Payer initiated mandate *****************************
    @Given("Payer have a valid vpa of payee for payer initiated mandate creation")
    public void payer_have_a_valid_vpa_of_payee_for_payer_initiated_mandate_creation() throws FileNotFoundException, InterruptedException {
        System.out.println("Payer have a valid vpa of payee for payer initiated mandate creation");
        //login with payer cred
        res = login(reader.getValueFromConfig("wallet.test.user1.mobile.number"),reader.getValueFromConfig("wallet.test.user1.passcode"),reader.getValueFromConfig("wallet.test.user1.device.id"),reader.getValueFromConfig("wallet.test.user1.device.id"));
        if(res.getStatusCode()!=HTTP_OK){
            // condition for unauthorized user
            System.out.println(res.asPrettyString());
            Assert.assertTrue(false);
        }
        else {
            payerAccessToken = getAccessTokenResponseData(res,"access_token");
        }

        // verify payee vpa
        payeeVpa = reader.getValueFromConfig("payee.vpa");
        res = verifyUPI(payeeVpa,payerAccessToken); // calling verify UPI method
        if(res.getStatusCode()!=HTTP_OK){
            System.out.println(res.asPrettyString());
            responseObject = extractJsonObjectFromResponse(res);
            JSONObject errorResponse = extractJsonValueFromJsonArray(responseObject,"errors",0);
            if(getValueFromJSONObject(errorResponse,"code").equals("NYE-PPI-222")){
                assertJsonValueEquals("message","UPI is not activated",errorResponse);
                assertJsonValueEquals("description","Please activate UPI first",errorResponse);
            }
            else{
                Assert.assertTrue(false);
            }

        }
        else {
            requestId = (String) getResponseData(res,"results.data");
            res = verifyByRequestId(requestId,payerAccessToken,false); // calling verify by requestId method
        }
        // verify payee vpa
        if (res.getStatusCode()!=HTTP_OK){
            System.out.println(res.asPrettyString());
            responseObject = extractJsonObjectFromResponse(res);
            JSONObject errorResponse = extractJsonValueFromJsonArray(responseObject,"errors",0);
            if(getValueFromJSONObject(errorResponse,"code").equals("NYE-PPI-222")){
                assertJsonValueEquals("message","UPI is not activated",errorResponse);
                assertJsonValueEquals("description","Please activate UPI first",errorResponse);
            }
            else{
                Assert.assertTrue(false);
            }

        }
        else {
            jsonSchemaValidator(res,reader.getValueFromConfig("wallet.verify.by.request.id.valid.schema"));
            responseObject = extractJsonObjectFromResponse(res);
            assertJsonValueEquals("message","Success",responseObject);
            JSONObject results = extractNestedJsonObject(responseObject,"results");
            payee.setReceiverVpa(payeeVpa);
            payee.setReceiverName(getValueFromJSONObject(results,"vpaHoldername"));

        }
    }
    @Given("On entering the amount to be transferred and comment")
    public void on_entering_the_amount_to_be_transferred_and_comment() {
        System.out.println("On entering the amount to be transferred and comment");
        payer.setAmount(String.valueOf(getRandomAmount()));
        payer.setComment(reader.getValueFromConfig("wallet.si.mandate.comment"));
    }
    @Given("On entering validity start and end date")
    public void on_entering_validity_start_and_end_date() {
        System.out.println("On entering validity start and end date");
        LocalDate currentDate = new LocalDate();
        payer.setValidityStart(String.valueOf(currentDate)); //
        payer.setValidityEnd(String.valueOf(currentDate.plusYears(1)));
    }
    @Given("On entering recurrence pattern {string}")
    public void on_entering_recurrence_pattern(String recurrencePattern) throws FileNotFoundException {
        System.out.println("On entering recurrence pattern "+recurrencePattern);
        if(recurrencePattern.equalsIgnoreCase(String.valueOf(RecurrencePatternEnum.YEARLY))){
            payer.setDebitStartAt(getDebitDate(payer.getValidityStart(),String.valueOf(RecurrencePatternEnum.YEARLY)));
        }
        else if(recurrencePattern.equalsIgnoreCase(String.valueOf(RecurrencePatternEnum.MONTHLY))){
            payer.setDebitStartAt(getDebitDate(payer.getValidityStart(),String.valueOf(RecurrencePatternEnum.MONTHLY)));
        }
        else if(recurrencePattern.equalsIgnoreCase(String.valueOf(RecurrencePatternEnum.WEEKLY))){
            payer.setDebitStartAt(getDebitDate(payer.getValidityStart(),String.valueOf(RecurrencePatternEnum.WEEKLY)));
        }
        payer.setRecurrencePattern(recurrencePattern);

        payer.setPasscode(getEncryptedAuthData(reader.getValueFromConfig("wallet.test.user1.passcode")));
    }
    @Given("Payer create mandate for payee")
    public void payer_create_mandate_for_payee() throws FileNotFoundException {
        System.out.println("Payer create mandate for payee");
        res = createMandate(payee,payer,payerAccessToken);  // calling method for mandate creation
    }
    @Then("Verify payer initiated mandate creation status")
    public void verify_payer_initiated_mandate_creation_status() {
        System.out.println("Verify payer initiated mandate creation status");
        responseObject = extractJsonObjectFromResponse(res);
        if(res.getStatusCode()!=HTTP_CREATED){
            System.out.println(res.asPrettyString());
            //failed cases scenario
            Assert.assertTrue(false);
        }
        else {

            if((payer.getRecurrencePattern().equals(String.valueOf(RecurrencePatternEnum.YEARLY))) || (payer.getRecurrencePattern().equals(String.valueOf(RecurrencePatternEnum.WEEKLY)))){
                jsonSchemaValidator(res,reader.getValueFromConfig("wallet.si.mandate.debit.start.at.valid.schema"));
            }
            else if(payer.getRecurrencePattern().equals(String.valueOf(RecurrencePatternEnum.MONTHLY))){
                jsonSchemaValidator(res,reader.getValueFromConfig("wallet.si.mandate.debit.start.at.valid.schema"));
            }
            else if(payer.getRecurrencePattern().equals(String.valueOf(RecurrencePatternEnum.ONETIME))){
                jsonSchemaValidator(res,reader.getValueFromConfig("wallet.si.mandate.onetime.valid.schema"));
            }
            else {
                jsonSchemaValidator(res,reader.getValueFromConfig("wallet.si.mandate.valid.schema"));
            }
            assertJsonValueEquals( "message","Payer Mandate created",responseObject);
            JSONObject results = extractNestedJsonObject(responseObject,"results");
            assertJsonValueEquals("amount",payer.getAmount(),results);
            assertJsonValueEquals("vpa",payee.getReceiverVpa(),results);
            assertJsonValueEquals("name",payee.getReceiverName(),results);
            assertJsonValueEquals("validityStart",payer.getValidityStart(),results);
            assertJsonValueEquals("validityEnd",payer.getValidityEnd(),results);
            assertJsonValueEquals("recurrencePattern",payer.getRecurrencePattern(),results);
            assertJsonValueEquals("amountRule",reader.getValueFromConfig("wallet.amount.rule"),results);
        }
    }
}
