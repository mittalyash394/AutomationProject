package stepdef.Wallet.UPITransaction;

import base.BaseBuilder;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.restassured.response.Response;
import org.json.JSONObject;
import org.junit.Assert;
import resources.Payee;
import resources.Payer;
import resources.TransTypeEnum;
import resources.Transaction;
import utilities.GlobalConstant;
import utilities.PropertyReader;

import java.io.FileNotFoundException;
import java.sql.SQLException;

import static utilities.CommonStepDef.*;
import static utilities.GlobalConstant.HTTP_OK;
import static utilities.Utils.*;

public class UPITransaction {
    private static PropertyReader reader = new PropertyReader();
    private static Response res ;
    private static String payeeAccessToken ;
    private static String payerAccessToken;
    private static String requestId;
    private static Double balance;
    private static JSONObject responseObject;
    private String transactionId;
    private String transactionHeaderId;

    private static BaseBuilder baseBuilder = new BaseBuilder();
    private static String transTypeEnum ;

    private Payee payee = new Payee();
    private Payer payer = new Payer();
    private static String payeeName;

    // ************************* upi transaction for invalid vpa *****************************
    @Given("User login with valid cred to do upi transaction for invalid vpa")
    public void user_login_with_valid_cred_to_do_upi_transaction_for_invalid_vpa() throws FileNotFoundException {
        System.out.println("User login with valid cred to do upi transaction for invalid vpa");
        res = login(reader.getValueFromConfig("wallet.upi.test.user7.mobile.number"),reader.getValueFromConfig("wallet.upi.test.user7.passcode"),reader.getValueFromConfig("wallet.upi.test.user7.device.id"),reader.getValueFromConfig("wallet.upi.test.user7.device.id"));
        payerAccessToken = getAccessTokenResponseData(res,"access_token");
    }
    @Given("User enter receiver detail to do upi transaction for invalid vpa")
    public void user_enter_receiver_detail_to_do_upi_transaction_for_invalid_vpa() throws FileNotFoundException, InterruptedException {
        System.out.println("User enter receiver detail to do upi transaction for invalid vpa");
        payee.setReceiverVpa(reader.getValueFromConfig("wallet.upi.external.inactive.vpa"));
        res = verifyUPI(payee.getReceiverVpa(),payerAccessToken); // calling verify by requestId method
        requestId = (String) getResponseData(res,"results.data");
        res = verifyByRequestId(requestId,payerAccessToken,false); // calling verify by requestId method
        if(res.getStatusCode()!=HTTP_OK){
            upiNotActivatedValidation(res); // calling method for error validation
        }
        else {
            Assert.assertEquals("UPI not activated","UPI activated");
        }

    }
    @Given("User enter amount and others details to do upi transaction for invalid vpa")
    public void user_enter_amount_and_others_details_to_do_upi_transaction_for_invalid_vpa() throws FileNotFoundException {
        System.out.println("User enter amount and others details to do upi transaction for invalid vpa");
        payee.setAmount(String.valueOf(getRandomAmount())); // setting amount
        payer.setPasscode(getEncryptedAuthData(reader.getValueFromConfig("wallet.test.user1.passcode")));
        transTypeEnum = String.valueOf(TransTypeEnum.WALLET_TO_OTHER_WALLET);
        payer.setAction(reader.getValueFromConfig("wallet.pay.action"));
        payer.setDeviceTypeEnum(reader.getValueFromConfig("device.type.enum"));
        payer.setComment(reader.getValueFromConfig("comment")); // setting comment
        payer.setUniqueFrontendId(getUniqueFrontendId());
    }
    @Given("User click pay api to do upi transaction for invalid vpa")
    public void user_click_pay_api_to_do_upi_transaction_for_invalid_vpa() throws FileNotFoundException {
        System.out.println("User click pay api to do upi transaction for invalid vpa");
        res = pay(payee,payer,transTypeEnum,payerAccessToken);
    }
    @Then("Verify upi transaction for invalid vpa")
    public void verify_upi_transaction_for_invalid_vpa() throws FileNotFoundException {
        System.out.println("Verify upi transaction for invalid vpa");
        if(res.getStatusCode()!=HTTP_OK){
            errorValidationOfTM(res,payee,payer); // calling method for error validation
        }
        else {
            Assert.assertEquals("UPI not activated","UPI activated");
        }
    }

    // ************************* UPI transaction for nye to nye user *****************************
    @Given("User login with valid cred to do upi transaction for nye to nye user")
    public void user_login_with_valid_cred_to_do_upi_transaction_for_nye_to_nye_user() throws FileNotFoundException {
        System.out.println("User login with valid cred to do upi transaction for nye to nye user");
        res = login(reader.getValueFromConfig("wallet.upi.test.user7.mobile.number"),reader.getValueFromConfig("wallet.upi.test.user7.passcode"),reader.getValueFromConfig("wallet.upi.test.user7.device.id"),reader.getValueFromConfig("wallet.upi.test.user7.device.id"));
        payerAccessToken = getAccessTokenResponseData(res,"access_token");
    }
    @Given("User enter receiver detail to do upi transaction for nye to nye user")
    public void user_enter_receiver_detail_to_do_upi_transaction_for_nye_to_nye_user() throws FileNotFoundException, InterruptedException {
        System.out.println("User enter receiver detail to do upi transaction for nye to nye user");
        payee.setReceiverVpa(reader.getValueFromConfig("wallet.upi.internal.vpa1"));
        res = verifyUPI(payee.getReceiverVpa(),payerAccessToken); // calling verify by requestId method
        requestId = (String) getResponseData(res,"results.data");
        res = verifyByRequestId(requestId,payerAccessToken,false); // calling verify by requestId method
        if(res.getStatusCode()!=HTTP_OK){
            upiNotActivatedValidation(res); // calling method for error validation
        }
        else {
            String payeeName = (String) getResponseData(res,"results.vpaHoldername"); // calling verify by requestId method
            payee.setReceiverName(payeeName);
        }
    }
    @Given("User enter amount and others details to do upi transaction for nye to nye user")
    public void user_enter_amount_and_others_details_to_do_upi_transaction_for_nye_to_nye_user() throws FileNotFoundException {
        System.out.println("User enter amount and others details to do upi transaction for nye to nye user");
        payee.setAmount(String.valueOf(getRandomAmount())); // setting amount
        payer.setPasscode(getEncryptedAuthData(reader.getValueFromConfig("wallet.test.user1.passcode")));
        transTypeEnum = String.valueOf(TransTypeEnum.WALLET_TO_OTHER_WALLET);
        payer.setAction(reader.getValueFromConfig("wallet.pay.action"));
        payer.setDeviceTypeEnum(reader.getValueFromConfig("device.type.enum"));
        payer.setComment(reader.getValueFromConfig("comment")); // setting comment
        payer.setUniqueFrontendId(getUniqueFrontendId());
        balance = Double.valueOf(getWalletBalance(payerAccessToken)); // fetching payer wallet balance
        payer.setWalletBalance(String.valueOf(balance));
        payer.setSenderVpa(reader.getValueFromConfig("wallet.upi.test.user7.vpa"));
    }
    @Given("User click pay api to do upi transaction for nye to nye user")
    public void user_click_pay_api_to_do_upi_transaction_for_nye_to_nye_user() throws FileNotFoundException {
        System.out.println("User click pay api to do upi transaction for nye to nye user");
        res = pay(payee,payer,transTypeEnum,payerAccessToken);
        if(res.getStatusCode()!=HTTP_OK){
            errorValidationOfTM(res,payee,payer);
        }
        else{
            assertJsonValueEquals("message","Success",extractJsonObjectFromResponse(res)); // assertion
            requestId = (String) getResponseData(res,"results.data");
            res = payByRequestId(requestId,payerAccessToken); //calling pay by request id
        }

    }
    @Then("Verify upi transaction for nye to nye user")
    public void verify_upi_transaction_for_nye_to_nye_user() throws FileNotFoundException {
        System.out.println("Verify upi transaction for nye to nye user");
        if(res.getStatusCode()!=HTTP_OK){
            payer.setIsTransactionSuccess(false); // when transaction failed
            errorValidationOfTM(res,payee,payer);
        }
        else {
            transactionId =  successTransactionValidation(res,payee,payer,transTypeEnum);
            payer.setIsTransactionSuccess(true);
        }
    }
    @Then("Also verify upi transaction status from db if transaction has been succeed for nye to nye user")
    public void also_verify_upi_transaction_status_from_db_if_transaction_has_been_succeed_for_nye_to_nye_user() throws SQLException {
        System.out.println("Also verify upi transaction status from db if transaction has been succeed for nye to nye user");
        if(payer.getIsTransactionSuccess() && transactionId!=null){
            Transaction transaction = getTransactionDetails(transactionId);
            System.out.println(transaction);
            successTransactionValidationFromDB(res,transaction,transTypeEnum);
            Assert.assertEquals(payer.getUniqueFrontendId(),transaction.getUniqueFrontendId()); // verifying unique frontend id
        }
        else {
            System.out.println("Transaction Failed! Transaction not Verified from DB");
        }
    }

    // ************************* UPI transaction for nye to external vpa *****************************
    @Given("User login with valid cred to do upi transaction for nye to external vpa")
    public void user_login_with_valid_cred_to_do_upi_transaction_for_nye_to_external_user() throws FileNotFoundException {
        System.out.println("User login with valid cred to do upi transaction for nye to external vpa");
        res = login(reader.getValueFromConfig("wallet.upi.test.user7.mobile.number"),reader.getValueFromConfig("wallet.upi.test.user7.passcode"),reader.getValueFromConfig("wallet.upi.test.user7.device.id"),reader.getValueFromConfig("wallet.upi.test.user7.device.id"));
        payerAccessToken = getAccessTokenResponseData(res,"access_token");
    }
    @Given("User enter receiver detail to do upi transaction for nye to external vpa")
    public void user_enter_receiver_detail_to_do_upi_transaction_for_nye_to_external_user() throws FileNotFoundException, InterruptedException {
        System.out.println("User enter receiver detail to do upi transaction for nye to external vpa");
        payee.setReceiverVpa(reader.getValueFromConfig("wallet.upi.external.vpa"));
        res = verifyUPI(payee.getReceiverVpa(),payerAccessToken); // calling verify by requestId method
        requestId = (String) getResponseData(res,"results.data");
        res = verifyByRequestId(requestId,payerAccessToken,true); // calling verify by requestId method
        if(res.getStatusCode()!=HTTP_OK){
            upiNotActivatedValidation(res); // calling method for error validation
        }
        else {
            String payeeName = (String) getResponseData(res,"results.vpaHoldername"); // calling verify by requestId method
            payee.setReceiverName(payeeName);
        }
    }
    @Given("User enter amount and others details to do upi transaction for nye to external vpa")
    public void user_enter_amount_and_others_details_to_do_upi_transaction_for_nye_to_external_user() throws FileNotFoundException {
        System.out.println("User enter amount and others details to do upi transaction for nye to external vpa");
        payee.setAmount(String.valueOf(getRandomAmount())); // setting amount
        payer.setPasscode(getEncryptedAuthData(reader.getValueFromConfig("wallet.upi.test.user7.passcode")));
        transTypeEnum = String.valueOf(TransTypeEnum.WALLET_TO_OTHER_WALLET);
        payer.setAction(reader.getValueFromConfig("wallet.pay.action"));
        payer.setDeviceTypeEnum(reader.getValueFromConfig("device.type.enum"));
        payer.setComment(reader.getValueFromConfig("comment")); // setting comment
        payer.setUniqueFrontendId(getUniqueFrontendId());
        balance = Double.valueOf(getWalletBalance(payerAccessToken)); // fetching payer wallet balance
        payer.setWalletBalance(String.valueOf(balance));
        payer.setSenderVpa(reader.getValueFromConfig("wallet.upi.test.user7.vpa"));
        payer.setSenderAccountId(reader.getValueFromConfig("wallet.upi.test.user7.vpa"));
        payer.setIsExternalVpa(true);
    }
    @Given("User click pay api to do upi transaction for nye to external vpa")
    public void user_click_pay_api_to_do_upi_transaction_for_nye_to_external_user() throws FileNotFoundException, InterruptedException {
        System.out.println("User click pay api to do upi transaction for nye to external vpa");
        res = pay(payee,payer,transTypeEnum,payerAccessToken);
        if(res.getStatusCode()!=HTTP_OK){
            errorValidationOfTM(res,payee,payer);
        }
        else{
            assertJsonValueEquals("message","Success",extractJsonObjectFromResponse(res)); // assertion
            requestId = (String) getResponseData(res,"results.data");
            res = upiPayByRequestId(requestId,payerAccessToken,true); //calling pay by request id
        }

    }
    @Then("Verify upi transaction for nye to external vpa")
    public void verify_upi_transaction_for_nye_to_external_user() throws FileNotFoundException {
        System.out.println("Verify upi transaction for nye to external vpa");
        if(res.getStatusCode()!=HTTP_OK){
            payer.setIsTransactionSuccess(false); // when transaction failed
            errorValidationOfTM(res,payee,payer);
        }
        else {
            transactionHeaderId =  successTransactionValidation(res,payee,payer,transTypeEnum);
            payer.setIsTransactionSuccess(true);
        }
    }
    @Then("Also verify upi transaction status from db if transaction has been succeed for nye to external vpa")
    public void also_verify_upi_transaction_status_from_db_if_transaction_has_been_succeed_for_nye_to_external_user() throws SQLException {
        System.out.println("Also verify upi transaction status from db if transaction has been succeed for nye to external vpa");
        if(payer.getIsTransactionSuccess() && transactionHeaderId!=null){
            Transaction transaction = getUPITransactionDetails(transactionHeaderId);
            System.out.println(transaction);
            successTransactionValidationFromDB(res,transaction,transTypeEnum);
        }
        else {
            System.out.println("Transaction Failed! Transaction not Verified from DB");
        }
    }

    // ************************* UPI transaction for insufficient wallet balance *****************************
    @Given("User login with valid cred to do upi transaction for insufficient balance")
    public void user_login_with_valid_cred_to_do_upi_transaction_for_insufficient_balance() throws FileNotFoundException {
        System.out.println("User login with valid cred to do upi transaction for insufficient balance");
        res = login(reader.getValueFromConfig("wallet.upi.test.user8.mobile.number"),reader.getValueFromConfig("wallet.upi.test.user8.passcode"),reader.getValueFromConfig("wallet.upi.test.user8.device.id"),reader.getValueFromConfig("wallet.upi.test.user8.device.id"));
        payerAccessToken = getAccessTokenResponseData(res,"access_token");
    }
    @Given("User enter receiver detail to do upi transaction for insufficient balance")
    public void user_enter_receiver_detail_to_do_upi_transaction_for_insufficient_balance() throws FileNotFoundException, InterruptedException {
        System.out.println("User enter receiver detail to do upi transaction for insufficient balance");
        payee.setReceiverVpa(reader.getValueFromConfig("wallet.upi.internal.vpa2"));
        res = verifyUPI(payee.getReceiverVpa(),payerAccessToken); // calling verify by requestId method
        requestId = (String) getResponseData(res,"results.data");
        res = verifyByRequestId(requestId,payerAccessToken,false); // calling verify by requestId method
        if(res.getStatusCode()!=HTTP_OK){
            errorValidationOfTM(res,payee,payer); // calling method for error validation
        }
        else {
            String payeeName = (String) getResponseData(res,"results.vpaHoldername"); // calling verify by requestId method
            payee.setReceiverName(payeeName);
        }
    }
    @Given("User enter amount and others details to do upi transaction for insufficient balance")
    public void user_enter_amount_and_others_details_to_do_upi_transaction_for_insufficient_balance() throws FileNotFoundException {
        System.out.println("User enter amount and others details to do upi transaction for insufficient balance");
        balance = Double.valueOf(getWalletBalance(payerAccessToken));
        double amount = Double.parseDouble((reader.getValueFromConfig("amount")));
        if(balance>amount){
            System.out.println(balance);
            amount = balance+1;
        }
        payee.setAmount(String.format("%.2f",amount));
        payer.setPasscode(getEncryptedAuthData(reader.getValueFromConfig("wallet.upi.test.user8.passcode")));
        transTypeEnum = String.valueOf(TransTypeEnum.WALLET_TO_OTHER_WALLET);
        payer.setAction(reader.getValueFromConfig("wallet.pay.action"));
        payer.setDeviceTypeEnum(reader.getValueFromConfig("device.type.enum"));
        payer.setComment(reader.getValueFromConfig("comment")); // setting comment
        payer.setUniqueFrontendId(getUniqueFrontendId());
        balance = Double.valueOf(getWalletBalance(payerAccessToken)); // fetching payer wallet balance
        payer.setWalletBalance(String.valueOf(balance));
        payer.setSenderVpa(reader.getValueFromConfig("wallet.upi.test.user7.vpa"));
        payer.setSenderAccountId(reader.getValueFromConfig("wallet.upi.test.user7.vpa"));
        payer.setIsExternalVpa(false);
    }
    @Given("User click pay api to do upi transaction for insufficient balance")
    public void user_click_pay_api_to_do_upi_transaction_for_insufficient_balance() throws FileNotFoundException, InterruptedException {
        System.out.println("User click pay api to do upi transaction for insufficient balance");
        res = pay(payee,payer,transTypeEnum,payerAccessToken);
        if(res.getStatusCode()!=HTTP_OK){
            errorValidationOfTM(res,payee,payer);
        }
        else{
            assertJsonValueEquals("message","Success",extractJsonObjectFromResponse(res)); // assertion
            requestId = (String) getResponseData(res,"results.data");
            res = upiPayByRequestId(requestId,payerAccessToken,false); //calling pay by request id
        }
    }
    @Then("Verify upi transaction for insufficient balance")
    public void verify_upi_transaction_for_insufficient_balance() throws FileNotFoundException {
        System.out.println(res.asPrettyString());
        if (res.getStatusCode()!=HTTP_OK){
            errorValidationOfTM(res,payee,payer); // calling method for error handling
        }
        else {
            Assert.assertEquals("FAILED","SUCCESS");
        }
    }

    // ************************* UPI Transaction for invalid amount *****************************
    @Given("User login with valid cred to do upi transaction for invalid amount")
    public void user_login_with_valid_cred_to_do_upi_transaction_for_invalid_amount() throws FileNotFoundException {
        System.out.println("User login with valid cred to do upi transaction for invalid amount");
        res = login(reader.getValueFromConfig("wallet.upi.test.user8.mobile.number"),reader.getValueFromConfig("wallet.upi.test.user8.passcode"),reader.getValueFromConfig("wallet.upi.test.user8.device.id"),reader.getValueFromConfig("wallet.upi.test.user8.device.id"));
        payerAccessToken = getAccessTokenResponseData(res,"access_token");
    }
    @Given("User has a valid details of receiver to do upi transaction for invalid amount")
    public void user_has_a_valid_details_of_receiver_to_do_upi_transaction_for_invalid_amount() throws FileNotFoundException, InterruptedException {
        System.out.println("User has a valid details of receiver to do upi transaction for invalid amount");
        payee.setReceiverVpa(reader.getValueFromConfig("wallet.upi.internal.vpa2"));
        res = verifyUPI(payee.getReceiverVpa(),payerAccessToken); // calling verify by requestId method
        requestId = (String) getResponseData(res,"results.data");
        res = verifyByRequestId(requestId,payerAccessToken,false); // calling verify by requestId method
        if(res.getStatusCode()!=HTTP_OK){
            errorValidationOfTM(res,payee,payer); // calling method for error validation
        }
        else {
            String payeeName = (String) getResponseData(res,"results.vpaHoldername"); // calling verify by requestId method
            payee.setReceiverName(payeeName);
        }

    }
    @Given("User enter {string} and {string} and other details to do upi transaction for invalid amount")
    public void user_enter_and_and_other_details_to_do_upi_transaction_for_invalid_amount(String amountType, String amountValue) throws FileNotFoundException {
        System.out.println("User enter "+amountType+" and "+amountValue+" to do upi transaction for invalid amount");
        if(amountValue.equalsIgnoreCase("empty")){
            payee.setAmount(" ");
        }
        else if(amountValue.equalsIgnoreCase("null")){
            payee.setAmount(null);
        }
        else {
            payee.setAmount(amountValue);  //setting amount
        }
        payer.setPasscode(getEncryptedAuthData(reader.getValueFromConfig("wallet.upi.test.user8.passcode")));
        transTypeEnum = String.valueOf(TransTypeEnum.WALLET_TO_OTHER_WALLET);
        payer.setAction(reader.getValueFromConfig("wallet.pay.action"));
        payer.setDeviceTypeEnum(reader.getValueFromConfig("device.type.enum"));
        payer.setComment(reader.getValueFromConfig("comment")); // setting comment
        payer.setUniqueFrontendId(getUniqueFrontendId());
        balance = Double.valueOf(getWalletBalance(payerAccessToken)); // fetching payer wallet balance
        payer.setWalletBalance(String.valueOf(balance));
        payer.setSenderVpa(reader.getValueFromConfig("wallet.upi.test.user8.vpa"));
        payer.setSenderAccountId(reader.getValueFromConfig("wallet.upi.test.user8.vpa"));
        payer.setIsExternalVpa(false);
    }
    @Given("User click pay api to do upi transaction for invalid amount")
    public void user_click_pay_api_to_do_upi_transaction_for_invalid_amount() throws FileNotFoundException, InterruptedException {
        System.out.println("User click pay api to do upi transaction for invalid amount");
        res = pay(payee,payer,transTypeEnum,payerAccessToken);
        if(res.getStatusCode()!=HTTP_OK){
            errorValidationOfTM(res,payee,payer);
        }
        else{
            assertJsonValueEquals("message","Success",extractJsonObjectFromResponse(res)); // assertion
            requestId = (String) getResponseData(res,"results.data");
            res = upiPayByRequestId(requestId,payerAccessToken,false); //calling pay by request id
        }
    }
    @Then("Verify upi transaction status for invalid amount")
    public void verify_upi_transaction_status_for_invalid_amount() throws FileNotFoundException {
        System.out.println("Verify upi transaction status for invalid amount");
        if (res.getStatusCode()!=HTTP_OK){
            errorValidationOfTM(res,payee,payer); // calling method for error handling
        }
        else {
            Assert.assertEquals("FAILED","SUCCESS");
        }
    }

    // ************************* UPI Transaction for valid amount *****************************
    @Given("User login with valid cred to do upi transaction for valid amount")
    public void user_login_with_valid_cred_to_do_upi_transaction_for_valid_amount() throws FileNotFoundException {
        System.out.println("User login with valid cred to do upi transaction for valid amount");
        res = login(reader.getValueFromConfig("wallet.upi.test.user8.mobile.number"),reader.getValueFromConfig("wallet.upi.test.user8.passcode"),reader.getValueFromConfig("wallet.upi.test.user8.device.id"),reader.getValueFromConfig("wallet.upi.test.user8.device.id"));
        payerAccessToken = getAccessTokenResponseData(res,"access_token");
    }
    @Given("User has a valid details of receiver to do upi transaction for valid amount")
    public void user_has_a_valid_details_of_receiver_to_do_upi_transaction_for_valid_amount() throws FileNotFoundException, InterruptedException {
        System.out.println("User has a valid details of receiver to do upi transaction for valid amount");
        payee.setReceiverVpa(reader.getValueFromConfig("wallet.upi.internal.vpa2"));
        res = verifyUPI(payee.getReceiverVpa(),payerAccessToken); // calling verify by requestId method
        requestId = (String) getResponseData(res,"results.data");
        res = verifyByRequestId(requestId,payerAccessToken,false); // calling verify by requestId method
        if(res.getStatusCode()!=HTTP_OK){
            errorValidationOfTM(res,payee,payer); // calling method for error validation
        }
        else {
            String payeeName = (String) getResponseData(res,"results.vpaHoldername"); // calling verify by requestId method
            payee.setReceiverName(payeeName);
        }
    }
    @Given("User enter amount and other details to do upi transaction for valid amount")
    public void user_enter_amount_and_other_details_to_do_upi_transaction_for_valid_amount() throws FileNotFoundException {
        System.out.println("User enter amount and other details to do upi transaction for valid amount");
        payee.setAmount(String.valueOf(getRandomAmount())); // setting amount
        payer.setPasscode(getEncryptedAuthData(reader.getValueFromConfig("wallet.upi.test.user8.passcode")));
        transTypeEnum = String.valueOf(TransTypeEnum.WALLET_TO_OTHER_WALLET);
        payer.setAction(reader.getValueFromConfig("wallet.pay.action"));
        payer.setDeviceTypeEnum(reader.getValueFromConfig("device.type.enum"));
        payer.setComment(reader.getValueFromConfig("comment")); // setting comment
        payer.setUniqueFrontendId(getUniqueFrontendId());
        balance = Double.valueOf(getWalletBalance(payerAccessToken)); // fetching payer wallet balance
        payer.setWalletBalance(String.valueOf(balance));
        payer.setSenderVpa(reader.getValueFromConfig("wallet.upi.test.user8.vpa"));
        payer.setSenderAccountId(reader.getValueFromConfig("wallet.upi.test.user8.vpa"));
        payer.setIsExternalVpa(false);
    }
    @Given("User click pay api to do upi transaction for valid amount")
    public void user_click_pay_api_to_do_upi_transaction_for_valid_amount() throws FileNotFoundException, InterruptedException {
        System.out.println("User click pay api to do upi transaction for valid amount");
        res = pay(payee,payer,transTypeEnum,payerAccessToken);
        if(res.getStatusCode()!=HTTP_OK){
            errorValidationOfTM(res,payee,payer);
        }
        else{
            assertJsonValueEquals("message","Success",extractJsonObjectFromResponse(res)); // assertion
            requestId = (String) getResponseData(res,"results.data");
            res = upiPayByRequestId(requestId,payerAccessToken,false); //calling pay by request id
        }
    }
    @Then("Verify upi transaction status for valid amount")
    public void verify_upi_transaction_status_for_valid_amount() throws FileNotFoundException {
        System.out.println("Verify upi transaction status for valid amount");
        if(res.getStatusCode()!=HTTP_OK){
            payer.setIsTransactionSuccess(false); // when transaction failed
            errorValidationOfTM(res,payee,payer);
        }
        else {
            transactionHeaderId =  successTransactionValidation(res,payee,payer,transTypeEnum);
            payer.setIsTransactionSuccess(true);
        }
    }
    @Then("Also verify upi transaction status from db if transaction has been succeed for valid amount")
    public void also_verify_upi_transaction_status_from_db_if_transaction_has_been_succeed_for_valid_amount() throws SQLException {
        System.out.println("Also verify upi transaction status from db if transaction has been succeed for valid amount");
        System.out.println(res.asPrettyString());
        System.out.println(transactionHeaderId);
        if(payer.getIsTransactionSuccess() && transactionHeaderId!=null){
            Transaction transaction = getTransactionDetails(transactionHeaderId); // calling method for transaction validation from db
            System.out.println(transaction);
            successTransactionValidationFromDB(res,transaction,transTypeEnum);
        }
        else {
            System.out.println("Transaction Failed! Transaction not Verified from DB");
        }
    }

}
