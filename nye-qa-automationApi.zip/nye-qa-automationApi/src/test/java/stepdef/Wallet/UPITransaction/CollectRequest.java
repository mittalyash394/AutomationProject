package stepdef.Wallet.UPITransaction;

import base.BaseBuilder;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.restassured.response.Response;
import org.json.JSONObject;
import org.junit.Assert;
import resources.Payee;
import resources.Payer;
import resources.TransTypeEnum;
import utilities.GlobalConstant;
import utilities.PropertyReader;
import utilities.Utils;

import java.io.FileNotFoundException;

import static utilities.CommonStepDef.*;
import static utilities.Utils.*;

public class CollectRequest {
    private static PropertyReader reader = new PropertyReader();
    private static Response res ;
    private static String payeeAccessToken ;
    private static String payerAccessToken;
    private static String requestId;
    private static Double balance;
    private static JSONObject responseObject;

    private static BaseBuilder baseBuilder = new BaseBuilder();

    private static Payee payee = new Payee();
    private static Payer payer = new Payer();


    // *************************Send collect request *****************************
    @Given("Payee have a valid vpa of payer")
    public void payee_have_a_valid_vpa_of_payer() throws FileNotFoundException, InterruptedException {
        System.out.println("Payee have a valid vpa of payer");
        String payerVpa = reader.getValueFromConfig("payer.vpa");
        res = login(reader.getValueFromConfig("payee.mobile.number"),reader.getValueFromConfig("payee.passcode"),reader.getValueFromConfig("payee.device.id"),reader.getValueFromConfig("payee.device.id"));
        payeeAccessToken = getAccessTokenResponseData(res,"access_token");
        res = verifyUPI(payerVpa,payeeAccessToken); // calling verify upi method
        requestId = (String) getResponseData(res,"results.data");
        res = verifyByRequestId(requestId,payeeAccessToken,false); // calling verify by requestId method
        payer.setSenderVpa(payerVpa);
        payer.setSenderName((String) getResponseData(res,"results.vpaHoldername"));

    }
    @Given("On entering the amount to be transferred and comment for collect request")
    public void on_entering_the_amount_to_be_transferred_and_comment_for_collect_request() {
        System.out.println("On entering the amount to be transferred and comment for collect request");
        payee.setAmount(String.valueOf(getRandomAmount())); // setting amount for collect request
        payee.setComment(reader.getValueFromConfig("wallet.send.collect.request.comment")); // setting comment for collect request
    }
    @Given("On initiating the send collect request")
    public void on_initiating_the_send_collect_request() throws FileNotFoundException {
        System.out.println("On initiating the send collect request");
        String transTypeEnum = String.valueOf(TransTypeEnum.COLLECT_WALLET_TO_OTHER_WALLET);
        payer.setAction(reader.getValueFromConfig("wallet.send.collect.request.action"));
        payer.setTxnId(getUniqueFrontendId());
        res = pay(payee,payer,transTypeEnum,payeeAccessToken); // calling send collect request method
        JSONObject responseObject = extractJsonObjectFromResponse(res);
        if(res.getStatusCode()!= GlobalConstant.HTTP_OK){
            System.out.println(res.asPrettyString());
            JSONObject errorsFromResponse = extractJsonValueFromJsonArray(responseObject,"errors",0);
            jsonSchemaValidator(res,reader.getValueFromConfig("wallet.send.collect.request.limit.exceed.valid.schema"));
            assertJsonValueEquals("message","Collect Request Limit Exceeded",errorsFromResponse);
        }
        else{
            payer.setTxnId((String) getResponseData(res,"results.txnId")); // setting texnid for collect request
            jsonSchemaValidator(res,reader.getValueFromConfig("wallet.send.collect.request.valid.schema"));
        }

    }
    @Then("Verify the send collect request status")
    public void verify_the_send_collect_request_status() {
        System.out.println("Verify the send collect request status");
        JSONObject responseObject = extractJsonObjectFromResponse(res);
        if(res.getStatusCode()!= GlobalConstant.HTTP_OK){
            JSONObject errorsFromResponse = extractJsonValueFromJsonArray(responseObject,"errors",0);
            assertJsonValueEquals("message","Collect Request Limit Exceeded",errorsFromResponse);
        }
        else {
            verifyStatusCode(res,GlobalConstant.HTTP_OK);
        }
    }


    // *************************Approve Collect request *****************************
    @Given("Payer have a valid collect request")
    public void payer_have_a_valid_collect_request() throws FileNotFoundException {
        System.out.println("Payer have a valid collect request");
        res = login(reader.getValueFromConfig("payer.mobile.number"),reader.getValueFromConfig("payer.passcode"),reader.getValueFromConfig("payer.device.id"),reader.getValueFromConfig("payer.device.id"));
        payerAccessToken = getAccessTokenResponseData(res,"access_token");
        res = getPendingTransaction(payerAccessToken); //calling pending transaction api
        if(res.getStatusCode()!=GlobalConstant.HTTP_OK){
            System.out.println(res.asPrettyString());
            Assert.assertTrue(false);
        }
        responseObject = extractJsonObjectFromResponse(res);
        JSONObject results = extractJsonValueFromJsonArray(responseObject,"results",0);
        payer.setTxnId(getValueFromJSONObject(results,"txnid"));
        payer.setAction(reader.getValueFromConfig("wallet.approve.collect.request.action")); //setting action COLLECTAPPROVE
        payee.setAmount(getValueFromJSONObject(results,"amount"));
        payee.setReceiverVpa(getValueFromJSONObject(results,"payeeVpa"));
        payee.setReceiverName(reader.getValueFromConfig("wallet.payee.name"));

    }
    @Given("On initiating approve collect request")
    public void on_initiating_approve_collect_request() throws FileNotFoundException {
        System.out.println("On initiating approve collect request");
        String transTypeEnum = String.valueOf(TransTypeEnum.WALLET_TO_OTHER_WALLET);
        res = checkRuleApi(payee,payer,transTypeEnum,payerAccessToken);  //calling check rule api
        responseObject = extractJsonObjectFromResponse(res); // extracting data from response
        if(res.getStatusCode()!=GlobalConstant.HTTP_OK){
            System.out.println(res.asPrettyString());
            JSONObject errorsFromResponse = extractJsonValueFromJsonArray(responseObject,"errors",0);
            assertJsonValueEquals("code","NYE-TM-001",errorsFromResponse);
        }
        else {
            JSONObject results = extractNestedJsonObject(responseObject,"results");
            jsonSchemaValidator(res,reader.getValueFromConfig("check.rule.valid.schema"));
            assertJsonValueEquals("data","SUCCESS",results);  // assertions
        }

        payer.setPasscode(getEncryptedAuthData(reader.getValueFromConfig("payer.passcode")));
        res = pay(payee,payer,transTypeEnum,payerAccessToken); // calling collect pay api
        responseObject = extractJsonObjectFromResponse(res);
        if(res.getStatusCode()!=GlobalConstant.HTTP_OK){
            System.out.println(res.asPrettyString());
            JSONObject errorsFromResponse = extractJsonValueFromJsonArray(responseObject,"errors",0);
            assertJsonValueEquals("code","NYE-TM-001",errorsFromResponse);
        }
        else {
            assertJsonValueEquals("message","Success",extractJsonObjectFromResponse(res)); // assertion
            String requestId = (String) getResponseData(res,"results.data");
            res = payByRequestId(requestId,payerAccessToken); //calling pay by request id
            jsonSchemaValidator(res,reader.getValueFromConfig("wallet.approve.collect.request.valid.schema")); //  json Schema Validation
            assertJsonValueEquals("message","Success",extractJsonObjectFromResponse(res)); // assertion
        }

    }

    @Then("Verify approve collect request status")
    public void verify_approve_collect_request_status() {
        System.out.println("Verify approve collect request status");
        if(res.getStatusCode()!=GlobalConstant.HTTP_OK){
            JSONObject errorsFromResponse = extractJsonValueFromJsonArray(responseObject,"errors",0);
            assertJsonValueEquals("code","NYE-TM-001",errorsFromResponse);
        }
        else {
            verifyStatusCode(res,GlobalConstant.HTTP_OK);
        }
    }

    // *************************Decline Collect request *****************************
    @Given("Payer have a valid collect request for decline")
    public void payer_have_a_valid_collect_request_for_decline() throws FileNotFoundException {
        System.out.println("Payer have a valid collect request for decline");
        res = login(reader.getValueFromConfig("payer.mobile.number"),reader.getValueFromConfig("payer.passcode"),reader.getValueFromConfig("payer.device.id"),reader.getValueFromConfig("payer.device.id"));
        payerAccessToken = getAccessTokenResponseData(res,"access_token");
        res = getPendingTransaction(payerAccessToken); //calling pending transaction api
        responseObject = extractJsonObjectFromResponse(res);
        if(res.getStatusCode()!=GlobalConstant.HTTP_OK){
            System.out.println(res.asPrettyString());
            Assert.assertTrue(false);
        }
        else {
            JSONObject results = extractJsonValueFromJsonArray(responseObject,"results",0);
            payer.setTxnId(getValueFromJSONObject(results,"txnid"));
            payer.setAction(reader.getValueFromConfig("wallet.decline.collect.request.action")); // setting action COLLECTREJECT
            payee.setAmount(getValueFromJSONObject(results,"amount"));
            payee.setReceiverVpa(getValueFromJSONObject(results,"payeeVpa"));
            payee.setReceiverName(reader.getValueFromConfig("wallet.payee.name"));
        }

    }
    @Given("On initiating decline collect request")
    public void on_initiating_decline_collect_request() throws FileNotFoundException {
        System.out.println("On initiating decline collect request");
        String transTypeEnum = String.valueOf(TransTypeEnum.WALLET_TO_OTHER_WALLET);
        payer.setPasscode(getEncryptedAuthData(reader.getValueFromConfig("payer.passcode")));
        res = pay(payee,payer,transTypeEnum,payerAccessToken); // calling collect pay api
        responseObject = extractJsonObjectFromResponse(res);
        if(res.getStatusCode()!=GlobalConstant.HTTP_OK){
            System.out.println(res.asPrettyString());
            JSONObject errorsFromResponse = extractJsonValueFromJsonArray(responseObject,"errors",0);
            assertJsonValueEquals("code","NYE-TM-001",errorsFromResponse);
        }
        else {
            jsonSchemaValidator(res,reader.getValueFromConfig("wallet.decline.collect.request.valid.schema")); //  json Schema Validation
            assertJsonValueEquals("message","Success",extractJsonObjectFromResponse(res)); // assertion
        }
    }
    @Then("Verify decline collect request status")
    public void verify_decline_collect_request_status() {
        System.out.println("Verify decline collect request status");
        if(res.getStatusCode()!=GlobalConstant.HTTP_OK){
            JSONObject errorsFromResponse = extractJsonValueFromJsonArray(responseObject,"errors",0);
            assertJsonValueEquals("code","NYE-TM-001",errorsFromResponse);
        }
        else {
            verifyStatusCode(res,GlobalConstant.HTTP_OK);
        }
    }

}
