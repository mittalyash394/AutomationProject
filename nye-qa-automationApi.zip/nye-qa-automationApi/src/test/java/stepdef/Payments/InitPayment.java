package stepdef.Payments;

import base.BaseBuilder;
import com.google.gson.Gson;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import org.json.JSONObject;
import org.junit.Assert;
import resources.InitPaymentEnum;
import resources.InitPayments;
import utilities.GlobalConstant;
import utilities.PropertyReader;
import utilities.Utils;

import java.io.FileNotFoundException;

import static utilities.Utils.*;
import static utilities.Utils.assertJsonValueEquals;

public class InitPayment {
    private PropertyReader reader = new PropertyReader();
    private static BaseBuilder baseBuilder = new BaseBuilder();
    private static RequestSpecification reqspec;
    private static Response res;
    private static JSONObject resultsFromResponse;
    private static JSONObject responseObject;
    private static String initRequest;
    private static Gson gson;
    private static String requestId;
    private static String oTxid;
    private static InitPayments initPaymentObject = new InitPayments();
    InitPayments.MetaData metaData = new InitPayments.MetaData();
    InitPayments.PayeeAndPayer payer = new InitPayments.PayeeAndPayer();
    @Given("I have provided valid values for all parameters")
    public void setValuesForInitRequest() {
        initPaymentObject.setProductId(String.valueOf(InitPaymentEnum.NBP));
        oTxid=Utils.getUniqueFrontendId();
        initPaymentObject.setOTxid(oTxid);
        initPaymentObject.setAction(String.valueOf(InitPaymentEnum.LOAD));
        initPaymentObject.setAmount(Integer.parseInt(generateRandomNumber()));
        metaData.setDeviceType(String.valueOf(InitPaymentEnum.ANDROID));
        metaData.setPlatformType(String.valueOf(InitPaymentEnum.WEB));
        initPaymentObject.setPayee(payer);
        initPaymentObject.setPayer(payer);
        initPaymentObject.setMeta(metaData);
        initRequest = new Gson().toJson(initPaymentObject);
    }
    @When("I hit the init api")
    public void hitInitApi() throws FileNotFoundException {
        reqspec = baseBuilder.placeSpecBuilder();
        reqspec = RestAssured.given().spec(reqspec).body(initRequest);
        res = reqspec.post(GlobalConstant.initPaymentEndpoint);
        requestId = (String) Utils.getResponseData(res, "results.requestId");
    }
    @Then("Response should be validated for payment initiation")
    public void validateResponse() {
        Utils.jsonSchemaValidator(res, reader.getValueFromConfig("init.payment.success.schema"));
        Utils.verifyStatusCode(res,GlobalConstant.HTTP_OK);
    }
    @Then("Verify the response body of init request")
    public void verifyResponseValues() {
        responseObject = extractJsonObjectFromResponse(res);
        resultsFromResponse = extractNestedJsonObject(responseObject, "results");
        assertJsonValueEquals("message", reader.getValueFromConfig("init.payment.success.message"), responseObject);
        Assert.assertEquals(oTxid,(String) Utils.getResponseData(res, "results.otxid"));
        assertJsonValueEquals("paymentsPageUrl",reader.getValueFromConfig("payments.page.url")+requestId, resultsFromResponse);
        assertJsonValueEquals("statusCheckByRequestIdUrl",reader.getValueFromConfig("status.check.by.request.id.url")+requestId, resultsFromResponse);
        assertJsonValueEquals("statusCheckByOTxidUrl",reader.getValueFromConfig("status.check.by.otxid.url")+oTxid, resultsFromResponse);
        assertJsonValueEquals("initiateRefundByRequestIdUrl",reader.getValueFromConfig("initiate.refund.by.request.id.url"), resultsFromResponse);
    }
}
