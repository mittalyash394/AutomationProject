package stepdef.Identity;
import base.BaseBuilder;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import org.json.JSONObject;
import utilities.GlobalConstant;
import utilities.JSONPayload;
import utilities.PropertyReader;
import utilities.Utils;
import java.io.FileNotFoundException;
import java.util.HashMap;
import static utilities.Utils.*;
import static utilities.Utils.assertJsonValueEquals;
public class UserMobileAccountRecovery {
    private static String encrypted_mobile_number;
    private PropertyReader reader = new PropertyReader();
    private static BaseBuilder baseBuilder = new BaseBuilder();
    private static RequestSpecification reqspec;
    private static JSONObject responseObject;
    private static JSONObject resultsFromResponse;
    private static JSONObject errorFromResponse;
    private Response res;
    private static String encrypted_password;
    private static String encrypted_passcode;
    private static String secretKey;
    @Given("I have mobile number {string} which needs to be verified for account recovery")
    public void encryptMobile(String mobile) throws InterruptedException, FileNotFoundException {
        Thread.sleep(1000);
        encrypted_mobile_number = Utils.getEncryptedAuthData(mobile);
    }
    @When("I enter registered mobile number")
    public void generateSmsString() throws FileNotFoundException {
        HashMap<String, Object> generateSmsStringPayload = JSONPayload.createOneParameterPayload("mobileNumber", encrypted_mobile_number);
        reqspec = baseBuilder.placeSpecBuilder();
        reqspec = RestAssured.given().spec(reqspec).body(generateSmsStringPayload);
        res = reqspec.post(GlobalConstant.generateSmsStringRecoveryEndpoint);
        System.out.println(res.asPrettyString());
    }
    @Then("Response json should be validated for error and status code should be {int}")
    public void validateErrorSchemaAndCode(Integer statusCode) {
        Utils.jsonSchemaValidator(res, reader.getValueFromConfig("messaging.errorResponseSchemaFilePath"));
        Utils.verifyStatusCode(res, statusCode);
    }
    @Then("Verify the message and code of invalid response")
    public void valdidateErrorDetails() {
        responseObject = extractJsonObjectFromResponse(res);
        errorFromResponse = extractJsonValueFromJsonArray(responseObject, "errors",0);
        assertJsonValueEquals("code", reader.getValueFromConfig("invalid.mobile.number.code"), errorFromResponse);
        assertJsonValueEquals("message", reader.getValueFromConfig("invalid.mobile.number.message"), errorFromResponse);
        assertJsonValueEquals("description", reader.getValueFromConfig("invalid.mobile.number.message"), errorFromResponse);
    }
    @Given("I have entered the registered mobile number")
    public void encryptTestMobile() throws FileNotFoundException {
        encrypted_mobile_number = Utils.getEncryptedAuthData(reader.getValueFromConfig("test.mobile.number"));
    }
    @When("I make a request to the generate sms string API")
    public void generateSmsStringForTestUser() {
        HashMap<String, Object> generateSmsStringPayload = JSONPayload.createOneParameterPayload("mobileNumber", encrypted_mobile_number);
        reqspec = RestAssured.given().spec(reqspec).body(generateSmsStringPayload);
        res = reqspec.post(GlobalConstant.generateSmsStringRecoveryEndpoint);
        secretKey = (String) Utils.getResponseData(res, "results.secretKey");
        System.out.println(res.asPrettyString());
    }
    @Then("I should receive a valid JSON response for generating SMS string")
    public void validateSmsStringGenartionSchema() {
        Utils.jsonSchemaValidator(res, reader.getValueFromConfig("generate.sms.string.valid.schema"));
        Utils.verifyStatusCode(res, GlobalConstant.HTTP_OK);
    }
    @Then("Verify the value of message and mobile number")
    public void verifyInactivityTimeOut() {
        responseObject = extractJsonObjectFromResponse(res);
        resultsFromResponse = extractNestedJsonObject(responseObject, "results");
        assertJsonValueEquals("inActiveTimeOutInSeconds", reader.getValueFromConfig("inactivity.time.out"), resultsFromResponse);
        assertJsonValueEquals("sendToMobileNumber", reader.getValueFromConfig("send.to.mobile.number"), resultsFromResponse);
    }
    @Given("I have new password {string} which needs to be set")
    public void encryptPassword(String password) throws FileNotFoundException {
        encrypted_password=getEncryptedAuthData(password);
    }
    @When("I enter new password with secret key {string}")
    public void resetPassword(String secret_key) {
        if(secret_key.isEmpty()==false){
            secret_key=secretKey;
        }
        HashMap<String, Object> secretKeyAndPasswordPayload = JSONPayload.createTwoParameterPayload("secretKey", secret_key, "password", encrypted_password);
        reqspec = RestAssured.given().spec(reqspec).body(secretKeyAndPasswordPayload);
        res = reqspec.put(GlobalConstant.resetPasswordEndpoint);
        System.out.println(res.asPrettyString());
    }
    @Then("Verify the message {string} and code {string} of account recovery flow")
    public void verifyErrorMessageAndCode(String message, String code) {
        responseObject = extractJsonObjectFromResponse(res);
        errorFromResponse = extractJsonValueFromJsonArray(responseObject, "errors",0);
        assertJsonValueEquals("code", code, errorFromResponse);
        assertJsonValueEquals("message", message, errorFromResponse);
        assertJsonValueEquals("description", message, errorFromResponse);
    }
    @Given("I have entered new password")
    public void encryptRecoveryPassword() throws FileNotFoundException {
        encrypted_password = Utils.getEncryptedAuthData(reader.getValueFromConfig("test.account.recover.password"));
    }
    @When("I make a request to the API with new password")
    public void resetPassword() {
        HashMap<String, Object> secretKeyAndPasswordPayload = JSONPayload.createTwoParameterPayload("secretKey", secretKey, "password", encrypted_password);
        reqspec = RestAssured.given().spec(reqspec).body(secretKeyAndPasswordPayload);
        res = reqspec.put(GlobalConstant.resetPasswordEndpoint);
        System.out.println(res.asPrettyString());
    }
    @Then("I should receive a valid JSON response for resetting password")
    public void valdiateJsonForResettingPassword() {
        Utils.jsonSchemaValidator(res, reader.getValueFromConfig("set.password.schema"));
    }
    @Then("Verify the message in resetting password response")
    public void verifyMessageForResettingPassword() {
        responseObject = extractJsonObjectFromResponse(res);
        assertJsonValueEquals("message", reader.getValueFromConfig("reset.password.message"), responseObject);
    }
    @Given("I have new passcode {string} which needs to be set")
    public void encryptPasscode(String passcode) throws FileNotFoundException {
        encrypted_passcode = getEncryptedAuthData(passcode);
    }
    @When("I pass new passcode with secret key {string}")
    public void resetPasscode(String secret_key) {
        if(secret_key.isEmpty()==false){
            secret_key=secretKey;
        }
        HashMap<String, Object> setPasscodePayload = JSONPayload.createThreeParameterPayload("secretKey", secret_key,
                "passcode", encrypted_passcode,
                "deviceId", reader.getValueFromConfig("test.device.id"));
        reqspec = RestAssured.given().spec(reqspec).body(setPasscodePayload);
        res = reqspec.put(GlobalConstant.resetPasscodeEndpoint);
    }
    @Given("I have entered new passcode")
    public void encryptRecoveryPasscode() throws FileNotFoundException {
        encrypted_passcode = Utils.getEncryptedAuthData(reader.getValueFromConfig("test.account.recover.passcode"));
    }
    @When("I make a request to the API with new passcode")
    public void resetPasscode() {
        HashMap<String, Object> setPasscodePayload = JSONPayload.createThreeParameterPayload("secretKey", secretKey,
                "passcode", encrypted_passcode,
                "deviceId", reader.getValueFromConfig("test.device.id"));
        reqspec = RestAssured.given().spec(reqspec).body(setPasscodePayload);
        res = reqspec.put(GlobalConstant.resetPasscodeEndpoint);
        System.out.println(res.asPrettyString());
    }
    @Then("I should receive a valid JSON response for resetting passcode")
    public void validateJsonForResettingPasscode() {
        Utils.jsonSchemaValidator(res, reader.getValueFromConfig("recover.passcode.schema"));
    }
    @Then("Verify the message in resetting passcode response")
    public void verifyMessageForResettingPasscode() {
        responseObject = extractJsonObjectFromResponse(res);
        assertJsonValueEquals("message", reader.getValueFromConfig("recover.password.message"), responseObject);
    }
}

