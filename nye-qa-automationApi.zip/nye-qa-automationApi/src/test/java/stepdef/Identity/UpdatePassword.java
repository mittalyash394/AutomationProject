package stepdef.Identity;
import base.BaseBuilder;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import org.json.JSONObject;
import utilities.GlobalConstant;
import utilities.JSONPayload;
import utilities.PropertyReader;
import utilities.Utils;
import java.io.FileNotFoundException;
import java.util.HashMap;
import static utilities.CommonStepDef.login;
import static utilities.Utils.*;
public class UpdatePassword {
    private static String access_token;
    private PropertyReader reader = new PropertyReader();
    private static BaseBuilder baseBuilder = new BaseBuilder();
    private static RequestSpecification reqspec;
    private static JSONObject responseObject;
    private static JSONObject errorFromResponse;
    private Response res;
    private static String encrypted_password;
    private static String secretKey;

    @Given("I have password {string} which needs to be verified")
    public void loginAndEncryptPassword(String password) throws InterruptedException, FileNotFoundException {
        Thread.sleep(1000);
        res = login(reader.getValueFromConfig("test.mobile.number"),reader.getValueFromConfig("test.recovery.passcode"),reader.getValueFromConfig("test.device.id"),reader.getValueFromConfig("test.device.id"));
        access_token = getAccessTokenResponseData(res,"access_token");
        encrypted_password = getEncryptedAuthData(password);
    }
    @When("I enter password with access token {string} for verification")
    public void verifyPasswordAfterLogin(String accessToken) throws FileNotFoundException {
        if(accessToken.isEmpty()==false){
            accessToken = access_token;
        }
        HashMap<String, Object> passwordPayload = JSONPayload.createOneParameterPayload("password", encrypted_password);
        reqspec = baseBuilder.placeSpecBuilder();
        deleteAuthUserCache(getEncryptedAuthData(reader.getValueFromConfig("test.mobile.number")));
        reqspec = RestAssured.given().spec(reqspec).header("Authorization","Bearer " + accessToken).body(passwordPayload);
        res = reqspec.post(GlobalConstant.verifyPasswordAfterLoginEndpoint);
        System.out.println(res.asPrettyString());
    }

    @Then("Response json should be validated for update password flow and status code should be {int}")
    public void validateResponseForVerifyPasswordError(Integer statusCode) {
        Utils.jsonSchemaValidator(res, reader.getValueFromConfig("messaging.errorResponseSchemaFilePath"));
        Utils.verifyStatusCode(res, statusCode);
    }

    @Then("Verify the message {string} and code {string} for verifying password")
    public void verifyErrorMessageAndCode(String message, String code) {
        responseObject = extractJsonObjectFromResponse(res);
        errorFromResponse = extractJsonValueFromJsonArray(responseObject, "errors",0);
        assertJsonValueEquals("code", code, errorFromResponse);
        assertJsonValueEquals("message", message, errorFromResponse);
        assertJsonValueEquals("description", message, errorFromResponse);
    }
    @Given("I have entered the old password after logging in")
    public void encryptOldPassword() throws FileNotFoundException, InterruptedException {
        encrypted_password = Utils.getEncryptedAuthData(reader.getValueFromConfig("test.password"));
    }
    @When("I make a request to the verify password after login API")
    public void verifyPasswordAfterLogin() throws FileNotFoundException {
        HashMap<String, Object> passwordPayload = JSONPayload.createOneParameterPayload("password", encrypted_password);
        reqspec = baseBuilder.placeSpecBuilder();
        deleteAuthUserCache(getEncryptedAuthData(reader.getValueFromConfig("test.mobile.number")));
        reqspec = RestAssured.given().spec(reqspec).header("Authorization","Bearer " + access_token).body(passwordPayload);
        res = reqspec.post(GlobalConstant.verifyPasswordAfterLoginEndpoint);
        secretKey = (String) Utils.getResponseData(res, "results.secretKey");
        System.out.println(res.asPrettyString());
    }
    @Then("I should receive a valid JSON response for verifying old password")
    public void validateJsonResponseForVerifyingPassword() {
        Utils.jsonSchemaValidator(res, reader.getValueFromConfig("verify.password.schema"));
    }
    @Then("Verify the message in response of verifying old password")
    public void verifyMessageForVerifyingPassword() {
        responseObject = extractJsonObjectFromResponse(res);
        assertJsonValueEquals("message", reader.getValueFromConfig("verify.password.message"), responseObject);
    }
    @Given("I have new password {string} which needs to be set for the user")
    public void encryptPassword(String password) throws FileNotFoundException {
        encrypted_password = Utils.getEncryptedAuthData(password);
    }
    @When("I enter new password and secret key {string}")
    public void changePassword(String secret_key) {
        if(secret_key.isEmpty()==false){
            secret_key=secretKey;
        }
        HashMap<String, Object> changePasswordPayload = JSONPayload.createTwoParameterPayload("newPassword", encrypted_password, "secretKey", secret_key);
        reqspec = RestAssured.given().spec(reqspec).header("Authorization","Bearer " + access_token).body(changePasswordPayload);
        res = reqspec.put(GlobalConstant.changePasswordEndpoint);
        System.out.println(res.asPrettyString());
    }
    @Given("I have entered new password after verifying old password")
    public void encryptTestPassword() throws FileNotFoundException {
        encrypted_password = Utils.getEncryptedAuthData(reader.getValueFromConfig("test.new.password"));
    }
    @When("I make a request to the API set new password")
    public void changePassword() {
        HashMap<String, Object> changePasswordPayload = JSONPayload.createTwoParameterPayload("newPassword", encrypted_password, "secretKey", secretKey);
        reqspec = RestAssured.given().spec(reqspec).header("Authorization","Bearer " + access_token).body(changePasswordPayload);
        res = reqspec.put(GlobalConstant.changePasswordEndpoint);
        System.out.println(res.asPrettyString());
    }
    @Then("I should receive a valid JSON response for resetting new password")
    public void validateResponseForChangingPassword() {
        Utils.jsonSchemaValidator(res, reader.getValueFromConfig("set.password.schema"));
    }
    @Then("Verify the message in response of resetting password")
    public void verifyMessageForChangingPassword() {
        responseObject = extractJsonObjectFromResponse(res);
        assertJsonValueEquals("message", reader.getValueFromConfig("reset.password.message"), responseObject);
    }
}