package stepdef.Identity;
import base.BaseBuilder;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import org.json.JSONObject;
import utilities.GlobalConstant;
import utilities.JSONPayload;
import utilities.PropertyReader;
import utilities.Utils;
import java.io.FileNotFoundException;
import java.util.HashMap;
import static utilities.Utils.*;
import static utilities.Utils.assertJsonValueEquals;
public class RegisteredUserRegistration {
    private PropertyReader reader = new PropertyReader();
    private static BaseBuilder baseBuilder = new BaseBuilder();
    private static RequestSpecification reqspec;
    private static JSONObject responseObject;
    private static JSONObject errorFromResponse;
    private Response res;
    private static String secretKey;
    @Given("User generates sms string and verifies email and sets password")
    public void user_generates_sms_string_and_verifies_email_and_sets_password() throws FileNotFoundException {
        HashMap<String, Object> generateSmsStringPayload = JSONPayload.createOneParameterPayload("mobileNumber", Utils.getEncryptedAuthData(reader.getValueFromConfig("test.mobile.number")));
        reqspec = baseBuilder.placeSpecBuilder();
        reqspec = RestAssured.given().spec(reqspec).body(generateSmsStringPayload);
        res = reqspec.post(GlobalConstant.generateSmsStringEndpoint);
        secretKey = (String) Utils.getResponseData(res, "results.secretKey");
        HashMap<String, Object> emailIdandSecretKeyPayload = JSONPayload.createTwoParameterPayload("email", Utils.getEncryptedAuthData(reader.getValueFromConfig("test.email")), "secretKey", secretKey);
        reqspec = RestAssured.given().spec(reqspec).body(emailIdandSecretKeyPayload);
        res = reqspec.post(GlobalConstant.sendEmailEndpoint);
        HashMap<String, Object> secretKeyAndPasswordPayload = JSONPayload.createTwoParameterPayload("secretKey", secretKey, "password",Utils.getEncryptedAuthData(reader.getValueFromConfig("test.password")) );
        reqspec = RestAssured.given().spec(reqspec).body(secretKeyAndPasswordPayload);
        res = reqspec.post(GlobalConstant.setPasswordEndpoint);
    }
    @When("User sets passcode")
    public void user_sets_passcode() throws FileNotFoundException {
        HashMap<String, Object> setPasscodePayload = JSONPayload.createSevenParameterPayload("secretKey", secretKey,
                "passcode", Utils.getEncryptedAuthData(reader.getValueFromConfig("test.passcode")) ,
                "deviceId", reader.getValueFromConfig("test.device.id"),
                "deviceType", reader.getValueFromConfig("test.device.type"),
                "fcmToken", reader.getValueFromConfig("test.fcm.token"),
                "versionCode", reader.getValueFromConfig("test.version.code"),
                "versionName", reader.getValueFromConfig("test.version.name"));
        reqspec = RestAssured.given().spec(reqspec).body(setPasscodePayload);
        res = reqspec.post(GlobalConstant.setPasscodeEndpoint);
    }
    @Then("User should receive error and schema should be validated")
    public void user_should_receive_error_and_schema_should_be_validated() {
        Utils.jsonSchemaValidator(res, reader.getValueFromConfig("registered.user.registration.schema"));
        Utils.verifyStatusCode(res, GlobalConstant.HTTP_BAD_REQUEST);
    }
    @Then("Verify the error message")
    public void verify_the_error_message() {
        responseObject = extractJsonObjectFromResponse(res);
        errorFromResponse = extractJsonValueFromJsonArray(responseObject, "errors",0);
        assertJsonValueEquals("code",reader.getValueFromConfig("user.already.exists.error.code") , errorFromResponse);
        assertJsonValueEquals("message",reader.getValueFromConfig("user.already.exists.error.message") , errorFromResponse);
        assertJsonValueEquals("description", reader.getValueFromConfig("user.already.exists.error.message"), errorFromResponse);
    }
}