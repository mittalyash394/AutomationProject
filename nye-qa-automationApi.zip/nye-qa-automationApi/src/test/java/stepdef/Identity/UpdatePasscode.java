package stepdef.Identity;
import base.BaseBuilder;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import org.json.JSONObject;
import utilities.GlobalConstant;
import utilities.JSONPayload;
import utilities.PropertyReader;
import utilities.Utils;
import java.io.FileNotFoundException;
import java.util.HashMap;
import java.util.concurrent.TimeUnit;
import static utilities.CommonStepDef.login;
import static utilities.Utils.*;
public class UpdatePasscode {
    private static String access_token;
    private PropertyReader reader = new PropertyReader();
    private static BaseBuilder baseBuilder = new BaseBuilder();
    private static RequestSpecification reqspec;
    private static JSONObject responseObject;
    private static JSONObject errorFromResponse;
    private Response res;
    private static String encrypted_passcode;
    private static String secretKey;
    @Given("I have passcode {string} which needs to be verified")
    public void loginAndEncryptPasscode(String passcode) throws FileNotFoundException {
        res = login(reader.getValueFromConfig("test.mobile.number"),reader.getValueFromConfig("test.new.passcode"),reader.getValueFromConfig("test.device.id"),reader.getValueFromConfig("test.device.id"));
        access_token = getAccessTokenResponseData(res,"access_token");
        encrypted_passcode = getEncryptedAuthData(passcode);
    }
    @When("I enter passcode with access token {string} for verification")
    public void verifyPasscodeAfterLogin(String accessToken) throws FileNotFoundException {
        if(accessToken.isEmpty()==false){
            accessToken = access_token;
        }
        reqspec = baseBuilder.placeSpecBuilder();
        deleteAuthUserCache(getEncryptedAuthData(reader.getValueFromConfig("test.mobile.number")));
        HashMap<String, Object> passcodePayload = JSONPayload.createOneParameterPayload("passcode", encrypted_passcode);
        reqspec = RestAssured.given().spec(reqspec).header("Authorization","Bearer " + accessToken).body(passcodePayload);
        res = reqspec.post(GlobalConstant.verifyPasscodeAfterLoginEndpoint);
        System.out.println(res.asPrettyString());
    }
    @Then("Response json should be validated for invalid passcode and status code should be {int}")
    public void validateJsonResponseForError(Integer statusCode) {
        Utils.jsonSchemaValidator(res, reader.getValueFromConfig("messaging.errorResponseSchemaFilePath"));
        Utils.verifyStatusCode(res, statusCode);
    }
    @Then("Verify the message {string} and code {string} for verifying passcode")
    public void verifyMessageAndCodeForError(String message, String code) {
        responseObject = extractJsonObjectFromResponse(res);
        errorFromResponse = extractJsonValueFromJsonArray(responseObject, "errors",0);
        assertJsonValueEquals("code", code, errorFromResponse);
        assertJsonValueEquals("message", message, errorFromResponse);
        assertJsonValueEquals("description", message, errorFromResponse);
    }

    @Given("I have entered the old passcode after logging in")
    public void encryptTestPasscode() throws FileNotFoundException{
        encrypted_passcode = Utils.getEncryptedAuthData(reader.getValueFromConfig("test.new.passcode"));
    }
    @When("I make a request to the verify passcode after login API")
    public void verifyPasscodeForTestUser() throws FileNotFoundException {
        HashMap<String, Object> passcodePayload = JSONPayload.createOneParameterPayload("passcode", encrypted_passcode);
        reqspec=baseBuilder.placeSpecBuilder();
        reqspec = RestAssured.given().spec(reqspec).header("Authorization","Bearer " + access_token).body(passcodePayload);
        res = reqspec.post(GlobalConstant.verifyPasscodeAfterLoginEndpoint);
        secretKey = (String) Utils.getResponseData(res, "results.secretKey");
        System.out.println(res.asPrettyString());
    }
    @Then("I should receive a valid JSON response for verifying old passcode")
    public void validateVerifyPasscodeSchema() {
        Utils.jsonSchemaValidator(res, reader.getValueFromConfig("verify.passcode.schema"));
    }
    @Then("Verify the message in response of verifying old passcode")
    public void verifyMessageOfVerifyingPasscode() {
        responseObject = extractJsonObjectFromResponse(res);
        assertJsonValueEquals("message", reader.getValueFromConfig("verify.passcode.message"), responseObject);
    }
    @Given("I have new passcode {string} which needs to be set for the user")
    public void encryptPasscode(String passcode) throws FileNotFoundException {
        encrypted_passcode = Utils.getEncryptedAuthData(passcode);
    }
    @When("I enter new passcode and secret key {string}")
    public void changePasscode(String secret_key) {
        if(secret_key.isEmpty()==false){
            secret_key=secretKey;
        }
        HashMap<String, Object> changePasscodePayload = JSONPayload.createTwoParameterPayload("newPasscode", encrypted_passcode, "secretKey", secret_key);
        reqspec = RestAssured.given().spec(reqspec).header("Authorization","Bearer " + access_token).body(changePasscodePayload);
        res = reqspec.put(GlobalConstant.changePasscodeEndpoint);
        System.out.println(res.asPrettyString());
    }
    @Given("I have entered new passcode after verifying old passcode")
    public void encryptNewTestPasscode() throws FileNotFoundException {
        encrypted_passcode = Utils.getEncryptedAuthData(reader.getValueFromConfig("test.recovery.passcode"));
    }
    @When("I make a request to the API set new passcode")
    public void changePasscode() {
        HashMap<String, Object> changePasscodePayload = JSONPayload.createTwoParameterPayload("newPasscode", encrypted_passcode, "secretKey", secretKey);
        reqspec = RestAssured.given().spec(reqspec).header("Authorization","Bearer " + access_token).body(changePasscodePayload);
        res = reqspec.put(GlobalConstant.changePasscodeEndpoint);
        System.out.println(res.asPrettyString());
    }
    @Then("I should receive a valid JSON response for resetting new passcode")
    public void validateJsonResponseForChangingPaasscode() {
        Utils.jsonSchemaValidator(res, reader.getValueFromConfig("recover.passcode.schema"));
    }
    @Then("Verify the message in response of resetting passcode")
    public void verifyMessageForChangingPasscode() {
        responseObject = extractJsonObjectFromResponse(res);
        assertJsonValueEquals("message", reader.getValueFromConfig("change.passcode.message"), responseObject);
    }
}