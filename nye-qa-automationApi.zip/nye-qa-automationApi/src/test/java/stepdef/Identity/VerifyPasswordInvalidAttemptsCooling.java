package stepdef.Identity;

import base.BaseBuilder;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import org.json.JSONObject;
import utilities.GlobalConstant;
import utilities.JSONPayload;
import utilities.PropertyReader;
import utilities.Utils;

import java.io.FileNotFoundException;
import java.util.HashMap;

import static utilities.CommonStepDef.login;
import static utilities.Utils.*;

public class VerifyPasswordInvalidAttemptsCooling {
    private static String access_token;
    private PropertyReader reader = new PropertyReader();
    private static BaseBuilder baseBuilder = new BaseBuilder();
    private static RequestSpecification reqspec;
    private static JSONObject responseObject;
    private static JSONObject errorFromResponse;
    private Response res;
    private static String encrypted_password;

    @Given("I have logged in for verifying password")
    public void loginAndEncryptPassword() throws FileNotFoundException {
        deleteAuthUserCache(getEncryptedAuthData(reader.getValueFromConfig("test.mobile.number")));
        res = login(reader.getValueFromConfig("test.mobile.number"),reader.getValueFromConfig("test.account.recover.passcode"),reader.getValueFromConfig("test.device.id"),reader.getValueFromConfig("test.device.id"));
        access_token = getAccessTokenResponseData(res,"access_token");
        encrypted_password = getEncryptedAuthData(reader.getValueFromConfig("test.new.password"));
    }

    @When("I make a request to the verify passcode api with wrong password max times")
    public void verifyPasswordMaxAttempts() throws FileNotFoundException {
        HashMap<String, Object> passwordPayload = JSONPayload.createOneParameterPayload("password", encrypted_password);
        reqspec = baseBuilder.placeSpecBuilder();
        reqspec = RestAssured.given().spec(reqspec).header("Authorization","Bearer " + access_token).body(passwordPayload);
        for(int i=0;i<Integer.parseInt(reader.getValueFromConfig("invalid.verify.password.attempts"));i++) {
            res = reqspec.post(GlobalConstant.verifyPasswordAfterLoginEndpoint);
        }
    }
    @Then("Cooling period should be imposed for exceeding invalid attempts at verifying password")
    public void checkCoolingPeriod() {
        Utils.jsonSchemaValidator(res, reader.getValueFromConfig("login.cooling.period.schema"));
        Utils.verifyStatusCode(res, GlobalConstant.REQUESTED_RESOURCE_LCOKED);
    }
    @Then("Verify the cooling period time for exceeding invalid attempts at verifying password")
    public void verifyCoolingPeriodDurationAndMessage() {
        responseObject = extractJsonObjectFromResponse(res);
        errorFromResponse = extractJsonValueFromJsonArray(responseObject, "errors",0);
        assertJsonValueEquals("code", reader.getValueFromConfig("verify.password.cooling.period.code"), errorFromResponse);
        assertJsonValueEquals("message", reader.getValueFromConfig("verify.password.cooling.period.message"), errorFromResponse);
        assertJsonValueEquals("coolingPeriod", reader.getValueFromConfig("verify.password.cooling.period"), errorFromResponse);
    }

    @Given("I make a request to the verify passcode api before login with wrong passcode max times")
    public void verifyPasswordBeforeLoginMaxAttempts() throws FileNotFoundException {
        deleteAuthUserCache(getEncryptedAuthData(reader.getValueFromConfig("test.mobile.number")));
        HashMap<String, Object> mobileNumberandPasswordPayload = JSONPayload.createTwoParameterPayload("mobileNumber",getEncryptedAuthData(reader.getValueFromConfig("test.mobile.number")) , "password", getEncryptedAuthData(reader.getValueFromConfig("test.new.password")));
        reqspec = RestAssured.given().spec(reqspec).body(mobileNumberandPasswordPayload);
        for(int i=0;i<Integer.parseInt(reader.getValueFromConfig("invalid.verify.password.attempts"));i++) {
            res = reqspec.post(GlobalConstant.verifyPasswordEndpoint);
        }
    }
}
