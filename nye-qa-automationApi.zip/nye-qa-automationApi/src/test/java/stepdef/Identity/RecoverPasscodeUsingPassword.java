package stepdef.Identity;

import base.BaseBuilder;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import org.json.JSONObject;
import utilities.GlobalConstant;
import utilities.JSONPayload;
import utilities.PropertyReader;
import utilities.Utils;

import java.io.FileNotFoundException;
import java.util.HashMap;

import static utilities.Utils.*;

public class RecoverPasscodeUsingPassword {
    private static String encrypted_mobile_number;
    private PropertyReader reader = new PropertyReader();
    private static BaseBuilder baseBuilder = new BaseBuilder();
    private static RequestSpecification reqspec;
    private static JSONObject responseObject;
    private static JSONObject errorFromResponse;
    private Response res;
    private static String encrypted_password;
    private static String encrypted_passcode;
    private static String secretKey;

    @Given("I have mobile number {string} and password {string} which needs to be verified")
    public void encryptMobileAndPassword(String mobile_number, String password) throws FileNotFoundException {
        encrypted_password = Utils.getEncryptedAuthData(password);
        encrypted_mobile_number = Utils.getEncryptedAuthData(mobile_number);
        deleteAuthUserCache(encrypted_mobile_number);
    }
    @When("I enter password and mobile number for verification")
    public void verifyPassword() throws FileNotFoundException {
        HashMap<String, Object> mobileNumberandSecretKetPayload = JSONPayload.createTwoParameterPayload("mobileNumber", encrypted_mobile_number, "password", encrypted_password);
        reqspec = baseBuilder.placeSpecBuilder();
        reqspec = RestAssured.given().spec(reqspec).body(mobileNumberandSecretKetPayload);
        res = reqspec.post(GlobalConstant.verifyPasswordEndpoint);
        secretKey = (String) Utils.getResponseData(res, "results.secretKey");
        System.out.println(res.asPrettyString());
    }

    @Then("Response json should be validated for invalid password and status code should be {int}")
    public void validateJsonForVerifyingInvalidPassword(Integer statusCode) {
        Utils.jsonSchemaValidator(res, reader.getValueFromConfig("messaging.errorResponseSchemaFilePath"));
        Utils.verifyStatusCode(res, statusCode);
    }
    @Then("Verify the message {string} and code {string}")
    public void verifyMessageAndCode(String message, String code) {
        responseObject = extractJsonObjectFromResponse(res);
        errorFromResponse = extractJsonValueFromJsonArray(responseObject, "errors",0);
        assertJsonValueEquals("code", code, errorFromResponse);
        assertJsonValueEquals("message", message, errorFromResponse);
        assertJsonValueEquals("description", message, errorFromResponse);
    }

    @Given("I have entered the mobile number and password")
    public void encryptTestMobileAndPassword() throws FileNotFoundException {
        deleteAuthUserCache(encrypted_mobile_number);
        encrypted_mobile_number = Utils.getEncryptedAuthData(reader.getValueFromConfig("test.mobile.number"));
        encrypted_password = Utils.getEncryptedAuthData(reader.getValueFromConfig("test.password"));
    }
    @When("I make a request to the verify password API")
    public void verifyPasswordForTestUser() throws FileNotFoundException {
        HashMap<String, Object> mobileNumberandPasswordPayload = JSONPayload.createTwoParameterPayload("mobileNumber", encrypted_mobile_number, "password", encrypted_password);
        reqspec = RestAssured.given().spec(reqspec).body(mobileNumberandPasswordPayload);
        res = reqspec.post(GlobalConstant.verifyPasswordEndpoint);
        secretKey = (String) Utils.getResponseData(res, "results.secretKey");
        System.out.println(res.asPrettyString());
    }
    @Then("I should receive a valid JSON response for verifying password")
    public void validateJsonResponseForVerifyPassword() {
        Utils.jsonSchemaValidator(res, reader.getValueFromConfig("verify.password.schema"));
    }
    @Then("Verify the message in response of verifying password")
    public void verifyMessageOfVerifyingPassword() {
        responseObject = extractJsonObjectFromResponse(res);
        assertJsonValueEquals("message", reader.getValueFromConfig("verify.password.message"), responseObject);
    }
    @Given("I have passcode {string} and mobile number {string} and password {string}")
    public void encryptMobilePasswordAndPasscode(String passcode, String mobile_number, String password) throws FileNotFoundException {
        encrypted_mobile_number = Utils.getEncryptedAuthData(mobile_number);
        encrypted_password = Utils.getEncryptedAuthData(password);
        encrypted_passcode = Utils.getEncryptedAuthData(passcode);

    }
    @When("I enter new passcode with secret key {string}")
    public void recoverPassword(String secret_key) {
        if(secret_key.isEmpty()==false){
            secret_key = secretKey;
        }
        HashMap<String, Object> recoverPasscodePayload = JSONPayload.createFourParameterPayload("mobileNumber", encrypted_mobile_number,
                "password", encrypted_password, "passcode",encrypted_passcode,"secretKey", secret_key);
        reqspec = RestAssured.given().spec(reqspec).body(recoverPasscodePayload);
        res = reqspec.post(GlobalConstant.recoverPasswordEndpoint);
        System.out.println(res.asPrettyString());
    }

    @Given("I have entered passcode after verifying password")
    public void encryptTestPasscode() throws FileNotFoundException {
        encrypted_passcode = Utils.getEncryptedAuthData(reader.getValueFromConfig("test.new.passcode"));
    }
    @When("I make a request to the recover password API")
    public void recoverPasswordForTestUser() {
        HashMap<String, Object> recoverPasscodePayload = JSONPayload.createFourParameterPayload("mobileNumber", encrypted_mobile_number,
                "password", encrypted_password, "passcode",encrypted_passcode,"secretKey", secretKey);
        reqspec = RestAssured.given().spec(reqspec).body(recoverPasscodePayload);
        res = reqspec.post(GlobalConstant.recoverPasswordEndpoint);
        System.out.println(res.asPrettyString());
    }
    @Then("I should receive a valid JSON response for recovering passcode")
    public void validateJsonResponseFOrRecoveringPasscode() {
        Utils.jsonSchemaValidator(res, reader.getValueFromConfig("recover.passcode.schema"));
    }
    @Then("Verify the message in response of recovering passcode")
    public void verifyMessageOfRecoveringPasscode() {
        responseObject = extractJsonObjectFromResponse(res);
        assertJsonValueEquals("message", reader.getValueFromConfig("recover.passcode.message"), responseObject);
    }
}
