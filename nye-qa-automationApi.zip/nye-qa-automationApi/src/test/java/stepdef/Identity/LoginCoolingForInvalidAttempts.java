package stepdef.Identity;

import base.BaseBuilder;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import org.json.JSONObject;
import utilities.GlobalConstant;
import utilities.JSONPayload;
import utilities.PropertyReader;
import utilities.Utils;

import java.io.FileNotFoundException;
import java.util.HashMap;

import static utilities.CommonStepDef.login;
import static utilities.Utils.*;
import static utilities.Utils.assertJsonValueEquals;

public class LoginCoolingForInvalidAttempts {
    private PropertyReader reader = new PropertyReader();
    private static BaseBuilder baseBuilder = new BaseBuilder();
    private static Response res;
    private static RequestSpecification reqspec;
    private static JSONObject responseObject;
    private static JSONObject errorFromResponse;

    @Given("User tries to login with wrong passcode")
    public void loginWithWrongPasscode() throws FileNotFoundException {
        deleteAuthUserCache(getEncryptedAuthData(reader.getValueFromConfig("test.mobile.number")));
        for(int i=0;i<Integer.parseInt(reader.getValueFromConfig("invalid.login.attempts"));i++){
            res = login(reader.getValueFromConfig("test.mobile.number"), reader.getValueFromConfig("test.new.passcode"), reader.getValueFromConfig("test.device.id"), reader.getValueFromConfig("test.new.device.id"));
        }
    }
    @Then("Cooling period should be imposed for invalid attempts and error json should be validated")
    public void validateCoolingPeriodResponseSchema() {
        Utils.jsonSchemaValidator(res, reader.getValueFromConfig("login.cooling.period.schema"));
    }
    @Then("Verify the cooling period time for invalid attempts and message")
    public void verifyCoolingCodeAndMessage() {
        responseObject = extractJsonObjectFromResponse(res);
        errorFromResponse = extractJsonValueFromJsonArray(responseObject, "errors",0);
        assertJsonValueEquals("code", reader.getValueFromConfig("login.cooling.period.code"), errorFromResponse);
        assertJsonValueEquals("message", reader.getValueFromConfig("login.cooling.period.message"), errorFromResponse);
        assertJsonValueEquals("coolingPeriod", reader.getValueFromConfig("login.cooling.period"), errorFromResponse);
    }
    @Then("Hit generate sms string api for account recovery")
    public void generateSmsString() throws FileNotFoundException {
        HashMap<String, Object> generateSmsStringPayload = JSONPayload.createOneParameterPayload("mobileNumber", getEncryptedAuthData(reader.getValueFromConfig("test.mobile.number")));
        reqspec=baseBuilder.placeSpecBuilder();
        reqspec = RestAssured.given().spec(reqspec).body(generateSmsStringPayload);
        res = reqspec.post(GlobalConstant.generateSmsStringRecoveryEndpoint);
    }
    @Then("It should give the response for valid sms string generation")
    public void validateSchemaForSmsStringGeneration(){
        Utils.jsonSchemaValidator(res, reader.getValueFromConfig("generate.sms.string.valid.schema"));
        Utils.verifyStatusCode(res, GlobalConstant.HTTP_OK);
    }
    @Then("Hit verify password api for recover passcode using password")
    public void verifyPassword() throws FileNotFoundException {
        HashMap<String, Object> mobileNumberandPasswordPayload = JSONPayload.createTwoParameterPayload("mobileNumber", getEncryptedAuthData(reader.getValueFromConfig("test.mobile.number")),
                "password", getEncryptedAuthData(reader.getValueFromConfig("test.account.recover.password")));
        reqspec = RestAssured.given().spec(reqspec).body(mobileNumberandPasswordPayload);
        res = reqspec.post(GlobalConstant.verifyPasswordEndpoint);
    }
    @Then("It should give the response for valid verification of password")
    public void validateSchemaForPasswordVerification(){
        Utils.jsonSchemaValidator(res, reader.getValueFromConfig("verify.password.schema"));
        Utils.verifyStatusCode(res, GlobalConstant.HTTP_OK);
    }
}
