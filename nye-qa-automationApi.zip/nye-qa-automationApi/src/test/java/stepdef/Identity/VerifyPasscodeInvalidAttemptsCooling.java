package stepdef.Identity;

import base.BaseBuilder;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import org.json.JSONObject;
import utilities.GlobalConstant;
import utilities.JSONPayload;
import utilities.PropertyReader;
import utilities.Utils;

import java.io.FileNotFoundException;
import java.util.HashMap;

import static utilities.CommonStepDef.login;
import static utilities.Utils.*;
import static utilities.Utils.assertJsonValueEquals;

public class VerifyPasscodeInvalidAttemptsCooling {
    private static String access_token;
    private PropertyReader reader = new PropertyReader();
    private static BaseBuilder baseBuilder = new BaseBuilder();
    private static RequestSpecification reqspec;
    private static JSONObject responseObject;
    private static JSONObject errorFromResponse;
    private Response res;
    private static String encrypted_passcode;

    @Given("I have logged in for verifying passcode")
    public void loginAndEncryptPasscode() throws FileNotFoundException {
        deleteAuthUserCache(getEncryptedAuthData(reader.getValueFromConfig("test.mobile.number")));
        res = login(reader.getValueFromConfig("test.mobile.number"),reader.getValueFromConfig("test.account.recover.passcode"),reader.getValueFromConfig("test.device.id"),reader.getValueFromConfig("test.device.id"));
        access_token = getAccessTokenResponseData(res,"access_token");
        encrypted_passcode = getEncryptedAuthData(reader.getValueFromConfig("test.new.passcode"));
    }
    @When("I make a request to the verify passcode api with wrong passcode max times")
    public void verifyPasscodeMaxTimes() throws FileNotFoundException {
        HashMap<String, Object> passcodePayload = JSONPayload.createOneParameterPayload("passcode", encrypted_passcode);
        reqspec=baseBuilder.placeSpecBuilder();
        reqspec = RestAssured.given().spec(reqspec).header("Authorization","Bearer " + access_token).body(passcodePayload);
        for(int i=0;i<Integer.parseInt(reader.getValueFromConfig("invalid.verify.passcode.attempts"));i++) {
            res = reqspec.post(GlobalConstant.verifyPasscodeAfterLoginEndpoint);
        }
    }
    @Then("Cooling period should be imposed for exceeding invalid attempts at verifying passcode")
    public void checkCoolingPeriodJson() {
        Utils.jsonSchemaValidator(res, reader.getValueFromConfig("login.cooling.period.schema"));
        Utils.verifyStatusCode(res, GlobalConstant.REQUESTED_RESOURCE_LCOKED);
    }
    @Then("Verify the cooling period time for exceeding invalid attempts at verifying passcode")
    public void checkCoolingPeriodDurationAndMessage() {
        responseObject = extractJsonObjectFromResponse(res);
        errorFromResponse = extractJsonValueFromJsonArray(responseObject, "errors",0);
        assertJsonValueEquals("code", reader.getValueFromConfig("verify.passcode.cooling.period.code"), errorFromResponse);
        assertJsonValueEquals("message", reader.getValueFromConfig("verify.passcode.cooling.period.message"), errorFromResponse);
        assertJsonValueEquals("coolingPeriod", reader.getValueFromConfig("verify.passcode.cooling.period"), errorFromResponse);
    }

}
