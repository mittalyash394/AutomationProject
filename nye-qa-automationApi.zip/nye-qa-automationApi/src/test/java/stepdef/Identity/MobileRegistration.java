package stepdef.Identity;

import base.BaseBuilder;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import org.json.JSONObject;
import org.junit.Assert;
import utilities.*;

import java.io.FileNotFoundException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.HashMap;

import static utilities.Utils.*;

public class MobileRegistration {
    private static String encrypted_mobile_number;
    private PropertyReader reader = new PropertyReader();
    private static BaseBuilder baseBuilder = new BaseBuilder();
    private static RequestSpecification reqspec;
    private static String query;
    private static Connection connection;
    private static JSONObject responseObject;
    private static JSONObject resultsFromResponse;
    private static JSONObject errorFromResponse;
    private Response res;
    private static String encrypted_email;
    private static String encrypted_password;
    private static String encrypted_passcode;
    private static String secretKey;


    @Given("I have mobile number {string} which needs to be verified")
    public void encryptMobileNumber(String mobileNumber) throws FileNotFoundException {
        encrypted_mobile_number = Utils.getEncryptedAuthData(mobileNumber);
    }
    @When("I enter mobile number")
    public void generateSmsString() throws FileNotFoundException {
        HashMap<String, Object> generateSmsStringPayload = JSONPayload.createOneParameterPayload("mobileNumber", encrypted_mobile_number);
        reqspec = baseBuilder.placeSpecBuilder();
        reqspec = RestAssured.given().spec(reqspec).body(generateSmsStringPayload);
        res = reqspec.post(GlobalConstant.generateSmsStringEndpoint);
    }
    @Then("Response json should be validated and status code should be {int}")
    public void validateJsonResponseAndStatusCode(Integer statusCode) {
        Utils.jsonSchemaValidator(res, reader.getValueFromConfig("messaging.errorResponseSchemaFilePath"));
        Utils.verifyStatusCode(res, statusCode);
    }
    @Then("Verify the message of invalid mobile number")
    public void verifyMessageOfInvalidNumber() {
        responseObject = extractJsonObjectFromResponse(res);
        errorFromResponse = extractJsonValueFromJsonArray(responseObject, "errors",0);
        assertJsonValueEquals("code", reader.getValueFromConfig("invalid.mobile.number.code"), errorFromResponse);
        assertJsonValueEquals("message", reader.getValueFromConfig("invalid.mobile.number.message"), errorFromResponse);
        assertJsonValueEquals("description", reader.getValueFromConfig("invalid.mobile.number.message"), errorFromResponse);
    }

    @Given("I have entered the mobile number")
    public void encryptMobileNumberForTestUser() throws FileNotFoundException {
        encrypted_mobile_number = Utils.getEncryptedAuthData(reader.getValueFromConfig("test.mobile.number"));
        deleteAuthUser(encrypted_mobile_number);
        deleteAuthUserCache(encrypted_mobile_number);
    }

    @When("I make a request to the API")
    public void generateSmsStringForTestUser(){
        HashMap<String, Object> generateSmsStringPayload = JSONPayload.createOneParameterPayload("mobileNumber", encrypted_mobile_number);
        reqspec = RestAssured.given().spec(reqspec).body(generateSmsStringPayload);
        res = reqspec.post(GlobalConstant.generateSmsStringEndpoint);
        secretKey = (String) Utils.getResponseData(res, "results.secretKey");
        System.out.println(res.asPrettyString());
    }

    @Then("I should receive a valid JSON response for SMS string")
    public void validateSmsStringResponse() {
        Utils.jsonSchemaValidator(res, reader.getValueFromConfig("generate.sms.string.valid.schema"));
        Utils.verifyStatusCode(res, GlobalConstant.HTTP_OK);
    }

    @Then("Verify the value of inActiveTimeOutInSeconds and mobile number")
    public void verifyInactivityTimeOutAndMobileNumber() {
        responseObject = extractJsonObjectFromResponse(res);
        resultsFromResponse = extractNestedJsonObject(responseObject, "results");
        assertJsonValueEquals("inActiveTimeOutInSeconds", reader.getValueFromConfig("inactivity.time.out"), resultsFromResponse);
        assertJsonValueEquals("sendToMobileNumber", reader.getValueFromConfig("send.to.mobile.number"), resultsFromResponse);
    }
    @Given("I have email {string} for which otp needs to be generated")
    public void encryptEmail(String email) throws FileNotFoundException {
        encrypted_email = Utils.getEncryptedAuthData(email);
    }
    @When("I enter email and secret key {string}")
    public void hitSendEmail(String secret_key) throws FileNotFoundException {
        if(secret_key.isEmpty()==false){
            secret_key = secretKey;
        }
        HashMap<String, Object> emailIdandSecretKeyPayload = JSONPayload.createTwoParameterPayload("email", encrypted_email, "secretKey", secret_key);
        reqspec = baseBuilder.placeSpecBuilder();
        reqspec = RestAssured.given().spec(reqspec).body(emailIdandSecretKeyPayload);
        res = reqspec.post(GlobalConstant.sendEmailEndpoint);
        System.out.println(res.asPrettyString());
    }
    @Then("Verify the value of code {string} and message {string}")
    public void verifyCodeAndMessage(String code,String message) {
        responseObject = extractJsonObjectFromResponse(res);
        errorFromResponse = extractJsonValueFromJsonArray(responseObject, "errors",0);
        assertJsonValueEquals("code", code, errorFromResponse);
        assertJsonValueEquals("message", message, errorFromResponse);
        assertJsonValueEquals("description", message, errorFromResponse);
    }

    @Given("I have entered email ID")
    public void encryptTestEmail() throws FileNotFoundException {
        encrypted_email = Utils.getEncryptedAuthData(reader.getValueFromConfig("test.email"));
    }

    @When("I request an OTP from the API")
    public void hitSendEmail(){
        HashMap<String, Object> emailIdandSecretKeyPayload = JSONPayload.createTwoParameterPayload("email", encrypted_email, "secretKey", secretKey);
        reqspec = RestAssured.given().spec(reqspec).body(emailIdandSecretKeyPayload);
        res = reqspec.post(GlobalConstant.sendEmailEndpoint);
        System.out.println(res.asPrettyString());
    }

    @Then("I should receive a valid JSON response for send otp response")
    public void validateSendEmailResponseSchema() {
        Utils.jsonSchemaValidator(res, reader.getValueFromConfig("send.otp.email.schema"));
    }

    @Then("I should receive an error message and JSON response should be validated")
    public void validateErrorMessageSchema() {
        Utils.jsonSchemaValidator(res, reader.getValueFromConfig("messaging.errorResponseSchemaFilePath"));
    }
    @Then("Verify the message for sending otp")
    public void verifyMessage() {
        responseObject = extractJsonObjectFromResponse(res);
        errorFromResponse = extractJsonValueFromJsonArray(responseObject, "errors",0);
        assertJsonValueEquals("code", reader.getValueFromConfig("otp.regeneration.code"), errorFromResponse);
        assertJsonValueEquals("message", reader.getValueFromConfig("otp.regeneration.message"), errorFromResponse);
        assertJsonValueEquals("description", reader.getValueFromConfig("otp.regeneration.description"), errorFromResponse);
    }

    @Given("I have password {string} which needs to be set")
    public void encryptPassword(String password) throws FileNotFoundException {
        encrypted_password = Utils.getEncryptedAuthData(password);
    }
    @When("I enter password and secret key {string}")
    public void setPassword(String secret_key){
        if(secret_key.isEmpty()==false){
            secret_key = secretKey;
        }
        HashMap<String, Object> secretKeyAndPasswordPayload = JSONPayload.createTwoParameterPayload("secretKey", secret_key, "password", encrypted_password);
        reqspec = RestAssured.given().spec(reqspec).body(secretKeyAndPasswordPayload);
        res = reqspec.post(GlobalConstant.setPasswordEndpoint);
        System.out.println(res.asPrettyString());
    }
    @Then("Verify the message {string} and code {string} of invalid password")
    public void verifyMessageForSetPassword(String message, String code) {
        responseObject = extractJsonObjectFromResponse(res);
        errorFromResponse = extractJsonValueFromJsonArray(responseObject, "errors",0);
        assertJsonValueEquals("code", code, errorFromResponse);
        assertJsonValueEquals("message", message, errorFromResponse);
        assertJsonValueEquals("description", message, errorFromResponse);
    }

    @Then("Verify the value of attempts left and otp validity and resend otp timer")
    public void verifyAttemptsLeft() {
        responseObject = extractJsonObjectFromResponse(res);
        resultsFromResponse = extractNestedJsonObject(responseObject, "results");
        assertJsonValueEquals("userAttemptsLeft", reader.getValueFromConfig("user.attempts.left"), resultsFromResponse);
        assertJsonValueEquals("emailOtpValidityInSeconds", reader.getValueFromConfig("otp.validity.in.seconds"), resultsFromResponse);
        assertJsonValueEquals("resendEmailOtpInSeconds", reader.getValueFromConfig("resend.otp.time.in.seconds"), resultsFromResponse);
    }

    @Given("I have entered password")
    public void encryptTestPassword() throws FileNotFoundException {
        encrypted_password = Utils.getEncryptedAuthData(reader.getValueFromConfig("test.password"));
    }

    @When("I make a request to the API with password")
    public void setPasswordForTestUser() {
        HashMap<String, Object> secretKeyAndPasswordPayload = JSONPayload.createTwoParameterPayload("secretKey", secretKey, "password", encrypted_password);
        reqspec = RestAssured.given().spec(reqspec).body(secretKeyAndPasswordPayload);
        res = reqspec.post(GlobalConstant.setPasswordEndpoint);
        System.out.println(res.asPrettyString());
    }

    @Then("I should receive a valid JSON response for setting password")
    public void validateSchemaForSettingPassword() {
        Utils.jsonSchemaValidator(res, reader.getValueFromConfig("set.password.schema"));
    }

    @Then("Verify the message in response")
    public void verifyMessageOfSetPassword() {
        responseObject = extractJsonObjectFromResponse(res);
        assertJsonValueEquals("message", reader.getValueFromConfig("set.password.message"), responseObject);
    }

    @Given("I have passcode {string} which needs to be set")
    public void encryptPasscode(String passcode) throws FileNotFoundException {
        encrypted_passcode = Utils.getEncryptedAuthData(passcode);
    }
    @When("I enter passcode and secret key {string}")
    public void setPasscode(String secret_key) {
        if(secret_key.isEmpty()==false){
            secret_key = secretKey;
        }
        HashMap<String, Object> setPasscodePayload = JSONPayload.createSevenParameterPayload("secretKey", secret_key,
                "passcode", encrypted_passcode,
                "deviceId", reader.getValueFromConfig("test.device.id"),
                "deviceType", reader.getValueFromConfig("test.device.type"),
                "fcmToken", reader.getValueFromConfig("test.fcm.token"),
                "versionCode", reader.getValueFromConfig("test.version.code"),
                "versionName", reader.getValueFromConfig("test.version.name"));
        reqspec = RestAssured.given().spec(reqspec).body(setPasscodePayload);
        res = reqspec.post(GlobalConstant.setPasscodeEndpoint);
        System.out.println(res.asPrettyString());
    }
    @Then("Verify the message {string} and code {string} of invalid passcode")
    public void verifyMessageAndCodeForSetPasscodeError(String message, String code) {
        responseObject = extractJsonObjectFromResponse(res);
        errorFromResponse = extractJsonValueFromJsonArray(responseObject, "errors",0);
        assertJsonValueEquals("code", code, errorFromResponse);
        assertJsonValueEquals("message", message, errorFromResponse);
        assertJsonValueEquals("description", message, errorFromResponse);
    }

    @Given("I have entered passcode")
    public void encryptTestPasscode() throws FileNotFoundException {
        encrypted_passcode = Utils.getEncryptedAuthData(reader.getValueFromConfig("test.passcode"));
    }

    @When("I make a request to the API with passcode")
    public void createTestUser() {
        HashMap<String, Object> setPasscodePayload = JSONPayload.createSevenParameterPayload("secretKey", secretKey,
                "passcode", encrypted_passcode,
                "deviceId", reader.getValueFromConfig("test.device.id"),
                "deviceType", reader.getValueFromConfig("test.device.type"),
                "fcmToken", reader.getValueFromConfig("test.fcm.token"),
                "versionCode", reader.getValueFromConfig("test.version.code"),
                "versionName", reader.getValueFromConfig("test.version.name"));
        reqspec = RestAssured.given().spec(reqspec).body(setPasscodePayload);
        res = reqspec.post(GlobalConstant.setPasscodeEndpoint);
        System.out.println(res.asPrettyString());
    }

    @Then("I should receive a valid JSON response for setting passcode")
    public void validateJsonForCreateUser() {
        Utils.jsonSchemaValidator(res, reader.getValueFromConfig("set.passcode.schema"));
    }

    @Then("Verify the message and token expiry and account status in response")
    public void verifyValuesOfUserCreationResponse() {
        responseObject = extractJsonObjectFromResponse(res);
        resultsFromResponse = extractNestedJsonObject(responseObject, "results");
        assertJsonValueEquals("message", reader.getValueFromConfig("set.passcode.message"), responseObject);
        assertJsonValueEquals("token_type", reader.getValueFromConfig("token.type"), resultsFromResponse);
        assertJsonValueEquals("acountStatus", reader.getValueFromConfig("user.account.status"), resultsFromResponse);
        assertJsonValueEquals("refresh_expires_in", reader.getValueFromConfig("refresh.token.expiry"), resultsFromResponse);
        assertJsonValueEquals("expires_in", reader.getValueFromConfig("access.token.expiry"), resultsFromResponse);
    }
    @Then("check in db if the user status is active")
    public void checkInDBIfUserIsActive() throws SQLException {
        query = "SELECT account_status FROM auth_service_user_credentials WHERE mobile_number = '"+ reader.getValueFromConfig("test.mobile.number")+"'";
        connection = Utils.getConnection("authservice_db");
        Statement statement = connection.createStatement();
        ResultSet resultSet = statement.executeQuery(query);
        if (resultSet.next()) {
            Assert.assertEquals(resultSet.getString("account_status"),"Active");
        }
        statement.close();
        Utils.closeConnection();
    }
}
