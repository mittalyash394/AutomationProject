package stepdef.Identity;

import base.BaseBuilder;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import org.json.JSONObject;
import utilities.GlobalConstant;
import utilities.JSONPayload;
import utilities.PropertyReader;
import utilities.Utils;

import java.io.FileNotFoundException;
import java.util.HashMap;

import static utilities.CommonStepDef.login;
import static utilities.Utils.*;

public class UpdateDeviceDetails {
    private static String access_token;
    private PropertyReader reader = new PropertyReader();
    private static BaseBuilder baseBuilder = new BaseBuilder();
    private static RequestSpecification reqspec;
    private static JSONObject responseObject;
    private Response res;

    @Given("I have logged in for updating device details")
    public void loginForUpdatingDetails() throws FileNotFoundException, InterruptedException {
        Thread.sleep(1000);
        res = login(reader.getValueFromConfig("test.mobile.number"),reader.getValueFromConfig("test.new.passcode"),reader.getValueFromConfig("test.device.id"),reader.getValueFromConfig("test.device.id"));
        access_token = getAccessTokenResponseData(res,"access_token");
    }
    @When("I pass access token in update device detail api")
    public void hitUpdateDeviceDetail() throws FileNotFoundException {
        HashMap<String, Object> updateDeviceDetailPayload = JSONPayload.createOneParameterPayload("isBiometricEnabled", reader.getValueFromConfig("biometric.enabled.flag"));
        reqspec=baseBuilder.placeSpecBuilder();
        reqspec = RestAssured.given().spec(reqspec).header("Authorization","Bearer " + access_token).body(updateDeviceDetailPayload);
        res=reqspec.put(GlobalConstant.updateDeviceDetailsEndpoint);
    }
    @Then("I should receive a valid JSON response for updating device details")
    public void validateUpdateDeviceDetailsResponse() {
        Utils.jsonSchemaValidator(res, reader.getValueFromConfig("update.device.details.schema"));
        Utils.verifyStatusCode(res, GlobalConstant.HTTP_OK);
    }
    @Then("Verify the message in response of updating device details")
    public void verifyMessageOfUpdatingDeviceDetails() {
        responseObject = extractJsonObjectFromResponse(res);
        assertJsonValueEquals("message", reader.getValueFromConfig("update.device.details.message"), responseObject);
    }
}
