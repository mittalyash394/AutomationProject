package stepdef.Identity;

import base.BaseBuilder;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import org.json.JSONObject;
import utilities.GlobalConstant;
import utilities.JSONPayload;
import utilities.PropertyReader;
import utilities.Utils;

import java.io.FileNotFoundException;
import java.util.HashMap;

import static utilities.CommonStepDef.login;
import static utilities.Utils.*;
import static utilities.Utils.assertJsonValueEquals;

public class BasicApis {
    private PropertyReader reader = new PropertyReader();
    private static BaseBuilder baseBuilder = new BaseBuilder();
    private static RequestSpecification reqspec;
    private static Response res;
    private static String encrypted_mobile_number;
    private static String access_token;
    private static String user_id;
    private static JSONObject responseObject;

    @Given("Get key api is hitted")
    public void hitGetKeyApi() throws FileNotFoundException {
        reqspec = baseBuilder.placeSpecBuilder();
        reqspec = RestAssured.given().spec(reqspec);
        res = reqspec.get(GlobalConstant.getKeyIdentityEndpoint);
    }
    @Then("Json schema for get key should be validated")
    public void validateJsonSchema() {
        Utils.jsonSchemaValidator(res, reader.getValueFromConfig("get.key.response.schema"));
        Utils.verifyStatusCode(res, GlobalConstant.HTTP_OK);
    }
    @Then("Verify the message of get key")
    public void verifyMessageOfGetKey() {
        responseObject = extractJsonObjectFromResponse(res);
        assertJsonValueEquals("message", reader.getValueFromConfig("get.key.message"), responseObject);
    }
    @Given("I have encrypted mobile number")
    public void encryptMobileNumber() throws FileNotFoundException {
        encrypted_mobile_number = getEncryptedAuthData(reader.getValueFromConfig("test.mobile.number"));
    }
    @When("I pass mobile number in get nonce api")
    public void hitGetNonceApi() {
        HashMap<String, Object> getNoncePayload = JSONPayload.createOneParameterPayload("mobileNumber", encrypted_mobile_number);
        reqspec = RestAssured.given().spec(reqspec).body(getNoncePayload);
        res = reqspec.post(GlobalConstant.getNonceEndpoint);
    }
    @Then("Nonce should be generated")
    public void validateNonceSchema() {
        Utils.jsonSchemaValidator(res, reader.getValueFromConfig("get.nonce.response.schema"));
        Utils.verifyStatusCode(res, GlobalConstant.HTTP_OK);
    }
    @Given("I have logged in")
    public void loginForGettingUserInfo() throws FileNotFoundException {
        res = login(reader.getValueFromConfig("test.mobile.number"),reader.getValueFromConfig("test.account.recover.passcode"),reader.getValueFromConfig("test.device.id"),reader.getValueFromConfig("test.device.id"));
        access_token = getAccessTokenResponseData(res,"access_token");
    }
    @When("I pass access token in user info api")
    public void hitUserInfoApi() {
        reqspec = RestAssured.given().spec(reqspec).header("Authorization",access_token);
        res = reqspec.post(GlobalConstant.getUserInfoEndpoint);
    }
    @Then("Json schema for user info should be validated")
    public void validateJsonSchemaForUserInfo() {
        Utils.jsonSchemaValidator(res, reader.getValueFromConfig("get.user.info.response.schema"));
        Utils.verifyStatusCode(res, GlobalConstant.HTTP_OK);
    }
    @Then("Verify the message of user info api")
    public void verifyMessageOfUserInfo() {
        responseObject = extractJsonObjectFromResponse(res);
        assertJsonValueEquals("message", reader.getValueFromConfig("get.user.info.message"), responseObject);
    }
    @Given("I have the user id from the user info api")
    public void fetchingUserId() {
        user_id = (String) Utils.getResponseData(res, "results.userId");
    }
    @When("I pass user id in get mobile device details api")
    public void hitGetDeviceDetailsApi() throws FileNotFoundException {
        reqspec=baseBuilder.placeSpecBuilder();
        reqspec = RestAssured.given().spec(reqspec).header("Authorization",access_token).header("userId",user_id);
        res = reqspec.get(GlobalConstant.getDeviceDetailsEndpoint);
    }
    @Then("Json schema for get mobile device details should be validated")
    public void validateJsonSchemaForDeviceDetails() {
        Utils.jsonSchemaValidator(res, reader.getValueFromConfig("get.device.detail.response.schema"));
        Utils.verifyStatusCode(res, GlobalConstant.HTTP_OK);
    }
    @Then("Verify the message of get mobile device details api")
    public void verifyMessageForFetchingDeviceDetail() {
        responseObject = extractJsonObjectFromResponse(res);
        assertJsonValueEquals("message", reader.getValueFromConfig("get.device.detail.message"), responseObject);
    }

}
