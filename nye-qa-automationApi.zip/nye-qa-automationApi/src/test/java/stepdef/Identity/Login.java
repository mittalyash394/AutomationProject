package stepdef.Identity;

import base.BaseBuilder;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.junit.Assert;
import utilities.CommonStepDef;
import utilities.GlobalConstant;
import utilities.PropertyReader;
import utilities.Utils;

import java.io.FileNotFoundException;

import static utilities.Utils.verifyStatusCode;

public class Login {

    private final static Logger logger = LogManager.getLogger(Login.class);
    private static RequestSpecification reqspec;
    private int statusCode;
    private String message;
    private static String accessToken;
    private static Response res;
    private static PropertyReader reader = new PropertyReader();
    private static BaseBuilder baseBuilder = new BaseBuilder();

    @Given("Enter valid mobileNumber and passcode in login api")
    public void loginWithDetails() throws FileNotFoundException {
        String deviceId = reader.getValueFromConfig("test.device.id");
        String mobileNumber = reader.getValueFromConfig("test.mobile.number");
        String passcode = reader.getValueFromConfig("test.account.recover.passcode");
        res = CommonStepDef.login(mobileNumber, passcode, deviceId,deviceId);
        System.out.println(res.asPrettyString());
        verifyStatusCode(res, GlobalConstant.HTTP_OK);
        message = (String) Utils.getResponseData(res, "message");
        accessToken = Utils.getAccessTokenResponseData(res, "results.access_token");
    }

    @Then("login successfully")
    public void checkIfLoggedIn() {
        if (message != null && message.equalsIgnoreCase("User Logged In")) {
            logger.info("Login successfully");
            Assert.assertTrue(true);
        } else {
            logger.error("Unable to login: " + message);
            Assert.assertTrue(false);
        }
    }

    @Then("verify status code")
    public void verifyStatusCodeAfterLogin() {
        verifyStatusCode(res, GlobalConstant.HTTP_OK);
    }

}
