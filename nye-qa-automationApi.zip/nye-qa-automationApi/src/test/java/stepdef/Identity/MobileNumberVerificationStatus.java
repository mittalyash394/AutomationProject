package stepdef.Identity;

import base.BaseBuilder;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import org.json.JSONObject;
import utilities.GlobalConstant;
import utilities.JSONPayload;
import utilities.PropertyReader;
import utilities.Utils;

import java.io.FileNotFoundException;
import java.util.HashMap;

import static utilities.Utils.*;

public class MobileNumberVerificationStatus {
    private static String encrypted_mobile_number;
    private PropertyReader reader = new PropertyReader();
    private static BaseBuilder baseBuilder = new BaseBuilder();
    private static RequestSpecification reqspec;
    private static JSONObject responseObject;
    private static JSONObject resultsFromResponse;
    private Response res;
    private static String smsString;
    private static String secretKey;

    @Given("I have generated sms string for registered mobile number")
    public void generateSmsStringForRegisteredUser() throws FileNotFoundException {
        deleteAuthUserCache(getEncryptedAuthData(reader.getValueFromConfig("test.mobile.number")));
        encrypted_mobile_number = getEncryptedAuthData(reader.getValueFromConfig("test.mobile.number"));
        HashMap<String, Object> generateSmsStringPayload = JSONPayload.createOneParameterPayload("mobileNumber", encrypted_mobile_number);
        reqspec = baseBuilder.placeSpecBuilder();
        reqspec = RestAssured.given().spec(reqspec).body(generateSmsStringPayload);
        res = reqspec.post(GlobalConstant.generateSmsStringEndpoint);
        secretKey = (String) Utils.getResponseData(res, "results.secretKey");
        smsString = (String) Utils.getResponseData(res, "results.smsString");
    }
    @When("I have verified sms string and hit the api for mobile verification status")
    public void verifySmsStringAndFetchTheStatusOfRegisteredMobileNumber() throws FileNotFoundException {
        reqspec = baseBuilder.placeSpecBuilder();
        reqspec = reqspec.header("Content-Type",reader.getValueFromConfig("verify.sms.string.content.type"));
        reqspec = reqspec.formParam("sender",reader.getValueFromConfig("sms.string.valid.sender"));
        reqspec = reqspec.formParam("keyword",reader.getValueFromConfig("sms.string.keyword"));
        reqspec = reqspec.formParam("content",smsString);
        RestAssured.given().spec(reqspec).auth().basic(reader.getValueFromConfig("sms.string.basic.auth.username")
                ,reader.getValueFromConfig("sms.string.basic.auth.password")).post(GlobalConstant.verifySmsStringEndpoint);
        HashMap<String, Object> mobileNumberandSecretKeyPayload = JSONPayload.createTwoParameterPayload("mobileNumber", encrypted_mobile_number,"secretKey",secretKey);
        reqspec = baseBuilder.placeSpecBuilder();
        reqspec = RestAssured.given().spec(reqspec).body(mobileNumberandSecretKeyPayload);
        res = reqspec.post(GlobalConstant.mobileNumberVerificationStatusEndpoint);

    }
    @Then("I should receive a valid JSON response for mobile number verification status")
    public void validateJsonResponse() {
        Utils.jsonSchemaValidator(res, reader.getValueFromConfig("mobile.number.verification.status.schema"));
        Utils.verifyStatusCode(res, GlobalConstant.HTTP_OK);
    }
    @Then("Verify the value of message and value of userExist")
    public void verifyMessageAndRegisteredUserStatus() {
        responseObject = extractJsonObjectFromResponse(res);
        resultsFromResponse = extractNestedJsonObject(responseObject, "results");
        assertJsonValueEquals("message", reader.getValueFromConfig("mobile.number.verification.status.message"), responseObject);
        assertJsonValueEquals("userExist", reader.getValueFromConfig("user.exist.flag.for.registered.mobile.number"), resultsFromResponse);
    }
    @Given("I have generated sms string for unregistered mobile number")
    public void generateSmsStringForUnregisteredUser() throws FileNotFoundException {
        encrypted_mobile_number = getEncryptedAuthData(reader.getValueFromConfig("test.unregistered.mobile.number"));
        HashMap<String, Object> generateSmsStringPayload = JSONPayload.createOneParameterPayload("mobileNumber", encrypted_mobile_number);
        reqspec = baseBuilder.placeSpecBuilder();
        reqspec = RestAssured.given().spec(reqspec).body(generateSmsStringPayload);
        res = reqspec.post(GlobalConstant.generateSmsStringEndpoint);
        secretKey = (String) Utils.getResponseData(res, "results.secretKey");
        smsString = (String) Utils.getResponseData(res, "results.smsString");
    }
    @When("I have verified sms string and hit the api for unregistered mobile verification status")
    public void verifySmsStringAndFetchTheStatusOfUnregisteredMobileNumber() throws FileNotFoundException {
        reqspec = baseBuilder.placeSpecBuilder();
        reqspec = reqspec.header("Content-Type",reader.getValueFromConfig("verify.sms.string.content.type"));
        reqspec = reqspec.formParam("sender",reader.getValueFromConfig("sms.string.invalid.sender"));
        reqspec = reqspec.formParam("keyword",reader.getValueFromConfig("sms.string.keyword"));
        reqspec = reqspec.formParam("content",smsString);
        RestAssured.given().spec(reqspec).auth().basic(reader.getValueFromConfig("sms.string.basic.auth.username"),
                reader.getValueFromConfig("sms.string.basic.auth.password")).post(GlobalConstant.verifySmsStringEndpoint);
        HashMap<String, Object> mobileNumberandSecretKeyPayload = JSONPayload.createTwoParameterPayload("mobileNumber", encrypted_mobile_number,"secretKey",secretKey);
        reqspec = baseBuilder.placeSpecBuilder();
        reqspec = RestAssured.given().spec(reqspec).body(mobileNumberandSecretKeyPayload);
        res = reqspec.post(GlobalConstant.mobileNumberVerificationStatusEndpoint);
    }
    @Then("Verify the value of message and value of userExist for unregistered number")
    public void verifyMessageAndUnregisteredUserStatus() {
        responseObject = extractJsonObjectFromResponse(res);
        resultsFromResponse = extractNestedJsonObject(responseObject, "results");
        assertJsonValueEquals("message", reader.getValueFromConfig("mobile.number.verification.status.message"), responseObject);
        assertJsonValueEquals("userExist", reader.getValueFromConfig("user.exist.flag.for.unregistered.mobile.number"), resultsFromResponse);
    }



}
