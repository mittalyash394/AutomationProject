package stepdef.Grievance;

import base.BaseBuilder;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import org.json.JSONArray;
import org.json.JSONObject;
import utilities.CommonStepDef;
import utilities.GlobalConstant;
import utilities.PropertyReader;
import utilities.Utils;

import java.io.FileNotFoundException;

import static io.restassured.RestAssured.given;

public class GetMenuMeta {


    private final PropertyReader propertyReader = new PropertyReader();

    public RequestSpecification requestSpecification;

    BaseBuilder baseBuilder = new BaseBuilder();
    private String access_token;

    private Response response;

    private JSONObject jsonObject;

    @Given("Pass the token in getMenuMeta API")
    public void pass_the_token_in_get_menu_meta_api() throws FileNotFoundException {
        System.out.println("Login with valid credentials");
        String mobileNumber = propertyReader.getValueFromConfig("grievance.user.mobile.number");
        String passcode = propertyReader.getValueFromConfig("grievance.user.passcode");
        String deviceId = propertyReader.getValueFromConfig("grievance.user.deviceId");
        response = CommonStepDef.login(mobileNumber,passcode,deviceId,deviceId);
        access_token = Utils.getAccessTokenResponseData(response,"access_token");
        System.out.println(response.asPrettyString());
        Utils.verifyStatusCode(response, GlobalConstant.HTTP_OK);
    }
    @When("Enter the valid getMenuMeta and hit the getMenuMeta API")
    public void enter_the_valid_get_menu_meta_and_hit_the_get_menu_meta_api() throws FileNotFoundException {
        requestSpecification = baseBuilder.placeSpecBuilder();

        response = given()
                .headers("Authorization", access_token)
                .spec(requestSpecification)
                .when()
                .log().all()
                .get(GlobalConstant.getMenuMeta);
        System.out.println("The active subscription response is " +response.asString());
    }
    @Then("Verify the statusCode of getMenuMeta API")
    public void verify_the_status_code_of_get_menu_meta_api() {
        System.out.println("Verifying the status code of activeSubscription API");
        Utils.verifyStatusCode(response, GlobalConstant.HTTP_OK);
    }
    @Then("Verify the response message of getMenuMeta API")
    public void verify_the_response_message_of_get_menu_meta_api() {
        jsonObject = Utils.extractJsonObjectFromResponse(response);
        System.out.println(jsonObject);
        Utils.assertJsonValueEquals("message", "GET Menu Meta executed SuccessFully", jsonObject);
    }
    @Then("Verify the response schema of getMenuMeta API")
    public void verify_the_response_schema_of_get_menu_meta_api() {
        jsonObject = Utils.extractJsonObjectFromResponse(response);
        System.out.println(jsonObject);
        JSONObject results = Utils.extractNestedJsonObject(jsonObject, "results");
        Utils.jsonSchemaValidator(response, propertyReader.getValueFromConfig("grievance.menu.meta.schema"));
    }
    @Then("The response body for getMenuMeta API should be valid for {string}")
    public void the_response_body_for_get_menu_meta_api_should_be_valid_for_and(String subscriptionMappingId) {
        String subscriptionMappingIdForNyeAccounts = propertyReader.getValueFromConfig("grievance.nyeAccounts.subscriptionMappingId");
        String subscriptionMappingIdForNyePrepaid = propertyReader.getValueFromConfig("grievance.nyePrepaid.subscriptionMappingId");
        String subscriptionMappingIdForJanaCa = propertyReader.getValueFromConfig("grievance.bankAccounts.jana.ca.subscriptionMappingId");
        String subscriptionMappingIdForJanaSa = propertyReader.getValueFromConfig("grievance.bankAccounts.jana.sa.subscriptionMappingId");
        String subscriptionMappingIdForIndusCa = propertyReader.getValueFromConfig("grievance.bankAccounts.indus.ca.subscriptionMappingId");
        String subscriptionMappingIdForGold = propertyReader.getValueFromConfig("grievance.gold.augmont.subscriptionMappingId");


        jsonObject = Utils.extractJsonObjectFromResponse(response);
        System.out.println(jsonObject);
        JSONObject results = Utils.extractNestedJsonObject(jsonObject, "results");
        System.out.println("The menu meta results response is " + results);

        System.out.println("*******************  Verifying the NYE Account grievance response for this  ****************");
        if (subscriptionMappingId.equals(subscriptionMappingIdForNyeAccounts)) {

            String expectedNyeAccountsDisplayName = propertyReader.getValueFromConfig("grievance.nyeAccounts.displayName");
            String expectedNyeAccountsDisplayKey = propertyReader.getValueFromConfig("grievance.nyeAccounts.displayKey");
            String expectedNyeAccountsServiceId = propertyReader.getValueFromConfig("grievance.nyeAccounts.serviceId");

            JSONObject nyeAccountResponse = Utils.extractJsonValueFromJsonArray(results, "types", 0);
            System.out.println("The menu meta nyeAccount results types response is " + nyeAccountResponse);

            Utils.assertJsonValueEquals("displayName", expectedNyeAccountsDisplayName, nyeAccountResponse);
            Utils.assertJsonValueEquals("displayKey", expectedNyeAccountsDisplayKey, nyeAccountResponse);
            Utils.assertJsonValueEquals("serviceId", expectedNyeAccountsServiceId, nyeAccountResponse);
        }

        System.out.println("*******************  Verifying the NYE Prepaid grievance response for this  ****************");
        if (subscriptionMappingId.equals(subscriptionMappingIdForNyePrepaid)) {

            String expectedNyePrepaidDisplayName = propertyReader.getValueFromConfig("grievance.nyePrepaid.displayName");
            String expectedNyePrepaidDisplayKey = propertyReader.getValueFromConfig("grievance.nyePrepaid.displayKey");
            String expectedNyePrepaidServiceId = propertyReader.getValueFromConfig("grievance.nyePrepaid.serviceId");

            JSONObject nyePrepaidResponse = Utils.extractJsonValueFromJsonArray(results, "types", 1);
            System.out.println("The menu meta nyePrepaid results types response is " + nyePrepaidResponse);

            Utils.assertJsonValueEquals("displayName", expectedNyePrepaidDisplayName, nyePrepaidResponse);
            Utils.assertJsonValueEquals("displayKey", expectedNyePrepaidDisplayKey, nyePrepaidResponse);
            Utils.assertJsonValueEquals("serviceId", expectedNyePrepaidServiceId, nyePrepaidResponse);
        }

        System.out.println("*******************  Verifying the gold grievance response for this  ****************");
        if (subscriptionMappingId.equals(subscriptionMappingIdForGold)) {

            String expectedGoldDisplayName = propertyReader.getValueFromConfig("grievance.gold.displayName");
            String expectedGoldDisplayKey = propertyReader.getValueFromConfig("griavance.gold.displayKey");
            String expectedGoldServiceId = propertyReader.getValueFromConfig("grievance.gold.serviceId");

            JSONObject gold = Utils.extractJsonValueFromJsonArray(results, "types", 3);
            System.out.println("The menu meta gold results types response is " + gold);

            Utils.assertJsonValueEquals("displayName", expectedGoldDisplayName, gold);
            Utils.assertJsonValueEquals("displayKey", expectedGoldDisplayKey, gold);
            Utils.assertJsonValueEquals("serviceId", expectedGoldServiceId, gold);

        }

        String subscriptionMappingIdForNull = null;
        if (subscriptionMappingIdForNull == null) {
            System.out.println("Hello YASH");
            System.out.println("*******************  Verifying the nyeBankAccounts grievance response for this  ****************");
            JSONObject nyeBankAccounts = Utils.extractJsonValueFromJsonArray(results, "types", 2);
            System.out.println("The menu meta nyeBankAccounts for JANA Current Account results types response is " + nyeBankAccounts);
            System.out.println("The subscriptionMapping Id is " + nyeBankAccounts.get("subscriptionMappingId"));

            String expectedNyeBankAccountsDisplayName = propertyReader.getValueFromConfig("grievance.bankAccounts.displayName");
            String expectedNyeBankAccountsDisplayKey = propertyReader.getValueFromConfig("grievance.bankAccounts.displayKey");
            String expectedNyeBankAccountsServiceId = propertyReader.getValueFromConfig("grievance.bankAccounts.serviceId");
            Utils.assertJsonValueEquals("displayName", expectedNyeBankAccountsDisplayName, nyeBankAccounts);
            Utils.assertJsonValueEquals("displayKey", expectedNyeBankAccountsDisplayKey, nyeBankAccounts);
            System.out.println("Getting the Bank Accounts subtype values");
            JSONArray bankAccountsSubTypeResponse = nyeBankAccounts.getJSONArray("subTypes");
            System.out.println("The bankAccountsSubTypeResponse hello is " + bankAccountsSubTypeResponse);

            System.out.println("*******************  Verifying the nyeBankAccounts for JANA Current Account grievance response for this  ****************");
            if (subscriptionMappingId.equals(subscriptionMappingIdForJanaCa)) {
                JSONObject jsonObjectForJanaCaResponse = bankAccountsSubTypeResponse.getJSONObject(0);
                System.out.println("The menu meta nyeBankAccounts for JANA Current Account results types response displayName is " + jsonObjectForJanaCaResponse.getString("displayName"));

                String expectedJanaCaAccountsDisplayName = propertyReader.getValueFromConfig("grievance.bankAccounts.jana.ca.displayName");
                String expectedJanaCaBankAccountsDisplayKey = propertyReader.getValueFromConfig("grievance.bankAccounts.jana.ca.displayKey");
                Utils.assertJsonValueEquals("displayName", expectedJanaCaAccountsDisplayName, jsonObjectForJanaCaResponse);
                Utils.assertJsonValueEquals("displayKey", expectedJanaCaBankAccountsDisplayKey, jsonObjectForJanaCaResponse);
                Utils.assertJsonValueEquals("serviceId", expectedNyeBankAccountsServiceId, jsonObjectForJanaCaResponse);
            }

            System.out.println("*******************  Verifying the nyeBankAccounts for JANA Savings Account grievance response for this  ****************");
            if(subscriptionMappingId.equals(subscriptionMappingIdForJanaSa)) {
                JSONObject janaSaResponse = bankAccountsSubTypeResponse.getJSONObject(1);
                System.out.println("The menu meta nyeBankAccounts for JANA Savings Account results types response is " + janaSaResponse);
                String expectedJanaSaAccountsDisplayName = propertyReader.getValueFromConfig("grievance.bankAccounts.jana.sa.displayName");
                String expectedJanaSaBankAccountsDisplayKey = propertyReader.getValueFromConfig("grievance.bankAccounts.jana.sa.displayKey");
                Utils.assertJsonValueEquals("displayName", expectedJanaSaAccountsDisplayName, janaSaResponse);
                Utils.assertJsonValueEquals("displayKey", expectedJanaSaBankAccountsDisplayKey, janaSaResponse);
                Utils.assertJsonValueEquals("serviceId", expectedNyeBankAccountsServiceId, janaSaResponse);
            }
            System.out.println("*******************  Verifying the nyeBankAccounts for INDUS Current Account grievance response for this  ****************");
            if(subscriptionMappingId.equals(subscriptionMappingIdForIndusCa)) {
                JSONObject indusCaResponse = bankAccountsSubTypeResponse.getJSONObject(2);
                System.out.println("The menu meta nyeBankAccounts for INDUS Current Account results types response is " + indusCaResponse);
                String expectedCaAccountsDisplayName = propertyReader.getValueFromConfig("grievance.bankAccounts.indus.ca.displayName");
                String expectedCaBankAccountsDisplayKey = propertyReader.getValueFromConfig("grievance.bankAccounts.indus.ca.displayKey");
                Utils.assertJsonValueEquals("displayName", expectedCaAccountsDisplayName, indusCaResponse);
                Utils.assertJsonValueEquals("displayKey", expectedCaBankAccountsDisplayKey, indusCaResponse);
                Utils.assertJsonValueEquals("serviceId", expectedNyeBankAccountsServiceId, indusCaResponse);
            }
        }
    }
}
