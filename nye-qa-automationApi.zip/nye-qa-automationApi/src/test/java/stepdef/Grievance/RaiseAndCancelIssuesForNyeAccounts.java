package stepdef.Grievance;

import base.BaseBuilder;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import org.json.JSONObject;
import utilities.CommonStepDef;
import utilities.GlobalConstant;
import utilities.PropertyReader;
import utilities.Utils;

import java.io.FileNotFoundException;

public class RaiseAndCancelIssuesForNyeAccounts {

    private final PropertyReader propertyReader = new PropertyReader();

    public RequestSpecification requestSpecification;

    BaseBuilder baseBuilder = new BaseBuilder();
    private String access_token;

    private Response loginResponse;

    private Response getScreenOptionsResponse;

    private Response raiseIssueApiResponse;

    private Response cancelIssueApiResponse;

    private JSONObject jsonObject;

    @Given("Pass the token in getScreenOptions API for nyeAccounts and non-transactional issues in grievance")
    public void pass_the_token_in_get_screen_options_api_for_nye_accounts_and_non_transactional_issues_in_grievance() throws FileNotFoundException {
        System.out.println("Login with valid credentials");
        String mobileNumber = propertyReader.getValueFromConfig("grievance.user.mobile.number");
        String passcode = propertyReader.getValueFromConfig("grievance.user.passcode");
        String deviceId = propertyReader.getValueFromConfig("grievance.user.deviceId");
        loginResponse = CommonStepDef.login(mobileNumber,passcode,deviceId,deviceId);
        access_token = Utils.getAccessTokenResponseData(loginResponse,"access_token");
        System.out.println(loginResponse.asPrettyString());
        Utils.verifyStatusCode(loginResponse, GlobalConstant.HTTP_OK);
    }

    @When("Enter the valid parameters in getScreenOptions API for nyeAccounts and non-transactional issues and hit the getIssueMeta API for nyeAccounts in grievance")
    public void enter_the_valid_parameters_in_get_screen_options_api_for_nye_accounts_and_non_transactional_issues_and_hit_the_get_issue_meta_api_for_nye_accounts_in_grievance() throws FileNotFoundException {
        String issueId = propertyReader.getValueFromConfig("grievance.nyeAccounts.non-transactionalIssue");
        requestSpecification = baseBuilder.placeSpecBuilder();

        getScreenOptionsResponse = CommonStepDef.getScreenOptions(issueId, access_token);
        System.out.println("The getScreenOptions API response is " +getScreenOptionsResponse.asString());
    }

    @Then("Verify the statusCode of getScreenOptions API for nyeAccounts and non-transactional issues in grievance")
    public void verify_the_status_code_of_get_screen_options_api_for_nye_accounts_and_non_transactional_issues_in_grievance() {
        System.out.println("Verifying the statusCode for getScreenOptions API for nyeAccounts and non-transactional issue");
        Utils.verifyStatusCode(getScreenOptionsResponse, GlobalConstant.HTTP_OK);
    }

    @Then("Verify the response message of getScreenOptions API for nyeAccounts and non-transactional issues in grievance")
    public void verify_the_response_message_of_get_screen_options_api_for_nye_accounts_and_non_transactional_issues_in_grievance() {
        System.out.println("Verifying the getScreenOptions API for nyeAccounts and non-transactional issues response");
        jsonObject = Utils.extractJsonObjectFromResponse(getScreenOptionsResponse);
        Utils.assertJsonValueEquals("message", "Get screen options Meta executed SuccessFully", jsonObject);
    }

    @Then("Verify the response schema of getScreenOptions API for nyeAccounts and non-transactional issues in grievance")
    public void verify_the_response_schema_of_get_screen_options_api_for_nye_accounts_and_non_transactional_issues_in_grievance() {
        System.out.println("Verifying the response schema for getIssueMeta for nyeAccounts and non-transactional issues");
        jsonObject = Utils.extractJsonObjectFromResponse(getScreenOptionsResponse);
        Utils.jsonSchemaValidator(getScreenOptionsResponse, propertyReader.getValueFromConfig("grievance.nyeAccounts.nyeAccounts.non.transactional.getScreenOptionsMeta"));
    }

    @Then("The response body for getScreenOptions API for nyeAccounts and non-transactional issues in grievance should be valid")
    public void the_response_body_for_get_screen_options_api_for_nye_accounts_and_non_transactional_issues_in_grievance_should_be_valid() {
        System.out.println("Verifying the getIssueMeta API response for nyeAccounts");
        jsonObject = Utils.extractJsonObjectFromResponse(getScreenOptionsResponse);
        System.out.println("The jsonObject response for nyeAccounts and non-transactional issues API is " + jsonObject);
        JSONObject results = Utils.extractNestedJsonObject(jsonObject, "results");
        System.out.println("The jsonObject results response for nyeAccounts and non-transactional issues API is " + results);
        String issueId = results.get("issueId").toString();
        Utils.assertJsonNullValue(String.valueOf(issueId));
    }

    @Given("Pass the token in RaiseIssue API for nyeAccounts and non-transactional issues in grievance")
    public void pass_the_token_in_raise_issue_api_for_nye_accounts_and_non_transactional_issues_in_grievance() throws FileNotFoundException {
        System.out.println("Login with valid credentials");
        String mobileNumber = propertyReader.getValueFromConfig("grievance.user.mobile.number");
        String passcode = propertyReader.getValueFromConfig("grievance.user.passcode");
        String deviceId = propertyReader.getValueFromConfig("grievance.user.deviceId");
        loginResponse = CommonStepDef.login(mobileNumber,passcode,deviceId,deviceId);
        access_token = Utils.getAccessTokenResponseData(loginResponse,"access_token");
        System.out.println(loginResponse.asPrettyString());
        Utils.verifyStatusCode(loginResponse, GlobalConstant.HTTP_OK);
    }

    @When("Enter the valid parameters in RaiseIssue API for nyeAccounts and non-transactional issues and hit the getIssueMeta API for nyeAccounts in grievance")
    public void enter_the_valid_parameters_in_raise_issue_api_for_nye_accounts_and_non_transactional_issues_and_hit_the_get_issue_meta_api_for_nye_accounts_in_grievance() throws FileNotFoundException {
        String api_key = propertyReader.getValueFromConfig("grievance.api.key");
        String issueId = propertyReader.getValueFromConfig("grievance.nyeAccounts.non-transactionalIssue");
        String attachmentPath = "";
        String description = "";
        String hasAttachment = "false";
        String referenceId = "";
        String referenceType = propertyReader.getValueFromConfig("grievance.nyeAccounts.raiseIssue.non.transactional.referenceType");
        String selectedOption = propertyReader.getValueFromConfig("grievance.nyeAccounts.raiseIssue.non.transactional.selectedOption");
        String serviceProductId = null;
        String subscriptionMappingId = propertyReader.getValueFromConfig("grievance.nyeAccounts.subscriptionMappingId");

        raiseIssueApiResponse = CommonStepDef.getRaiseIssueApiResponse(access_token, api_key, issueId, attachmentPath, description, hasAttachment, referenceId, referenceType, selectedOption, subscriptionMappingId, serviceProductId);
        System.out.println("The RaiseIssue API response is " +raiseIssueApiResponse.asString());
    }

    @Then("Verify the statusCode of RaiseIssue API for nyeAccounts and non-transactional issues in grievance")
    public void verify_the_status_code_of_raise_issue_api_for_nye_accounts_and_non_transactional_issues_in_grievance() {
        System.out.println("Verifying the statusCode for RaiseIssue API for nyeAccounts and non-transactional issue");
        Utils.verifyStatusCode(raiseIssueApiResponse, GlobalConstant.HTTP_OK);
    }

    @Then("Verify the response message of RaiseIssue API for nyeAccounts and non-transactional issues in grievance")
    public void verify_the_response_message_of_raise_issue_api_for_nye_accounts_and_non_transactional_issues_in_grievance() {
        System.out.println("Verifying the RaiseIssue API API for nyeAccounts and non-transactional issues response");
        jsonObject = Utils.extractJsonObjectFromResponse(raiseIssueApiResponse);
        Utils.assertJsonValueEquals("message", "Success", jsonObject);
    }

    @Then("Verify the response schema of RaiseIssue API for nyeAccounts and non-transactional issues in grievance")
    public void verify_the_response_schema_of_raise_issue_api_for_nye_accounts_and_non_transactional_issues_in_grievance() {
        System.out.println("Verifying the response schema for RaiseIssue API for nyeAccounts and non-transactional issues");
        jsonObject = Utils.extractJsonObjectFromResponse(raiseIssueApiResponse);
        Utils.jsonSchemaValidator(raiseIssueApiResponse, propertyReader.getValueFromConfig("grievance.nyeAccounts.raiseIssue.nonTransactionalIssue.schema"));
    }

    @Then("The response body for RaiseIssue API for nyeAccounts and non-transactional issues in grievance should be valid")
    public void the_response_body_for_raise_issue_api_for_nye_accounts_and_non_transactional_issues_in_grievance_should_be_valid() {
        System.out.println("Verifying the getIssueMeta API response for RaiseIssue API for nyeAccounts and non-transactional issues");
        jsonObject = Utils.extractJsonObjectFromResponse(raiseIssueApiResponse);
        System.out.println("The jsonObject response for RaiseIssue API for nyeAccounts and non-transactional issues is " + jsonObject);
        JSONObject results = Utils.extractNestedJsonObject(jsonObject, "results");
        System.out.println("The jsonObject results response for RaiseIssue API for nyeAccounts and non-transactional issues is " + results);
        String issueId = propertyReader.getValueFromConfig("grievance.nyeAccounts.non-transactionalIssue");
        Utils.assertJsonValueEquals("issueId", issueId, results);
    }

    @Given("Pass the token in CancelIssue or update API for nyeAccounts and non-transactional issues in grievance")
    public void pass_the_token_in_cancel_issue_or_update_api_for_nye_accounts_and_non_transactional_issues_in_grievance() throws FileNotFoundException {
        System.out.println("Login with valid credentials");
        String mobileNumber = propertyReader.getValueFromConfig("grievance.user.mobile.number");
        String passcode = propertyReader.getValueFromConfig("grievance.user.passcode");
        String deviceId = propertyReader.getValueFromConfig("grievance.user.deviceId");
        loginResponse = CommonStepDef.login(mobileNumber,passcode,deviceId,deviceId);
        access_token = Utils.getAccessTokenResponseData(loginResponse,"access_token");
        System.out.println(loginResponse.asPrettyString());
        Utils.verifyStatusCode(loginResponse, GlobalConstant.HTTP_OK);
    }

    @When("Enter the valid parameters in CancelIssue or update API for nyeAccounts and non-transactional issues and hit the getIssueMeta API for nyeAccounts in grievance")
    public void enter_the_valid_parameters_in_cancel_issue_or_update_api_for_nye_accounts_and_non_transactional_issues_and_hit_the_get_issue_meta_api_for_nye_accounts_in_grievance() throws FileNotFoundException {
        String statusForCancel = propertyReader.getValueFromConfig("grievance.nyeAccounts.cancelStatus");
        String resolution = propertyReader.getValueFromConfig("grievance.nyeAccounts.cancelResolution");
        String nyeTicketId = getNyeTicketIdForCancelTicket();
        String api_key = propertyReader.getValueFromConfig("grievance.api.key");
        requestSpecification = baseBuilder.placeSpecBuilder();


        cancelIssueApiResponse = CommonStepDef.updateGrievanceApiForCancellation(statusForCancel, resolution, nyeTicketId, access_token, api_key);
        System.out.println("The cancelIssue or updateIssue API response is " +cancelIssueApiResponse.asString());

    }

    private String getNyeTicketIdForCancelTicket() {
        System.out.println("Verifying the getIssueMeta API response for RaiseIssue API for nyeAccounts and non-transactional issues");
        jsonObject = Utils.extractJsonObjectFromResponse(raiseIssueApiResponse);
        System.out.println("The jsonObject response for RaiseIssue API for nyeAccounts and non-transactional issues is " + jsonObject);
        JSONObject results = Utils.extractNestedJsonObject(jsonObject, "results");
        System.out.println("The jsonObject results response for RaiseIssue API for nyeAccounts and non-transactional issues is " + results);
        String nyeTicketId = results.getString("nyeTicketId");
        return nyeTicketId;
    }

    @Then("Verify the statusCode of CancelIssue or update API for nyeAccounts and non-transactional issues in grievance")
    public void verify_the_status_code_of_cancel_issue_or_update_api_for_nye_accounts_and_non_transactional_issues_in_grievance() {
        System.out.println("Verifying the statusCode for CancelIssue or update API for nyeAccounts and non-transactional issue");
        Utils.verifyStatusCode(cancelIssueApiResponse, GlobalConstant.HTTP_OK);
    }

    @Then("Verify the response message of CancelIssue or update API for nyeAccounts and non-transactional issues in grievance")
    public void verify_the_response_message_of_cancel_issue_or_update_api_for_nye_accounts_and_non_transactional_issues_in_grievance() {
        System.out.println("Verifying the CancelIssue or update API for nyeAccounts and non-transactional issues response");
        jsonObject = Utils.extractJsonObjectFromResponse(cancelIssueApiResponse);
        Utils.assertJsonValueEquals("message", "Success", jsonObject);
    }

    @Then("Verify the response schema of CancelIssue or update API for nyeAccounts and non-transactional issues in grievance")
    public void verify_the_response_schema_of_cancel_issue_or_update_api_for_nye_accounts_and_non_transactional_issues_in_grievance() {
        System.out.println("Verifying the response schema for CancelIssue or update API for nyeAccounts and non-transactional issues");
        jsonObject = Utils.extractJsonObjectFromResponse(cancelIssueApiResponse);
        Utils.jsonSchemaValidator(cancelIssueApiResponse, propertyReader.getValueFromConfig("grievance.nyeAccounts.cancelIssue.schema"));
    }

    @Then("The response body for CancelIssue or update API for nyeAccounts and non-transactional issues in grievance should be valid")
    public void the_response_body_for_cancel_issue_or_update_api_for_nye_accounts_and_non_transactional_issues_in_grievance_should_be_valid() {
        System.out.println("Verifying the getIssueMeta API response for nyeAccounts");
        jsonObject = Utils.extractJsonObjectFromResponse(cancelIssueApiResponse);
        System.out.println("The jsonObject response for nyeAccounts and non-transactional issues API is " + jsonObject);
        JSONObject results = Utils.extractNestedJsonObject(jsonObject, "results");
//        System.out.println("The jsonObject results response for CancelIssue or update API and non-transactional issues API is " + results);
//        JSONObject status = results.get("status").toString();
//        Utils.assertJsonValueEquals(status, "CANCELLED", status);
    }
}
