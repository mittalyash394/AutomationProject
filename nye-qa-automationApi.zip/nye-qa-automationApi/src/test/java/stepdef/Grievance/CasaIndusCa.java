package stepdef.Grievance;

public class CasaIndusCa {
}
