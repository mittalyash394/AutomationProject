package stepdef.Grievance;

import base.BaseBuilder;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import org.json.JSONObject;
import utilities.CommonStepDef;
import utilities.GlobalConstant;
import utilities.PropertyReader;
import utilities.Utils;

import java.io.FileNotFoundException;

import static io.restassured.RestAssured.given;

public class NyeAccountsGetIssueMeta {

    private final PropertyReader propertyReader = new PropertyReader();

    public RequestSpecification requestSpecification;

    BaseBuilder baseBuilder = new BaseBuilder();
    private String access_token;

    private Response response;

    private JSONObject jsonObject;

    @Given("Pass the token in getIssueMeta API for nyeAccounts in grievance")
    public void pass_the_token_in_get_issue_meta_api_for_nye_accounts_in_grievance() throws FileNotFoundException {
        System.out.println("Login with valid credentials");
        String mobileNumber = propertyReader.getValueFromConfig("grievance.user.mobile.number");
        String passcode = propertyReader.getValueFromConfig("grievance.user.passcode");
        String deviceId = propertyReader.getValueFromConfig("grievance.user.deviceId");
        response = CommonStepDef.login(mobileNumber, passcode, deviceId, deviceId);
        access_token = Utils.getAccessTokenResponseData(response, "access_token");
        System.out.println(response.asPrettyString());
        Utils.verifyStatusCode(response, GlobalConstant.HTTP_OK);
    }

    @When("Enter the valid parameters in getIssueMeta API and hit the getIssueMeta API for nyeAccounts in grievance")
    public void enter_the_valid_parameters_in_get_issue_meta_api_and_hit_the_get_issue_meta_api_for_nye_accounts_in_grievance() throws FileNotFoundException {
        String nyAccountsServiceProductId = "";
        String subscriptionMappingId = propertyReader.getValueFromConfig("grievance.nyeAccounts.subscriptionMappingId");
        String status = propertyReader.getValueFromConfig("grievance.nyeAccounts.status");
        requestSpecification = baseBuilder.placeSpecBuilder();

        response = given()
                .headers("Authorization", access_token)
                .spec(requestSpecification)
                .queryParam("serviceProductId", nyAccountsServiceProductId)
                .queryParam("subscriptionMappingId", subscriptionMappingId)
                .queryParam("status", status)
                .when()
                .log().all()
                .get(GlobalConstant.getIssueMetaForNyeAccounts);
        System.out.println("The pinCode API response is " + response.asString());
    }

    @Then("Verify the statusCode of getIssueMeta API for nyeAccounts in grievance")
    public void verify_the_status_code_of_get_issue_meta_api_for_nye_accounts_in_grievance() {
        System.out.println("Verifying the statusCode for getIssueMeta API for nyeAccounts");
        Utils.verifyStatusCode(response, GlobalConstant.HTTP_OK);
    }

    @Then("Verify the response message of getIssueMeta API for nyeAccounts in grievance")
    public void verify_the_response_message_of_get_issue_meta_api_for_nye_accounts_in_grievance() {
        System.out.println("Verifying the getIssueMeta API response");
        jsonObject = Utils.extractJsonObjectFromResponse(response);
        Utils.assertJsonValueEquals("message", "GET Issue Meta executed SuccessFully", jsonObject);
    }

    @Then("Verify the response schema of getIssueMeta API for nyeAccounts in grievance")
    public void verify_the_response_schema_of_get_issue_meta_api_for_nye_accounts_in_grievance() {
        System.out.println("Verifying the response schema for getIssueMeta for nyeAccounts");
        jsonObject = Utils.extractJsonObjectFromResponse(response);
        Utils.jsonSchemaValidator(response, propertyReader.getValueFromConfig("grievance.nyeAccounts.getIssueMeta.schema"));
    }

    @Then("The response body for getIssueMeta API for nyeAccounts in grievance should be valid")
    public void the_response_body_for_get_issue_meta_api_for_nye_accounts_in_grievance_should_be_valid() {
        System.out.println("Verifying the getIssueMeta API response for nyeAccounts");
        jsonObject = Utils.extractJsonObjectFromResponse(response);
        System.out.println("The jsonObject response for pinCode API is " + jsonObject);
        JSONObject results = Utils.extractNestedJsonObject(jsonObject, "results");
        System.out.println("The jsonObject results response for pinCode API is " + results);
        JSONObject issueTransactionsResponse = Utils.extractNestedJsonObject(results, "issueTransactionsResponse");
        System.out.println("The issueTransactionResponse is " + issueTransactionsResponse);

        System.out.println(" ********** Verifying the transactionCount *********  ");
        String transactionCount = issueTransactionsResponse.get("transactionCount").toString();
        System.out.println("The transactionCount is " + transactionCount);
        Utils.assertJsonNullValue(transactionCount);
    }
}
