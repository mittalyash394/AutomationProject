package stepdef.CKYC;

import base.BaseBuilder;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.json.JSONArray;
import org.json.JSONObject;
import stepdef.Identity.Login;
import utilities.CommonStepDef;
import utilities.GlobalConstant;
import utilities.PropertyReader;
import utilities.Utils;

import java.io.FileNotFoundException;
import java.util.HashMap;

import static utilities.Utils.*;


public class createWallet {

    private final static Logger logger = LogManager.getLogger(Login.class);
    private int statusCode;
    private String message;
    private static String accessToken;
    private static Response res;
    private static PropertyReader reader = new PropertyReader();
    private static RequestSpecification reqspec;
    private static BaseBuilder baseBuilder = new BaseBuilder();
    private JSONObject jsonObject;
    private Response response;

    @Given("Login with valid credentials for creating wallet")
    public void login_with_valid_credentials_for_creating_wallet() throws FileNotFoundException {
        String deviceId = reader.getValueFromConfig("vc.user.deviceid");
        String mobileNumber = reader.getValueFromConfig("vc.user.mobile.number");
        String passcode = reader.getValueFromConfig("vc.user.passcode");
        res = CommonStepDef.login(mobileNumber,passcode,deviceId,deviceId);
        System.out.println(res.asPrettyString());
        verifyStatusCode(res, GlobalConstant.HTTP_OK);
        message = (String) Utils.getResponseData(res,"message");
        accessToken = Utils.getAccessTokenResponseData(res,"access_token");


    }
    @Given("Hit the API using latitude, longitude, device id")
    public void hit_the_api_using_latitude_longitude_device_id() throws FileNotFoundException {
        HashMap<String, String> payload = Utils.getLocation();
        String privacy = reader.getValueFromConfig("vc.user.privacy");
        reqspec = baseBuilder.placeSpecBuilder().queryParam("privacy",privacy);
        System.out.println("AccessToken"+accessToken);
        reqspec = reqspec.header("Authorization","Bearer " + accessToken);
        reqspec = RestAssured.given().spec(reqspec).body(payload);
        String path = GlobalConstant.createWallet+"?privacy"+privacy;
        System.out.println(path);
        res = reqspec.post(GlobalConstant.createWallet);
        System.out.println(res.asPrettyString());
    }


    @Given("Verify the error response when wallet is already created")
    public void verify_the_error_response_when_wallet_is_already_created() {
        Utils.verifyStatusCode(res,GlobalConstant.HTTP_BAD_REQUEST);
    }

    @Then("Response should be valid for create wallet")
    public void response_should_be_valid_for_create_wallet() {
        System.out.println("Verifying the CreateWallet API response");
        jsonObject = Utils.extractJsonObjectFromResponse(res);
        JSONObject errors = extractJsonValueFromJsonArray(jsonObject,"errors",0);
       System.out.println("The jsonArray response is " + errors);
       Utils.jsonSchemaValidator(res, reader.getValueFromConfig("vc.createwallet.schema"));
       assertJsonValueEquals("code","NYE-PPI-002",errors);
       assertJsonValueEquals("message","NYE Prepaid already exists",errors);
       assertJsonValueEquals("description","NYE Prepaid already exists for this user. Please log in to continue.",errors);
    }

    @Given("Login with valid credentials to create wallet for first time")
    public void login_with_valid_credentials_to_create_wallet_for_first_time() throws FileNotFoundException {
        System.out.println("Login with valid credentials to create wallet for first time");
        String deviceId = reader.getValueFromConfig("vc.user.deviceid.withoutwallet");
        String mobileNumber = reader.getValueFromConfig("vc.user.mobile.number.withoutwallet");
        String passcode = reader.getValueFromConfig("vc.user.passcode.withoutwallet");
        res = CommonStepDef.login(mobileNumber,passcode,deviceId,deviceId);
        System.out.println(res.asPrettyString());
        verifyStatusCode(res, GlobalConstant.HTTP_OK);
        message = (String) Utils.getResponseData(res,"message");
        accessToken = Utils.getAccessTokenResponseData(res,"access_token");
        System.out.println(accessToken);
        System.out.println("Delete the wallet for the user");
        res = deleteVCWallet(accessToken);
        System.out.println(res.asPrettyString());

    }
    @Given("Hit the API using latitude, longitude, device id to create wallet for first time")
    public void hit_the_api_using_latitude_longitude_device_id_to_create_wallet_for_first_time() throws FileNotFoundException {
        HashMap<String, String> payload = Utils.getLocation();
        String privacy = reader.getValueFromConfig("vc.user.privacy.withoutwallet");
        reqspec = baseBuilder.placeSpecBuilder().queryParam("privacy",privacy);
        System.out.println("AccessToken"+accessToken);
        reqspec = reqspec.header("Authorization","Bearer " + accessToken);
        reqspec = RestAssured.given().spec(reqspec).body(payload);
        String path = GlobalConstant.createWallet+"?privacy"+privacy;
        System.out.println(path);
        res = reqspec.post(GlobalConstant.createWallet);
        System.out.println(res.asPrettyString());

    }
    @Given("Verify the success response when wallet is created")
    public void verify_the_success_response_when_wallet_is_created() {
        Utils.verifyStatusCode(res,GlobalConstant.HTTP_CREATED);
    }
    @Then("Response should be valid when wallet created first time")
    public void response_should_be_valid_when_wallet_created_first_time() {
        System.out.println("Verifying the success response for wallet created first time");
        jsonObject = Utils.extractJsonObjectFromResponse(res);
        System.out.println(jsonObject.toString());
        JSONObject responseObject = Utils.extractJsonObjectFromResponse(res);
        JSONObject results = Utils.extractNestedJsonObject(responseObject, "results");
        Utils.jsonSchemaValidator(res, reader.getValueFromConfig("vc.createwallet.schema.withoutwallet"));
        assertJsonValueEquals("message","Wallet Created Successfully", responseObject);
        assertJsonValueEquals("data","SUCCESS",results);

    }

}
