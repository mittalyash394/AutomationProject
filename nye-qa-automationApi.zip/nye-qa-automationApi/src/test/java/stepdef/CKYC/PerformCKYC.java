package stepdef.CKYC;

import base.BaseBuilder;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import org.json.simple.JSONObject;
import utilities.GlobalConstant;
import utilities.JSONPayload;
import utilities.PropertyReader;
import utilities.Utils;

import java.io.FileNotFoundException;
import java.util.HashMap;

import static utilities.CommonStepDef.ckycLogin;
import static utilities.GlobalConstant.HTTP_OK;
import static utilities.Utils.*;
import static utilities.Utils.extractJsonValueFromJsonArray;

public class PerformCKYC {

    private static Response res;
    private static PropertyReader reader = new PropertyReader();
    private static RequestSpecification reqspec;
    private org.json.JSONObject jsonObject;



    @Given("Login with valid username and password to perform CKYC")
    public void login_with_valid_username_and_password_to_perform_ckyc() {
        System.out.println("Login with valid username and password to perform CKYC");
        ckycLogin();
    }

    @Given("Enter valid PAN & DOB")
    public void enter_valid_pan_dob() throws FileNotFoundException {
        String panNumber = reader.getValueFromConfig("vc.pan.ckycsecuredsearch");
        String dateofBirth = reader.getValueFromConfig("vc.dob");
        HashMap<String, Object> performCKYC = JSONPayload.nestedPayloadToPerformCKYC(panNumber, dateofBirth);
        System.out.println("The nested payload to perform CKYC "+performCKYC);
        JSONObject jsonObject = new JSONObject();
        reqspec = new BaseBuilder().placeSpecBuilder();
        reqspec = RestAssured.given().spec(reqspec).body(performCKYC);
        res = reqspec.post(GlobalConstant.performckycEndpoint).then().extract().response();
        System.out.println("The response for CKYC is " + res);
        if(res.getStatusCode()!=HTTP_OK){
            System.out.println(res.asPrettyString());
        }
        reqspec = RestAssured.given().spec(reqspec).body(performCKYC);
        res = reqspec.post(GlobalConstant.performckycEndpoint);
        System.out.println(res.asPrettyString());
    }

    @Given("Verify the success response after CKYC perfomed")
    public void verify_the_success_response_after_ckyc_perfomed() {
        Utils.verifyStatusCode(res, HTTP_OK);

    }

    @Then("Response should be valid for ckyc")
    public void response_should_be_valid_for_ckyc() {
        System.out.println("Verifying the response for CKYC");
        jsonObject = Utils.extractJsonObjectFromResponse(res);
        System.out.println(jsonObject.toString());
        org.json.JSONObject responseObject = Utils.extractJsonObjectFromResponse(res);
        Utils.jsonSchemaValidator(res, reader.getValueFromConfig("vc.performckyc.schema"));
        assertJsonValueEquals("message","Success", responseObject);
        org.json.JSONObject results = extractNestedJsonObject(responseObject,"results");
        org.json.JSONObject pidData = extractNestedJsonObject(results,"PID_DATA");
        org.json.JSONObject personalDetails = extractNestedJsonObject(pidData,"PERSONAL_DETAILS");
        assertJsonValueEquals("PAN",reader.getValueFromConfig("vc.pan.ckycsecuredsearch"),personalDetails);
        System.out.println();


    }

    @Given("I have PAN {string}, DOB {string} which needs to be verified")
    public void i_have_pan_dob_which_needs_to_be_verified(String pan, String dob) throws FileNotFoundException {
        System.out.println("Verifying negative scenarios for perform ckyc api");
        HashMap<String, Object> performCKYC = JSONPayload.nestedPayloadToPerformCKYC(pan,dob);
        System.out.println(performCKYC );
        reqspec = new BaseBuilder().placeSpecBuilder();
        ckycLogin();
        reqspec = RestAssured.given().spec(reqspec).body(performCKYC );
        res = reqspec.post(GlobalConstant.performckycEndpoint).then().extract().response();
        if(res.getStatusCode()!=HTTP_OK){
            System.out.println(res.asPrettyString());
        }
        System.out.println(res.asPrettyString());
    }

    @Then("Response json should be validated for invalid pan & dob and status code should be {int}")
    public void response_json_should_be_validated_for_invalid_pan_dob_and_status_code_should_be(Integer statusCode) {
        System.out.println("Validating the error code for invalid scenarios for performckyc");
        Utils.jsonSchemaValidator(res, reader.getValueFromConfig("vc.errorperformckyc"));
        Utils.verifyStatusCode(res, statusCode);

    }
    @Then("Verify the error code {string} and message {string} for perform ckyc")
    public void verify_the_error_code_and_message_for_perform_ckyc(String errorCode, String message) {
        System.out.println(message);
        org.json.JSONObject responseObject = extractJsonObjectFromResponse(res);
        org.json.JSONObject errorFromResponse = extractJsonValueFromJsonArray(responseObject, "errors", 0);
        assertJsonValueEquals( "code",errorCode, errorFromResponse);
        assertJsonValueEquals("message", message,errorFromResponse);
    }




}
