package stepdef.CKYC;

import base.BaseBuilder;

import io.cucumber.java.en.*;
import io.restassured.RestAssured;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.restassured.RestAssured;
import io.restassured.authentication.PreemptiveBasicAuthScheme;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import org.json.simple.JSONObject;
import utilities.*;

import java.io.FileNotFoundException;
import java.util.HashMap;

import static utilities.CommonStepDef.ckycLogin;
import static utilities.CommonStepDef.login;
import static utilities.GlobalConstant.HTTP_OK;
import static utilities.Utils.*;
import static utilities.Utils.getEncryptedAuthData;

public class CKYCSecuredSearch {

    private static Response res;
    private static PropertyReader reader = new PropertyReader();
    private static RequestSpecification reqspec;
    private org.json.JSONObject jsonObject;


    @Given("Login with valid username and password")
    public void login_with_valid_username_and_password() throws FileNotFoundException {
        System.out.println("Login with valid username and password");
        ckycLogin();
    }
    @Given("Enter PAN number to search")
    public void enter_pan_number_to_search() throws FileNotFoundException {
        System.out.println("Enter PAN number to search");
        HashMap<String, Object> enterPanForSearch = JSONPayload.nestedPayloadForCkycSecuredSearch(reader.getValueFromConfig("vc.pan.ckycsecuredsearch"));
        System.out.println(enterPanForSearch);
        reqspec = new BaseBuilder().placeSpecBuilder();
        reqspec = RestAssured.given().spec(reqspec).body(enterPanForSearch);
        res = reqspec.post(GlobalConstant.ckycsecuredsearchloginEndpoint);
        System.out.println(res.asPrettyString());
        if(res.getStatusCode()!=HTTP_OK){
            System.out.println(res.asPrettyString());
        }
        reqspec = RestAssured.given().spec(reqspec).body(enterPanForSearch);
        res = reqspec.post(GlobalConstant.ckycsecuredsearchloginEndpoint);
        System.out.println(res.asPrettyString());
    }


    @Given("Verify the success response upon searching")
    public void verify_the_success_response_upon_searching() {
        Utils.verifyStatusCode(res, HTTP_OK);
    }

    @Then("Response should be valid for secured search")
    public void response_should_be_valid_for_secured_search() {
        System.out.println("Verifying the response for ckyc secured search");
        jsonObject = Utils.extractJsonObjectFromResponse(res);
        System.out.println(jsonObject.toString());
        org.json.JSONObject responseObject = Utils.extractJsonObjectFromResponse(res);
        Utils.jsonSchemaValidator(res, reader.getValueFromConfig("vc.ckycsecuredsearch.schema"));
        assertJsonValueEquals("message","Success", responseObject);
    }

    @Given("I have PAN {string} which needs to be verified")
    public void i_have_pan_which_needs_to_be_verified(String pan) throws FileNotFoundException {
        System.out.println("PAN Verification");
        HashMap<String, Object> panverification = JSONPayload.nestedPayloadForCkycSecuredSearch(pan);
        System.out.println(panverification );
        JSONObject jsonObject = new JSONObject();
        reqspec = new BaseBuilder().placeSpecBuilder();
        ckycLogin();
        reqspec = RestAssured.given().spec(reqspec).body(panverification );
        res = reqspec.post(GlobalConstant.ckycsecuredsearchloginEndpoint).then().extract().response();
        if(res.getStatusCode()!=HTTP_OK){
            System.out.println(res.asPrettyString());
        }
        reqspec = RestAssured.given().spec(reqspec).body(panverification );
        res = reqspec.post(GlobalConstant.ckycsecuredsearchloginEndpoint);
        System.out.println(res.asPrettyString());

    }
    @Then("Response json should be validated for invalid pan and status code should be {int}")
    public void response_json_should_be_validated_for_invalid_pan_and_status_code_should_be(Integer statusCode) {
        System.out.println("Validating the error code for invalid PAN");
        Utils.jsonSchemaValidator(res, reader.getValueFromConfig("vc.errorckycsecuredsearch"));
        Utils.verifyStatusCode(res, statusCode);
    }
    @Then("Verify the error message {string} and code {string}")
    public void verify_the_error_message_and_code(String errorCode , String message) {
        System.out.println(message);
        org.json.JSONObject responseObject = extractJsonObjectFromResponse(res);
        org.json.JSONObject errorFromResponse = extractJsonValueFromJsonArray(responseObject, "errors", 0);
        assertJsonValueEquals( "code",errorCode, errorFromResponse);
        assertJsonValueEquals("message", message,errorFromResponse);
    }

}
