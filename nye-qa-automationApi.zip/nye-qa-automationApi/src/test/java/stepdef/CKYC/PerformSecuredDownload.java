package stepdef.CKYC;

import base.BaseBuilder;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import org.json.simple.JSONObject;
import utilities.GlobalConstant;
import utilities.JSONPayload;
import utilities.PropertyReader;
import utilities.Utils;

import java.io.FileNotFoundException;
import java.util.HashMap;

import static utilities.CommonStepDef.ckycLogin;
import static utilities.GlobalConstant.HTTP_OK;
import static utilities.Utils.*;
import static utilities.Utils.extractJsonValueFromJsonArray;

public class PerformSecuredDownload {

    private static Response res;
    private static PropertyReader reader = new PropertyReader();
    private static RequestSpecification reqspec;
    private org.json.JSONObject jsonObject;

    @Given("Login with valid username and password to download")
    public void login_with_valid_username_and_password_to_download() {
        System.out.println("Login with valid username and password to search user CKYC data");
        ckycLogin();

    }

    @Given("Enter CKYC Number DOB & Pincode with DOB")
    public void enter_ckyc_number_dob_pincode_with_dob() throws FileNotFoundException {
        String ckycNumber = reader.getValueFromConfig("vc.ckycnumber");
        String dateofBirth = reader.getValueFromConfig("vc.dob");
        String pincodewithYearofBirth = reader.getValueFromConfig("vc.pincodewithdateofbirth");
        HashMap<String, Object> enterCkycNumberToDownload = JSONPayload.nestedPayloadForCkycSecuredDownload(ckycNumber, dateofBirth, pincodewithYearofBirth);
        System.out.println("The nested payload for CKYC download " +enterCkycNumberToDownload);
        JSONObject jsonObject = new JSONObject();
        reqspec = new BaseBuilder().placeSpecBuilder();
        reqspec = RestAssured.given().spec(reqspec).body(enterCkycNumberToDownload);
        res = reqspec.post(GlobalConstant.ckycsecureddownloadEndpoint).then().extract().response();
        System.out.println("The response for CKYC download is " + res);
        if(res.getStatusCode()!=HTTP_OK){
            System.out.println(res.asPrettyString());
        }
        reqspec = RestAssured.given().spec(reqspec).body(enterCkycNumberToDownload);
        res = reqspec.post(GlobalConstant.ckycsecureddownloadEndpoint);
        System.out.println(res.asPrettyString());

    }

    @Given("Verify the success response on downloding ckyc data")
    public void verify_the_success_response_on_downloding_ckyc_data() {
        Utils.verifyStatusCode(res, HTTP_OK);
    }

    @Then("Response should be valid for ckyc downloading")
    public void response_should_be_valid_for_ckyc_downloading() {
        System.out.println("Verifying the response for ckyc downloading");
        jsonObject = Utils.extractJsonObjectFromResponse(res);
        System.out.println(jsonObject.toString());
        org.json.JSONObject responseObject = Utils.extractJsonObjectFromResponse(res);
        Utils.jsonSchemaValidator(res, reader.getValueFromConfig("vc.performckycdownloading.schema"));
        assertJsonValueEquals("message","Success", responseObject);
        org.json.JSONObject results = extractNestedJsonObject(responseObject,"results");
        org.json.JSONObject pidData = extractNestedJsonObject(results,"PID_DATA");
        org.json.JSONObject personalDetails = extractNestedJsonObject(pidData,"PERSONAL_DETAILS");
        assertJsonValueEquals("PAN",reader.getValueFromConfig("vc.pan.ckycsecuredsearch"),personalDetails);
        System.out.println();
    }
    @Given("I have ckyc number {string}, date of birth {string}, pincode with year of birth {string} which needs to be verified")
    public void i_have_ckyc_number_date_of_birth_pincode_with_year_of_birth_which_needs_to_be_verified(String ckycnumber, String dob, String pincodewithyearofbirth) throws FileNotFoundException {
            System.out.println("Verifying negative scenarios for perform secured download api");
            HashMap<String, Object> performsecureddownlod = JSONPayload.nestedPayloadForCkycSecuredDownload(ckycnumber,dob,pincodewithyearofbirth);
            System.out.println(performsecureddownlod );
            reqspec = new BaseBuilder().placeSpecBuilder();
            ckycLogin();
            reqspec = RestAssured.given().spec(reqspec).body(performsecureddownlod );
            res = reqspec.post(GlobalConstant.ckycsecureddownloadEndpoint).then().extract().response();
            if(res.getStatusCode()!=HTTP_OK){
                System.out.println(res.asPrettyString());
            }
            System.out.println(res.asPrettyString());

    }

    @Then("Response json should be validated for invalid ckyc number, date of birth & pincode with year of birth and status code should be {int}")
    public void response_json_should_be_validated_for_invalid_ckyc_number_date_of_birth_pincode_with_year_of_birth_and_status_code_should_be(Integer statusCode) {
        System.out.println("Validating the error code for invalid scenarios for performsecureddownload");
        Utils.jsonSchemaValidator(res, reader.getValueFromConfig("vc.errorperformsecureddownload"));
        Utils.verifyStatusCode(res, statusCode);
    }

    @Then("Verify the error code {string} and message {string} for negative scenarios")
    public void verify_the_error_code_and_message_for_negative_scenarios(String errorCode, String message) {
        System.out.println(message);
        org.json.JSONObject responseObject = extractJsonObjectFromResponse(res);
        org.json.JSONObject errorFromResponse = extractJsonValueFromJsonArray(responseObject, "errors", 0);
        assertJsonValueEquals( "code",errorCode, errorFromResponse);
        assertJsonValueEquals("message", message,errorFromResponse);
        RestAssured.reset(); // resetting basic auth
    }







}
